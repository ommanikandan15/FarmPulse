import { SupportedLanguage, FarmAnalysisInput } from '../types';

export interface AskAiResponse {
  answer: string;
  source: 'gemini-3.8-flash' | 'tnau-agri-rules' | 'farmpulse-engine';
  isAiModel: boolean;
  model: string;
  suggestedFollowUps?: string[];
  fieldChecklist?: string[];
}

export interface SuggestedQuestion {
  id: string;
  category: 'water' | 'nutrient' | 'pest' | 'weather' | 'general';
  textEn: string;
  textTa: string;
}

export const SUGGESTED_QUESTIONS: SuggestedQuestion[] = [
  {
    id: 'awd-water',
    category: 'water',
    textEn: 'What should I do if my paddy soil moisture is below 20%?',
    textTa: 'நெல் வயலில் மண் ஈரப்பதம் 20% க்கு கீழ் குறைந்தால் என்ன செய்ய வேண்டும்?',
  },
  {
    id: 'awd-timing',
    category: 'water',
    textEn: 'When should I irrigate during panicle initiation stage?',
    textTa: 'கதிர் உருவாகும் தருணத்தில் பாசன இடைவெளி எவ்வாறு இருக்க வேண்டும்?',
  },
  {
    id: 'blast-mgmt',
    category: 'pest',
    textEn: 'How to manage rice blast disease in cloudy, humid weather?',
    textTa: 'மேகமூட்டம் மற்றும் காற்றில் ஈரப்பதம் அதிகமாக உள்ள போது குலை நோயை எவ்வாறு தடுப்பது?',
  },
  {
    id: 'urea-timing',
    category: 'nutrient',
    textEn: 'When should I apply urea top dressing using Leaf Color Chart (LCC)?',
    textTa: 'இலை வண்ண அட்டை (LCC) அடிப்படையில் யூரியா மேலுரம் எப்போது இட வேண்டும்?',
  },
  {
    id: 'heat-rolling',
    category: 'weather',
    textEn: 'My paddy leaves are rolling up at noon. Is it heat stress or drought?',
    textTa: 'நண்பகலில் நெல் இலைகள் சுருளுகின்றன; இது வெப்ப அழுத்தமா அல்லது நீர் பற்றாக்குறையா?',
  },
  {
    id: 'stem-borer',
    category: 'pest',
    textEn: 'How to control yellow stem borer organically using pheromone traps?',
    textTa: 'இனியூட்டி பொறி (Pheromone trap) கொண்டு தண்டு துளைப்பானை எவ்வாறு இயற்கை முறையில் கட்டுப்படுத்துவது?',
  },
  {
    id: 'soil-salinity',
    category: 'general',
    textEn: 'How to improve saline clay soil for short-duration paddy?',
    textTa: 'களர் நிலத்தில் குறுகிய கால நெல் சாகுபடியை மேம்படுத்துவது எப்படி?',
  },
];

/**
 * Intelligent deterministic Agronomic Engine based on TNAU Crop Production Guide (CPG Paddy)
 */
export function generateLocalAgronomicAnswer(
  query: string,
  language: SupportedLanguage = 'en',
  farmContext?: Partial<FarmAnalysisInput>
): AskAiResponse {
  const q = query.toLowerCase();
  const isTa = language === 'ta';

  // 1. Water / Moisture / Drought / AWD
  if (q.includes('moisture') || q.includes('water') || q.includes('irrigation') || q.includes('drought') || q.includes('ஈரப்பதம்') || q.includes('பாசனம்') || q.includes('நீர்')) {
    if (isTa) {
      return {
        answer: `### நீர் அழுத்த வழிகாட்டல் & தகுந்த மேலாண்மை (TNAU வழிகாட்டி)

**காரணம் (WHY):**
மண் ஈரப்பதம் 20% க்கும் குறைவாக குறையும் போது, நெல் வேர்கள் ஊட்டச்சத்துக்களை உறிஞ்ச சிரமப்படுகின்றன. குறிப்பாக கதிர் உருவாகும் தருணத்தில் (Panicle Initiation) நீர் தட்டுப்பாடு ஏற்பட்டால் 30-40% வரை மகசூல் இழப்பு ஏற்படும் வாய்ப்புள்ளது.

**பரிந்துரைக்கப்பட்ட உடனடி நடவடிக்கைகள் (ACTION):**
1. **களச் சரிபார்ப்பு:** வயலில் 15 செ.மீ துளையிடப்பட்ட பிவிசி (AWD Pani pipe) குழாயை வைத்து நீர் மட்டத்தை அளவிடவும். நீர்மட்டம் தரைக்கு கீழ் 10-15 செ.மீ சென்றால் உடனே 2 அங்குலம் (5 செ.மீ) மட்டும் பாசனம் செய்யவும்.
2. **மாற்று நனைத்தல் மற்றும் உலர்த்துதல் (AWD):** கதிர் பூக்கும் பருவம் தவிர மற்ற நேரங்களில் தொடர்ந்து தேக்கி வைக்காமல், நீர் வடிந்த 1 நாள் கழித்து பாசனம் செய்வது 25-30% நீரை மிச்சப்படுத்தும்.
3. **பூக்கும் பருவம் (Flowering):** பயிர் பூக்கும் நிலையில் இருந்தால் நீர் தட்டுப்பாடு வரக்கூடாது; குறைந்தபட்சம் 2-3 செ.மீ நீர் தொடர்ந்து இருக்குமாறு பார்த்துக்கொள்ளவும்.
4. **இலைவழி தெளிப்பு:** கடும் வறட்சி நிலவினால் 1% பொட்டாசியம் குளோரைடு (KCl) அல்லது பிங்க் பிக்மென்டட் பாக்டீரியா (PPFM) 500 மி.லி/ஏக்கர் தெளிப்பது வறட்சியைத் தாங்க உதவும்.

*குறிப்பு: ரசாயன உரங்களை மண் காய்ந்த நிலையில் இட வேண்டாம்.*`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'AWD பாசன குழாய் அமைப்பது எப்படி?',
          'பூக்கும் பருவத்தில் நீர் மேலாண்மை முறைகள் என்ன?',
          'வறட்சியைத் தாங்கும் PPFM தெளிப்பு முறை என்ன?'
        ],
        fieldChecklist: [
          'வயல் மண்ணை கையில் எடுத்து உருட்டும்போது தூளாக உடைந்து விழுகிறதா என பார்க்கவும்',
          'AWD குழாயில் நீர் மட்டத்தை காலை 8 மணிக்கு அளவிடவும்',
          'வாய்க்கால் கசிவுகளை உடனே அடைத்து நீர் விரயத்தை தவிர்க்கவும்'
        ]
      };
    } else {
      return {
        answer: `### Water Stress & Irrigation Advisory (TNAU / IRRI AWD Protocol)

**Why this matters (The "WHY"):**
When root-zone soil moisture drops below 20%, root hydraulic conductivity declines sharply. If moisture deficit coincides with the panicle initiation or flowering stages, pollen sterility and high spikelet emptiness occur.

**Step-by-step Recommended Action:**
1. **Field Inspection:** Check water depth using a perforated 15 cm field water tube (AWD Pani pipe). If water is 15 cm below soil surface, immediately apply a shallow irrigation depth of 5 cm (2 inches).
2. **Alternate Wetting & Drying (AWD):** Do not keep deep standing water continuously during vegetative stage; allow water to drop to root zone before re-irrigating to promote deeper root growth and save 25-30% irrigation water.
3. **Critical Flowering Stage:** Ensure standing water of 2.5–3 cm is strictly maintained during flowering and grain-filling to prevent chaffy grains.
4. **Stress Alleviation Foliar Spray:** If severe drought spells occur, spray Pink Pigmented Facultative Methylotrophs (PPFM) @ 500 mL/acre or 1% KCl in late afternoon to close stomata and preserve cellular turgor.

*Limitation: Advice is based on standard irrigated lowland paddy. Always check local Palar / Cauvery canal turn schedules.*`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'How to install an AWD Pani pipe?',
          'What is the water requirement during flowering stage?',
          'Can I spray PPFM bio-inoculant during drought?'
        ],
        fieldChecklist: [
          'Perform ball-squeeze soil test: does soil crumble without holding moisture?',
          'Check leaf rolling intensity between 11:30 AM and 2:30 PM',
          'Inspect bunds for rat holes and lateral canal seepage'
        ]
      };
    }
  }

  // 2. Blast / Fungal Disease / Pest
  if (q.includes('blast') || q.includes('disease') || q.includes('pest') || q.includes('fungus') || q.includes('குலை') || q.includes('நோய்') || q.includes('பூச்சி')) {
    if (isTa) {
      return {
        answer: `### நெல் குலை நோய் மற்றும் பூச்சி மேலாண்மை (விரிவான விளக்கம்)

**காரணம் (WHY):**
தொடர் மேகமூட்டம், 85% க்கும் மேற்பட்ட காற்றின் ஈரப்பதம், இரவில் பனிப்பொழிவு மற்றும் தழைச்சத்து (யூரியா) அதிகமாக இடுதல் ஆகியவை நெல் குலை நோய் (Pyricularia oryzae) மற்றும் இலைச்சுருட்டுப் புழு உருவாக ஏதுவான சூழலை உருவாக்குகின்றன.

**களப் பரிசோதனை & பாதுகாப்பு நடவடிக்கைகள்:**
1. **இலை அறிகுறிகள்:** இலைகளில் சுழல் வடிவ (கதிர் வடிவ) சாம்பல் நிற மையமும் பழுப்பு நிற ஓரமும் கொண்ட புள்ளிகள் உள்ளதா எனப் பார்க்கவும்.
2. **உடனடி நடவடிக்கை:**
   - உடனடியாக யூரியா மற்றும் தழைச்சத்து உரங்களை இடுவதை தற்காலிகமாக நிறுத்தவும்.
   - வயலில் அதிகப்படியான நீரை வடித்துவிட்டு புதிய நீரை பாய்ச்சவும்.
3. **இயற்கை & உயிரியல் கட்டுப்பாடு:**
   - சூடோமோனாஸ் புளோரசன்ஸ் (Pseudomonas fluorescens) 10 கிராம்/லிட்டர் அல்லது பேசிலஸ் சப்டிலிஸ் தெளிக்கவும்.
   - வேப்பங்கொட்டை சாறு 5% அல்லது அசாடிராக்டின் 1% காலை அல்லது மாலை வேளையில் தெளிக்கவும்.
4. **வல்லுநர் ஆலோசனை:** 5% க்கும் மேற்பட்ட இலைகளில் புள்ளிகள் தீவிரமாக பரவினால், உங்கள் வட்டார வேளாண்மை விரிவாக்க அலுவலர் (AEO / ADO) பரிந்துரைக்கும் பூஞ்சாணக் கொல்லியைப் பயன்படுத்தவும்.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'குலை நோய்க்கு சூடோமோனாஸ் தெளிக்கும் முறை என்ன?',
          'இலைச்சுருட்டு புழுவிற்கான விளக்குப் பொறி முறை என்ன?',
          'வேப்பங்கொட்டை கரைசல் தயாரிக்கும் முறை என்ன?'
        ],
        fieldChecklist: [
          'கடைசி 5 இலைகளில் சுழல் வடிவ புள்ளிகள் உள்ளதா என பூதக்கண்ணாடி கொண்டு பார்க்கவும்',
          'வயல் வரப்புகளில் உள்ள புல் பூண்டுகளை செதுக்கி களைகளை அகற்றவும்',
          'காலையில் பனித்துளி இலைகளில் அதிக நேரம் தங்குகிறதா என கவனிக்கவும்'
        ]
      };
    } else {
      return {
        answer: `### Blast & Foliar Disease Advisory (Explainable Diagnostics)

**Why this risk arises (The "WHY"):**
Rice blast (*Pyricularia oryzae*) thrives under overcast skies with relative humidity above 85%, prolonged dew periods (>10 hours), and high ambient night moisture. Excessive basal or top-dressed nitrogen fertilizer makes leaf epidermal cells soft and susceptible to fungal hyphae penetration.

**Recommended Tactical Steps:**
1. **Immediate Cultural Action:**
   - Immediately halt any planned Urea/Nitrogen top-dressing until weather clears.
   - Drain stagnant field water and allow aeration for 24 hours if canal water permits.
2. **Biological / Organic Prophylaxis:**
   - Foliar spray of *Pseudomonas fluorescens* liquid formulation @ 2.5 g/L or 1 kg/acre in 200 L water during late afternoon.
   - Neem oil 3% (30 mL/L) with soap emulsifier to deter secondary spore germination.
3. **Physical Monitoring:**
   - Inspect upper 3 leaves for spindle-shaped eye spots with gray center and reddish-brown margins.
   - If >5% leaf area is spotted, immediately invite your local Block Agriculture Extension Officer for an official registered fungicide recommendation.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'How does high nitrogen increase blast susceptibility?',
          'How to prepare neem oil emulsion spray?',
          'What are the symptoms of neck blast vs leaf blast?'
        ],
        fieldChecklist: [
          'Examine spindle lesion centers on 20 random hills',
          'Confirm whether morning dew remains on leaves past 9:30 AM',
          'Ensure weed hosts along field bunds (Leersia hexandra) are cleared'
        ]
      };
    }
  }

  // 3. Fertilizer / Nutrient / Urea / LCC
  if (q.includes('urea') || q.includes('fertilizer') || q.includes('nutrient') || q.includes('lcc') || q.includes('nitrogen') || q.includes('உரம்') || q.includes('யூரியா') || q.includes('ஊட்டச்சத்து')) {
    if (isTa) {
      return {
        answer: `### ஊட்டச்சத்து & யூரியா மேலுர மேலாண்மை (இலை வண்ண அட்டை முறை)

**காரணம் (WHY):**
ஒரே நேரத்தில் அதிகப்படியான யூரியாவை இடுவதால் 50% தழைச்சத்து ஆவியாகவும், நிலத்தடி நீரில் கரைந்தும் வீணாகிறது. மேலும் பயிரில் பூச்சி மற்றும் நோய் தாக்குதலை அதிகரிக்கிறது.

**பரிந்துரைக்கப்படும் அறிவியல் முறை:**
1. **இலை வண்ண அட்டை (LCC):**
   - காலை 9-11 மணிக்குள், சூரிய ஒளிக்கு முதுகை காட்டி நின்று, பயிரின் முழுமையாக விரிந்த மூன்றாவது இலையின் நடுப்பகுதியை LCC அட்டையுடன் ஒப்பிடவும்.
   - அட்டை நிறம் 4 க்கும் குறைவாக இருந்தால் மட்டுமே ஏக்கருக்கு 15-20 கிலோ யூரியா மேலுரமாக இட வேண்டும்.
   - அட்டை நிறம் 4 அல்லது அதற்கு மேல் இருந்தால் உரம் தேவையில்லை.
2. **பிரித்து இடுதல்:**
   - தழைச்சத்தை நட்ட 15-20 நாள் (தூர்கட்டும் பருவம்), 35-40 நாள் (கதிர் உருவாகும் தருணம்), மற்றும் 55-60 நாள் (பூக்கும் முன்) என மூன்று தவணைகளாக பிரித்து இடவும்.
3. **ஜிப்சம் & வேப்பங்கொட்டை பொடி கலவை:**
   - 100 கிலோ யூரியாவுடன் 20 கிலோ வேப்பங்கொட்டை பொடி கலந்து ஒரு இரவு வைத்திருந்து இடுவதன் மூலம் தழைச்சத்து மெதுவாக பயிருக்கு கிடைக்கும்.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'இலை வண்ண அட்டை (LCC) எங்கு கிடைக்கும்?',
          'வேப்பம்பிண்ணாக்கு கலந்த யூரியா தயாரிப்பது எப்படி?',
          'நெற்பயிருக்கு நுண்ணூட்டச் சத்து கலவை தெளிக்கும் முறை என்ன?'
        ],
        fieldChecklist: [
          'வயலின் 10 இடங்களில் உள்ள சீரான பயிர்களை LCC அட்டையுடன் ஒப்பிடவும்',
          'உரம் இடும் முன் வயலில் அதிக நீரை வடித்து, மெல்லிய ஈரப்பதம் மட்டும் வைக்கவும்'
        ]
      };
    } else {
      return {
        answer: `### Explainable Nutrient & Urea Optimization (TNAU Leaf Color Chart Guide)

**Why calibrated application is crucial (The "WHY"):**
Applying nitrogen in bulk results in up to 50% volatilization loss as ammonia gas and groundwater leaching. Excess succulent vegetative growth also weakens the silica layer of rice leaf sheaths, inviting yellow stem borer and blast.

**Actionable Scientific Protocol:**
1. **Leaf Color Chart (LCC) Calibration:**
   - Between 9:00 AM and 11:00 AM, face away from direct sun.
   - Measure the middle portion of the topmost fully expanded leaf on 10 random hills.
   - If average shade is **below Critical Value 4**, apply 15–20 kg Urea per acre.
   - If shade is **4 or darker**, skip top-dressing; nitrogen reserve is sufficient.
2. **Split Application Schedule:**
   - Basal (25%), Active Tillering (25%), Panicle Initiation (30%), and Heading (20%).
3. **Neem-Coated Slow Release Technique:**
   - Blend 100 kg Urea with 20 kg powdered neem cake or 500 mL neem oil. Keep overnight before broadcast to slow nitrification and boost efficiency by 20%.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'How does the 4-panel Leaf Color Chart work?',
          'How to treat zinc deficiency in calcareous soils?',
          'What is the ideal N-P-K ratio for short duration paddy?'
        ],
        fieldChecklist: [
          'Test 10 representative hills across diagonal of field',
          'Drain field to a thin film before broadcasting top-dressing to prevent runoff'
        ]
      };
    }
  }

  // 4. Heat / Temperature / Noon Leaf Rolling
  if (q.includes('heat') || q.includes('temperature') || q.includes('rolling') || q.includes('sun') || q.includes('வெப்பம்') || q.includes('சுருளல்') || q.includes('வெயில்')) {
    if (isTa) {
      return {
        answer: `### வெப்ப அழுத்தம் & இலை சுருளுதல் தீர்வு

**காரணம் (WHY):**
பகல் வெப்பநிலை 35°C ஐத் தாண்டும் போது, இலைகளின் நீராவிப்போக்கு வேர்களின் நீர் உறிஞ்சும் வேகத்தை விட அதிகமாகிறது. நீரிழப்பைத் தடுக்க பயிர் தனது இலைகளை ஊசி போல் சுருட்டிக் கொள்கிறது. 

**எப்போது எச்சரிக்கை தேவை?**
- நண்பகலில் (12 - 2 PM) சுருண்டு, மாலை 5 மணிக்கு இயல்பு நிலைக்கு திரும்பினால் அது தற்காலிக வெப்ப பாதுகாப்பு.
- ஆனால் மாலை மற்றும் காலையிலும் இலைகள் சுருண்டே இருந்தால் அது கடுமையான வறட்சி அல்லது வேர் அழுகல் அறிகுறி.

**மேலாண்மை:**
1. வயலில் மதிய வேளையில் 2-3 செ.மீ நீர் இருக்குமாறு பார்த்துக்கொள்ளவும் (நீர் குளிரூட்டும் அமைப்பாக செயல்படும்).
2. மாலை வேளையில் 0.5% பொட்டாசியம் சல்பேட் தெளிப்பது இலைகளின் நீர் தக்கவைப்பை அதிகரிக்கும்.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'நண்பகல் இலை சுருளலுக்கும் வறட்சிக்கும் உள்ள வித்தியாசம் என்ன?',
          'வெப்பத்தால் மகரந்தச் சேர்க்கை பாதிக்கப்படுமா?'
        ],
        fieldChecklist: [
          'மாலை 5:30 மணிக்கு மீண்டும் இலைகளை பரிசோதிக்கவும்: விரிந்துள்ளதா?',
          'மண்ணை தோண்டி வேர்கள் வெள்ளையாக ஆரோக்கியமாக உள்ளதா என சரிபார்க்கவும்'
        ]
      };
    } else {
      return {
        answer: `### Heat Stress & Mid-day Leaf Rolling Diagnostic

**Why leaves roll at noon (The "WHY"):**
When ambient temperatures exceed 35°C and relative humidity drops, transpirational pull exceeds root water uptake. Rice plants curl their leaf blades into needle shapes to minimize solar radiation absorption and reduce water loss.

**How to distinguish temporary heat defense vs true water deficit:**
- **Reversible Heat Defense:** Leaves curl between 12:00 PM and 2:30 PM, but fully unroll and flatten by 5:30 PM.
- **True Severe Moisture Stress:** Leaves remain tightly rolled into the evening, indicating root depletion below permanent wilting point.

**Protective Actions:**
1. **Evaporative Cooling:** Maintain a thin 2–3 cm water layer during heatwaves; water evaporation lowers canopy microclimate temperature by 2–3°C.
2. **Osmolyte Spray:** Apply 1% Potassium chloride (KCl) or PPFM foliar spray to strengthen stomatal regulation.`,
        source: 'tnau-agri-rules',
        isAiModel: false,
        model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
        suggestedFollowUps: [
          'Does temperature above 35°C cause spikelet sterility?',
          'What micro-irrigation works best for heat mitigation in paddy?'
        ],
        fieldChecklist: [
          'Inspect leaf rolling status at 5:30 PM to verify recovery',
          'Measure root depth: check for dark root discoloration or hardpan blockage'
        ]
      };
    }
  }

  // 5. Default General Farm Advisory
  if (isTa) {
    return {
      answer: `### FarmPulse வேளாண் AI ஆலோசனைக் குறிப்பு

உங்கள் கேள்வி "${query}" பரிசீலிக்கப்பட்டது.

**முக்கிய வேளாண் நடைமுறைகள்:**
1. **மண் மற்றும் பயிர் நிலை:** பயிரின் வளர்ச்சிப் பருவம் (தூர்கட்டுதல், கதிர் உருவாக்கம், பூத்தல்) மற்றும் மண் ஈரப்பதத்தை தொடர்ந்து கண்காணிக்கவும்.
2. **நீர் சேமிப்பு:** தொடர்ந்து தேக்கி வைக்காமல் மாற்று நனைத்தல் மற்றும் உலர்த்துதல் (AWD) முறையை கடைப்பிடிக்கவும்.
3. **ரசாயனத் தெளிப்புக்கு முன்:** உயிரியல் கட்டுப்பாட்டு காரணிகள் (ட்ரைக்கோடெர்மா, சூடோமோனாஸ், வேப்ப எண்ணெய்) மற்றும் தகுந்த விளக்குப் பொறிகளை முதலில் பயன்படுத்தவும்.
4. **வட்டார உதவி:** கூடுதல் களப் பரிசோதனைக்கு அருகில் உள்ள உழவர் மையத்தை (KVK) அல்லது வேளாண்மை அலுவலரை அணுகவும்.`,
      source: 'tnau-agri-rules',
      isAiModel: false,
      model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
      suggestedFollowUps: [
        'மண் ஈரப்பதம் 20% க்கு கீழ் குறைந்தால் என்ன செய்வது?',
        'நெல் குலை நோயை எவ்வாறு தடுப்பது?',
        'இலை வண்ண அட்டை அடிப்படையில் யூரியா இடுவது எப்படி?'
      ],
      fieldChecklist: [
        'களத்தில் பயிரின் வேர் மற்றும் இலை அடிப் பகுதியை நேரடியாக பரிசோதிக்கவும்'
      ]
    };
  }

  return {
    answer: `### FarmPulse Agronomic Intelligence Advisory

Regarding your question: "${query}"

**Fundamental Agronomic Principles (TNAU & IRRI Guidelines):**
1. **Root-zone Monitoring:** Observe soil moisture trends alongside leaf visual health before any major chemical intervention.
2. **Explainable Action:** Match farm practices to exact growth stages (tillering vs panicle initiation vs grain filling).
3. **Biological First:** Prioritize cultural sanitation, field bund clearing, and bio-inoculants (Pseudomonas, Trichoderma, neem formulations) before synthetic agrochemicals.
4. **Expert Escalation:** For complex soil salinity or persistent pest attacks, consult your local Krishi Vigyan Kendra (KVK) or Block Agriculture Officer (ADO).`,
    source: 'tnau-agri-rules',
    isAiModel: false,
    model: 'FarmPulse Agronomic Knowledge Engine (TNAU CPG)',
    suggestedFollowUps: [
      'What should I do if paddy soil moisture drops below 20%?',
      'How to identify rice blast vs brown spot?',
      'How does the Leaf Color Chart save nitrogen cost?'
    ],
    fieldChecklist: [
      'Conduct a morning field walk inspecting the bottom stems and leaf undersides'
    ]
  };
}

/**
 * Ask AI function: Queries server endpoint `/api/ask-ai` first, falls back gracefully to local engine
 */
export async function askAgriAi(
  question: string,
  language: SupportedLanguage = 'en',
  farmContext?: Partial<FarmAnalysisInput>
): Promise<AskAiResponse> {
  try {
    const res = await fetch('/api/ask-ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, language, farmContext }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.answer) {
        return {
          answer: data.answer,
          source: data.source || 'gemini-3.8-flash',
          isAiModel: Boolean(data.isAiModel),
          model: data.model || 'gemini-3.8-flash',
          suggestedFollowUps: data.suggestedFollowUps || [
            language === 'ta' ? 'அடுத்த கட்ட களப் பரிசோதனை என்ன?' : 'What is the recommended field verification?',
            language === 'ta' ? 'நீர் மேலாண்மை முறை என்ன?' : 'How does this affect water scheduling?'
          ],
        };
      }
    }
  } catch {
    // If backend endpoint is unreachable or not yet booted, fall through
  }

  // Deterministic local agronomic response
  return generateLocalAgronomicAnswer(question, language, farmContext);
}
