import React from 'react';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface VoicePlayerButtonProps {
  textToRead: string;
  className?: string;
  size?: 'sm' | 'md';
}

export const VoicePlayerButton: React.FC<VoicePlayerButtonProps> = ({
  textToRead,
  className = '',
  size = 'md',
}) => {
  const { isSpeaking, speakText, stopSpeaking, speechSupported, t, language } = useApp();

  if (!speechSupported) {
    return null;
  }

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speakText(textToRead);
    }
  };

  const buttonClass = size === 'sm' 
    ? 'px-2.5 py-1 text-xs' 
    : 'px-3 py-1.5 text-xs sm:text-sm';

  return (
    <button
      onClick={handleToggle}
      className={`inline-flex items-center gap-1.5 font-medium rounded-lg transition-all border ${
        isSpeaking
          ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse'
          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
      } ${buttonClass} ${className}`}
      title={isSpeaking ? t.stopAudio : t.readAloud}
      aria-label={isSpeaking ? t.stopAudio : t.readAloud}
    >
      {isSpeaking ? (
        <>
          <VolumeX className="w-3.5 h-3.5 text-amber-700" />
          <span>{t.stopAudio}</span>
        </>
      ) : (
        <>
          <Volume2 className="w-3.5 h-3.5 text-emerald-700" />
          <span>{t.readAloud}</span>
          <span className="text-[10px] px-1 py-0.2 rounded bg-emerald-200/60 font-mono uppercase tracking-wider text-emerald-800">
            {language.toUpperCase()}
          </span>
        </>
      )}
    </button>
  );
};
