import React, { useState } from 'react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow, 
  useMap 
} from '@vis.gl/react-google-maps';
import { Plot } from '../../types';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import { 
  Layers, 
  Compass, 
  Maximize2, 
  Minimize2, 
  Eye, 
  MapPin, 
  ArrowUpRight, 
  Info,
  ShieldAlert,
  Sprout
} from 'lucide-react';
import { getCropInfo } from '../../data/cropLandData';

interface GoogleMapsOverviewProps {
  plots: Plot[];
  selectedPlotId: string;
  onSelectPlot: (plot: Plot) => void;
  onOpenPlotDetail: (plot: Plot) => void;
  onToggleToSchematic: () => void;
}

export const GoogleMapsOverview: React.FC<GoogleMapsOverviewProps> = ({
  plots,
  selectedPlotId,
  onSelectPlot,
  onOpenPlotDetail,
  onToggleToSchematic,
}) => {
  const { t, language, formatArea, formatTemp, setActiveTab } = useApp();

  const [mapType, setMapType] = useState<'satellite' | 'hybrid' | 'roadmap'>('hybrid');
  const [activeInfoWindowPlot, setActiveInfoWindowPlot] = useState<Plot | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const apiKey = (import.meta as unknown as { env: Record<string, string> }).env?.VITE_GOOGLE_MAPS_API_KEY || 
                 'AIzaSyAG2GcmSByW4dTJeWukaabUChbBAhaQFEk';

  // Kaveripakkam center
  const defaultCenter = { lat: 12.9015, lng: 79.4685 };

  const getPinColors = (risk: string) => {
    switch (risk) {
      case 'high':
        return { background: '#DC2626', borderColor: '#991B1B', glyphColor: '#FFFFFF' };
      case 'watch':
        return { background: '#D97706', borderColor: '#92400E', glyphColor: '#FFFFFF' };
      default:
        return { background: '#2D8A4E', borderColor: '#1B6336', glyphColor: '#FFFFFF' };
    }
  };

  return (
    <div className={`bg-white rounded-2xl border border-[#E3E8DC] shadow-xs overflow-hidden transition-all ${
      isFullscreen ? 'fixed inset-4 z-50 flex flex-col' : 'relative p-5'
    }`}>
      {/* Map Card Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E3E8DC]">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-base text-[#173F35]">
              {t.fieldHealthOverview}
            </h3>
            <span className="text-[10px] font-semibold bg-blue-100 text-blue-800 px-2 py-0.5 rounded border border-blue-300">
              Google Maps
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-0.5 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#4E9B5F] shrink-0" />
            <span>{t.illustrativeMapNote}</span>
          </p>
        </div>

        {/* Map Type & View Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Map Type (Satellite / Hybrid / Roadmap) */}
          <div className="flex items-center rounded-lg border border-[#E3E8DC] p-0.5 bg-[#F7F8F4] text-xs">
            <button
              onClick={() => setMapType('hybrid')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                mapType === 'hybrid'
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
            >
              {t.mapViewHybrid}
            </button>
            <button
              onClick={() => setMapType('satellite')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                mapType === 'satellite'
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
            >
              {t.mapViewSatellite}
            </button>
            <button
              onClick={() => setMapType('roadmap')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                mapType === 'roadmap'
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
            >
              {t.mapViewRoadmap}
            </button>
          </div>

          {/* Toggle to Schematic Map */}
          <button
            onClick={onToggleToSchematic}
            className="px-2.5 py-1 rounded-lg border border-[#E3E8DC] bg-[#F7F8F4] hover:bg-white text-xs font-semibold text-[#566761] hover:text-[#173F35] transition-colors"
            title={t.mapToggleSchematic}
          >
            {t.mapToggleSchematic}
          </button>

          {/* Jump to Field & Place Map */}
          <button
            onClick={() => setActiveTab('fieldmap')}
            className="px-2.5 py-1 rounded-lg bg-[#173F35] hover:bg-[#255e50] text-white text-xs font-bold transition-colors shadow-xs flex items-center gap-1"
            title="Open Field & Place Map to search any place"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-300" />
            <span>{language === 'ta' ? 'இடம் தேடல்' : 'Know Place'}</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-lg border border-[#E3E8DC] bg-[#F7F8F4] hover:bg-white text-[#566761] hover:text-[#173F35] transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Expand Map'}
            aria-label="Toggle Fullscreen Map"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Google Map Container */}
      <div className={`mt-4 rounded-xl overflow-hidden border border-[#E3E8DC] relative ${
        isFullscreen ? 'flex-1 min-h-0' : 'h-[440px]'
      }`}>
        <APIProvider apiKey={apiKey}>
          <Map
            mapId="FARM_PULSE_PILOT_MAP"
            defaultCenter={defaultCenter}
            defaultZoom={15}
            mapTypeId={mapType}
            gestureHandling="cooperative"
            disableDefaultUI={false}
            className="w-full h-full"
          >
            {/* Interactive Advanced Markers for each Plot */}
            {plots.map((plot) => {
              const isSelected = plot.id === selectedPlotId;
              const pinStyle = getPinColors(plot.advisory.riskLevel);
              const crop = getCropInfo(plot.variety || plot.cropType);

              return (
                <AdvancedMarker
                  key={plot.id}
                  position={{ lat: plot.coordinates.lat, lng: plot.coordinates.lng }}
                  onClick={() => {
                    onSelectPlot(plot);
                    setActiveInfoWindowPlot(plot);
                  }}
                  title={language === 'ta' ? plot.nameTa : plot.name}
                >
                  <div className="relative group cursor-pointer transition-transform hover:scale-110">
                    <Pin
                      background={pinStyle.background}
                      borderColor={pinStyle.borderColor}
                      glyphColor={pinStyle.glyphColor}
                      scale={isSelected ? 1.3 : 1.1}
                    />
                    {/* Hover label pill */}
                    <div className="absolute left-1/2 -translate-x-1/2 -top-6 whitespace-nowrap bg-black/85 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-md pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      <span>{crop.emoji}</span>
                      <span>{language === 'te' && plot.nameTe ? plot.nameTe : language === 'ta' ? plot.nameTa : plot.name}</span>
                    </div>
                  </div>
                </AdvancedMarker>
              );
            })}

            {/* InfoWindow for Clicked Plot */}
            {activeInfoWindowPlot && (
              <InfoWindow
                position={{
                  lat: activeInfoWindowPlot.coordinates.lat + 0.0008,
                  lng: activeInfoWindowPlot.coordinates.lng,
                }}
                onCloseClick={() => setActiveInfoWindowPlot(null)}
              >
                <div className="p-2 max-w-[270px] text-[#1C2723] space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2">
                      <span className="text-2xl p-1 rounded-lg bg-emerald-50 border border-emerald-200">
                        {getCropInfo(activeInfoWindowPlot.variety || activeInfoWindowPlot.cropType).emoji}
                      </span>
                      <div>
                        <div className="flex items-center gap-1 flex-wrap">
                          <span className="text-[10px] font-mono font-bold text-[#83948E]">
                            #{activeInfoWindowPlot.id.toUpperCase()}
                          </span>
                          {activeInfoWindowPlot.surveyNumber && (
                            <span className="text-[9px] bg-gray-100 text-gray-700 font-bold px-1 py-0.2 rounded">
                              {activeInfoWindowPlot.surveyNumber}
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-xs sm:text-sm text-[#173F35]">
                          {language === 'te' && activeInfoWindowPlot.nameTe ? activeInfoWindowPlot.nameTe : language === 'ta' ? activeInfoWindowPlot.nameTa : activeInfoWindowPlot.name}
                        </h4>
                        <p className="text-[11px] text-emerald-800 font-semibold">
                          {activeInfoWindowPlot.variety} • {formatArea(activeInfoWindowPlot.areaAcres)}
                        </p>
                      </div>
                    </div>
                    <StatusBadge level={activeInfoWindowPlot.advisory.riskLevel} size="sm" />
                  </div>

                  {/* Ground Observations */}
                  <div className="grid grid-cols-2 gap-1.5 p-2 bg-stone-50 rounded-lg text-[10px] border border-stone-200">
                    <div>
                      <span className="text-stone-500 block">Soil Moisture:</span>
                      <strong className={`font-bold ${activeInfoWindowPlot.latestObservation.soilMoisturePercent < 20 ? 'text-rose-600' : 'text-stone-900'}`}>
                        {activeInfoWindowPlot.latestObservation.soilMoisturePercent}%
                      </strong>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Rain-free:</span>
                      <strong className="font-bold text-stone-900">
                        {activeInfoWindowPlot.latestObservation.daysWithoutRain} days
                      </strong>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Greenness:</span>
                      <strong className={`font-bold ${activeInfoWindowPlot.latestObservation.weeklyGreennessChangePercent <= -12 ? 'text-rose-600' : 'text-stone-900'}`}>
                        {activeInfoWindowPlot.latestObservation.weeklyGreennessChangePercent}%
                      </strong>
                    </div>
                    <div>
                      <span className="text-stone-500 block">Temp:</span>
                      <strong className="font-bold text-stone-900">
                        {formatTemp(activeInfoWindowPlot.latestObservation.temperatureCelsius)}
                      </strong>
                    </div>
                  </div>

                  {/* Primary Action Guidance */}
                  <div className="text-[10px] text-amber-900 bg-amber-50 p-1.5 rounded border border-amber-200 leading-tight">
                    <span className="font-bold block text-amber-950">Action:</span>
                    {language === 'ta' ? activeInfoWindowPlot.advisory.primaryActionTa : activeInfoWindowPlot.advisory.primaryAction}
                  </div>

                  <button
                    onClick={() => onOpenPlotDetail(activeInfoWindowPlot)}
                    className="w-full py-1.5 px-2 bg-[#173F35] text-white rounded text-[11px] font-bold hover:bg-[#1E4D41] flex items-center justify-center gap-1 transition-colors"
                  >
                    <span>{t.viewPlotDetails}</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </InfoWindow>
            )}
          </Map>
        </APIProvider>

        {/* Legend Overlay on Map */}
        <div className="absolute bottom-4 left-4 z-10 bg-white/95 backdrop-blur-md px-3 py-2 rounded-xl shadow-md border border-[#E3E8DC] text-xs space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#566761] block">
            Plot Stress Legend
          </span>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2D8A4E]" />
              <span className="text-[11px] text-[#566761]">{t.riskLow}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D97706]" />
              <span className="text-[11px] text-[#566761]">{t.riskWatch}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626]" />
              <span className="text-[11px] text-[#566761]">{t.riskHigh}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
