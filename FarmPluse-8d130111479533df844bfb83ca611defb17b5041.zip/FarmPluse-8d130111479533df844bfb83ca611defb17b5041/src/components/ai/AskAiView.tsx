import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { askAgriAi, SUGGESTED_QUESTIONS, AskAiResponse } from '../../services/agriAiAssistant';
import { 
  Bot, 
  Send, 
  Sparkles, 
  HelpCircle, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  CheckCircle2, 
  ShieldAlert, 
  Sprout, 
  Droplets, 
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  Flame,
  MessageSquare
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  meta?: AskAiResponse;
}

export const AskAiView: React.FC = () => {
  const { t, language, activeAnalysis, speakText, stopSpeaking, isSpeaking } = useApp();

  const [inputQuestion, setInputQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-0',
      sender: 'ai',
      text: language === 'ta'
        ? `வணக்கம்! நான் FarmPulse வேளாண் AI உதவியாளர். உங்கள் நெல் மற்றும் பயிர் சாகுபடி, மண் ஈரப்பதம், மாற்று நனைத்தல் முறை (AWD), இலை சுருளல், உரம் மற்றும் பூச்சி மேலாண்மை குறித்த கேள்விகளை தமிழில் கேட்கலாம்.`
        : `Vanakkam! I am your FarmPulse Agri AI Copilot. Ask me anything about your crop health, AWD irrigation schedules, blast risk, Leaf Color Chart fertilizer timing, or heat stress mitigation.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      meta: {
        answer: '',
        source: 'farmpulse-engine',
        isAiModel: true,
        model: 'Gemini 3.8 Flash & TNAU Agronomic Rules',
        suggestedFollowUps: [
          language === 'ta' ? 'மண் ஈரப்பதம் 20% க்கு கீழ் குறைந்தால் என்ன செய்வது?' : 'What to do if paddy soil moisture is below 20%?',
          language === 'ta' ? 'குலை நோய் வராமல் தடுக்க என்ன வழி?' : 'How to prevent rice blast in cloudy weather?',
        ],
      },
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (queryText?: string) => {
    const textToSend = (queryText || inputQuestion).trim();
    if (!textToSend || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuestion('');
    setLoading(true);

    try {
      const moistureEvidence = activeAnalysis?.advisory?.evidenceList?.find(
        (e) => e.category === 'moisture'
      );
      const parsedMoisture = moistureEvidence ? parseFloat(moistureEvidence.inputValue) : undefined;
      const farmContext = activeAnalysis ? {
        farmName: activeAnalysis.farmName,
        location: activeAnalysis.location,
        cropType: activeAnalysis.cropType,
        growthStage: activeAnalysis.growthStage,
        soilMoisturePercent: typeof parsedMoisture === 'number' && !isNaN(parsedMoisture) ? parsedMoisture : undefined,
      } : undefined;

      const response = await askAgriAi(textToSend, language, farmContext);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: response.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        meta: response,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      const errorMsg: ChatMessage = {
        id: `ai-err-${Date.now()}`,
        sender: 'ai',
        text: language === 'ta'
          ? 'மன்னிக்கவும், பதிலை பெறுவதில் பிழை ஏற்பட்டது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.'
          : 'Sorry, could not retrieve advisory response at this moment. Please try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleResetChat = () => {
    stopSpeaking();
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        sender: 'ai',
        text: language === 'ta'
          ? 'புதிய உரையாடல் துவக்கப்பட்டது. உங்கள் விவசாயக் கேள்விகளைக் கேட்கலாம்.'
          : 'Conversation restarted. Ask any agricultural question for explainable advice.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        meta: {
          answer: '',
          source: 'farmpulse-engine',
          isAiModel: true,
          model: 'Gemini 3.8 Flash',
        },
      },
    ]);
  };

  return (
    <div className="space-y-4 pb-12 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#173F35] to-[#2D8A4E] text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35] flex items-center gap-2">
                {language === 'ta' ? 'வேளாண் AI உதவியாளர் (Ask AI)' : 'Agri AI Copilot (Ask AI)'}
              </h1>
              <p className="text-xs text-[#566761] mt-0.5">
                {language === 'ta' 
                  ? 'விவசாயிகளுக்கு விளக்கக்கூடிய ஆலோசனைகள் — "என்ன செய்ய வேண்டும் என்பதுடன் ஏன் செய்ய வேண்டும் என்பதையும் கூறுங்கள்"' 
                  : 'Explainable, science-backed guidance powered by Gemini 3.8 Flash & TNAU agronomic guidelines.'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleResetChat}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#566761] hover:text-[#173F35] bg-[#F7F8F4] hover:bg-gray-100 rounded-lg border border-[#E3E8DC] transition-all"
            title="Reset conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'அழித்து புதிதாக்கு' : 'Reset Chat'}</span>
          </button>
        </div>
      </div>

      {/* Farm Context Indicator (If available) */}
      {activeAnalysis && (
        <div className="bg-emerald-50/80 border border-emerald-200/90 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-900 font-medium">
            <Sprout className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>{language === 'ta' ? 'இணைக்கப்பட்ட வயல்:' : 'Connected Farm:'}</strong> {activeAnalysis.farmName} ({activeAnalysis.cropType})
            </span>
            <span className="text-emerald-700 font-bold">•</span>
            <span>{activeAnalysis.growthStage}</span>
            <span className="text-emerald-700 font-bold">•</span>
            <span className="capitalize">{activeAnalysis.overallRisk} risk</span>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded">
            {language === 'ta' ? 'நேரலை சூழல் இயக்கம்' : 'Context-Aware AI'}
          </span>
        </div>
      )}

      {/* Suggested Questions Grid */}
      <div className="bg-white p-4 rounded-2xl border border-[#E3E8DC] shadow-xs">
        <div className="flex items-center gap-2 mb-2.5">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <span className="text-xs font-bold text-[#173F35] uppercase tracking-wider">
            {language === 'ta' ? 'பரிந்துரைக்கப்பட்ட விவசாயக் கேள்விகள் (ஒரு கிளிக்கில் கேட்கலாம்):' : 'Suggested Agricultural Questions (Click to Ask):'}
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_QUESTIONS.map((sq) => (
            <button
              key={sq.id}
              onClick={() => handleSend(language === 'ta' ? sq.textTa : sq.textEn)}
              disabled={loading}
              className="text-left text-xs bg-[#F7F8F4] hover:bg-emerald-50 hover:border-emerald-300 border border-[#E3E8DC] text-[#173F35] px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 group disabled:opacity-50"
            >
              <span>{language === 'ta' ? sq.textTa : sq.textEn}</span>
              <ArrowRight className="w-3 h-3 text-[#566761] group-hover:text-emerald-700 transition-transform group-hover:translate-x-0.5 shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="bg-white rounded-2xl border border-[#E3E8DC] shadow-xs p-4 sm:p-5 min-h-[420px] max-h-[560px] overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'ai' && (
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                <Bot className="w-4 h-4 text-emerald-400" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-[#173F35] text-white rounded-br-xs'
                  : 'bg-[#F7F8F4] text-[#1C2723] border border-[#E3E8DC] rounded-bl-xs'
              }`}
            >
              <div className="flex items-center justify-between gap-3 mb-2 pb-1 border-b border-black/5 dark:border-white/10">
                <span className="font-bold text-[11px] opacity-75">
                  {msg.sender === 'user' 
                    ? (language === 'ta' ? 'விவசாயி' : 'Farmer') 
                    : (language === 'ta' ? 'FarmPulse வேளாண் AI' : 'FarmPulse Agri Copilot')}
                </span>
                <span className="text-[10px] opacity-60">{msg.timestamp}</span>
              </div>

              {/* Message Content */}
              <div className="whitespace-pre-line font-normal space-y-2">
                {msg.text}
              </div>

              {/* Model & Voice Bar for AI answers */}
              {msg.sender === 'ai' && msg.text && (
                <div className="mt-3 pt-3 border-t border-[#E3E8DC] flex flex-wrap items-center justify-between gap-2 text-[11px]">
                  <div className="flex items-center gap-1.5 text-[#566761]">
                    <span className="font-medium bg-white px-2 py-0.5 rounded border border-[#E3E8DC] text-[10px]">
                      {msg.meta?.model || 'Gemini 3.8 Flash'}
                    </span>
                    <span className="text-emerald-700 font-semibold text-[10px]">
                      {msg.meta?.source === 'gemini-3.8-flash' ? '• Server AI Model' : '• TNAU Rules'}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      if (isSpeaking) {
                        stopSpeaking();
                      } else {
                        speakText(msg.text);
                      }
                    }}
                    className="flex items-center gap-1.5 text-[#173F35] font-semibold bg-white hover:bg-emerald-50 px-2.5 py-1 rounded-lg border border-[#E3E8DC] transition-all text-xs"
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                        <span>{t.stopAudio}</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{t.readAloud}</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* Suggested Followups */}
              {msg.sender === 'ai' && msg.meta?.suggestedFollowUps && msg.meta.suggestedFollowUps.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-dashed border-[#E3E8DC]">
                  <p className="text-[10px] font-bold text-[#566761] uppercase tracking-wider mb-1.5">
                    {language === 'ta' ? 'தொடர்புடைய அடுத்த கேள்விகள்:' : 'Follow-up Questions:'}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.meta.suggestedFollowUps.map((fu, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSend(fu)}
                        disabled={loading}
                        className="text-[11px] bg-white hover:bg-emerald-100/70 border border-[#CCD6C6] text-[#173F35] px-2.5 py-1 rounded-lg transition-all"
                      >
                        {fu}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {msg.sender === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                <MessageSquare className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3 justify-start items-center text-xs text-[#566761]">
            <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-emerald-400 animate-pulse" />
            </div>
            <div className="bg-[#F7F8F4] border border-[#E3E8DC] rounded-2xl px-4 py-3 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" />
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.2s]" />
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.4s]" />
              <span className="ml-2 font-medium">
                {language === 'ta' ? 'விளக்கக்கூடிய ஆலோசனையை உருவாக்குகிறது...' : 'Generating explainable advisory...'}
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Question Input Box */}
      <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-[#E3E8DC] shadow-xs">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputQuestion}
            onChange={(e) => setInputQuestion(e.target.value)}
            placeholder={
              language === 'ta'
                ? 'உங்கள் விவசாயக் கேள்வியை இங்கே தட்டச்சு செய்யவும் (எ.கா: யூரியா எப்போது இட வேண்டும்?)...'
                : 'Ask anything about crop water stress, fertilizer timing, or pest risks...'
            }
            className="flex-1 px-4 py-3 text-xs sm:text-sm rounded-xl border border-[#CCD6C6] focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] focus:border-transparent bg-[#FAFAF8]"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={!inputQuestion.trim() || loading}
            className="px-4 sm:px-6 py-3 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs transition-all disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          >
            <span>{language === 'ta' ? 'கேட்க' : 'Ask AI'}</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
        <div className="flex items-center justify-between text-[11px] text-[#566761] mt-2 px-1">
          <span>
            {language === 'ta' ? 'ஆதாரம்: TNAU CPG வழிகாட்டுதல்கள் மற்றும் ஜெமினி 3.8 AI' : 'Grounding: TNAU CPG Guidelines & Gemini 3.8 Flash'}
          </span>
          <span className="hidden sm:inline">
            {language === 'ta' ? 'ரசாயன மருந்துகளை பரிந்துரைக்காது' : 'No synthetic pesticides prescribed'}
          </span>
        </div>
      </div>
    </div>
  );
};
