import { evaluateCropStress, EngineInput } from './advisoryEngine';

export interface TestResult {
  title: string;
  passed: boolean;
  message: string;
  details?: Record<string, unknown>;
}

export function runAdvisoryEngineTests(): TestResult[] {
  const results: TestResult[] = [];

  // TEST 1: Low-Risk Case
  try {
    const lowRiskInput: EngineInput = {
      crop: 'Paddy (CO 51)',
      growthStage: 'tillering',
      daysWithoutRain: 2,
      soilMoisturePercent: 32,
      weeklyGreennessChangePercent: 2,
      temperatureCelsius: 29,
      humidityPercent: 65,
      ndvi: 0.65,
      ndwi: 0.15,
    };

    const res = evaluateCropStress(lowRiskInput);
    const passed = res.riskLevel === 'low' && res.stressScore < 35 && res.officerConsultWarning === false;
    results.push({
      title: 'Low-Risk Scenario Verification',
      passed,
      message: passed
        ? `Passed: Low stress score of ${res.stressScore} mapped correctly to Low risk.`
        : `Failed: Expected 'low', got '${res.riskLevel}' with score ${res.stressScore}.`,
      details: { score: res.stressScore, risk: res.riskLevel },
    });
  } catch (err) {
    results.push({
      title: 'Low-Risk Scenario Verification',
      passed: false,
      message: `Error thrown: ${err instanceof Error ? err.message : String(err)}`,
    });
  }

  // TEST 2: High-Risk Case
  try {
    const highRiskInput: EngineInput = {
      crop: 'Paddy (CR 1009)',
      growthStage: 'panicle_initiation',
      daysWithoutRain: 9, // triggers rain high
      soilMoisturePercent: 16, // triggers soil moisture crit
      weeklyGreennessChangePercent: -14, // triggers greenness drop
      temperatureCelsius: 37, // triggers heat stress
      humidityPercent: 35, // triggers dry humidity
      ndvi: 0.38,
      ndwi: -0.12,
    };

    const res = evaluateCropStress(highRiskInput);
    const passed = 
      res.riskLevel === 'high' && 
      res.stressScore >= 50 && 
      res.officerConsultWarning === true &&
      res.evidenceList.length >= 4;

    results.push({
      title: 'High-Risk Compound Stress Verification',
      passed,
      message: passed
        ? `Passed: High stress score of ${res.stressScore} triggered High risk level and officer consult warning.`
        : `Failed: Expected 'high' with score >=50, got '${res.riskLevel}' with score ${res.stressScore}.`,
      details: { score: res.stressScore, risk: res.riskLevel, factorsCount: res.evidenceList.length },
    });
  } catch (err) {
    results.push({
      title: 'High-Risk Compound Stress Verification',
      passed: false,
      message: `Error thrown: ${err instanceof Error ? err.message : String(err)}`,
    });
  }

  // TEST 3: Four Stress Categories Output Verification
  try {
    const multiCategoryInput: EngineInput = {
      crop: 'Paddy (ADT 45)',
      growthStage: 'panicle_initiation',
      daysWithoutRain: 8,
      soilMoisturePercent: 18,
      weeklyGreennessChangePercent: -10,
      temperatureCelsius: 36,
      humidityPercent: 82,
      ndvi: 0.42,
      ndwi: -0.05,
    };

    const res = evaluateCropStress(multiCategoryInput);
    const cats = res.categories;
    const allCategoriesExist = Boolean(
      cats &&
      cats.waterStress &&
      cats.nutrientStress &&
      cats.pestDiseaseRisk &&
      cats.heatStress
    );

    const waterHighOrWatch = cats?.waterStress.riskLevel === 'high' || cats?.waterStress.riskLevel === 'watch';
    const heatHighOrWatch = cats?.heatStress.riskLevel === 'high' || cats?.heatStress.riskLevel === 'watch';

    const passed = allCategoriesExist && waterHighOrWatch && heatHighOrWatch;
    results.push({
      title: 'Four Stress Categories (Water, Nutrient, Pest, Heat) Verification',
      passed,
      message: passed
        ? `Passed: All 4 categories computed with independent risk levels (Water: ${cats?.waterStress.riskLevel}, Nutrient: ${cats?.nutrientStress.riskLevel}, Pest: ${cats?.pestDiseaseRisk.riskLevel}, Heat: ${cats?.heatStress.riskLevel}).`
        : `Failed: Missing categories or incorrect risk mapping.`,
      details: {
        water: cats?.waterStress.riskLevel,
        nutrient: cats?.nutrientStress.riskLevel,
        pest: cats?.pestDiseaseRisk.riskLevel,
        heat: cats?.heatStress.riskLevel,
      },
    });
  } catch (err) {
    results.push({
      title: 'Four Stress Categories Verification',
      passed: false,
      message: `Error thrown: ${err instanceof Error ? err.message : String(err)}`,
    });
  }

  // TEST 4: The 5 Explainable Questions Verification
  try {
    const explainInput: EngineInput = {
      crop: 'Paddy (CO 51)',
      growthStage: 'tillering',
      daysWithoutRain: 6,
      soilMoisturePercent: 22,
      weeklyGreennessChangePercent: -5,
      temperatureCelsius: 34,
      humidityPercent: 55,
      ndvi: 0.52,
      ndwi: 0.05,
    };

    const res = evaluateCropStress(explainInput);
    const eq = res.explainableQuestions;
    const passed = Boolean(
      eq &&
      eq.identifiedProblem.title &&
      eq.whySuspected.reasoning &&
      eq.supportingInputs.factors.length > 0 &&
      eq.whatToCheckNext.checklist.length > 0 &&
      eq.reliabilityAndLimitations.reliabilityScore &&
      eq.reliabilityAndLimitations.limitations.length > 0
    );

    results.push({
      title: 'The 5 Explainability Questions Synthesis',
      passed,
      message: passed
        ? `Passed: All 5 explainable questions formulated with transparent agronomic attribution.`
        : `Failed: Incomplete 5 explainable questions structure.`,
      details: {
        problem: eq?.identifiedProblem.title,
        reliability: eq?.reliabilityAndLimitations.reliabilityScore,
        factors: eq?.supportingInputs.factors.length,
      },
    });
  } catch (err) {
    results.push({
      title: 'The 5 Explainability Questions Synthesis',
      passed: false,
      message: `Error thrown: ${err instanceof Error ? err.message : String(err)}`,
    });
  }

  // TEST 5: Missing Optional Data Graceful Fallback
  try {
    const noSatelliteInput: EngineInput = {
      crop: 'Paddy (ADT 45)',
      growthStage: 'grain_filling',
      daysWithoutRain: 5,
      soilMoisturePercent: 24,
      weeklyGreennessChangePercent: -4,
      temperatureCelsius: 32,
      humidityPercent: 50,
      ndvi: null,
      ndwi: null,
    };

    const res = evaluateCropStress(noSatelliteInput);
    const missingBoth = res.missingFields.length === 2 && 
      res.dataCoveragePercent < 100 && 
      res.dataCoveragePercent === Math.round((5 / 7) * 100);

    results.push({
      title: 'Missing Optional Satellite Data Graceful Fallback',
      passed: missingBoth,
      message: missingBoth
        ? `Passed: Handled missing NDVI & NDWI gracefully; coverage set to ${res.dataCoveragePercent}% without engine failure.`
        : `Failed: Missing fields not registered accurately (${res.missingFields.length} found).`,
      details: { coverage: res.dataCoveragePercent, missing: res.missingFields },
    });
  } catch (err) {
    results.push({
      title: 'Missing Optional Satellite Data Graceful Fallback',
      passed: false,
      message: `Error thrown: ${err instanceof Error ? err.message : String(err)}`,
    });
  }

  return results;
}
