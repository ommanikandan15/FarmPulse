import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Sprout, 
  Sparkles, 
  HelpCircle,
  MoreHorizontal,
  Map,
  ScanSearch,
  CloudSun,
  Truck,
  FileText,
  Settings,
  X,
  Bot,
  Compass,
  CloudRain,
  TrendingUp
} from 'lucide-react';
import { useApp, NavigationTab } from '../../context/AppContext';

export const MobileNav: React.FC = () => {
  const { activeTab, setActiveTab, t, language } = useApp();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  const mainTabs: { id: NavigationTab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'analysis', label: t.navAnalysis, icon: Sprout },
    { id: 'advisory', label: t.navAdvisory, icon: Sparkles },
    { id: 'ask-ai', label: t.navAskAi, icon: Bot },
  ];

  const moreTabs: { id: NavigationTab; label: string; icon: React.ElementType }[] = [
    { id: 'explanation', label: t.navExplanation, icon: HelpCircle },
    { id: 'fieldmap', label: t.navFieldMap, icon: Compass },
    { id: 'weathermap', label: t.navWeatherMap, icon: CloudRain },
    { id: 'mandi', label: t.navMandi, icon: TrendingUp },
    { id: 'plots', label: t.navPlots, icon: Map },
    { id: 'leafcheck', label: t.navLeafCheck, icon: ScanSearch },
    { id: 'weather', label: t.navWeather, icon: CloudSun },
    { id: 'reports', label: t.navReports, icon: FileText },
    { id: 'fpo', label: t.navFpo, icon: Truck },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  const isMoreActive = moreTabs.some((t) => t.id === activeTab);

  return (
    <>
      {/* More Bottom Sheet Drawer */}
      {showMoreMenu && (
        <div 
          className="md:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex flex-col justify-end"
          onClick={() => setShowMoreMenu(false)}
        >
          <div 
            className="bg-white rounded-t-2xl p-5 border-t border-[#E3E8DC] shadow-2xl space-y-4 max-h-[70vh] overflow-y-auto animate-in slide-in-from-bottom duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-[#E3E8DC]">
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold text-[#173F35]">
                  FarmPulse
                </span>
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                  PRIME ELITE
                </span>
              </div>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {moreTabs.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setShowMoreMenu(false);
                    }}
                    className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-[#173F35] text-white border-[#173F35]'
                        : 'bg-[#F7F8F4] text-[#1C2723] border-[#E3E8DC] hover:bg-[#EBF4ED]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#65A66F]' : 'text-[#4E9B5F]'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav 
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E3E8DC] px-2 py-1.5 shadow-lg flex items-center justify-around"
        aria-label="Mobile Navigation Bar"
      >
        {mainTabs.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-1.5 rounded-lg transition-colors min-w-[52px] ${
                isActive
                  ? 'text-[#173F35] font-bold'
                  : 'text-[#83948E] hover:text-[#173F35]'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-[#4E9B5F]' : ''}`} />
              <span className="text-[10px] mt-0.5 max-w-[62px] truncate text-center">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* More Button */}
        <button
          onClick={() => setShowMoreMenu(true)}
          className={`flex flex-col items-center justify-center py-1 px-1.5 rounded-lg transition-colors min-w-[52px] ${
            isMoreActive
              ? 'text-[#173F35] font-bold'
              : 'text-[#83948E] hover:text-[#173F35]'
          }`}
          aria-label="More views"
        >
          <MoreHorizontal className={`w-5 h-5 ${isMoreActive ? 'text-[#4E9B5F]' : ''}`} />
          <span className="text-[10px] mt-0.5 max-w-[62px] truncate text-center">
            {language === 'ta' ? 'கூடுதல்' : 'More...'}
          </span>
        </button>
      </nav>
    </>
  );
};
