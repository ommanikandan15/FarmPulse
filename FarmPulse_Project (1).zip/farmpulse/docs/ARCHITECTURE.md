# Architecture and data flow

```text
Weather / satellite / farmer observation
                ↓
       Input validation (Pydantic)
                ↓
  Transparent crop-stage rule engine
                ↓
  Evidence objects (value + trigger + reason)
                ↓
 Farmer dashboard: status → evidence → safe next step
                ↓
 Aggregated cluster signals for FPO planning
```

## Current prototype
- FastAPI serves the API and static dashboard.
- `data/demo_plots.json` contains synthetic examples.
- `evaluate()` is deliberately transparent and testable.
- Current thresholds are illustrative, not agronomically validated.

## Production integration roadmap
1. Establish farmer consent, plot IDs and a data-retention policy.
2. Add Open-Meteo adapter with request caching, source timestamps and missing-data handling.
3. Add Sentinel-2 processing with cloud masking and field-boundary aggregation; record acquisition date and pixel coverage.
4. Validate thresholds with Tamil Nadu Agricultural University / local extension experts and representative field observations.
5. Only after collecting labelled data, train and evaluate models by crop, stage, season and geography. Compare against the rule baseline.
6. Use SHAP only for an evaluated model; explain association/contribution, not causality. Validate generated explanations with domain experts.
7. Run a farmer pilot with Tamil-language usability testing and monitor false alerts, missed alerts and action outcomes.
