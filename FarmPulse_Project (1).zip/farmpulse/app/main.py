from pathlib import Path
import json
from typing import Literal
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = ROOT / "data" / "demo_plots.json"
PLOTS = json.loads(DATA_FILE.read_text(encoding="utf-8"))
app = FastAPI(title="FarmPulse API", version="0.1.0", description="Explainable crop stress demo API. Sample data only.")
app.mount("/static", StaticFiles(directory=ROOT / "app" / "static"), name="static")

class Observation(BaseModel):
    crop: str = "paddy"
    days_without_rain: int = Field(ge=0, le=365)
    soil_moisture_pct: float = Field(ge=0, le=100)
    greenness_change_pct: float = Field(ge=-100, le=100)
    temperature_c: float = Field(ge=-10, le=60)
    humidity_pct: float = Field(ge=0, le=100)
    growth_stage: str = "unknown"
    ndvi: float | None = Field(default=None, ge=-1, le=1)
    ndwi: float | None = Field(default=None, ge=-1, le=1)


def evaluate(o: dict) -> dict:
    """Transparent demo rules; thresholds are illustrative, not validated agronomic advice."""
    factors = []
    score = 0
    if o["days_without_rain"] >= 7:
        score += 3; factors.append({"factor":"Rainfall gap", "value":f'{o["days_without_rain"]} days without rain', "effect":"high", "reason":"The demo rule flags a prolonged dry spell at 7 days."})
    elif o["days_without_rain"] >= 4:
        score += 1; factors.append({"factor":"Rainfall gap", "value":f'{o["days_without_rain"]} days without rain', "effect":"moderate", "reason":"Several rain-free days may increase monitoring priority."})
    if o["soil_moisture_pct"] < 20:
        score += 3; factors.append({"factor":"Soil moisture", "value":f'{o["soil_moisture_pct"]:.0f}%', "effect":"high", "reason":"Below the illustrative 20% demo threshold."})
    elif o["soil_moisture_pct"] < 28:
        score += 1; factors.append({"factor":"Soil moisture", "value":f'{o["soil_moisture_pct"]:.0f}%', "effect":"moderate", "reason":"Moisture is in the demo watch range (20–28%)."})
    if o["greenness_change_pct"] <= -12:
        score += 2; factors.append({"factor":"Greenness trend", "value":f'{o["greenness_change_pct"]:.0f}% over the last week', "effect":"high", "reason":"A sharp drop merits a field check; greenness alone does not identify the cause."})
    elif o["greenness_change_pct"] <= -6:
        score += 1; factors.append({"factor":"Greenness trend", "value":f'{o["greenness_change_pct"]:.0f}% over the last week', "effect":"moderate", "reason":"A downward trend is a reason to inspect the plot."})
    if o["temperature_c"] >= 35:
        score += 1; factors.append({"factor":"Heat", "value":f'{o["temperature_c"]:.0f}°C', "effect":"moderate", "reason":"High temperature can increase crop water demand."})
    if o.get("ndwi") is not None and o["ndwi"] < 0:
        factors.append({"factor":"NDWI indicator", "value":f'{o["ndwi"]:.2f}', "effect":"context", "reason":"Satellite index is supporting context only and can be affected by cloud, soil and timing."})
    level = "High" if score >= 6 else "Watch" if score >= 3 else "Low"
    color = "red" if level == "High" else "amber" if level == "Watch" else "green"
    if level == "High":
        action = "Visit the plot within 24 hours. Check water availability and soil conditions; consult a local agriculture officer before deciding irrigation depth or treatment."
    elif level == "Watch":
        action = "Inspect the plot within 48 hours. Verify soil moisture at more than one point and compare with recent rainfall before taking action."
    else:
        action = "Continue routine monitoring. Recheck after the next weather event or if visible symptoms appear."
    provided = sum(v is not None for v in [o.get("days_without_rain"), o.get("soil_moisture_pct"), o.get("greenness_change_pct"), o.get("temperature_c"), o.get("humidity_pct"), o.get("ndvi"), o.get("ndwi")])
    confidence = "Better coverage" if provided >= 6 else "Limited coverage" if provided >= 4 else "Low coverage"
    return {"level":level,"color":color,"score":score,"factors":factors,"action":action,"coverage":confidence,"coverage_note":"Coverage describes how many input fields are present; it is not a probability that the advisory is correct.","method":"Transparent rules v0.1 · demo thresholds · not a trained ML prediction"}

@app.get("/")
def home(): return FileResponse(ROOT / "app" / "static" / "index.html")
@app.get("/api/health")
def health(): return {"status":"ok","demo_mode":True,"version":"0.1.0"}
@app.get("/api/plots")
def plots():
    result=[]
    for p in PLOTS:
        adv=evaluate(p)
        result.append({"id":p["id"],"name":p["name"],"crop":p["crop"],"stage":p["growth_stage"],"area_acres":p["area_acres"],"level":adv["level"],"color":adv["color"],"ndvi":p["ndvi"],"moisture":p["soil_moisture_pct"]})
    return {"demo_mode":True,"plots":result}
@app.get("/api/plots/{plot_id}")
def plot_detail(plot_id: str):
    p=next((x for x in PLOTS if x["id"]==plot_id),None)
    if not p: raise HTTPException(404,"Plot not found")
    return {"plot":p,"advisory":evaluate(p),"demo_mode":True}
@app.get("/api/cluster")
def cluster():
    items=[{"plot":p,"advisory":evaluate(p)} for p in PLOTS]
    counts={k:sum(i["advisory"]["level"]==k for i in items) for k in ["High","Watch","Low"]}
    area=sum(i["plot"]["area_acres"] for i in items)
    return {"cluster_name":"Kaveripakkam demo cluster","demo_mode":True,"plot_count":len(items),"area_acres":round(area,1),"risk_counts":counts,"priority_plots":[i["plot"]["id"] for i in items if i["advisory"]["level"]=="High"],"procurement_note":"Planning signal only: confirm with field visits, farmer reports and local crop calendars before procurement decisions."}
@app.post("/api/advisory")
def advisory(obs: Observation):
    return {"advisory":evaluate(obs.model_dump()),"demo_mode":True}
