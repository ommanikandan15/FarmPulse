import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { runAdvisoryEngineTests, TestResult } from '../../services/advisoryEngine.test';
import { LANGUAGE_OPTIONS } from '../../data/translations';
import { 
  Settings, 
  Languages, 
  Ruler, 
  Bell, 
  RotateCcw, 
  ShieldCheck, 
  Info, 
  CheckCircle2, 
  FlaskConical, 
  Check, 
  AlertCircle,
  Smartphone,
  Sparkles,
  Cpu,
  Wifi,
  Download
} from 'lucide-react';
import { ApkInstallModal } from '../pwa/ApkInstallModal';

export const SettingsView: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    tempUnit, 
    setTempUnit, 
    areaUnit, 
    setAreaUnit, 
    resetDemoData, 
    setActiveTab,
    t 
  } = useApp();

  const [resetSuccessNotice, setResetSuccessNotice] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[] | null>(null);
  const [showApkModal, setShowApkModal] = useState(false);

  const handleReset = () => {
    if (window.confirm(t.resetDemoConfirm)) {
      resetDemoData();
      setResetSuccessNotice(true);
      setTimeout(() => setResetSuccessNotice(false), 4000);
    }
  };

  const handleRunTests = () => {
    const results = runAdvisoryEngineTests();
    setTestResults(results);
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs">
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
          {t.settingsTitle}
        </h1>
        <p className="text-xs text-[#566761] mt-1">
          {t.settingsSubtitle}
        </p>
      </div>

      {resetSuccessNotice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{t.resetSuccess}</span>
        </div>
      )}

      {/* Language Preferences */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-[#173F35] pb-3 border-b border-[#E3E8DC]">
          <Languages className="w-4 h-4 text-[#4E9B5F]" />
          <span>{t.prefLanguage}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {LANGUAGE_OPTIONS.map((opt) => (
            <button
              key={opt.code}
              onClick={() => setLanguage(opt.code)}
              className={`p-3.5 rounded-xl border text-left transition-all ${
                language === opt.code
                  ? 'bg-emerald-50/70 border-[#2D8A4E] ring-2 ring-[#2D8A4E]/20'
                  : 'bg-[#F7F8F4] border-[#E3E8DC] hover:bg-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#1C2723]">{opt.nativeLabel}</span>
                {language === opt.code && <Check className="w-4 h-4 text-[#2D8A4E]" />}
              </div>
              <p className="text-xs text-[#566761] mt-0.5">
                {opt.label} • Audio: {opt.speechLocale}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Units Preferences */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-[#173F35] pb-3 border-b border-[#E3E8DC]">
          <Ruler className="w-4 h-4 text-[#4E9B5F]" />
          <span>{t.prefUnits}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          {/* Temperature unit */}
          <div className="p-3.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-2">
            <span className="font-semibold text-[#1C2723] block">
              {language === 'ta' ? 'வெப்பநிலை அலகு' : 'Temperature Scale'}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setTempUnit('C')}
                className={`flex-1 py-1.5 px-3 rounded-lg font-bold border transition-all ${
                  tempUnit === 'C'
                    ? 'bg-[#173F35] text-white border-[#173F35]'
                    : 'bg-white text-[#566761] border-[#E3E8DC] hover:bg-stone-50'
                }`}
              >
                Celsius (°C)
              </button>
              <button
                onClick={() => setTempUnit('F')}
                className={`flex-1 py-1.5 px-3 rounded-lg font-bold border transition-all ${
                  tempUnit === 'F'
                    ? 'bg-[#173F35] text-white border-[#173F35]'
                    : 'bg-white text-[#566761] border-[#E3E8DC] hover:bg-stone-50'
                }`}
              >
                Fahrenheit (°F)
              </button>
            </div>
          </div>

          {/* Area unit */}
          <div className="p-3.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-2">
            <span className="font-semibold text-[#1C2723] block">
              {language === 'ta' ? 'பரப்பளவு அலகு' : 'Land Measurement Unit'}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAreaUnit('acre')}
                className={`flex-1 py-1.5 px-3 rounded-lg font-bold border transition-all ${
                  areaUnit === 'acre'
                    ? 'bg-[#173F35] text-white border-[#173F35]'
                    : 'bg-white text-[#566761] border-[#E3E8DC] hover:bg-stone-50'
                }`}
              >
                Acres (ac)
              </button>
              <button
                onClick={() => setAreaUnit('ha')}
                className={`flex-1 py-1.5 px-3 rounded-lg font-bold border transition-all ${
                  areaUnit === 'ha'
                    ? 'bg-[#173F35] text-white border-[#173F35]'
                    : 'bg-white text-[#566761] border-[#E3E8DC] hover:bg-stone-50'
                }`}
              >
                Hectares (ha)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Built-in Engine Unit Tests Suite Runner */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div className="flex items-center gap-2 text-sm font-bold text-[#173F35]">
            <FlaskConical className="w-4 h-4 text-[#4E9B5F]" />
            <span>Advisory Rules Engine Verification Tests</span>
          </div>
          <button
            onClick={handleRunTests}
            className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-[#173F35] border border-emerald-300 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <FlaskConical className="w-3.5 h-3.5 text-[#4E9B5F]" />
            <span>Run All 4 Tests</span>
          </button>
        </div>

        <p className="text-xs text-[#566761]">
          Verifies low-risk calibration, high-risk compound thresholds, missing optional satellite data fallback, and 100% normalized factor contributions.
        </p>

        {testResults && (
          <div className="space-y-2 pt-1">
            {testResults.map((tRes, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                  tRes.passed ? 'bg-emerald-50/70 border-emerald-300' : 'bg-rose-50 border-rose-300'
                }`}
              >
                {tRes.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <span className="font-bold text-[#1C2723] block">{tRes.title}</span>
                  <p className="text-[#566761] mt-0.5">{tRes.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Android APK & PWA Installation Card */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div className="flex items-center gap-2 text-sm font-bold text-[#173F35]">
            <Smartphone className="w-4 h-4 text-[#4E9B5F]" />
            <span>{language === 'ta' ? 'ஆண்ட்ராய்டு செயலி (APK) & ஆஃப்லைன்' : (language === 'te' ? 'ఆండ్రాయిడ్ యాప్ (APK) & ఆఫ్‌లైన్' : 'Android App (APK) & Offline Support')}</span>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
            v1.0.0 Stable
          </span>
        </div>

        <p className="text-xs text-[#566761] leading-relaxed">
          {language === 'ta'
            ? 'ஃபார்ம்பல்ஸ் செயலியை உங்கள் ஆண்ட்ராய்டு ஸ்மார்ட்போனில் நிறுவி இணையம் இல்லாமலும் களத்தில் பயன்படுத்தலாம்.'
            : (language === 'te'
              ? 'ఫార్మ్‌పల్స్ యాప్‌ను మీ ఆండ్రాయిడ్ స్మార్ట్‌ఫోన్‌లో ఇన్‌స్టాల్ చేసుకోండి. ఇంటర్నెట్ లేనప్పుడు కూడా గత సమాచారాన్ని వీక్షించవచ్చు.'
              : 'Install FarmPulse directly on Android devices as a native-feel WebAPK with offline caching, local data persistence, and instant launcher access.')}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <Wifi className="w-3.5 h-3.5 text-[#4E9B5F]" />
              <span>{language === 'ta' ? 'ஆஃப்லைன் வசதி' : (language === 'te' ? 'ఆఫ్‌లైన్ నిల్వ' : 'Offline Cache')}</span>
            </div>
            <p className="text-[11px] text-[#566761] mt-1">
              Service Worker & Cache API enabled for remote field use
            </p>
          </div>

          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <Smartphone className="w-3.5 h-3.5 text-[#4E9B5F]" />
              <span>{language === 'ta' ? 'ஆண்ட்ராய்டு பதிப்பு' : (language === 'te' ? 'ఆండ్రాయిడ్ వెర్షన్' : 'Android Build')}</span>
            </div>
            <p className="text-[11px] text-[#566761] mt-1">
              Target SDK 34 (Android 14+), Min SDK 24 (Nougat+)
            </p>
          </div>

          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#4E9B5F]" />
              <span>{language === 'ta' ? 'பாதுகாப்பு & அனுமதி' : (language === 'te' ? 'భద్రత & అనుమతులు' : 'Security & Rules')}</span>
            </div>
            <p className="text-[11px] text-[#566761] mt-1">
              No sensitive permissions; isolated camera & geolocation prompts
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowApkModal(true)}
          className="w-full sm:w-auto px-5 py-2.5 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4 text-[#65A66F]" />
          <span>{language === 'ta' ? 'ஆண்ட்ராய்டு APK / செயலி நிறுவல்' : (language === 'te' ? 'ఆండ్రాయిడ్ APK / ఇన్‌స్టాల్ గైడ్' : 'Install Android APK / WebAPK')}</span>
        </button>
      </div>

      {/* Gemini 3.8 Flash AI Model Integration Card */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div className="flex items-center gap-2 text-sm font-bold text-[#173F35]">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Gemini 3.8 Flash AI Agronomy Engine</span>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
            Server-Side Secured
          </span>
        </div>

        <p className="text-xs text-[#566761] leading-relaxed">
          {language === 'ta'
            ? 'பயிர் இலை நோயறிதல் மற்றும் வேளாண் வழிகாட்டுதலுக்கு கூகுள் ஜெமினி 3.8 ஃப்ளாஷ் மல்டிமாடல் மாதிரியை சர்வர் வழியாகப் பாதுகாப்பாகப் பயன்படுத்துகிறது. ஏபிஐ கீ வெளிப்படுத்தப்படுவதில்லை.'
            : (language === 'te'
              ? 'పంట ఆకుల ఫోటో విశ్లేషణ మరియు రైతు సలహాల కోసం గూగుల్ జెమిని 3.8 ఫ్లాష్ AI మోడల్‌ను సర్వర్-సైడ్ ప్రాక్సీ ద్వారా సురక్షితంగా ఉపయోగిస్తుంది.'
              : 'FarmPulse integrates Gemini 3.8 Flash Multimodal via Express server-side proxy (/api/gemini-leaf-analyze & /api/ask-ai). Client builds never expose API credentials.')}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <Cpu className="w-3.5 h-3.5 text-emerald-600" />
              <span>Vision Pathology Engine</span>
            </div>
            <p className="text-[11px] text-[#566761] mt-1">
              Multi-factor diagnostic scan: chlorosis, necrosis, leaf rolling, AWD water deficit
            </p>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Safety & Ethical Fallback</span>
            </div>
            <p className="text-[11px] text-[#566761] mt-1">
              Deterministic TNAU / ICAR crop doctor rules kick in seamlessly if network or API key is offline
            </p>
          </div>
        </div>
      </div>

      {/* Reset Data & About */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-[#173F35] pb-3 border-b border-[#E3E8DC]">
          <RotateCcw className="w-4 h-4 text-rose-600" />
          <span>{t.resetDemoData}</span>
        </div>

        <p className="text-xs text-[#566761]">
          {language === 'ta'
            ? 'அனைத்து மாதிரி நிலங்கள், வானிலை பதிவுகள் மற்றும் உருவகப்படுத்தல்களை இயல்பு நிலைக்கு மீட்டமைக்கும்.'
            : 'Restores all demo plots and custom what-if scenario simulations to pristine initial states.'}
        </p>

        <button
          onClick={handleReset}
          className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold transition-colors flex items-center gap-2"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.resetDemoData}</span>
        </button>
      </div>

      {/* About Box */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-2 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
          <ShieldCheck className="w-4 h-4 text-[#4E9B5F]" />
          <span>{t.aboutTitle}</span>
        </div>
        <p className="text-[#566761] leading-relaxed">
          {t.aboutBody}
        </p>
        <div className="pt-2 text-[10px] text-[#83948E] flex items-center gap-3">
          <span>FarmPulse Version: 1.0.0-pilot</span>
          <span>•</span>
          <span>Target Platform: Android WebAPK / PWA / Standalone Mobile</span>
        </div>
      </div>

      {/* Android APK Modal */}
      <ApkInstallModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
      />
    </div>
  );
};
