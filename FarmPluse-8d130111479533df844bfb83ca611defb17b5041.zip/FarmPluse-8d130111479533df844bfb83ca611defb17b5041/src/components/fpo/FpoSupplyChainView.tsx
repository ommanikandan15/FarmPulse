import React from 'react';
import { useApp } from '../../context/AppContext';
import { DEMO_CLUSTER_SUMMARY } from '../../data/demoData';
import { 
  Truck, 
  Download, 
  Calendar, 
  Layers, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  AlertTriangle,
  Building,
  Info
} from 'lucide-react';

export const FpoSupplyChainView: React.FC = () => {
  const { plots, t, language, formatArea } = useApp();

  const cluster = DEMO_CLUSTER_SUMMARY;
  const totalPlots = plots.length;
  const totalAcres = plots.reduce((acc, p) => acc + p.areaAcres, 0);

  const lowCount = plots.filter((p) => p.advisory.riskLevel === 'low').length;
  const watchCount = plots.filter((p) => p.advisory.riskLevel === 'watch').length;
  const highCount = plots.filter((p) => p.advisory.riskLevel === 'high').length;

  // Browser-side CSV generation
  const handleExportCsv = () => {
    const headers = ['Plot ID', 'Crop Variety', 'Growth Stage', 'Acreage', 'Risk Level', 'Stress Score', 'Soil Moisture %', 'Rainfall Gap Days', 'Primary Recommended Action', 'Cluster Notice'];
    const rows = plots.map((p) => [
      `"${p.id}"`,
      `"${p.variety}"`,
      `"${p.growthStage}"`,
      `"${p.areaAcres}"`,
      `"${p.advisory.riskLevel.toUpperCase()}"`,
      `"${p.advisory.stressScore}"`,
      `"${p.latestObservation.soilMoisturePercent}%"`,
      `"${p.latestObservation.daysWithoutRain}"`,
      `"${p.advisory.primaryAction.replace(/"/g, '""')}"`,
      `"DEMO DATA — NOT A GUARANTEED YIELD FORECAST"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `FarmPulse_FPO_Cluster_Outlook_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {t.fpoTitle}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-xl">
            {t.fpoSubtitle}
          </p>
        </div>

        {/* Export CSV button */}
        <button
          onClick={handleExportCsv}
          className="self-start md:self-auto px-4 py-2.5 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          <span>{t.exportFpoCsv}</span>
        </button>
      </div>

      {/* Mandatory Strong Planning Caveat */}
      <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-950 space-y-1">
        <div className="flex items-center gap-1.5 font-bold text-amber-900">
          <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
          <span>{t.fpoCaveatTitle}</span>
        </div>
        <p className="leading-relaxed">
          {t.fpoCaveatText}
        </p>
      </div>

      {/* Cluster KPI Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <span className="text-xs font-semibold text-[#566761]">{t.totalPlotsCovered}</span>
          <div className="mt-2 text-2xl font-extrabold text-[#1C2723]">{totalPlots}</div>
          <span className="text-[11px] text-[#4E9B5F] mt-1 block font-medium">
            {language === 'ta' ? 'காவேரிப்பாக்கம் வட்டம்' : 'Kaveripakkam Pilot Hub'}
          </span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <span className="text-xs font-semibold text-[#566761]">{t.totalAreaCovered}</span>
          <div className="mt-2 text-2xl font-extrabold text-[#1C2723]">{formatArea(totalAcres)}</div>
          <span className="text-[11px] text-[#566761] mt-1 block">
            {language === 'ta' ? 'விவசாய நில பரப்பளவு' : 'Cultivated paddy plots'}
          </span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <span className="text-xs font-semibold text-[#566761]">{t.riskHigh}</span>
          <div className="mt-2 text-2xl font-extrabold text-rose-700">{highCount}</div>
          <span className="text-[11px] text-rose-600 mt-1 block font-medium">
            {language === 'ta' ? 'உடனடி ஆய்வு தேவை' : 'Requires field validation'}
          </span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <span className="text-xs font-semibold text-[#566761]">{t.riskLow} / {t.riskWatch}</span>
          <div className="mt-2 text-2xl font-extrabold text-[#1C2723]">{lowCount + watchCount}</div>
          <span className="text-[11px] text-emerald-700 mt-1 block font-medium">
            {language === 'ta' ? 'சாதகமான / கண்காணிப்பு' : 'Normal to moderate watch'}
          </span>
        </div>
      </div>

      {/* Crop Risk Breakdown Table */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div>
            <h3 className="font-bold text-base text-[#173F35]">
              {t.cropRiskBreakdown}
            </h3>
            <p className="text-xs text-[#566761] mt-0.5">
              {language === 'ta' ? 'ரகம் வாரியான கொள்முதல் திட்டமிடல் விபரம்' : 'Variety distribution across the cluster'}
            </p>
          </div>
          <span className="text-xs font-mono text-[#83948E]">
            {cluster.district}, {cluster.state}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7F8F4] border-b border-[#E3E8DC] text-[#566761] font-semibold uppercase tracking-wider">
              <tr>
                <th className="p-3">Variety</th>
                <th className="p-3">Plots</th>
                <th className="p-3">Acreage</th>
                <th className="p-3">Low Stress</th>
                <th className="p-3">Watch</th>
                <th className="p-3">High Risk</th>
                <th className="p-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3E8DC]">
              {cluster.cropBreakdown.map((item, idx) => (
                <tr key={idx} className="hover:bg-[#F7F8F4] transition-colors">
                  <td className="p-3 font-bold text-[#1C2723]">
                    {language === 'ta' ? item.cropTa : item.crop}
                  </td>
                  <td className="p-3 text-[#566761]">{item.plots}</td>
                  <td className="p-3 font-semibold text-[#1C2723]">{formatArea(item.acres)}</td>
                  <td className="p-3 text-emerald-700 font-bold">{item.riskDistribution.low}</td>
                  <td className="p-3 text-amber-700 font-bold">{item.riskDistribution.watch}</td>
                  <td className="p-3 text-rose-700 font-bold">{item.riskDistribution.high}</td>
                  <td className="p-3 text-right">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                      item.riskDistribution.high > 0 ? 'bg-rose-100 text-rose-800' :
                      item.riskDistribution.watch > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {item.riskDistribution.high > 0 ? 'Inspection Priority' : 'On Track'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Procurement-Readiness Timeline */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div>
            <h3 className="font-bold text-base text-[#173F35]">
              {t.procurementTimeline}
            </h3>
            <p className="text-xs text-[#566761] mt-0.5">
              {language === 'ta'
                ? 'அறுவடை தயார்நிலை பரந்த காலக்கோடு — உறுதியான கணிப்பு அல்ல'
                : 'Broad harvesting windows for harvester scheduling and mill procurement coordination.'}
            </p>
          </div>
          <Clock className="w-4 h-4 text-[#4E9B5F]" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {cluster.readinessTimeline.map((item, idx) => {
            const statusConfig = {
              on_track: { bg: 'bg-emerald-50/70 border-emerald-300 text-emerald-950', badge: 'On Track' },
              delayed_water: { bg: 'bg-amber-50/70 border-amber-300 text-amber-950', badge: 'Power/Heat Delayed' },
              needs_inspection: { bg: 'bg-rose-50/70 border-rose-300 text-rose-950', badge: 'Verify in Field' },
            }[item.status];

            return (
              <div key={idx} className={`p-4 rounded-xl border ${statusConfig.bg} space-y-2 flex flex-col justify-between`}>
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-xs uppercase tracking-wider text-[#173F35]">
                      {language === 'ta' ? item.periodTa : item.period}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white border border-stone-200">
                      {statusConfig.badge}
                    </span>
                  </div>

                  <div className="mt-2 text-xl font-extrabold text-[#1C2723]">
                    {formatArea(item.expectedHarvestAcres)}
                  </div>

                  <p className="text-xs text-[#566761] mt-1.5 leading-relaxed">
                    {language === 'ta' ? item.descriptionTa : item.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-stone-200/60 text-[10px] text-[#83948E]">
                  Planning window • Subject to monsoon onset
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Suggested FPO Operations Checklist */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
        <h3 className="font-bold text-base text-[#173F35]">
          {t.suggestedOperations}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {cluster.operationalRecommendations.map((op) => (
            <div key={op.id} className="p-3.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] flex items-start gap-3 text-xs">
              <CheckCircle2 className="w-4 h-4 text-[#4E9B5F] shrink-0 mt-0.5" />
              <p className="text-[#1C2723] leading-relaxed">
                {language === 'ta' ? op.textTa : op.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
