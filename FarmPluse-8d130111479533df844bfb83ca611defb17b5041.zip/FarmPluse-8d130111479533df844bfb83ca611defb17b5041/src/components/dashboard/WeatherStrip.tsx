import React from 'react';
import { useApp } from '../../context/AppContext';
import { DEMO_WEATHER_STRIP } from '../../data/demoData';
import { Sun, CloudRain, CloudSun, Flame, Droplets } from 'lucide-react';

export const WeatherStrip: React.FC = () => {
  const { t, language, formatTemp } = useApp();

  const getWeatherIcon = (cond: string) => {
    switch (cond) {
      case 'rainy':
        return <CloudRain className="w-5 h-5 text-blue-600" />;
      case 'partly_cloudy':
        return <CloudSun className="w-5 h-5 text-amber-500" />;
      case 'hot_dry':
        return <Flame className="w-5 h-5 text-rose-500" />;
      default:
        return <Sun className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#E3E8DC] shadow-xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
        <div className="flex items-center gap-2">
          <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
            {t.weatherStripTitle}
          </h3>
          <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
            {t.demoBadge}
          </span>
        </div>
        <span className="text-xs text-[#566761] hidden sm:block">
          {language === 'ta' ? 'காவேரிப்பாக்கம் பகுதி மாதிரி' : 'Kaveripakkam Cluster'}
        </span>
      </div>

      <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {DEMO_WEATHER_STRIP.map((day, idx) => {
          const isToday = idx === 6; // last day is today in the timeline
          return (
            <div
              key={day.date}
              className={`p-3 rounded-xl border flex flex-col items-center text-center transition-all ${
                isToday
                  ? 'bg-emerald-50/70 border-emerald-300 ring-2 ring-emerald-200'
                  : 'bg-[#F7F8F4] border-[#E3E8DC] hover:bg-white'
              }`}
            >
              <span className={`text-[11px] font-semibold ${isToday ? 'text-emerald-900' : 'text-[#566761]'}`}>
                {language === 'ta' ? day.dayNameTa : day.dayName}
              </span>

              <div className="my-2" aria-hidden="true">
                {getWeatherIcon(day.condition)}
              </div>

              <span className="text-xs font-bold text-[#1C2723]">
                {formatTemp(day.tempMaxC)}
              </span>
              <span className="text-[10px] text-[#83948E]">
                {formatTemp(day.tempMinC)} min
              </span>

              {/* Rain amount */}
              <div className="mt-2 pt-1.5 border-t border-[#E3E8DC] w-full flex items-center justify-center gap-1 text-[10px] font-medium text-blue-700">
                <Droplets className="w-3 h-3 text-blue-500 shrink-0" />
                <span>{day.rainfallMm} mm</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
