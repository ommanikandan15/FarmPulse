import React from 'react';
import { RiskLevel } from '../../types';
import { useApp } from '../../context/AppContext';

interface StatusBadgeProps {
  level: RiskLevel;
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ level, showIcon = true, size = 'md' }) => {
  const { t } = useApp();

  const config = {
    low: {
      text: t.riskLow,
      bg: 'bg-[#EBF7EE]',
      textCol: 'text-[#1B6336]',
      border: 'border-[#BDDFCA]',
      dot: 'bg-[#2D8A4E]',
      icon: '✓',
    },
    watch: {
      text: t.riskWatch,
      bg: 'bg-[#FEF7EA]',
      textCol: 'text-[#9A5B08]',
      border: 'border-[#F7DEB2]',
      dot: 'bg-[#D97706]',
      icon: '!',
    },
    high: {
      text: t.riskHigh,
      bg: 'bg-[#FDF2F2]',
      textCol: 'text-[#B91C1C]',
      border: 'border-[#F8B4B4]',
      dot: 'bg-[#DC2626]',
      icon: '▲',
    },
  }[level];

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-medium',
    md: 'text-xs px-2.5 py-1 font-semibold',
    lg: 'text-sm px-3.5 py-1.5 font-bold',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md border ${config.bg} ${config.textCol} ${config.border} ${sizeClasses}`}
      role="status"
      aria-label={`Risk Level: ${config.text}`}
    >
      <span className={`w-2 h-2 rounded-full ${config.dot} shrink-0`} aria-hidden="true" />
      <span>{config.text}</span>
      {showIcon && <span className="opacity-70 text-[10px] ml-0.5">{config.icon}</span>}
    </span>
  );
};
