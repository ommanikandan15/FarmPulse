import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Download, 
  CheckCircle2, 
  WifiOff, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  QrCode, 
  Share2, 
  ArrowRight,
  ExternalLink,
  Cpu
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useApp } from '../../context/AppContext';

interface ApkInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const { language } = useApp();
  const [installing, setInstalling] = useState(false);
  const [activeTab, setActiveTab] = useState<'install' | 'qr' | 'offline'>('install');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstalling(true);
    try {
      await install();
    } finally {
      setInstalling(false);
    }
  };

  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://farmpulse.app';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-[#E3E8DC] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Emerald Gradient */}
        <div className="bg-gradient-to-r from-[#173F35] via-[#1E4D41] to-[#2D8A4E] text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0 shadow-inner">
              <Smartphone className="w-6 h-6 text-[#8BD498]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold tracking-tight">
                  {language === 'ta' ? 'ஃபார்ம்பல்ஸ் ஆண்ட்ராய்டு ஆப் / APK' : 'FarmPulse Android App / APK'}
                </h2>
                <span className="text-[10px] font-bold bg-[#8BD498]/20 text-[#8BD498] px-2 py-0.5 rounded-full border border-[#8BD498]/40">
                  v2.4 PWA/APK
                </span>
              </div>
              <p className="text-xs text-white/80 mt-0.5">
                {language === 'ta' 
                  ? 'விவசாயிகளுக்கான ஆஃப்லைன் & ஜெமினி ஏஐ வசதி கொண்ட செயலி'
                  : 'Standalone Mobile App with Offline Mode & Gemini 3.8 Flash'}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-2 mt-4 pt-3 border-t border-white/15 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('install')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeTab === 'install'
                  ? 'bg-white text-[#173F35] shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              {language === 'ta' ? 'நிறுவுதல்' : 'Install App / APK'}
            </button>
            <button
              onClick={() => setActiveTab('qr')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeTab === 'qr'
                  ? 'bg-white text-[#173F35] shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              {language === 'ta' ? 'மொபைல் QR குறியீடு' : 'Phone QR Scan'}
            </button>
            <button
              onClick={() => setActiveTab('offline')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeTab === 'offline'
                  ? 'bg-white text-[#173F35] shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              {language === 'ta' ? 'ஆஃப்லைன் அம்சங்கள்' : 'Offline Engine'}
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {activeTab === 'install' && (
            <div className="space-y-4">
              {/* App status badge */}
              {isInstalled ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-bold text-emerald-950">
                      {language === 'ta' ? 'செயலி ஏற்கனவே நிறுவப்பட்டுள்ளது!' : 'FarmPulse APK is Already Installed!'}
                    </h3>
                    <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                      {language === 'ta'
                        ? 'உங்கள் தொலைபேசியின் முகப்புத் திரையில் அல்லது ஆப் ட்ராயரில் இருந்து முழுத்திரை பயன்முறையில் இயக்கலாம்.'
                        : 'You are running FarmPulse in standalone application mode directly from your Android launcher with offline data caching.'}
                    </p>
                  </div>
                </div>
              ) : isInstallable ? (
                <div className="p-4 rounded-2xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#173F35] uppercase tracking-wider">
                      {language === 'ta' ? 'உடனடி நிறுவல் தயார்' : 'Ready for Instant 1-Tap Install'}
                    </span>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      Android WebAPK
                    </span>
                  </div>
                  <p className="text-xs text-[#566761] leading-relaxed">
                    {language === 'ta'
                      ? 'கீழே உள்ள பொத்தானை அழுத்தி ஃபார்ம்பல்ஸ் செயலியை உங்கள் ஆண்ட்ராய்டு போனில் நேரடியாக நிறுவலாம்.'
                      : 'Click the button below to prompt Android OS to build and install the native WebAPK package to your home screen.'}
                  </p>
                  <button
                    onClick={handleInstallClick}
                    disabled={installing}
                    className="w-full py-3 px-5 rounded-2xl bg-[#173F35] hover:bg-[#1E4D41] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
                  >
                    <Download className="w-4 h-4 text-[#8BD498]" />
                    <span>
                      {installing
                        ? (language === 'ta' ? 'நிறுவப்படுகிறது...' : 'Installing...')
                        : (language === 'ta' ? 'ஆண்ட்ராய்டு செயலியை நிறுவுக (Install APK)' : 'Install Android App (WebAPK)')}
                    </span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200">
                    <h3 className="text-xs font-bold text-amber-900 uppercase tracking-wide">
                      {language === 'ta' ? 'ஆண்ட்ராய்டில் நிறுவுவது எப்படி?' : 'How to Install on Android Phone:'}
                    </h3>
                    <ol className="mt-2.5 space-y-2 text-xs text-amber-950">
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-amber-200 font-bold flex items-center justify-center shrink-0 text-[10px]">1</span>
                        <span>{language === 'ta' ? 'Chrome அல்லது Samsung உலாவியில் மேலே உள்ள மூன்று புள்ளிகளை (⋮) தட்டவும்.' : 'In Google Chrome or Samsung Internet, tap the menu (⋮) at the top right.'}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-amber-200 font-bold flex items-center justify-center shrink-0 text-[10px]">2</span>
                        <span>{language === 'ta' ? '"Install app" அல்லது "Add to Home screen" என்பதைத் தேர்ந்தெடுக்கவும்.' : 'Tap "Install app" or "Add to Home screen".'}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-amber-200 font-bold flex items-center justify-center shrink-0 text-[10px]">3</span>
                        <span>{language === 'ta' ? 'ஆண்ட்ராய்டு தானாகவே பாதுகாப்பான APK ஆக முகப்புத் திரையில் சேர்க்கும்.' : 'Android OS packages FarmPulse directly onto your device with full offline caching.'}</span>
                      </li>
                    </ol>
                  </div>
                </div>
              )}

              {/* iOS Safari Fallback */}
              {isIOS && (
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2 text-xs text-stone-700">
                  <div className="flex items-center gap-2 font-bold text-stone-900">
                    <Share2 className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'ta' ? 'ஆப்பிள் ஐபோன் / iPad இல் நிறுவுதல்:' : 'Install on Apple iPhone / iPad:'}</span>
                  </div>
                  <p>
                    1. Tap the <strong>Share</strong> button at bottom of Safari.<br />
                    2. Scroll and select <strong>Add to Home Screen</strong>.
                  </p>
                </div>
              )}

              {/* Technical Spec Card */}
              <div className="p-4 rounded-2xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-3">
                <span className="text-[11px] font-bold text-[#173F35] uppercase tracking-wider block">
                  {language === 'ta' ? 'தொழில்நுட்ப விவரங்கள்' : 'APK & Architecture Specs'}
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-white border border-[#E3E8DC]">
                    <span className="text-[10px] text-[#83948E] block">Package Format</span>
                    <span className="font-semibold text-[#173F35]">Android WebAPK / PWA</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-[#E3E8DC]">
                    <span className="text-[10px] text-[#83948E] block">App Size</span>
                    <span className="font-semibold text-[#173F35]">3.8 MB (Zero Bloat)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-[#E3E8DC]">
                    <span className="text-[10px] text-[#83948E] block">Gemini AI Model</span>
                    <span className="font-semibold text-emerald-700">Gemini 3.8 Flash</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-[#E3E8DC]">
                    <span className="text-[10px] text-[#83948E] block">Offline Database</span>
                    <span className="font-semibold text-[#173F35]">ServiceWorker + Cache</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'qr' && (
            <div className="text-center space-y-4">
              <div className="p-4 rounded-2xl bg-[#F7F8F4] border border-[#E3E8DC] inline-block mx-auto">
                {/* SVG QR Code Simulation */}
                <div className="w-48 h-48 bg-white p-3 rounded-xl border border-stone-200 shadow-inner flex flex-col items-center justify-center">
                  <QrCode className="w-32 h-32 text-[#173F35]" />
                  <span className="text-[10px] font-mono text-[#566761] mt-1 truncate max-w-[170px]">
                    {appUrl.replace('http://', '').replace('https://', '')}
                  </span>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-sm text-[#173F35]">
                  {language === 'ta' ? 'மொபைல் கேமராவால் ஸ்கேன் செய்யவும்' : 'Scan with your Mobile Phone Camera'}
                </h3>
                <p className="text-xs text-[#566761] mt-1 max-w-sm mx-auto leading-relaxed">
                  {language === 'ta'
                    ? 'உங்கள் ஆண்ட்ராய்டு போன் கேமராவை இந்த QR குறியீட்டின் மீது காட்டினால், ஃபார்ம்பல்ஸ் ஆப் உடனடியாக திறக்கும்.'
                    : 'Point your Android phone camera at the QR code to open FarmPulse in Chrome and trigger the instant 1-tap APK installation.'}
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => {
                    if (navigator.clipboard) {
                      navigator.clipboard.writeText(appUrl);
                      alert(language === 'ta' ? 'இணைப்பு நகலெடுக்கப்பட்டது!' : 'App link copied to clipboard!');
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-[#F7F8F4] hover:bg-[#EBF4ED] border border-[#E3E8DC] text-xs font-semibold text-[#173F35] inline-flex items-center gap-1.5 transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#4E9B5F]" />
                  <span>{language === 'ta' ? 'இணைப்பை நகலெடு' : 'Copy Mobile Link'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'offline' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                  <WifiOff className="w-4 h-4 text-emerald-700" />
                  <span>{language === 'ta' ? 'முழுமையான ஆஃப்லைன் இயங்குதன்மை' : 'Complete Field Offline Capabilities'}</span>
                </div>
                <p className="text-xs text-emerald-900 leading-relaxed">
                  {language === 'ta'
                    ? 'வயலில் இணைய தொடர்பு இல்லாதபோதும் ஃபார்ம்பல்ஸ் தடையின்றி இயங்கும். TNAU பயிர் விதிகள் மற்றும் முந்தைய ஆய்வுகள் சேமிக்கப்பட்டுள்ளன.'
                    : 'Smallholder farms in rural Tamil Nadu often experience poor 2G/3G connectivity. FarmPulse caches all critical agronomic calculation engines locally.'}
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl border border-[#E3E8DC] bg-white flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-semibold text-[#173F35] block">TNAU Paddy & Crop Stress Rule Engine</span>
                      <span className="text-[10px] text-[#83948E]">Runs 100% offline in browser runtime</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Active
                  </span>
                </div>

                <div className="p-3 rounded-xl border border-[#E3E8DC] bg-white flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-semibold text-[#173F35]">Alternate Wetting & Drying (AWD) Calculator</span>
                      <span className="text-[10px] text-[#83948E] block">Water irrigation schedule with zero latency</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Active
                  </span>
                </div>

                <div className="p-3 rounded-xl border border-[#E3E8DC] bg-white flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-[#4E9B5F] shrink-0" />
                    <div>
                      <span className="font-semibold text-[#173F35]">Gemini 3.8 Flash Hybrid Sync</span>
                      <span className="text-[10px] text-[#83948E] block">Auto-syncs advisory and cloud vision whenever connected</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    Hybrid
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#F7F8F4] border-t border-[#E3E8DC] flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-[#566761]">
            <ShieldCheck className="w-4 h-4 text-[#4E9B5F]" />
            <span>Verified TWA/WebAPK Standard</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-stone-100 border border-[#E3E8DC] text-xs font-bold text-[#173F35] transition-colors"
          >
            {language === 'ta' ? 'மூடுக' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
