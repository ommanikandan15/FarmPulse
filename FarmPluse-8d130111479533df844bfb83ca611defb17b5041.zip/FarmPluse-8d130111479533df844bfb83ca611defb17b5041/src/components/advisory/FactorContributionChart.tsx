import React from 'react';
import { EvidenceFactor } from '../../types';
import { useApp } from '../../context/AppContext';
import { BarChart3 } from 'lucide-react';

interface FactorContributionChartProps {
  factors: EvidenceFactor[];
}

export const FactorContributionChart: React.FC<FactorContributionChartProps> = ({ factors }) => {
  const { t, language } = useApp();

  return (
    <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
              {t.ruleContributions}
            </h3>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-0.5">
            {language === 'ta'
              ? 'விதிகளின் சதவீத பங்களிப்பு — மாதிரி தர்க்கம் (SHAP அல்ல)'
              : 'Deterministic rule weight contribution — not a black-box SHAP approximation.'}
          </p>
        </div>
        <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
          <BarChart3 className="w-4 h-4 text-[#4E9B5F]" />
        </div>
      </div>

      <div className="mt-4 space-y-3.5">
        {factors.map((factor) => {
          const barColor = {
            high: 'bg-rose-500',
            watch: 'bg-amber-500',
            low: 'bg-[#2D8A4E]',
            info: 'bg-blue-500',
          }[factor.severity];

          return (
            <div key={factor.id} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#1C2723] flex items-center gap-1.5">
                  <span>{language === 'ta' ? factor.titleTa : factor.title}</span>
                  {factor.isSatelliteContext && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200">
                      Context
                    </span>
                  )}
                </span>
                <div className="text-right">
                  <span className="font-bold text-[#1C2723]">{factor.contributionPercent}%</span>
                  <span className="text-[10px] text-[#83948E] ml-1">
                    (+{factor.weight} pts)
                  </span>
                </div>
              </div>

              {/* Accessible Bar with subtle animation */}
              <div 
                className="h-2.5 w-full bg-stone-100 rounded-full overflow-hidden flex"
                role="progressbar"
                aria-valuenow={factor.contributionPercent}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`${factor.title}: ${factor.contributionPercent}% contribution`}
              >
                <div
                  style={{ width: `${Math.max(2, factor.contributionPercent)}%` }}
                  className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] text-[#83948E]">
                <span>{language === 'ta' ? 'அளவீடு' : 'Observed'}: {factor.inputValue}</span>
                <span>{language === 'ta' ? factor.thresholdRuleTa : factor.thresholdRule}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
