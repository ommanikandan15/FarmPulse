# FarmPulse — Explainable Crop Stress Advisory
**Team:** PRIME ELITE  
**Tagline:** *“Don’t just tell the farmer what. Tell them why.”*  

FarmPulse is a production-grade, explainable agricultural intelligence web application designed for smallholder farmers and Farmer Producer Organizations (FPOs). Its defining capability is transparent, rule-backed crop stress assessment: **never show a stress score without showing the observations and agronomic rules/evidence behind it.**

Tailored for paddy clusters in Tamil Nadu, India (pilot scenario: Kaveripakkam cluster, Ranipet district), with full support across **6 local languages** (**English**, **தமிழ் (Tamil)**, **తెలుగు (Telugu)**, **हिन्दी (Hindi)**, **മലയാളം (Malayalam)**, and **ಕನ್ನಡ (Kannada)**) along with browser speech synthesis readouts.

---

## Key Features

### 1. Farm Information & Input Validation
- Enter or select farm/plot name, location, crop variety, growth stage (nursery, tillering, panicle initiation, flowering, grain filling, maturity), planting date, soil moisture (%), rain-free days, peak temperature (°C), humidity (%), and optional leaf photo.
- Real-time input validation clearly flagging missing sensor readings without ever silently inventing values.

### 2. Four Dedicated Crop-Stress Categories
Every analysis evaluates 4 independent dimensions:
1. **Water Stress**: Compounding rainfall deficit, soil moisture thresholds (<20% critical, 20–28% watch), and Sentinel-2 NDWI surface moisture context.
2. **Nutrient Stress**: Weekly canopy greenness deltas, Leaf Color Chart (LCC) benchmarks, and growth-stage nitrogen demand.
3. **Pest & Disease Risk**: Temperature & humidity microclimatic windows (blast spore incubation at 24–31°C with >80% RH; thrips/stem borer risk during hot dry spells) and leaf lesion screening.
4. **Heat Stress**: Peak thermal load against stage-specific physiological limits (≥35°C during panicle initiation/flowering impairs pollen viability).

Each category displays:
- Risk level (Low, Moderate, High)
- Supporting observations
- Likely contributing factors
- Plain language explanation (English & Tamil)
- Safe, non-chemical recommended next steps
- Missing information and limitations
- Data source & timestamp

### 3. Explainable AI — Our Main Differentiator
Every advisory systematically answers the **5 Core Questions**:
1. **What possible crop problem was identified?**
2. **Why does the system suspect this problem?** (Transparent agronomic principle)
3. **Which available inputs support the result?** (Itemized factor weights summing to 100%)
4. **What should the farmer check next?** (Sequential field check steps & safety warnings)
5. **How reliable is this recommendation and what are the limitations?** (Honest rule-based attribution; no black-box ML or fabricated SHAP claims)

### 4. 1-Click "Try Sample Farm" Demo Mode
- Instant 1-click button loads realistic verified data for a Kaveripakkam paddy field under moisture tension.
- One-click reset restores default scenario.

### 5. Google Maps Platform Satellite & Hybrid Overview
- Live interactive mapping powered by `@vis.gl/react-google-maps` with `AdvancedMarkerElement`.
- Kaveripakkam pilot cluster coordinates with risk markers (Green, Amber, Red).
- High-resolution Satellite, Hybrid, and Roadmap views with one-click toggle to schematic grid.

### 6. Reports & Historical Analysis Log
- Saves recent analyses in browser `localStorage` (`farmpulse_analysis_history`).
- Side-by-side comparison modal to compare two scenarios across all 4 stress metrics.
- Export to downloadable CSV and print-ready summary with clean demo watermarks.

### 7. Smart Farm Advisory & Non-Chemical Management
- Practical, non-chemical field actions: 10 cm subsoil test, Alternate Wetting and Drying (AWD), bund rodent/crab burrow sealing, morning scouting.
- Strict warnings to avoid synthetic urea or chemical sprays while plants are under moisture tension.
- Prompt reminders to consult local Agriculture Extension Officers (ADO/VAO).

### 8. Multi-Language Audio Accessibility
- Smooth language toggle across 6 languages with natural Tamil agricultural terminology.
- Web Speech API read-aloud buttons with graceful fallback.

---

## File Structure

```
├── index.html                                 # App shell with Noto Sans Tamil & Plus Jakarta Sans
├── metadata.json                              # Applet metadata
├── package.json                               # Dependencies and scripts
├── tsconfig.json                              # TypeScript configuration
├── vite.config.ts                             # Vite bundler configuration
├── README.md                                  # Documentation and architecture guide
└── src/
    ├── App.tsx                                # Main App shell & view routing
    ├── main.tsx                               # React 19 root entry
    ├── index.css                              # Tailwind v4 theme, palette tokens
    ├── types/
    │   └── index.ts                           # Data contracts for 4 categories, 5 questions, history
    ├── services/
    │   ├── advisoryEngine.ts                  # Deterministic 4-category explainable rules engine
    │   ├── advisoryEngine.test.ts             # Unit tests for low, high, missing, 4 cats & 5 questions
    │   ├── weatherService.ts                  # Open-Meteo weather adapter with synthetic fallback
    │   └── geminiService.ts                   # Optional Gemini Vision analysis
    ├── data/
    │   ├── demoData.ts                        # Kaveripakkam pilot plots and weather
    │   └── translations.ts                    # Multi-language dictionary (En, Ta, Te, Hi, Ml, Kn)
    ├── context/
    │   └── AppContext.tsx                     # State, history, speech synthesis, language, user profiles
    └── components/
        ├── layout/
        │   ├── Header.tsx                     # Brand, PRIME ELITE badge, region, language, alerts
        │   ├── Sidebar.tsx                    # Desktop navigation
        │   └── MobileNav.tsx                  # Mobile bottom navigation
        ├── common/
        │   ├── StatusBadge.tsx                # Accessible risk level badge
        │   ├── DataSourceBadge.tsx            # Data attribution badge
        │   ├── ExplainabilityModal.tsx        # "How this was assessed" transparent math popover
        │   └── VoicePlayerButton.tsx          # Web Speech Synthesis audio button
        ├── dashboard/
        │   ├── DashboardView.tsx              # Overview dashboard with KPIs, Google Maps, & alerts
        │   ├── GoogleMapsOverview.tsx         # Google Maps Platform satellite/hybrid overview
        │   ├── PlotMapSchematic.tsx           # Fallback schematic field health map
        │   ├── WeatherStrip.tsx               # 7-day weather strip
        │   ├── WhyThisAlertCard.tsx           # Compact evidence snapshot card
        │   └── PriorityActionsList.tsx        # Action checklist
        ├── analysis/
        │   └── FarmAnalysisView.tsx           # Farm Information form, Try Sample Farm, input validation
        ├── advisory/
        │   ├── ExplainableAdvisoryView.tsx     # 4 Crop-Stress categories cards with audio & safe actions
        │   ├── ExplanationInsightsView.tsx    # The 5 Core Explainability Answers deep-dive
        │   ├── FactorContributionChart.tsx     # Factor contribution percentage chart
        │   └── InteractiveScenarioTester.tsx  # Real-time "What-If" simulator
        ├── plots/
        │   ├── PlotExplorerView.tsx           # Search, filter, sort, grid/list view
        │   └── PlotDetailModal.tsx            # Detailed field summary & trend chart
        ├── leafcheck/
        │   └── LeafCheckView.tsx              # Image upload & symptom assistant
        ├── weather/
        │   └── WeatherTrendsView.tsx          # 7-day interactive SVG charts & hourly spray advisor
        ├── reports/
        │   └── ReportsView.tsx                # Analysis history log, comparison, CSV & printable report
        └── settings/
            └── SettingsView.tsx               # Units conversion, test runner, reset data
```

---

## Environment Variables

FarmPulse works **100% in Demo Mode out of the box** without any secret keys.
If you wish to enable the optional AI Vision feature on the Leaf Check page:

```env
# Optional: Enables Gemini 2.5 Flash visual second opinion in Leaf Check
GEMINI_API_KEY="your-gemini-api-key"
```

---

## Verification & Build

```bash
# Type check and lint
npm run lint

# Build for production
npm run build
```

---

## Agronomic Safety Boundaries

1. **Deterministic Rule Engine**: FarmPulse evaluates agronomic thresholds validated against Tamil Nadu Agriculture University (TNAU) guidelines. It does not hallucinate arbitrary machine-learning weights.
2. **Zero Chemical Endorsements**: The application strictly avoids prescribing commercial pesticide brand names or chemical dosages.
3. **Extension Officer Consultation**: High-risk advisories mandate consulting the local Block Agriculture Extension Officer before applying corrective inputs.
