import React from 'react';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import { VoicePlayerButton } from '../common/VoicePlayerButton';
import { ArrowRight, HelpCircle, AlertCircle } from 'lucide-react';

interface WhyThisAlertCardProps {
  onOpenExplainability: () => void;
  onNavigateToAdvisory: () => void;
}

export const WhyThisAlertCard: React.FC<WhyThisAlertCardProps> = ({
  onOpenExplainability,
  onNavigateToAdvisory,
}) => {
  const { selectedPlot, t, language } = useApp();
  const advisory = selectedPlot.advisory;

  const spokenText = language === 'ta'
    ? `${selectedPlot.nameTa}. ${advisory.headlineTa}. ${advisory.summaryTa}. ${advisory.primaryActionTa}`
    : `${selectedPlot.name}. ${advisory.headline}. ${advisory.summary}. Primary action: ${advisory.primaryAction}`;

  return (
    <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex items-start justify-between gap-2 pb-3 border-b border-[#E3E8DC]">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
                {t.whyThisAlertTitle}
              </h3>
              <StatusBadge level={advisory.riskLevel} size="sm" />
            </div>
            <p className="text-xs text-[#566761] mt-0.5">
              {language === 'ta' ? selectedPlot.nameTa : selectedPlot.name} • {selectedPlot.variety}
            </p>
          </div>

          <VoicePlayerButton textToRead={spokenText} size="sm" />
        </div>

        {/* Headline & Summary */}
        <div className="mt-3.5 space-y-2">
          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <h4 className="font-bold text-xs sm:text-sm text-[#1C2723]">
              {language === 'ta' ? advisory.headlineTa : advisory.headline}
            </h4>
            <p className="text-xs text-[#566761] mt-1 leading-relaxed">
              {language === 'ta' ? advisory.summaryTa : advisory.summary}
            </p>
          </div>

          {/* Top Triggered Factors Preview */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#566761] block">
              {language === 'ta' ? 'தூண்டிய காரணிகள் (விதிக் குறியீடுகள்)' : 'Top Triggered Rules & Ground Evidence'}
            </span>
            <div className="space-y-1.5">
              {advisory.evidenceList.slice(0, 3).map((factor) => (
                <div
                  key={factor.id}
                  className="flex items-start justify-between gap-2 p-2 rounded-lg bg-stone-50 border border-stone-200 text-xs"
                >
                  <div className="space-y-0.5">
                    <span className="font-semibold text-[#1C2723] block">
                      {language === 'ta' ? factor.titleTa : factor.title}
                    </span>
                    <span className="text-[11px] text-[#566761]">
                      {language === 'ta' ? factor.thresholdRuleTa : factor.thresholdRule}
                    </span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-rose-700 block text-xs">
                      {factor.inputValue}
                    </span>
                    <span className="text-[10px] text-[#83948E]">
                      +{factor.weight} pts
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="mt-4 pt-3 border-t border-[#E3E8DC] flex items-center justify-between">
        <button
          onClick={onOpenExplainability}
          className="text-xs text-[#566761] hover:text-[#173F35] flex items-center gap-1 font-medium"
        >
          <HelpCircle className="w-3.5 h-3.5 text-[#4E9B5F]" />
          <span>{t.howThisWasAssessed}</span>
        </button>

        <button
          onClick={onNavigateToAdvisory}
          className="inline-flex items-center gap-1 text-xs font-bold text-[#173F35] hover:text-[#1E4D41] bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-200 transition-colors"
        >
          <span>{language === 'ta' ? 'முழு ஆய்வு' : 'Deep Dive'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
