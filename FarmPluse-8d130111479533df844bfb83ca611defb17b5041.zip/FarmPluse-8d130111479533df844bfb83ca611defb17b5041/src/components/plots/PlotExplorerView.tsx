import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Plot, RiskLevel } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { DataSourceBadge } from '../common/DataSourceBadge';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  LayoutGrid, 
  List, 
  ChevronRight, 
  AlertCircle,
  MapPin,
  Calendar,
  Layers,
  Info,
  Compass,
  Plus,
  Sprout
} from 'lucide-react';
import { MarkLandModal } from '../maps/MarkLandModal';
import { getCropInfo } from '../../data/cropLandData';

interface PlotExplorerViewProps {
  onSelectPlotDetail: (plot: Plot) => void;
}

export const PlotExplorerView: React.FC<PlotExplorerViewProps> = ({ onSelectPlotDetail }) => {
  const { plots, t, language, formatArea, formatTemp, setActiveTab } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'all' | RiskLevel>('all');
  const [cropFilter, setCropFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'risk' | 'area'>('recent');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isMarkLandOpen, setIsMarkLandOpen] = useState(false);

  // Extract unique crops
  const availableCrops = useMemo(() => {
    return Array.from(new Set(plots.map((p) => p.variety)));
  }, [plots]);

  // Filtered & sorted plots
  const filteredPlots = useMemo(() => {
    return plots
      .filter((plot) => {
        // Search
        const query = searchQuery.toLowerCase().trim();
        const matchesQuery = 
          plot.name.toLowerCase().includes(query) ||
          plot.nameTa.toLowerCase().includes(query) ||
          plot.variety.toLowerCase().includes(query) ||
          plot.farmerName.toLowerCase().includes(query) ||
          plot.farmerNameTa.toLowerCase().includes(query);

        if (!matchesQuery) return false;

        // Risk filter
        if (riskFilter !== 'all' && plot.advisory.riskLevel !== riskFilter) {
          return false;
        }

        // Crop filter
        if (cropFilter !== 'all' && plot.variety !== cropFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'risk') {
          return b.advisory.stressScore - a.advisory.stressScore;
        }
        if (sortBy === 'area') {
          return b.areaAcres - a.areaAcres;
        }
        // Most recent
        return new Date(b.latestObservation.timestamp).getTime() - new Date(a.latestObservation.timestamp).getTime();
      });
  }, [plots, searchQuery, riskFilter, cropFilter, sortBy]);

  return (
    <div className="space-y-5 pb-12">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {t.navPlots}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span>
              {language === 'ta'
                ? 'மாதிரி நெல் நிலங்கள் — கள அளவீடுகள், மண் ஈரப்பதம் மற்றும் விதிகள்'
                : 'Fictional demo plots for Kaveripakkam pilot scenario. Not real farmer identities.'}
            </span>
          </p>
        </div>

        {/* Actions & View Mode Toggle */}
        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('fieldmap')}
            className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-[#173F35] border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-700" />
            <span>{language === 'te' ? 'భూమి మ్యాప్ చూడండి' : language === 'ta' ? 'புல வரைபடம்' : 'Field Map'}</span>
          </button>

          <button
            onClick={() => setIsMarkLandOpen(true)}
            className="px-3 py-2 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-300" />
            <span>{language === 'te' ? '+ పొలం మార్క్ చేయండి' : language === 'ta' ? '+ நிலத்தைக் குறிக்க' : '+ Mark Land'}</span>
          </button>

          <div className="flex items-center gap-1 bg-[#F7F8F4] p-1 rounded-xl border border-[#E3E8DC]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
              title={t.viewGrid}
              aria-label={t.viewGrid}
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">{t.viewGrid}</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === 'list'
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
              title={t.viewList}
              aria-label={t.viewList}
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">{t.viewList}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-[#E3E8DC] shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#83948E] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.plotSearchPlaceholder}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-[#E3E8DC] text-xs focus:outline-hidden focus:border-[#4E9B5F] focus:ring-1 focus:ring-[#4E9B5F]"
            />
          </div>

          {/* Risk Level Filter */}
          <div className="flex items-center gap-1.5">
            <Filter className="w-4 h-4 text-[#83948E] shrink-0" />
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value as 'all' | RiskLevel)}
              className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723] focus:outline-hidden focus:border-[#4E9B5F]"
            >
              <option value="all">{t.filterAllRisk}</option>
              <option value="low">{t.riskLow}</option>
              <option value="watch">{t.riskWatch}</option>
              <option value="high">{t.riskHigh}</option>
            </select>
          </div>

          {/* Crop Variety Filter */}
          <div className="flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-[#83948E] shrink-0" />
            <select
              value={cropFilter}
              onChange={(e) => setCropFilter(e.target.value)}
              className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723] focus:outline-hidden focus:border-[#4E9B5F]"
            >
              <option value="all">{t.filterAllCrops}</option>
              {availableCrops.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="w-4 h-4 text-[#83948E] shrink-0" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'recent' | 'risk' | 'area')}
              className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723] focus:outline-hidden focus:border-[#4E9B5F]"
            >
              <option value="recent">{t.sortByRecent}</option>
              <option value="risk">{t.sortByRisk}</option>
              <option value="area">{t.sortByArea}</option>
            </select>
          </div>
        </div>

        {/* Filter Results Status */}
        <div className="flex items-center justify-between text-xs text-[#566761] pt-1 border-t border-[#E3E8DC]">
          <span>
            {language === 'ta' ? 'காட்டப்படும் நிலங்கள்' : 'Showing'} {filteredPlots.length} {language === 'ta' ? 'நிலங்கள்' : 'plots'}
          </span>
          {(searchQuery || riskFilter !== 'all' || cropFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setRiskFilter('all');
                setCropFilter('all');
              }}
              className="text-xs font-semibold text-[#4E9B5F] hover:underline"
            >
              {language === 'ta' ? 'வடிகட்டிகளை அழிக்க' : 'Reset filters'}
            </button>
          )}
        </div>
      </div>

      {/* Empty State */}
      {filteredPlots.length === 0 && (
        <div className="bg-white p-12 text-center rounded-2xl border border-[#E3E8DC] space-y-3">
          <AlertCircle className="w-8 h-8 text-[#83948E] mx-auto" />
          <h3 className="font-bold text-base text-[#1C2723]">{t.noPlotsFound}</h3>
          <p className="text-xs text-[#566761]">
            {language === 'ta' ? 'வேறு தேடல் அல்லது வடிகட்டிகளை தேர்வு செய்யவும்.' : 'Try adjusting your search terms or clearing active filters.'}
          </p>
        </div>
      )}

      {/* Grid Mode */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPlots.map((plot) => {
            const crop = getCropInfo(plot.variety || plot.cropType);
            return (
              <div
                key={plot.id}
                onClick={() => onSelectPlotDetail(plot)}
                className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs hover:border-[#4E9B5F] transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span className="text-3xl p-1.5 rounded-xl bg-emerald-50 border border-emerald-200 shrink-0">
                        {crop.emoji}
                      </span>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] font-mono font-bold text-[#83948E]">
                            #{plot.id.toUpperCase()}
                          </span>
                          {plot.surveyNumber && (
                            <span className="text-[10px] bg-gray-100 text-gray-700 font-bold px-1.5 py-0.2 rounded">
                              {plot.surveyNumber}
                            </span>
                          )}
                        </div>
                        <h3 className="font-bold text-base text-[#1C2723] group-hover:text-[#173F35]">
                          {language === 'te' && plot.nameTe ? plot.nameTe : language === 'ta' ? plot.nameTa : plot.name}
                        </h3>
                        <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                          {plot.variety}
                        </p>
                        <p className="text-[11px] text-[#566761]">
                          {language === 'te' && plot.farmerNameTe ? plot.farmerNameTe : language === 'ta' ? plot.farmerNameTa : plot.farmerName} • {formatArea(plot.areaAcres)}
                        </p>
                      </div>
                    </div>
                    <StatusBadge level={plot.advisory.riskLevel} size="sm" />
                  </div>

                <div className="mt-3 p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[#566761]">{t.growthStage}:</span>
                    <span className="font-semibold text-[#1C2723]">
                      {plot.growthStage.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#566761]">{t.soilMoisture}:</span>
                    <span className={`font-bold ${plot.latestObservation.soilMoisturePercent < 20 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
                      {plot.latestObservation.soilMoisturePercent}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#566761]">{t.daysWithoutRain}:</span>
                    <span className={`font-bold ${plot.latestObservation.daysWithoutRain >= 7 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
                      {plot.latestObservation.daysWithoutRain} days
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#566761]">{t.weeklyGreenness}:</span>
                    <span className={`font-bold ${plot.latestObservation.weeklyGreennessChangePercent <= -12 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
                      {plot.latestObservation.weeklyGreennessChangePercent >= 0 ? '+' : ''}{plot.latestObservation.weeklyGreennessChangePercent}%
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#E3E8DC] flex items-center justify-between text-xs">
                <DataSourceBadge type={plot.latestObservation.sourceType} />
                <span className="font-semibold text-[#4E9B5F] group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                  <span>{t.viewPlotDetails}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
            );
          })}
        </div>
      )}

      {/* List Mode */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-2xl border border-[#E3E8DC] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F8F4] border-b border-[#E3E8DC] text-[#566761] font-semibold uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Plot & Variety</th>
                  <th className="p-3.5">Farmer & Area</th>
                  <th className="p-3.5">Risk Level</th>
                  <th className="p-3.5">Soil Moisture</th>
                  <th className="p-3.5">Rain Gap</th>
                  <th className="p-3.5">Greenness</th>
                  <th className="p-3.5">Data Source</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E8DC]">
                {filteredPlots.map((plot) => (
                  <tr
                    key={plot.id}
                    onClick={() => onSelectPlotDetail(plot)}
                    className="hover:bg-[#F7F8F4] transition-colors cursor-pointer"
                  >
                    <td className="p-3.5">
                      <span className="font-bold text-[#1C2723] block text-sm">
                        {language === 'ta' ? plot.nameTa : plot.name}
                      </span>
                      <span className="text-[#566761] text-[11px]">
                        {language === 'ta' ? plot.varietyTa : plot.variety}
                      </span>
                    </td>
                    <td className="p-3.5 text-[#566761]">
                      <span className="text-[#1C2723] font-medium block">
                        {language === 'ta' ? plot.farmerNameTa : plot.farmerName}
                      </span>
                      <span>{formatArea(plot.areaAcres)}</span>
                    </td>
                    <td className="p-3.5">
                      <StatusBadge level={plot.advisory.riskLevel} size="sm" />
                    </td>
                    <td className="p-3.5 font-bold">
                      <span className={plot.latestObservation.soilMoisturePercent < 20 ? 'text-rose-600' : 'text-[#1C2723]'}>
                        {plot.latestObservation.soilMoisturePercent}%
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className={plot.latestObservation.daysWithoutRain >= 7 ? 'text-rose-600 font-bold' : 'text-[#566761]'}>
                        {plot.latestObservation.daysWithoutRain} days
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className={plot.latestObservation.weeklyGreennessChangePercent <= -12 ? 'text-rose-600 font-bold' : 'text-[#566761]'}>
                        {plot.latestObservation.weeklyGreennessChangePercent >= 0 ? '+' : ''}{plot.latestObservation.weeklyGreennessChangePercent}%
                      </span>
                    </td>
                    <td className="p-3.5">
                      <DataSourceBadge type={plot.latestObservation.sourceType} />
                    </td>
                    <td className="p-3.5 text-right">
                      <button className="text-[#4E9B5F] font-bold hover:underline">
                        {t.viewPlotDetails}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Mark Land Modal */}
      <MarkLandModal
        isOpen={isMarkLandOpen}
        onClose={() => setIsMarkLandOpen(false)}
      />
    </div>
  );
};
