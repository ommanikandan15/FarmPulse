import React from 'react';
import { Plot } from '../../types';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import { DataSourceBadge } from '../common/DataSourceBadge';
import { VoicePlayerButton } from '../common/VoicePlayerButton';
import { 
  X, 
  Droplet, 
  Calendar, 
  Thermometer, 
  TrendingUp, 
  Layers, 
  MapPin, 
  ShieldAlert, 
  Database,
  ArrowRight
} from 'lucide-react';

import { getCropInfo } from '../../data/cropLandData';

interface PlotDetailModalProps {
  plot: Plot | null;
  onClose: () => void;
  onNavigateToAdvisory: (plot: Plot) => void;
}

export const PlotDetailModal: React.FC<PlotDetailModalProps> = ({
  plot,
  onClose,
  onNavigateToAdvisory,
}) => {
  const { t, language, formatTemp, formatArea } = useApp();

  if (!plot) return null;

  const advisory = plot.advisory;
  const obs = plot.latestObservation;
  const crop = getCropInfo(plot.variety || plot.cropType);

  const spokenText = language === 'te'
    ? `${plot.nameTe || plot.name}. ${advisory.headline}. ${advisory.summary}.`
    : language === 'ta'
    ? `${plot.nameTa}. ${advisory.headlineTa}. ${advisory.summaryTa}. ${advisory.primaryActionTa}`
    : `${plot.name}. ${advisory.headline}. ${advisory.summary}. Primary action: ${advisory.primaryAction}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="plot-detail-title"
    >
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#E3E8DC] p-5 sm:p-6 text-[#1C2723]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#E3E8DC] pb-4">
          <div className="flex items-start gap-3">
            <span className="text-4xl p-2 rounded-2xl bg-emerald-50 border border-emerald-200 shrink-0">
              {crop.emoji}
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold text-[#566761] bg-[#F7F8F4] px-2 py-0.5 rounded border border-[#E3E8DC]">
                  {plot.id.toUpperCase()}
                </span>
                {plot.surveyNumber && (
                  <span className="text-[11px] font-bold text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
                    {plot.surveyNumber}
                  </span>
                )}
                <h2 id="plot-detail-title" className="text-lg sm:text-xl font-bold text-[#173F35]">
                  {language === 'te' && plot.nameTe ? plot.nameTe : language === 'ta' ? plot.nameTa : plot.name}
                </h2>
                <StatusBadge level={advisory.riskLevel} size="md" />
                <DataSourceBadge type={obs.sourceType} />
              </div>

              <p className="text-xs text-[#566761] mt-1 flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-emerald-800">
                  {language === 'te' && plot.cropTypeTe ? plot.cropTypeTe : language === 'ta' && plot.cropTypeTa ? plot.cropTypeTa : plot.variety}
                </span>
                <span>•</span>
                <span>{formatArea(plot.areaAcres)}</span>
                <span>•</span>
                <span className="flex items-center gap-0.5">
                  <MapPin className="w-3 h-3 text-[#4E9B5F]" />
                  {language === 'te' && plot.locationNameTe ? plot.locationNameTe : language === 'ta' ? plot.locationNameTa : plot.locationName}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <VoicePlayerButton textToRead={spokenText} size="sm" />
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
              aria-label={t.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Demo Notice */}
        <div className="mt-3 px-3 py-1.5 rounded-lg bg-emerald-50/70 border border-emerald-200 text-[11px] text-emerald-800 flex items-center justify-between">
          <span>{language === 'ta' ? 'மாதிரி நிலத் தரவு — உண்மையான விவசாயி தரவு அல்ல' : 'Illustrative synthetic demo plot — not real farmer confidential data'}</span>
          <span className="font-mono text-[10px] text-emerald-700">Ref: #{plot.id}</span>
        </div>

        {/* Core Field Metrics Cards */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <span className="text-[10px] text-[#566761] uppercase tracking-wider block font-semibold">
              {t.soilMoisture}
            </span>
            <span className={`text-lg font-bold block mt-0.5 ${obs.soilMoisturePercent < 20 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
              {obs.soilMoisturePercent}%
            </span>
            <span className="text-[10px] text-[#83948E]">
              {obs.soilMoisturePercent < 20 ? 'Critical deficit' : 'Standard zone'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <span className="text-[10px] text-[#566761] uppercase tracking-wider block font-semibold">
              {t.daysWithoutRain}
            </span>
            <span className={`text-lg font-bold block mt-0.5 ${obs.daysWithoutRain >= 7 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
              {obs.daysWithoutRain} days
            </span>
            <span className="text-[10px] text-[#83948E]">
              Last rain: 15 Oct
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <span className="text-[10px] text-[#566761] uppercase tracking-wider block font-semibold">
              {t.weeklyGreenness}
            </span>
            <span className={`text-lg font-bold block mt-0.5 ${obs.weeklyGreennessChangePercent <= -12 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
              {obs.weeklyGreennessChangePercent >= 0 ? '+' : ''}{obs.weeklyGreennessChangePercent}%
            </span>
            <span className="text-[10px] text-[#83948E]">
              7-day canopy index
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
            <span className="text-[10px] text-[#566761] uppercase tracking-wider block font-semibold">
              {t.temperature}
            </span>
            <span className="text-lg font-bold block mt-0.5 text-[#1C2723]">
              {formatTemp(obs.temperatureCelsius)}
            </span>
            <span className="text-[10px] text-[#83948E]">
              RH: {obs.humidityPercent}%
            </span>
          </div>
        </div>

        {/* Observation History Trend Chart (Clean Accessible SVG) */}
        <div className="mt-4 p-4 rounded-xl border border-[#E3E8DC] bg-white">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#E3E8DC]">
            <h4 className="font-bold text-xs text-[#173F35]">
              {language === 'ta' ? 'மண் ஈரப்பதம் & பசுமை போக்கு (சமீபத்திய 4 பதிவுகள்)' : 'Observation Timeline Trend (Soil Moisture & Canopy)'}
            </h4>
            <span className="text-[10px] text-[#566761]">
              {language === 'ta' ? 'அனைத்து அளவுகளும் மாதிரி' : 'Observed sensor intervals'}
            </span>
          </div>

          {/* SVG Trend Graph */}
          <div className="w-full h-36 flex items-end justify-between gap-4 pt-4 px-2">
            {plot.history.map((hist, idx) => {
              const moistureHeight = Math.max(10, Math.min(100, (hist.soilMoisturePercent / 45) * 100));
              return (
                <div key={hist.id} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div className="text-[10px] font-bold text-[#1C2723] mb-1 group-hover:scale-110 transition-transform">
                    {hist.soilMoisturePercent}%
                  </div>
                  <div className="w-full max-w-[40px] bg-stone-100 rounded-t-lg h-24 flex items-end p-0.5">
                    <div 
                      style={{ height: `${moistureHeight}%` }}
                      className={`w-full rounded-t-md transition-all ${
                        hist.soilMoisturePercent < 20 
                          ? 'bg-rose-500' 
                          : hist.soilMoisturePercent < 28 
                          ? 'bg-amber-500' 
                          : 'bg-[#2D8A4E]'
                      }`}
                    />
                  </div>
                  <span className="text-[10px] text-[#566761] mt-1.5">
                    {hist.timestamp.split('T')[0].split('-').slice(1).join('/')}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-2 flex items-center justify-center gap-4 text-[10px] text-[#566761]">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#2D8A4E]" />
              <span>&gt;28% Optimal</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" />
              <span>20–28% Watch</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" />
              <span>&lt;20% Critical</span>
            </div>
          </div>
        </div>

        {/* Explainable Evidence Box */}
        <div className="mt-4 p-4 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs uppercase tracking-wider text-[#173F35]">
              {t.whyWeThinkThis}
            </h4>
            <span className="text-[11px] font-bold text-rose-800">
              {language === 'ta' ? 'மதிப்பீட்டு மதிப்பெண்' : 'Score'}: {advisory.stressScore} / 100
            </span>
          </div>

          <div className="space-y-2">
            {advisory.evidenceList.map((factor) => (
              <div key={factor.id} className="p-2.5 bg-white rounded-lg border border-[#E3E8DC] text-xs">
                <div className="flex items-center justify-between font-semibold text-[#1C2723]">
                  <span>{language === 'ta' ? factor.titleTa : factor.title}</span>
                  <span className="text-rose-700 font-mono">+{factor.weight} pts ({factor.contributionPercent}%)</span>
                </div>
                <p className="text-[11px] text-[#566761] mt-1 leading-relaxed">
                  {language === 'ta' ? factor.explanationTa : factor.explanation}
                </p>
                <div className="mt-1 text-[10px] text-[#83948E] flex items-center gap-2">
                  <span>{language === 'ta' ? 'அளவீடு' : 'Value'}: <strong className="text-[#1C2723]">{factor.inputValue}</strong></span>
                  <span>•</span>
                  <span>{language === 'ta' ? 'விதி' : 'Rule'}: {language === 'ta' ? factor.thresholdRuleTa : factor.thresholdRule}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Primary Action Guidance */}
        <div className="mt-4 p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1">
            <ShieldAlert className="w-4 h-4 text-amber-700" />
            <span>{t.whatToDoNext}</span>
          </div>
          <p className="text-amber-950 font-medium leading-relaxed">
            {language === 'ta' ? advisory.primaryActionTa : advisory.primaryAction}
          </p>
        </div>

        {/* Footer Buttons */}
        <div className="mt-5 pt-3 border-t border-[#E3E8DC] flex items-center justify-between">
          <div className="text-[11px] text-[#566761] flex items-center gap-1">
            <Database className="w-3.5 h-3.5 text-[#4E9B5F]" />
            <span>{t.dataCoverage}: {advisory.dataCoveragePercent}% ({advisory.availableFieldsCount}/{advisory.totalFieldsCount} inputs)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onNavigateToAdvisory(plot);
              }}
              className="px-4 py-2 bg-[#173F35] text-white rounded-xl text-xs font-bold hover:bg-[#1E4D41] transition-colors flex items-center gap-1.5"
            >
              <span>{language === 'ta' ? 'ஆலோசனை இயந்திரத்தில் காண்க' : 'Open in Scenario Tester'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
