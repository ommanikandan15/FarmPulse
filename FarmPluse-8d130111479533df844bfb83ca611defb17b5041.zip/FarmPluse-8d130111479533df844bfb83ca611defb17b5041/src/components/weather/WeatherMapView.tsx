import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  CloudRain, 
  Thermometer, 
  Wind, 
  Droplets, 
  Layers, 
  MapPin, 
  Maximize2, 
  Minimize2, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Compass, 
  ShieldAlert, 
  Info,
  Calendar,
  Sun,
  Flame,
  CloudSun
} from 'lucide-react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow 
} from '@vis.gl/react-google-maps';

export interface WeatherStationPoint {
  id: string;
  name: string;
  nameTa: string;
  district: string;
  basin: string;
  lat: number;
  lng: number;
  temp: number;
  tempForecast24h: number;
  rainMm: number;
  rainForecast24h: number;
  humidity: number;
  windKmh: number;
  windDir: string;
  status: 'normal' | 'watch' | 'alert';
  advisoryEn: string;
  advisoryTa: string;
}

export const TAMIL_NADU_WEATHER_STATIONS: WeatherStationPoint[] = [
  {
    id: 'kaveripakkam',
    name: 'Kaveripakkam Pilot Basin',
    nameTa: 'காவேரிப்பாக்கம் மாதிரி பாசனம்',
    district: 'Ranipet',
    basin: 'Palar River Basin',
    lat: 12.8982,
    lng: 79.4674,
    temp: 36.5,
    tempForecast24h: 37.2,
    rainMm: 0,
    rainForecast24h: 1.5,
    humidity: 38,
    windKmh: 14,
    windDir: 'ENE',
    status: 'alert',
    advisoryEn: 'High thermal stress alert. Panicle initiation requires standing water (2-3 cm) to prevent spikelet sterility.',
    advisoryTa: 'கடும் வெப்ப எச்சரிக்கை. கதிர் உருவாகும் தருணத்தில் மலட்டுத்தன்மையை தவிர்க்க 2-3 செ.மீ நீர் தேக்குதல் அவசியம்.',
  },
  {
    id: 'thanjavur',
    name: 'Thanjavur Delta Station',
    nameTa: 'தஞ்சாவூர் டெல்டா நிலையம்',
    district: 'Thanjavur',
    basin: 'Cauvery Lower Delta',
    lat: 10.7870,
    lng: 79.1378,
    temp: 33.2,
    tempForecast24h: 32.5,
    rainMm: 12.4,
    rainForecast24h: 18.0,
    humidity: 82,
    windKmh: 18,
    windDir: 'E',
    status: 'watch',
    advisoryEn: 'High humidity and sporadic rain. Watch for blast lesion spots on upper foliage. Postpone urea top dressing.',
    advisoryTa: 'அதிக காற்றின் ஈரப்பதம் மற்றும் சாரல் மழை. குலை நோய் பரவ வாய்ப்பு; யூரியா மேலுரம் இடுவதை தள்ளிப்போடவும்.',
  },
  {
    id: 'madurai',
    name: 'Madurai Agricultural Cluster',
    nameTa: 'மதுரை வேளாண் மண்டலம்',
    district: 'Madurai',
    basin: 'Vaigai Basin',
    lat: 9.9252,
    lng: 78.1198,
    temp: 35.8,
    tempForecast24h: 36.0,
    rainMm: 0,
    rainForecast24h: 0,
    humidity: 44,
    windKmh: 12,
    windDir: 'NE',
    status: 'watch',
    advisoryEn: 'Dry north-easterly wind. Evapotranspiration is 5.4 mm/day. Schedule irrigation before 10 AM.',
    advisoryTa: 'வறண்ட வடகிழக்கு காற்று. நீராவிப்போக்கு அதிகம்; காலை 10 மணிக்குள் பாசனம் செய்து முடிக்கவும்.',
  },
  {
    id: 'coimbatore',
    name: 'Coimbatore Agro Zone',
    nameTa: 'கோயம்புத்தூர் வேளாண் வலயம்',
    district: 'Coimbatore',
    basin: 'Noyyal Basin',
    lat: 11.0168,
    lng: 76.9558,
    temp: 30.5,
    tempForecast24h: 31.0,
    rainMm: 3.2,
    rainForecast24h: 5.0,
    humidity: 65,
    windKmh: 16,
    windDir: 'SW',
    status: 'normal',
    advisoryEn: 'Optimal microclimate for tillering paddy and millets. Soil moisture remains adequate.',
    advisoryTa: 'பயிர் தூர்கட்டுதலுக்கு உகந்த சூழல். மண் ஈரப்பதம் சீராக உள்ளது.',
  },
  {
    id: 'tiruvannamalai',
    name: 'Tiruvannamalai Dryland Hub',
    nameTa: 'திருவண்ணாமலை வறண்ட நில வலயம்',
    district: 'Tiruvannamalai',
    basin: 'Cheyyar Basin',
    lat: 12.2253,
    lng: 79.0747,
    temp: 35.0,
    tempForecast24h: 35.8,
    rainMm: 0,
    rainForecast24h: 0.2,
    humidity: 46,
    windKmh: 11,
    windDir: 'NE',
    status: 'watch',
    advisoryEn: 'Soil moisture depleting in red loam tracts. Alternate wetting and drying interval recommended at 4 days.',
    advisoryTa: 'செம்மண் பகுதியில் ஈரப்பதம் குறைகிறது; 4 நாட்கள் இடைவெளியில் சுழற்சி முறையில் பாசனம் செய்யவும்.',
  },
  {
    id: 'trichy',
    name: 'Tiruchirappalli Srirangam Basin',
    nameTa: 'திருச்சிராப்பள்ளி ஸ்ரீரங்கம் பகுதி',
    district: 'Tiruchirappalli',
    basin: 'Cauvery Central',
    lat: 10.7905,
    lng: 78.7047,
    temp: 34.2,
    tempForecast24h: 34.0,
    rainMm: 1.0,
    rainForecast24h: 4.5,
    humidity: 62,
    windKmh: 15,
    windDir: 'ENE',
    status: 'normal',
    advisoryEn: 'Moderate conditions. Normal paddy vegetative development reported across Cauvery distributary channels.',
    advisoryTa: 'மிதமான வானிலை. நெற்பயிர் வளர்ச்சி சீராக உள்ளது.',
  },
];

type WeatherLayerType = 'radar' | 'temp' | 'wind' | 'humidity';
type TimeScrubberStep = 0 | 3 | 6 | 12 | 24 | 48;

export const WeatherMapView: React.FC = () => {
  const { t, language, speakText, stopSpeaking, isSpeaking } = useApp();

  const [activeLayer, setActiveLayer] = useState<WeatherLayerType>('radar');
  const [activeTime, setActiveTime] = useState<TimeScrubberStep>(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedStation, setSelectedStation] = useState<WeatherStationPoint>(TAMIL_NADU_WEATHER_STATIONS[0]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [useGoogleMaps, setUseGoogleMaps] = useState(true);

  const apiKey = (import.meta as unknown as { env: Record<string, string> }).env?.VITE_GOOGLE_MAPS_API_KEY || 
                 'AIzaSyAG2GcmSByW4dTJeWukaabUChbBAhaQFEk';

  // Animated time scrubber
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setActiveTime((prev) => {
          if (prev === 0) return 3;
          if (prev === 3) return 6;
          if (prev === 6) return 12;
          if (prev === 12) return 24;
          if (prev === 24) return 48;
          return 0;
        });
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const getStationStatusColor = (status: string) => {
    switch (status) {
      case 'alert': return '#DC2626';
      case 'watch': return '#D97706';
      default: return '#2D8A4E';
    }
  };

  const getLayerColor = (st: WeatherStationPoint) => {
    if (activeLayer === 'radar') {
      const rain = activeTime === 0 ? st.rainMm : st.rainForecast24h;
      if (rain > 10) return 'rgba(37, 99, 235, 0.75)';
      if (rain > 2) return 'rgba(59, 130, 246, 0.65)';
      if (rain > 0) return 'rgba(96, 165, 250, 0.45)';
      return 'rgba(209, 213, 219, 0.3)';
    }
    if (activeLayer === 'temp') {
      const temp = activeTime === 0 ? st.temp : st.tempForecast24h;
      if (temp >= 36) return 'rgba(239, 68, 68, 0.75)';
      if (temp >= 33) return 'rgba(245, 158, 11, 0.65)';
      return 'rgba(34, 197, 94, 0.65)';
    }
    if (activeLayer === 'humidity') {
      if (st.humidity >= 80) return 'rgba(30, 64, 175, 0.75)';
      if (st.humidity >= 60) return 'rgba(59, 130, 246, 0.55)';
      return 'rgba(251, 191, 36, 0.55)';
    }
    // wind
    return 'rgba(16, 185, 129, 0.65)';
  };

  const currentSummary = language === 'ta'
    ? `${selectedStation.nameTa}: வெப்பநிலை ${selectedStation.temp}°C, மழை ${selectedStation.rainMm} மி.மீ, காற்றின் ஈரப்பதம் ${selectedStation.humidity}%, காற்று வேகம் ${selectedStation.windKmh} கி.மீ/மணி. ${selectedStation.advisoryTa}`
    : `${selectedStation.name} (${selectedStation.district}): Temperature ${selectedStation.temp}°C, Rainfall ${selectedStation.rainMm} mm, Humidity ${selectedStation.humidity}%, Wind ${selectedStation.windKmh} km/h from ${selectedStation.windDir}. ${selectedStation.advisoryEn}`;

  return (
    <div className={`space-y-4 pb-12 ${isFullscreen ? 'fixed inset-0 z-50 bg-[#F7F8F4] p-4 flex flex-col overflow-y-auto' : ''}`}>
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#173F35] to-[#255e50] text-white flex items-center justify-center shadow-xs">
              <CloudRain className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35] flex items-center gap-2">
                {language === 'ta' ? 'வேளாண் வானிலை வரைபடம்' : 'Interactive Agricultural Weather Map'}
              </h1>
              <p className="text-xs text-[#566761] mt-0.5">
                {language === 'ta'
                  ? 'மழை ரேடார், வெப்பப் பரவல் மற்றும் காற்று திசை நேரலை மேலோட்டம்'
                  : 'Live precipitation radar, thermal stress heatmaps, and wind velocity contours across Tamil Nadu.'}
              </p>
            </div>
          </div>
        </div>

        {/* Controls Bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setUseGoogleMaps(!useGoogleMaps)}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-[#E3E8DC] bg-[#F7F8F4] text-[#173F35] hover:bg-gray-100 transition-all"
          >
            {useGoogleMaps ? 'Google Maps Hybrid' : 'High-Contrast Geospatial'}
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 text-xs font-semibold rounded-lg border border-[#E3E8DC] bg-[#F7F8F4] text-[#173F35] hover:bg-gray-100 transition-all"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Layer Toggles & Time Scrubber */}
      <div className="bg-white p-4 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Layer Selection */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-[#566761] mr-1 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5" />
            {language === 'ta' ? 'அடுக்குகள்:' : 'Layers:'}
          </span>

          <button
            onClick={() => setActiveLayer('radar')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeLayer === 'radar'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-[#F7F8F4] text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
            }`}
          >
            <CloudRain className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'மழை ரேடார்' : 'Rain Radar'}</span>
          </button>

          <button
            onClick={() => setActiveLayer('temp')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeLayer === 'temp'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-[#F7F8F4] text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
            }`}
          >
            <Thermometer className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'வெப்பநிலை' : 'Thermal Map'}</span>
          </button>

          <button
            onClick={() => setActiveLayer('wind')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeLayer === 'wind'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-[#F7F8F4] text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'காற்று வேகம்' : 'Wind Vectors'}</span>
          </button>

          <button
            onClick={() => setActiveLayer('humidity')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeLayer === 'humidity'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-[#F7F8F4] text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
            }`}
          >
            <Droplets className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'ஈரப்பதம்' : 'Humidity'}</span>
          </button>
        </div>

        {/* Time Timeline / Scrubber */}
        <div className="flex items-center gap-2 bg-[#F7F8F4] p-1.5 rounded-xl border border-[#E3E8DC] self-start md:self-auto">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1.5 bg-white text-[#173F35] hover:bg-emerald-50 rounded-lg border border-[#E3E8DC] transition-all"
            title={isPlaying ? 'Pause timeline' : 'Play timeline animation'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 text-emerald-700" /> : <Play className="w-3.5 h-3.5 text-emerald-700" />}
          </button>

          {([0, 3, 6, 12, 24, 48] as TimeScrubberStep[]).map((hr) => (
            <button
              key={hr}
              onClick={() => {
                setIsPlaying(false);
                setActiveTime(hr);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                activeTime === hr
                  ? 'bg-[#173F35] text-white shadow-xs'
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
            >
              {hr === 0 ? (language === 'ta' ? 'இப்போது' : 'Now') : `+${hr}h`}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Map Stage (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-[#E3E8DC] overflow-hidden shadow-xs relative min-h-[460px] h-[520px]">
          {useGoogleMaps ? (
            <APIProvider apiKey={apiKey}>
              <Map
                defaultCenter={{ lat: 11.2, lng: 78.8 }}
                defaultZoom={7.4}
                mapId="farmpulse-weather-map"
                mapTypeId="hybrid"
                className="w-full h-full"
                gestureHandling="greedy"
              >
                {TAMIL_NADU_WEATHER_STATIONS.map((station) => (
                  <AdvancedMarker
                    key={station.id}
                    position={{ lat: station.lat, lng: station.lng }}
                    onClick={() => setSelectedStation(station)}
                  >
                    <Pin
                      background={getStationStatusColor(station.status)}
                      borderColor="#FFFFFF"
                      glyphColor="#FFFFFF"
                      scale={selectedStation.id === station.id ? 1.3 : 1.0}
                    />
                  </AdvancedMarker>
                ))}
              </Map>
            </APIProvider>
          ) : (
            /* High-Contrast Geospatial Schematic Canvas */
            <div className="w-full h-full bg-[#12221E] relative p-6 flex flex-col justify-between text-white overflow-hidden">
              {/* Radar Grid Overlay */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-20"
                style={{
                  backgroundImage: 'radial-gradient(circle, #4E9B5F 1px, transparent 1px)',
                  backgroundSize: '32px 32px'
                }}
              />

              {/* Radar Sweep Effect */}
              {activeLayer === 'radar' && (
                <div 
                  className="absolute inset-0 pointer-events-none opacity-25 animate-spin"
                  style={{
                    background: 'conic-gradient(from 0deg, transparent 0deg, rgba(78, 155, 95, 0.4) 60deg, transparent 65deg)',
                    animationDuration: '6s',
                    animationIterationCount: 'infinite',
                    animationTimingFunction: 'linear'
                  }}
                />
              )}

              {/* Station Markers on High Contrast Canvas */}
              <div className="relative w-full h-full">
                {TAMIL_NADU_WEATHER_STATIONS.map((st) => {
                  // Normalize coordinates to percentage container
                  // Lat bounds: ~9.5 to 13.2 -> top
                  // Lng bounds: ~76.5 to 80.2 -> left
                  const topPercent = ((13.2 - st.lat) / (13.2 - 9.5)) * 80 + 10;
                  const leftPercent = ((st.lng - 76.5) / (80.2 - 76.5)) * 80 + 10;
                  const isSel = selectedStation.id === st.id;

                  return (
                    <div
                      key={st.id}
                      onClick={() => setSelectedStation(st)}
                      style={{ top: `${topPercent}%`, left: `${leftPercent}%` }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                    >
                      {/* Atmospheric Aura based on active layer */}
                      <div
                        className="absolute inset-0 -m-5 rounded-full pointer-events-none animate-pulse"
                        style={{
                          backgroundColor: getLayerColor(st),
                          filter: 'blur(12px)',
                        }}
                      />

                      {/* Station Badge */}
                      <div className={`relative px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-transform ${
                        isSel 
                          ? 'bg-white text-[#173F35] border-emerald-400 scale-110 shadow-lg' 
                          : 'bg-[#173F35]/90 text-white border-white/20 group-hover:scale-105'
                      }`}>
                        <span 
                          className="w-2.5 h-2.5 rounded-full" 
                          style={{ backgroundColor: getStationStatusColor(st.status) }} 
                        />
                        <span>{language === 'ta' ? st.nameTa.split(' ')[0] : st.name.split(' ')[0]}</span>
                        <span className="text-[10px] opacity-75 font-mono">
                          {activeLayer === 'temp' ? `${st.temp}°` : activeLayer === 'radar' ? `${st.rainMm}mm` : `${st.windKmh}k`}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Geographic Legend */}
              <div className="relative z-10 flex items-center justify-between text-xs text-emerald-200/80 bg-black/40 backdrop-blur-xs p-2.5 rounded-xl border border-white/10">
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-emerald-400" />
                  <span>Tamil Nadu Agri Meteorological Grid (Palar, Cauvery, Vaigai)</span>
                </div>
                <span>Zoom Level: Regional 1:250k</span>
              </div>
            </div>
          )}

          {/* Map Layer Legend Floating Overlay */}
          <div className="absolute top-4 left-4 z-20 bg-white/95 backdrop-blur-xs rounded-xl p-3 border border-[#E3E8DC] shadow-md text-xs space-y-1.5 max-w-xs">
            <span className="font-bold text-[#173F35] block">
              {activeLayer === 'radar' && (language === 'ta' ? 'மழை தீவிரம் (மி.மீ)' : 'Rain Intensity (mm/h)')}
              {activeLayer === 'temp' && (language === 'ta' ? 'வெப்பநிலை (°C)' : 'Surface Temp (°C)')}
              {activeLayer === 'wind' && (language === 'ta' ? 'காற்று வேகம் (கி.மீ/மணி)' : 'Wind Speed (km/h)')}
              {activeLayer === 'humidity' && (language === 'ta' ? 'காற்றின் ஈரப்பதம் (%)' : 'Relative Humidity (%)')}
            </span>
            <div className="flex items-center gap-2 text-[10px] font-semibold text-[#566761]">
              {activeLayer === 'radar' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-gray-300" /> 0 mm</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-300" /> 1-5 mm</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-600" /> &gt;10 mm</span>
                </>
              )}
              {activeLayer === 'temp' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" /> &lt;32°C</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" /> 33-35°C</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500" /> &gt;36°C</span>
                </>
              )}
              {activeLayer === 'wind' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-400" /> Light</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-700" /> Moderate</span>
                </>
              )}
              {activeLayer === 'humidity' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400" /> Dry &lt;50%</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> Humid &gt;80%</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Selected Station Inspector Panel (1 Col) */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  {selectedStation.basin}
                </span>
                <h3 className="font-extrabold text-lg text-[#173F35] mt-1">
                  {language === 'ta' ? selectedStation.nameTa : selectedStation.name}
                </h3>
                <p className="text-xs text-[#566761]">
                  District: {selectedStation.district} • GPS {selectedStation.lat.toFixed(4)}, {selectedStation.lng.toFixed(4)}
                </p>
              </div>

              <div 
                className="w-3.5 h-3.5 rounded-full shrink-0" 
                style={{ backgroundColor: getStationStatusColor(selectedStation.status) }} 
                title={selectedStation.status}
              />
            </div>

            {/* Weather Metrics Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-[#F7F8F4] p-3 rounded-xl border border-[#E3E8DC]">
                <div className="flex items-center gap-1.5 text-xs text-[#566761] mb-1">
                  <Thermometer className="w-3.5 h-3.5 text-rose-500" />
                  <span>{language === 'ta' ? 'வெப்பநிலை' : 'Temperature'}</span>
                </div>
                <div className="text-xl font-black text-[#173F35]">
                  {activeTime === 0 ? `${selectedStation.temp}°C` : `${selectedStation.tempForecast24h}°C`}
                </div>
                <span className="text-[10px] text-[#566761]">
                  {activeTime === 0 ? 'Live reading' : `+${activeTime}h forecast`}
                </span>
              </div>

              <div className="bg-[#F7F8F4] p-3 rounded-xl border border-[#E3E8DC]">
                <div className="flex items-center gap-1.5 text-xs text-[#566761] mb-1">
                  <CloudRain className="w-3.5 h-3.5 text-blue-500" />
                  <span>{language === 'ta' ? 'மழைப்பொழிவு' : 'Precipitation'}</span>
                </div>
                <div className="text-xl font-black text-[#173F35]">
                  {activeTime === 0 ? `${selectedStation.rainMm} mm` : `${selectedStation.rainForecast24h} mm`}
                </div>
                <span className="text-[10px] text-[#566761]">
                  {selectedStation.rainMm > 0 ? 'Active rain gauge' : 'Dry canopy'}
                </span>
              </div>

              <div className="bg-[#F7F8F4] p-3 rounded-xl border border-[#E3E8DC]">
                <div className="flex items-center gap-1.5 text-xs text-[#566761] mb-1">
                  <Droplets className="w-3.5 h-3.5 text-cyan-600" />
                  <span>{language === 'ta' ? 'ஈரப்பதம்' : 'Air Humidity'}</span>
                </div>
                <div className="text-xl font-black text-[#173F35]">
                  {selectedStation.humidity}%
                </div>
                <span className="text-[10px] text-[#566761]">
                  {selectedStation.humidity > 80 ? 'Spore incubation risk' : 'Normal range'}
                </span>
              </div>

              <div className="bg-[#F7F8F4] p-3 rounded-xl border border-[#E3E8DC]">
                <div className="flex items-center gap-1.5 text-xs text-[#566761] mb-1">
                  <Wind className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'ta' ? 'காற்று' : 'Wind Speed'}</span>
                </div>
                <div className="text-xl font-black text-[#173F35]">
                  {selectedStation.windKmh} km/h
                </div>
                <span className="text-[10px] text-[#566761]">
                  Direction: {selectedStation.windDir}
                </span>
              </div>
            </div>

            {/* Agricultural Impact Advisory */}
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
                <span>{language === 'ta' ? 'வேளாண் வானிலை அறிவுரை (WHY):' : 'Crop Weather Impact & Advisory:'}</span>
              </div>
              <p className="text-xs text-amber-950 leading-relaxed font-medium">
                {language === 'ta' ? selectedStation.advisoryTa : selectedStation.advisoryEn}
              </p>
            </div>
          </div>

          {/* Action Bar */}
          <div className="pt-2 border-t border-[#E3E8DC] flex items-center justify-between gap-2">
            <button
              onClick={() => {
                if (isSpeaking) {
                  stopSpeaking();
                } else {
                  speakText(currentSummary);
                }
              }}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs font-bold shadow-xs transition-all"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-4 h-4 text-rose-300" />
                  <span>{t.stopAudio}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-300" />
                  <span>{language === 'ta' ? 'வானிலை சுருக்கத்தை கேட்க' : 'Listen to Weather Report'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
