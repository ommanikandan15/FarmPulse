/**
 * Mandi Market Prices and Seasonal Crop Calendar Data
 * Grounded in official Agmarknet (Directorate of Marketing & Inspection, Govt of India)
 * and e-NAM (National Agriculture Market) price structures and ICAR/TNAU/ANGRAU calendars.
 */

export interface MandiRecord {
  id: string;
  state: string;
  stateCode: 'AP' | 'TS' | 'TN' | 'ALL';
  district: string;
  marketName: string;
  commodity: string;
  variety: string;
  arrivalVolumeQuintals: number;
  minPricePerQtl: number;
  maxPricePerQtl: number;
  modalPricePerQtl: number;
  mspPerQtl: number | null;
  priceTrend: 'up' | 'down' | 'stable';
  changePercent: number;
  lastUpdated: string;
  source: 'Agmarknet / e-NAM' | 'Regulated APMC';
}

export interface CropSeasonalGuidance {
  id: string;
  cropName: string;
  cropNameTe: string;
  cropNameTa: string;
  season: 'Kharif' | 'Rabi' | 'Summer / Zaid' | 'Samba / Thaladi' | 'Kuruvai';
  sowingWindow: string;
  harvestWindow: string;
  durationDays: string;
  recommendedVarieties: string[];
  waterRequirementMm: string;
  criticalWaterStages: string[];
  keyOperationsByMonth: {
    month: string;
    stage: string;
    actions: string[];
    actionsTe?: string[];
    actionsTa?: string[];
  }[];
  majorPestsAndDiseases: {
    name: string;
    symptoms: string;
    prevention: string;
  }[];
  waterSavingTechnique: string;
}

export const MANDI_MARKET_PRICES: MandiRecord[] = [
  {
    id: 'm-1',
    state: 'Tamil Nadu',
    stateCode: 'TN',
    district: 'Ranipet',
    marketName: 'Kaveripakkam Regulated Market',
    commodity: 'Paddy (Dhan)',
    variety: 'CO 51 / Fine Grade',
    arrivalVolumeQuintals: 420,
    minPricePerQtl: 2380,
    maxPricePerQtl: 2540,
    modalPricePerQtl: 2460,
    mspPerQtl: 2320,
    priceTrend: 'up',
    changePercent: 2.1,
    lastUpdated: 'Today, 09:30 AM',
    source: 'Regulated APMC',
  },
  {
    id: 'm-2',
    state: 'Tamil Nadu',
    stateCode: 'TN',
    district: 'Thanjavur',
    marketName: 'Thanjavur Grain Mandi',
    commodity: 'Paddy (Dhan)',
    variety: 'BPT 5204 (Samba Mahsuri)',
    arrivalVolumeQuintals: 1150,
    minPricePerQtl: 2450,
    maxPricePerQtl: 2680,
    modalPricePerQtl: 2580,
    mspPerQtl: 2320,
    priceTrend: 'stable',
    changePercent: 0.0,
    lastUpdated: 'Today, 10:15 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-3',
    state: 'Andhra Pradesh',
    stateCode: 'AP',
    district: 'Guntur',
    marketName: 'Guntur APMC Yard',
    commodity: 'Chilli',
    variety: 'Guntur Teja (Hot Red Dry)',
    arrivalVolumeQuintals: 3850,
    minPricePerQtl: 14200,
    maxPricePerQtl: 19800,
    modalPricePerQtl: 17500,
    mspPerQtl: null,
    priceTrend: 'up',
    changePercent: 3.4,
    lastUpdated: 'Today, 08:45 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-4',
    state: 'Andhra Pradesh',
    stateCode: 'AP',
    district: 'Guntur',
    marketName: 'Tenali Mandi',
    commodity: 'Paddy (Dhan)',
    variety: 'BPT 5204 / RNR 15048',
    arrivalVolumeQuintals: 820,
    minPricePerQtl: 2400,
    maxPricePerQtl: 2610,
    modalPricePerQtl: 2520,
    mspPerQtl: 2320,
    priceTrend: 'up',
    changePercent: 1.6,
    lastUpdated: 'Today, 10:00 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-5',
    state: 'Telangana',
    stateCode: 'TS',
    district: 'Warangal',
    marketName: 'Enumamula Grain Market',
    commodity: 'Cotton (Kapas)',
    variety: 'Medium / Long Staple Hybrid',
    arrivalVolumeQuintals: 4600,
    minPricePerQtl: 6950,
    maxPricePerQtl: 7480,
    modalPricePerQtl: 7260,
    mspPerQtl: 7121,
    priceTrend: 'up',
    changePercent: 1.8,
    lastUpdated: 'Today, 09:15 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-6',
    state: 'Telangana',
    stateCode: 'TS',
    district: 'Warangal',
    marketName: 'Enumamula Grain Market',
    commodity: 'Maize (Makka)',
    variety: 'Yellow Hybrid Dent',
    arrivalVolumeQuintals: 1950,
    minPricePerQtl: 2180,
    maxPricePerQtl: 2340,
    modalPricePerQtl: 2260,
    mspPerQtl: 2225,
    priceTrend: 'stable',
    changePercent: 0.2,
    lastUpdated: 'Today, 09:40 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-7',
    state: 'Telangana',
    stateCode: 'TS',
    district: 'Nizamabad',
    marketName: 'Nizamabad APMC',
    commodity: 'Turmeric',
    variety: 'Finger / Bulb Grade',
    arrivalVolumeQuintals: 2100,
    minPricePerQtl: 11400,
    maxPricePerQtl: 14800,
    modalPricePerQtl: 13200,
    mspPerQtl: null,
    priceTrend: 'up',
    changePercent: 4.2,
    lastUpdated: 'Today, 11:00 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-8',
    state: 'Andhra Pradesh',
    stateCode: 'AP',
    district: 'Kurnool',
    marketName: 'Kurnool APMC Yard',
    commodity: 'Groundnut (Pods)',
    variety: 'K 6 / Kadiri Bold',
    arrivalVolumeQuintals: 1480,
    minPricePerQtl: 6400,
    maxPricePerQtl: 7150,
    modalPricePerQtl: 6850,
    mspPerQtl: 6783,
    priceTrend: 'stable',
    changePercent: -0.4,
    lastUpdated: 'Today, 10:30 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-9',
    state: 'Andhra Pradesh',
    stateCode: 'AP',
    district: 'Kurnool',
    marketName: 'Adoni Market',
    commodity: 'Cotton (Kapas)',
    variety: 'Bunny / Brahma Staple',
    arrivalVolumeQuintals: 2700,
    minPricePerQtl: 7000,
    maxPricePerQtl: 7520,
    modalPricePerQtl: 7310,
    mspPerQtl: 7121,
    priceTrend: 'up',
    changePercent: 1.2,
    lastUpdated: 'Today, 09:50 AM',
    source: 'Agmarknet / e-NAM',
  },
  {
    id: 'm-10',
    state: 'Tamil Nadu',
    stateCode: 'TN',
    district: 'Vellore',
    marketName: 'Vellore Katpadi Mandi',
    commodity: 'Tomato',
    variety: 'Local Hybrid Shivam',
    arrivalVolumeQuintals: 620,
    minPricePerQtl: 1600,
    maxPricePerQtl: 2200,
    modalPricePerQtl: 1950,
    mspPerQtl: null,
    priceTrend: 'down',
    changePercent: -5.0,
    lastUpdated: 'Today, 08:15 AM',
    source: 'Regulated APMC',
  },
  {
    id: 'm-11',
    state: 'Tamil Nadu',
    stateCode: 'TN',
    district: 'Madurai',
    marketName: 'Mattuthavani APMC',
    commodity: 'Red Gram (Tur)',
    variety: 'Paiyur 1 / LRG 41',
    arrivalVolumeQuintals: 310,
    minPricePerQtl: 7400,
    maxPricePerQtl: 8200,
    modalPricePerQtl: 7850,
    mspPerQtl: 7550,
    priceTrend: 'up',
    changePercent: 1.5,
    lastUpdated: 'Today, 10:45 AM',
    source: 'Agmarknet / e-NAM',
  },
];

export const CROP_CALENDARS: CropSeasonalGuidance[] = [
  {
    id: 'crop-paddy-kharif',
    cropName: 'Paddy (Rice) - Kharif / Kuruvai',
    cropNameTe: 'వరి (ఖరీఫ్ / కురువై)',
    cropNameTa: 'நெல் (குறுவை / காரிஃப்)',
    season: 'Kuruvai',
    sowingWindow: 'June 1 – July 15',
    harvestWindow: 'September 15 – October 31',
    durationDays: '105 – 120 days',
    recommendedVarieties: ['CO 51', 'ADT 43', 'MTU 1010', 'Telangana Sona (RNR 15048)'],
    waterRequirementMm: '1100 – 1250 mm',
    criticalWaterStages: [
      'Transplanting & Tillering (0–35 DAT)',
      'Panicle Initiation (45–60 DAT) — Never allow moisture deficit',
      'Flowering & Milk Stage (65–85 DAT)'
    ],
    keyOperationsByMonth: [
      {
        month: 'June',
        stage: 'Nursery & Field Prep',
        actions: [
          'Prepare wet nursery beds with 100 kg FYM + 2 kg Trichoderma / acre.',
          'Puddle main field thoroughly and level to conserve irrigation water.',
          'Seed treatment with Pseudomonas fluorescens @ 10g/kg of seed.'
        ],
        actionsTe: [
          'నారుమడి తయారీ: 100 కేజీల సేంద్రియ ఎరువు + ట్రైకోడెర్మా కలపండి.',
          'ప్రధాన పొలాన్ని దమ్ము చేసి సమాంతరంగా చదును చేయండి.',
          'విత్తన శుద్ధి: కిలో విత్తనానికి 10 గ్రా. సూడోమోనాస్ వాడండి.'
        ],
        actionsTa: [
          'நாற்றங்கால் தயார் செய்தல்: 100 கிலோ தொழுவுரம் + ட்ரைக்கோடெர்மா இடவும்.',
          'வயலை நன்கு சமன்படுத்தி நீரை சேமிக்கவும்.',
          'சூடோமோனாஸ் மூலம் விதை நேர்த்தி செய்யவும்.'
        ]
      },
      {
        month: 'July',
        stage: 'Transplanting & Early Tillering',
        actions: [
          'Transplant 18–22 day-old healthy seedlings at 20x10 cm spacing.',
          'Apply pre-emergence herbicide within 3 days under thin film of water.',
          'Install AWD (Alternate Wetting and Drying) field water tube.'
        ],
        actionsTe: [
          '18–22 రోజుల నారును 20x10 సెం.మీ దూరంలో నాటండి.',
          'నాటిన 3 రోజుల్లో కలుపు నివారణ మందు వాడండి.',
          'నీటి పొదుపు కోసం AWD క్షేత్ర పైపును ఏర్పాటు చేయండి.'
        ]
      },
      {
        month: 'August',
        stage: 'Panicle Initiation & Maximum Tillering',
        actions: [
          'Topdress 2nd split nitrogen with neem-coated urea based on Leaf Color Chart (LCC).',
          'Maintain 2–3 cm standing water; moisture stress now severely damages grain count.',
          'Scout for leaf folder and rice blast; spray Pseudomonas @ 2g/litre if humidity >85%.'
        ],
        actionsTe: [
          'చిరుపొట్ట దశ: ఎల్.సి.సి (LCC) చార్ట్ ఆధారంగా రెండవ విడత యూరియా వేయండి.',
          'పొలంలో 2–3 సెం.మీ నీటిని ఖచ్చితంగా నిలబెట్టండి.',
          'ఆకుచుట్టు పురుగు మరియు అగ్గితెగులు గమనించి జీవ నియంత్రణ చేపట్టండి.'
        ]
      },
      {
        month: 'September',
        stage: 'Flowering & Grain Filling',
        actions: [
          'Maintain thin water layer during flowering; drain field 7–10 days before harvest.',
          'Erect bird perches and install light traps.',
          'Check grains: harvest when 85% panicle turns golden yellow.'
        ],
        actionsTe: [
          'ఈనె మరియు పాలుపోసుకునే దశ: పొలంలో పలుచని నీరు ఉంచండి; కోతకు 10 రోజుల ముందు నీరు తీసివేయండి.',
          '85% గింజలు బంగారు రంగుకు మారినప్పుడు కోత ప్రారంభించండి.'
        ]
      }
    ],
    majorPestsAndDiseases: [
      {
        name: 'Rice Blast (Magnaporthe oryzae)',
        symptoms: 'Spindle-shaped brown lesions with whitish-grey center on leaves and neck.',
        prevention: 'Avoid excess nitrogen fertilizer. Spray Pseudomonas fluorescens @ 0.2% prophylactically during humid overcast spells.'
      },
      {
        name: 'Leaf Folder (Cnaphalocrocis medinalis)',
        symptoms: 'Leaves folded longitudinally with white transparent scraped patches.',
        prevention: 'Set up light traps (1/acre); release Trichogramma chilonis egg parasitoid @ 2 cc/acre.'
      }
    ],
    waterSavingTechnique: 'AWD (Alternate Wetting & Drying) saves 25–30% irrigation water without reducing grain yield.'
  },
  {
    id: 'crop-cotton-kharif',
    cropName: 'Cotton (Kapas) - Kharif Season',
    cropNameTe: 'పత్తి (ఖరీఫ్ సీజన్)',
    cropNameTa: 'பருத்தி (காரிஃப் பருவம்)',
    season: 'Kharif',
    sowingWindow: 'June 15 – July 25',
    harvestWindow: 'November 15 – January 31',
    durationDays: '150 – 170 days',
    recommendedVarieties: ['Bunny Bt', 'RCH 659', 'Brahma', 'Suraj (Non-Bt High Density)'],
    waterRequirementMm: '650 – 750 mm',
    criticalWaterStages: [
      'Squaring Stage (45–55 DAS)',
      'Flowering & Peak Boll Formation (65–95 DAS)',
      'Boll Development & Maturation'
    ],
    keyOperationsByMonth: [
      {
        month: 'June - July',
        stage: 'Sowing & Germination',
        actions: [
          'Deep summer ploughing to expose pupae of bollworms to sun.',
          'Sow seeds on ridges with spacing 90x60 cm or 90x45 cm.',
          'Grow 2 border rows of maize or castor as trap crops for sucking pests.'
        ],
        actionsTe: [
          'వేసవి లోతు దుక్కులు చేసి పత్తి కాయతొలుచు పురుగు కోశాలను ఎండకు గురిచేయండి.',
          'బోదెలపై 90x60 సెం.మీ దూరంలో విత్తనాలు నాటండి.',
          'పొలం చుట్టూ 2 వరుసల మొక్కజొన్న లేదా ఆముదం ఎరపంటగా వేయండి.'
        ]
      },
      {
        month: 'August - September',
        stage: 'Squaring & Sucking Pest Monitoring',
        actions: [
          'Monitor jassids, thrips, and whiteflies using yellow and blue sticky traps (10/acre).',
          'Spray 5% Neem Seed Kernel Extract (NSKE) at early squaring.',
          'Apply 1% potassium nitrate (13-0-45) spray to prevent square shedding.'
        ],
        actionsTe: [
          'పసుపు, నీలి రంగు జిగురు అట్టలను ఎకరానికి 10 చొప్పున ఏర్పాటు చేయండి.',
          'గుడ్లదశలో 5% వేప గింజల కషాయం (NSKE) పిచికారీ చేయండి.',
          'పూత మరియు పిందె రాలకుండా 1% పొటాషియం నైట్రేట్ పిచికారీ చేయండి.'
        ]
      },
      {
        month: 'October - November',
        stage: 'Peak Boll Formation & Picking',
        actions: [
          'Install pink bollworm pheromone traps (Phero-traps @ 4/acre) to scout moth flight.',
          'Do not apply synthetic pyrethroids; preserve natural predators like chrysoperla.',
          'Begin first picking in morning hours when bolls are fully burst and clean.'
        ],
        actionsTe: [
          'గులాబీ రంగు పురుగు కోసం ఎకరానికి 4 లింగాకర్షక బుట్టలు అమర్చండి.',
          'పూర్తిగా విచ్చుకున్న తెల్లటి దూదిని ఉదయం పూట మాత్రమే ఏరండి.'
        ]
      }
    ],
    majorPestsAndDiseases: [
      {
        name: 'Pink Bollworm (Pectinophora gossypiella)',
        symptoms: 'Rosetted flowers, damaged locules, stained lint, premature boll opening.',
        prevention: 'Strict pheromone trap monitoring; install PBM traps; spray neem oil; timely picking.'
      },
      {
        name: 'Bacterial Blight / Angular Leaf Spot (Xanthomonas citri)',
        symptoms: 'Angular water-soaked spots bounded by veins turning dark brown.',
        prevention: 'Spray copper oxychloride 0.25% + streptocycline 100 ppm.'
      }
    ],
    waterSavingTechnique: 'Alternate furrow irrigation and drip fertigation reduce water requirement by 40%.'
  },
  {
    id: 'crop-groundnut-rabi',
    cropName: 'Groundnut (Peanut) - Rabi / Chitta',
    cropNameTe: 'వేరుశనగ (రబీ సీజన్)',
    cropNameTa: 'நிலக்கடலை (ரபி / சித்திரை)',
    season: 'Rabi',
    sowingWindow: 'October 15 – November 30',
    harvestWindow: 'February 1 – March 15',
    durationDays: '105 – 115 days',
    recommendedVarieties: ['Kadiri 6', 'Dharani', 'TMV 13', 'TAG 24', 'K 9'],
    waterRequirementMm: '450 – 550 mm',
    criticalWaterStages: [
      'Flowering (25–35 DAS)',
      'Peg Penetration (40–50 DAS) — Top critical stage',
      'Pod Filling & Seed Development (60–80 DAS)'
    ],
    keyOperationsByMonth: [
      {
        month: 'October - November',
        stage: 'Land Preparation & Sowing',
        actions: [
          'Apply 5 tons well-decomposed FYM + 200 kg gypsum/acre at final ploughing.',
          'Seed treatment with Trichoderma viride @ 4g/kg seed + Rhizobium culture.',
          'Sow at 30x10 cm spacing at 4–5 cm soil depth.'
        ],
        actionsTe: [
          'ఆఖరి దుక్కిలో ఎకరానికి 5 టన్నుల పశువుల ఎరువు + 200 కేజీల జిప్సం వేయండి.',
          'ట్రైకోడెర్మా విరిడే (4 గ్రా/కిలో) మరియు రైజోబియం కల్చర్‌తో విత్తన శుద్ధి చేయండి.'
        ]
      },
      {
        month: 'December',
        stage: 'Pegging & Second Gypsum Dose',
        actions: [
          'Apply second dose of 200 kg gypsum/acre at 40–45 DAS around plant base.',
          'Light earthing up to facilitate smooth peg penetration into soil.',
          'Ensure adequate soil moisture so pegs do not dry before entering soil.'
        ],
        actionsTe: [
          '40–45 రోజుల్లో ఊడలు దిగే దశ: మొక్కల మొదళ్ళలో 200 కేజీల జిప్సం వేయండి.',
          'ఊడలు సులభంగా నేలలోకి దిగేందుకు మట్టిని కదిలించండి మరియు తేమను కాపాడండి.'
        ]
      },
      {
        month: 'January - February',
        stage: 'Pod Development & Harvest',
        actions: [
          'Inspect pod inner shell: harvest when inner shell turns dark brownish-black.',
          'Dry pods in sun until moisture drops below 9% for safe storage.',
          'Store in clean, moisture-free gunny bags on wooden pallets.'
        ],
        actionsTe: [
          'కాయను పగులగొట్టి లోపలి పొర నలుపు రంగుకు మారినప్పుడు పంటను తవ్వండి.',
          'కాయలను ఎండలో ఆరబెట్టి 9% కంటే తక్కువ తేమ ఉన్నప్పుడు భద్రపరచండి.'
        ]
      }
    ],
    majorPestsAndDiseases: [
      {
        name: 'Tikka Leaf Spot (Cercospora personata)',
        symptoms: 'Small circular dark brown to black spots with yellow halo on leaves.',
        prevention: 'Spray Mancozeb @ 2.5g/L or carbendazim @ 1g/L at first appearance of spots.'
      },
      {
        name: 'Spodoptera / Tobacco Caterpillar',
        symptoms: 'Skeletonized leaves with large irregular holes; defoliation.',
        prevention: 'Set up pheromone traps (5/acre); handpick egg masses; spray NSKE 5%.'
      }
    ],
    waterSavingTechnique: 'Sprinkler irrigation during peg penetration provides uniform moisture with 35% water savings.'
  }
];

export const REGIONAL_LOCATION_PRESETS = [
  { id: 'kaveripakkam', name: 'Kaveripakkam (Ranipet, Tamil Nadu)', state: 'Tamil Nadu', lat: 12.8982, lng: 79.4674 },
  { id: 'thanjavur', name: 'Thanjavur (Cauvery Delta, Tamil Nadu)', state: 'Tamil Nadu', lat: 10.7870, lng: 79.1378 },
  { id: 'madurai', name: 'Madurai (Vaigai Basin, Tamil Nadu)', state: 'Tamil Nadu', lat: 9.9252, lng: 78.1198 },
  { id: 'coimbatore', name: 'Coimbatore (Noyyal Basin, Tamil Nadu)', state: 'Tamil Nadu', lat: 11.0168, lng: 76.9558 },
  { id: 'guntur', name: 'Guntur (Krishna-Godavari Zone, Andhra Pradesh)', state: 'Andhra Pradesh', lat: 16.3067, lng: 80.4365 },
  { id: 'kurnool', name: 'Kurnool (Rayalaseema Zone, Andhra Pradesh)', state: 'Andhra Pradesh', lat: 15.8281, lng: 78.0373 },
  { id: 'vijayawada', name: 'Vijayawada (Krishna Delta, Andhra Pradesh)', state: 'Andhra Pradesh', lat: 16.5062, lng: 80.6480 },
  { id: 'warangal', name: 'Warangal (Kakatiya Hub, Telangana)', state: 'Telangana', lat: 17.9689, lng: 79.5941 },
  { id: 'nizamabad', name: 'Nizamabad (Northern Telangana Zone)', state: 'Telangana', lat: 18.6725, lng: 78.0941 },
  { id: 'khammam', name: 'Khammam (Godavari Basin, Telangana)', state: 'Telangana', lat: 17.2473, lng: 80.1514 },
];
