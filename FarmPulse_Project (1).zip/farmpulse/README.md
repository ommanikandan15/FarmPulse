# FarmPulse — Explainable Crop Stress Advisory

**Tagline:** Don’t just tell the farmer *what*. Tell them *why*.

FarmPulse is a polished, mobile-first prototype that turns weather, crop and soil observations into an explainable crop-stress advisory. It is designed for a Tamil Nadu pilot, with paddy as the sample crop, Tamil/English-ready interface labels, plot-level status, transparent contributing factors, and a village procurement risk view.

> **Prototype honesty:** the included observations are clearly labelled demonstration data. This project does not yet ingest live satellite imagery, validate agronomic recommendations, or diagnose real leaf disease. Do not use demo recommendations for real farming decisions. Irrigation quantities and treatment decisions require local agronomist validation and field-specific measurements.

## What makes it stand out

- **Evidence before advice:** every advisory shows the input values and the rule that triggered it.
- **No fake certainty:** confidence is a data-coverage indicator, not a calibrated probability of correctness.
- **Action guardrails:** high-impact actions such as pesticide application are never auto-prescribed.
- **Supply-chain bridge:** cluster-level risk summary helps FPOs plan scouting and procurement conversations.
- **Offline-friendly architecture:** static frontend and lightweight API can be hosted locally; the UI can be extended as a PWA.
- **Demo / live-data separation:** demo mode is explicit and visible.

## Run locally

Python 3.10+ recommended.

```bash
cd farmpulse
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000. API docs: http://127.0.0.1:8000/docs.

## Project structure

```text
farmpulse/
├── app/
│   ├── main.py              # FastAPI routes and advisory engine
│   └── static/              # responsive dashboard (HTML/CSS/JS)
├── data/demo_plots.json     # synthetic sample observations
├── docs/                    # architecture, model card, demo script
├── tests/test_advisory.py   # basic rule-engine tests
├── requirements.txt
├── Dockerfile
└── README.md
```

## API

- `GET /api/health` — service health and demo-mode flag
- `GET /api/plots` — plot summaries
- `GET /api/plots/{plot_id}` — observations, advisory, evidence and recommended next step
- `GET /api/cluster` — village-level risk summary for planning
- `POST /api/advisory` — evaluate a supplied observation payload

Example request:

```json
{
  "crop": "paddy",
  "days_without_rain": 9,
  "soil_moisture_pct": 18,
  "greenness_change_pct": -14,
  "temperature_c": 36,
  "humidity_pct": 48,
  "growth_stage": "tillering"
}
```

## Current engine and next steps

The starter uses interpretable agronomy-inspired rules rather than claiming a trained ML model. Thresholds are illustrative and must be reviewed by local agronomists before any pilot. The intended next stage is to version crop-stage rules, ingest validated weather and Sentinel-2 features, add model evaluation and calibration, and use SHAP only after a real supervised model is trained and independently evaluated.

## Safety and responsible use

- Advisory outputs are decision support, not a substitute for local agricultural extension advice.
- Confirm crop stage, irrigation access, soil type, recent rainfall and field observations before acting.
- Never recommend pesticide products or dosages from image classification alone.
- Treat uploaded photos and farm location as potentially sensitive data; obtain consent and define retention rules before deployment.
- Cluster summaries should be aggregated and shared only with farmer/FPO consent.

## License

Educational prototype. Add a project license before public distribution or commercial deployment.
