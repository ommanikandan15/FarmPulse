import React from 'react';
import { X, HelpCircle, ShieldAlert, Cpu, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface ExplainabilityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExplainabilityModal: React.FC<ExplainabilityModalProps> = ({ isOpen, onClose }) => {
  const { t, language } = useApp();

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#E3E8DC] p-6 text-[#1C2723]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[#E3E8DC] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
              <HelpCircle className="w-5 h-5 text-[#4E9B5F]" />
            </div>
            <div>
              <h3 id="modal-title" className="text-lg font-bold text-[#173F35]">
                {t.howThisWasAssessed}
              </h3>
              <p className="text-xs text-[#566761]">
                {language === 'ta' ? 'வெளிப்படையான மற்றும் தணிக்கை செய்யக்கூடிய விதிமுறை விளக்கம்' : 'Deterministic, Auditable Agricultural Rules Framework'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-4 text-sm leading-relaxed">
          {/* Tagline / Mission */}
          <div className="bg-[#F7F8F4] p-3.5 rounded-xl border border-[#E3E8DC] text-xs sm:text-sm">
            <span className="font-bold text-[#173F35] block mb-1">
              {t.tagline}
            </span>
            <p className="text-[#566761]">
              {t.howFormulaWorks}
            </p>
          </div>

          {/* Rule Breakdown Table */}
          <div>
            <h4 className="font-semibold text-xs uppercase tracking-wider text-[#566761] mb-2">
              {language === 'ta' ? 'விதிகள் மற்றும் எடைகள் (மாதிரி தர்க்கம்)' : 'Evaluation Rules & Severity Weights'}
            </h4>
            <div className="border border-[#E3E8DC] rounded-xl overflow-hidden divide-y divide-[#E3E8DC] text-xs">
              <div className="p-3 bg-stone-50 grid grid-cols-12 font-medium text-[#566761]">
                <div className="col-span-5">{language === 'ta' ? 'அளவீடு & காரணி' : 'Biometric / Weather Metric'}</div>
                <div className="col-span-4">{language === 'ta' ? 'விதி வரம்பு' : 'Threshold Trigger'}</div>
                <div className="col-span-3 text-right">{language === 'ta' ? 'எடை புள்ளிகள்' : 'Weight'}</div>
              </div>

              <div className="p-3 grid grid-cols-12 items-center">
                <div className="col-span-5 font-medium text-[#1C2723]">
                  {language === 'ta' ? 'மண் ஈரப்பதம்' : 'Volumetric Soil Moisture'}
                </div>
                <div className="col-span-4 text-[#566761]">&lt; 20% (Crit) / 20–28% (Watch)</div>
                <div className="col-span-3 text-right font-semibold text-rose-700">+35 / +18 pts</div>
              </div>

              <div className="p-3 grid grid-cols-12 items-center">
                <div className="col-span-5 font-medium text-[#1C2723]">
                  {language === 'ta' ? 'மழை இல்லாத காலம்' : 'Consecutive Dry Days'}
                </div>
                <div className="col-span-4 text-[#566761]">≥ 7 days (High) / 4–6 days (Mod)</div>
                <div className="col-span-3 text-right font-semibold text-rose-700">+30 / +15 pts</div>
              </div>

              <div className="p-3 grid grid-cols-12 items-center">
                <div className="col-span-5 font-medium text-[#1C2723]">
                  {language === 'ta' ? 'வாராந்திர பசுமை மாற்றம்' : 'Weekly Canopy Greenness (NDVI trend)'}
                </div>
                <div className="col-span-4 text-[#566761]">≤ -12% (Sharp) / -6% to -11.9%</div>
                <div className="col-span-3 text-right font-semibold text-rose-700">+30 / +15 pts</div>
              </div>

              <div className="p-3 grid grid-cols-12 items-center">
                <div className="col-span-5 font-medium text-[#1C2723]">
                  {language === 'ta' ? 'உச்ச வெப்பநிலை' : 'Peak Ambient Heat'}
                </div>
                <div className="col-span-4 text-[#566761]">≥ 35°C (Thermal load)</div>
                <div className="col-span-3 text-right font-semibold text-amber-700">+15 pts</div>
              </div>

              <div className="p-3 grid grid-cols-12 items-center">
                <div className="col-span-5 font-medium text-[#1C2723]">
                  {language === 'ta' ? 'செயற்கைக்கோள் நீர் குறியீடு (NDWI)' : 'Sentinel-2 Water Index (NDWI)'}
                </div>
                <div className="col-span-4 text-[#566761]">&lt; 0.0 (Optical context)</div>
                <div className="col-span-3 text-right font-semibold text-blue-700">+5 pts (Context)</div>
              </div>
            </div>
          </div>

          {/* Scoring Tiers */}
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200">
              <span className="font-bold text-emerald-800 block text-sm">0 – 34</span>
              <span className="text-emerald-700 font-medium">{t.riskLow}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200">
              <span className="font-bold text-amber-800 block text-sm">35 – 64</span>
              <span className="text-amber-700 font-medium">{t.riskWatch}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200">
              <span className="font-bold text-rose-800 block text-sm">65 – 100</span>
              <span className="text-rose-700 font-medium">{t.riskHigh}</span>
            </div>
          </div>

          {/* Critical Guardrails */}
          <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2 text-xs text-amber-900">
            <div className="flex items-center gap-1.5 font-bold">
              <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
              <span>{t.officerConsultWarningTitle}</span>
            </div>
            <p className="leading-normal">
              {t.officerConsultWarningBody}
            </p>
            <ul className="list-disc list-inside space-y-1 text-amber-800">
              <li>{language === 'ta' ? 'செயலி ரசாயன பூச்சிக்கொல்லிகளை பரிந்துரைக்காது.' : 'FarmPulse never prescribes chemical brand names or dosages.'}</li>
              <li>{language === 'ta' ? 'பசுமை குறைவு மட்டுமே நோயை உறுதிப்படுத்தாது; கள ஆய்வு அவசியம்.' : 'Canopy greenness changes indicate vegetative stress, not a specific pathogen diagnosis.'}</li>
              <li>{language === 'ta' ? 'தரவு கவரேஜ் என்பது கிடைத்த தகவலின் அளவு, துல்லிய கணிப்பு அல்ல.' : 'Data coverage denotes input completeness, not machine prediction confidence.'}</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-[#E3E8DC] pt-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#173F35] text-white rounded-lg text-sm font-semibold hover:bg-[#1E4D41] transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
