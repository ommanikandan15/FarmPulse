import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CheckSquare, Square, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const PriorityActionsList: React.FC = () => {
  const { selectedPlot, t, language } = useApp();
  const advisory = selectedPlot.advisory;

  const [completedActions, setCompletedActions] = useState<Record<string, boolean>>({});

  const toggleAction = (idx: number) => {
    const key = `${selectedPlot.id}-act-${idx}`;
    setCompletedActions((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const checklist = language === 'ta' ? advisory.actionChecklistTa : advisory.actionChecklist;

  return (
    <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
              {t.priorityActionsToday}
            </h3>
            <p className="text-xs text-[#566761] mt-0.5">
              {language === 'ta' ? 'பாதுகாப்பான முன்னுரிமை களப் பணிகள்' : 'Safe agronomist-aligned checklist'}
            </p>
          </div>
          <span className="text-[11px] font-semibold text-[#4E9B5F]">
            {Object.keys(completedActions).filter((k) => completedActions[k] && k.startsWith(selectedPlot.id)).length} / {checklist.length} {t.actionCompleted}
          </span>
        </div>

        {/* Primary Action Callout */}
        <div className="mt-3.5 p-3 rounded-xl bg-amber-50/80 border border-amber-200">
          <span className="text-[10px] font-bold tracking-wider uppercase text-amber-800 block mb-1">
            {language === 'ta' ? 'முக்கிய முன்னுரிமை பணி' : 'Primary Recommended Action'}
          </span>
          <p className="text-xs sm:text-sm font-semibold text-amber-950 leading-snug">
            {language === 'ta' ? advisory.primaryActionTa : advisory.primaryAction}
          </p>
        </div>

        {/* Action Checkbox items */}
        <div className="mt-3.5 space-y-2">
          {checklist.map((actionText, idx) => {
            const key = `${selectedPlot.id}-act-${idx}`;
            const isDone = !!completedActions[key];

            return (
              <button
                key={idx}
                onClick={() => toggleAction(idx)}
                className={`w-full text-left p-2.5 rounded-xl border flex items-start gap-2.5 transition-all text-xs ${
                  isDone
                    ? 'bg-emerald-50/50 border-emerald-200 text-stone-500 line-through'
                    : 'bg-[#F7F8F4] border-[#E3E8DC] text-[#1C2723] hover:bg-white'
                }`}
                aria-label={`Toggle action: ${actionText}`}
              >
                {isDone ? (
                  <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-[#83948E] shrink-0 mt-0.5" />
                )}
                <span className="leading-snug">{actionText}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Safety Notice */}
      <div className="mt-4 pt-3 border-t border-[#E3E8DC] flex items-center gap-1.5 text-[11px] text-[#566761]">
        <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" />
        <span>
          {language === 'ta'
            ? 'அதிக தாக்கமுள்ள பணிகளுக்கு முன் கிராம வேளாண் அலுவலரிடம் ஆலோசனை பெறவும்.'
            : 'Review with local agriculture officer before deep irrigation or treatments.'}
        </span>
      </div>
    </div>
  );
};
