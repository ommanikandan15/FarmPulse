/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { MobileNav } from './components/layout/MobileNav';
import { ExplainabilityModal } from './components/common/ExplainabilityModal';
import { PlotDetailModal } from './components/plots/PlotDetailModal';
import { LoginModal } from './components/common/LoginModal';

// Views
import { DashboardView } from './components/dashboard/DashboardView';
import { FarmAnalysisView } from './components/analysis/FarmAnalysisView';
import { ExplainableAdvisoryView } from './components/advisory/ExplainableAdvisoryView';
import { ExplanationInsightsView } from './components/advisory/ExplanationInsightsView';
import { PlotExplorerView } from './components/plots/PlotExplorerView';
import { LeafCheckView } from './components/leafcheck/LeafCheckView';
import { WeatherTrendsView } from './components/weather/WeatherTrendsView';
import { FpoSupplyChainView } from './components/fpo/FpoSupplyChainView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { AskAiView } from './components/ai/AskAiView';
import { WeatherMapView } from './components/weather/WeatherMapView';
import { FieldPlaceMapView } from './components/maps/FieldPlaceMapView';
import { MandiAndCalendarView } from './components/mandi/MandiAndCalendarView';
import { Plot } from './types';
import { Bot, Sparkles } from 'lucide-react';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';

function MainAppShell() {
  const { 
    activeTab, 
    setActiveTab, 
    setSelectedPlotId,
    isLoginModalOpen,
    setIsLoginModalOpen,
    language
  } = useApp();

  const [isExplainModalOpen, setIsExplainModalOpen] = useState(false);
  const [detailPlot, setDetailPlot] = useState<Plot | null>(null);

  const handleSelectPlotDetail = (plot: Plot) => {
    setDetailPlot(plot);
  };

  const handleNavigateToAdvisory = (plot: Plot) => {
    setSelectedPlotId(plot.id);
    setActiveTab('advisory');
  };

  return (
    <div className="min-h-screen bg-[#F7F8F4] text-[#1C2723] flex flex-col font-sans relative">
      {/* Sticky Header */}
      <Header />

      {/* Main Body Layout */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar */}
        <Sidebar onOpenExplainability={() => setIsExplainModalOpen(true)} />

        {/* Dynamic Route Content */}
        <main className="flex-1 p-3.5 sm:p-6 overflow-y-auto min-w-0 pb-20 md:pb-8">
          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenExplainability={() => setIsExplainModalOpen(true)}
              onSelectPlotDetail={handleSelectPlotDetail}
            />
          )}

          {activeTab === 'analysis' && <FarmAnalysisView />}

          {activeTab === 'advisory' && (
            <ExplainableAdvisoryView onOpenExplainability={() => setIsExplainModalOpen(true)} />
          )}

          {activeTab === 'explanation' && <ExplanationInsightsView />}

          {activeTab === 'ask-ai' && <AskAiView />}

          {activeTab === 'fieldmap' && (
            <FieldPlaceMapView onSelectPlotDetail={handleSelectPlotDetail} />
          )}

          {activeTab === 'plots' && (
            <PlotExplorerView onSelectPlotDetail={handleSelectPlotDetail} />
          )}

          {activeTab === 'leafcheck' && <LeafCheckView />}

          {activeTab === 'weather' && <WeatherTrendsView />}

          {activeTab === 'weathermap' && <WeatherMapView />}

          {activeTab === 'mandi' && <MandiAndCalendarView />}

          {activeTab === 'fpo' && <FpoSupplyChainView />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Floating Ask AI Button (visible on all other tabs) */}
      {activeTab !== 'ask-ai' && (
        <button
          onClick={() => setActiveTab('ask-ai')}
          className="fixed bottom-20 md:bottom-6 right-5 z-40 bg-[#173F35] hover:bg-[#255e50] text-white px-4 py-3 rounded-full shadow-lg flex items-center gap-2 border-2 border-emerald-400/60 transition-transform hover:scale-105 active:scale-95 group"
          title="Ask Agri AI Copilot"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-emerald-300" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <span className="text-xs font-bold tracking-wide">
            {language === 'ta' ? 'AI உதவி கேட்க' : 'Ask AI'}
          </span>
        </button>
      )}

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Modals */}
      <ExplainabilityModal
        isOpen={isExplainModalOpen}
        onClose={() => setIsExplainModalOpen(false)}
      />

      <PlotDetailModal
        plot={detailPlot}
        onClose={() => setDetailPlot(null)}
        onNavigateToAdvisory={handleNavigateToAdvisory}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />

      {/* Offline Status Toast */}
      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppShell />
    </AppProvider>
  );
}
