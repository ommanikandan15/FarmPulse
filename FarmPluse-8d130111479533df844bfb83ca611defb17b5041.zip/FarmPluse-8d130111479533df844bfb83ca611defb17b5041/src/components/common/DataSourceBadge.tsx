import React from 'react';
import { DataSourceType } from '../../types';
import { useApp } from '../../context/AppContext';
import { Cpu, Satellite, CloudSun, UserCheck, TestTube } from 'lucide-react';

interface DataSourceBadgeProps {
  type: DataSourceType;
}

export const DataSourceBadge: React.FC<DataSourceBadgeProps> = ({ type }) => {
  const { t } = useApp();

  const config = {
    sensor: {
      label: t.sourceSensor,
      icon: Cpu,
      color: 'text-[#1B6336] bg-[#EBF7EE] border-[#BDDFCA]',
    },
    satellite: {
      label: t.sourceSatellite,
      icon: Satellite,
      color: 'text-[#1D4ED8] bg-[#EFF6FF] border-[#BFDBFE]',
    },
    weather_api: {
      label: t.sourceWeatherApi,
      icon: CloudSun,
      color: 'text-[#7C3AED] bg-[#F5F3FF] border-[#DDD6FE]',
    },
    farmer: {
      label: t.sourceFarmer,
      icon: UserCheck,
      color: 'text-[#92400E] bg-[#FEF3C7] border-[#FDE68A]',
    },
    demo: {
      label: t.sourceDemo,
      icon: TestTube,
      color: 'text-[#475569] bg-[#F1F5F9] border-[#CBD5E1]',
    },
  }[type];

  const Icon = config.icon;

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium border ${config.color}`}
      title={`Data source: ${config.label}`}
    >
      <Icon className="w-3 h-3 shrink-0" aria-hidden="true" />
      <span>{config.label}</span>
    </span>
  );
};
