import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { LEAF_SYMPTOMS_LIST, SYMPTOM_DIAGNOSES } from '../../data/demoData';
import { PossibleDiagnosis } from '../../types';
import { analyzeLeafImageWithGemini, AiVisionResult } from '../../services/geminiService';
import { 
  Upload, 
  X, 
  CheckSquare, 
  Square, 
  ShieldAlert, 
  HelpCircle, 
  Eye, 
  Sparkles, 
  FileCheck,
  Lock,
  AlertTriangle,
  RefreshCw,
  Image as ImageIcon
} from 'lucide-react';

export const LeafCheckView: React.FC = () => {
  const { t, language } = useApp();

  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['symptom-leaf-curling']);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [fileError, setFileError] = useState<string | null>(null);
  const [isAnalyzingAi, setIsAnalyzingAi] = useState(false);
  const [aiResult, setAiResult] = useState<AiVisionResult | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sample leaf presets for quick testing
  const samplePresets = [
    {
      label: 'Sample: Leaf Curling (Water Stress)',
      labelTa: 'மாதிரி: இலை சுருளுதல் (வறட்சி)',
      symptoms: ['symptom-leaf-curling'],
      previewColor: 'from-amber-700 via-amber-800 to-emerald-950',
    },
    {
      label: 'Sample: V-Shape Yellowing (N-Hunger)',
      labelTa: 'மாதிரி: V-வடிவ மஞ்சள் (தழைச்சத்து)',
      symptoms: ['symptom-yellow-tips'],
      previewColor: 'from-yellow-600 via-emerald-800 to-green-950',
    },
    {
      label: 'Sample: Spindle Spots (Blast Check)',
      labelTa: 'மாதிரி: வைர புள்ளிகள் (குலை நோய்)',
      symptoms: ['symptom-spindle-spots'],
      previewColor: 'from-stone-700 via-amber-900 to-emerald-950',
    },
    {
      label: 'Sample: Folded Leaves (Leaf Folder)',
      labelTa: 'மாதிரி: சுருட்டப்பட்ட இலை (இலைசுருட்டு)',
      symptoms: ['symptom-holes-chewed'],
      previewColor: 'from-emerald-700 via-lime-800 to-emerald-950',
    },
  ];

  const toggleSymptom = (id: string) => {
    setSelectedSymptoms((prev) => 
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileError(null);
    setAiResult(null);
    setAiError(null);

    // Validate type
    if (!file.type.match(/^image\/(jpeg|png|webp)$/)) {
      setFileError('Invalid file format. Please upload JPEG, PNG, or WebP images.');
      return;
    }

    // Validate size (< 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setFileError('File size exceeds 5MB limit. Please select a smaller photo.');
      return;
    }

    setImageMime(file.type);
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setImagePreview(uploadEvent.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const syntheticEvent = { target: { files: [file] } } as unknown as React.ChangeEvent<HTMLInputElement>;
      handleFileChange(syntheticEvent);
    }
  };

  const clearPhoto = () => {
    setImagePreview(null);
    setFileError(null);
    setAiResult(null);
    setAiError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Derive rule-based diagnoses from selected symptoms
  const matchedDiagnoses: PossibleDiagnosis[] = [];

  if (selectedSymptoms.includes('symptom-yellow-tips')) {
    matchedDiagnoses.push(SYMPTOM_DIAGNOSES.nitrogen_deficiency);
  }
  if (selectedSymptoms.includes('symptom-spindle-spots')) {
    matchedDiagnoses.push(SYMPTOM_DIAGNOSES.rice_blast);
  }
  if (selectedSymptoms.includes('symptom-wavy-margins')) {
    matchedDiagnoses.push(SYMPTOM_DIAGNOSES.bacterial_blight);
  }
  if (selectedSymptoms.includes('symptom-holes-chewed')) {
    matchedDiagnoses.push(SYMPTOM_DIAGNOSES.leaf_folder);
  }
  if (selectedSymptoms.includes('symptom-leaf-curling')) {
    matchedDiagnoses.push(SYMPTOM_DIAGNOSES.water_stress);
  }

  // If no symptoms selected, fallback to water stress demo
  const displayDiagnoses = matchedDiagnoses.length > 0 ? matchedDiagnoses : [SYMPTOM_DIAGNOSES.water_stress];

  const handleRunAiSecondOpinion = async () => {
    if (!imagePreview) return;
    setIsAnalyzingAi(true);
    setAiError(null);

    try {
      const result = await analyzeLeafImageWithGemini(
        imagePreview,
        imageMime,
        selectedSymptoms,
        language
      );
      setAiResult(result);
    } catch (err: unknown) {
      setAiError(
        language === 'ta'
          ? 'காட்சி பகுப்பாய்வில் பிழை ஏற்பட்டது; மாதிரி ஆய்வுக் குறிப்புகளைப் பார்க்கவும்.'
          : 'AI vision check failed; falling back to deterministic agronomic rules.'
      );
    } finally {
      setIsAnalyzingAi(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {t.leafCheckTitle}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-xl">
            {t.leafCheckSubtitle}
          </p>
        </div>

        {/* Local Processing Privacy Badge */}
        <div className="flex items-center gap-1.5 text-xs text-[#566761] bg-[#F7F8F4] px-3 py-1.5 rounded-xl border border-[#E3E8DC]">
          <Lock className="w-3.5 h-3.5 text-[#4E9B5F]" />
          <span>{language === 'ta' ? 'உள்ளூர் உலாவியில் ஆய்வு' : 'Local Browser Inspection'}</span>
        </div>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Photo Upload & Symptoms Checklist */}
        <div className="lg:col-span-5 space-y-5">
          {/* Photo Upload Box */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-[#173F35]">
                {language === 'ta' ? 'இலை புகைப்படம்' : 'Leaf Photo Upload'}
              </h3>
              {imagePreview && (
                <button
                  onClick={clearPhoto}
                  className="text-xs text-rose-600 hover:text-rose-800 flex items-center gap-1 font-semibold"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>{t.removePhoto}</span>
                </button>
              )}
            </div>

            {/* Hidden Input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFileChange}
              className="hidden"
              id="leaf-photo-input"
            />

            {/* Drag & drop or preview */}
            {!imagePreview ? (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#BDDFCA] hover:border-[#4E9B5F] bg-[#F7F8F4] hover:bg-[#EBF4ED] rounded-xl p-6 text-center cursor-pointer transition-colors space-y-2"
              >
                <div className="w-10 h-10 rounded-full bg-white shadow-xs mx-auto flex items-center justify-center text-[#4E9B5F]">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-[#1C2723]">
                    {t.dragDropPhoto}
                  </p>
                  <p className="text-[11px] text-[#83948E] mt-0.5">
                    {t.photoFormatLimit}
                  </p>
                </div>
                <button
                  type="button"
                  className="mt-2 px-3 py-1.5 bg-[#173F35] text-white rounded-lg text-xs font-bold hover:bg-[#1E4D41] transition-colors"
                >
                  {t.browsePhoto}
                </button>
              </div>
            ) : (
              <div className="relative rounded-xl overflow-hidden border border-[#E3E8DC] bg-stone-900 group">
                <img
                  src={imagePreview}
                  alt="Uploaded crop leaf inspection"
                  className="w-full h-52 object-cover object-center"
                />
                {isAnalyzingAi && (
                  <div className="absolute inset-0 bg-emerald-950/75 backdrop-blur-2xs flex flex-col items-center justify-center text-white z-10 animate-in fade-in">
                    <div className="w-12 h-12 rounded-full border-3 border-emerald-400 border-t-transparent animate-spin mb-2" />
                    <span className="text-xs font-bold tracking-wide flex items-center gap-1.5 text-emerald-300">
                      <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                      Gemini 3.8 Flash Multimodal Analysis
                    </span>
                    <span className="text-[10px] text-emerald-100/70 mt-0.5">Diagnosing leaf lesions and chlorosis pattern...</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-3 pointer-events-none">
                  <div className="text-white text-xs">
                    <span className="font-semibold block">Photo Loaded</span>
                    <span className="text-[10px] text-stone-300">Ready for Gemini multimodal & symptom inspection</span>
                  </div>
                </div>
              </div>
            )}

            {fileError && (
              <p className="text-xs text-rose-600 bg-rose-50 p-2 rounded-lg border border-rose-200">
                {fileError}
              </p>
            )}

            {/* Quick Test Presets */}
            <div className="pt-2">
              <span className="text-[10px] font-semibold text-[#83948E] uppercase tracking-wider block mb-1.5">
                {language === 'ta' ? 'மாதிரி பயிர் இலை சோதனைகள்:' : 'Quick Demo Presets (Instant Inspection):'}
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {samplePresets.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedSymptoms(preset.symptoms)}
                    className="p-2 text-left rounded-lg bg-[#F7F8F4] hover:bg-[#EBF4ED] border border-[#E3E8DC] text-[11px] font-medium text-[#1C2723] transition-colors"
                  >
                    {language === 'ta' ? preset.labelTa : preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Observed Symptoms Checklist */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
            <div>
              <h3 className="font-bold text-sm text-[#173F35]">
                {t.symptomsObserved}
              </h3>
              <p className="text-xs text-[#566761] mt-0.5">
                {t.selectSymptomsHint}
              </p>
            </div>

            <div className="space-y-2">
              {LEAF_SYMPTOMS_LIST.map((symptom) => {
                const isSelected = selectedSymptoms.includes(symptom.id);

                return (
                  <button
                    key={symptom.id}
                    onClick={() => toggleSymptom(symptom.id)}
                    className={`w-full text-left p-3 rounded-xl border flex items-start gap-2.5 transition-all text-xs ${
                      isSelected
                        ? 'bg-emerald-50/60 border-emerald-300 ring-1 ring-emerald-200'
                        : 'bg-[#F7F8F4] border-[#E3E8DC] hover:bg-white'
                    }`}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-[#2D8A4E] shrink-0 mt-0.5" />
                    ) : (
                      <Square className="w-4 h-4 text-[#83948E] shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-semibold text-[#1C2723] block leading-snug">
                        {language === 'ta' ? symptom.labelTa : symptom.label}
                      </span>
                      <p className="text-[11px] text-[#566761] mt-0.5 leading-tight">
                        {language === 'ta' ? symptom.descriptionTa : symptom.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Privacy Disclaimer */}
          <div className="p-4 rounded-2xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-1.5 text-xs text-[#566761]">
            <div className="flex items-center gap-1.5 font-bold text-[#173F35]">
              <Lock className="w-4 h-4 text-[#4E9B5F]" />
              <span>{t.privacyNoticeTitle}</span>
            </div>
            <p className="leading-relaxed">
              {t.privacyNoticeBody}
            </p>
          </div>
        </div>

        {/* Right Column: Differential Diagnoses & Field Verification */}
        <div className="lg:col-span-7 space-y-5">
          {/* Main Inspection Guidance Header */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E3E8DC] shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
              <div>
                <h3 className="font-bold text-base text-[#173F35]">
                  {t.possibleCausesTitle}
                </h3>
                <p className="text-xs text-[#566761] mt-0.5">
                  {t.confirmWithAgronomist}
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-stone-100 text-[#566761] border border-stone-200">
                {displayDiagnoses.length} {language === 'ta' ? 'சாத்தியங்கள்' : 'matches'}
              </span>
            </div>

            {/* Diagnoses cards */}
            <div className="space-y-4">
              {displayDiagnoses.map((diag, idx) => (
                <div
                  key={idx}
                  className="p-4 sm:p-5 rounded-xl border border-[#E3E8DC] bg-[#F7F8F4] space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm sm:text-base text-[#1C2723]">
                        {language === 'ta' ? diag.nameTa : diag.name}
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                        {language === 'ta' ? diag.causeTypeTa : diag.causeType}
                      </span>
                    </div>

                    <span className="text-xs font-medium text-[#566761] bg-white px-2 py-0.5 rounded border border-[#E3E8DC] w-fit">
                      {language === 'ta' ? diag.confidenceTa : diag.confidence}
                    </span>
                  </div>

                  <p className="text-xs text-[#566761] leading-relaxed">
                    {language === 'ta' ? diag.descriptionTa : diag.description}
                  </p>

                  {/* Key Visual Signs */}
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-[#173F35] block uppercase tracking-wider">
                      {language === 'ta' ? 'முக்கிய காட்சி அடையாளங்கள்:' : 'Key Visual Characteristics:'}
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-xs text-[#566761]">
                      {(language === 'ta' ? diag.keyVisualSignsTa : diag.keyVisualSigns).map((sign, sIdx) => (
                        <li key={sIdx}>{sign}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Field Inspection Checklist */}
                  <div className="p-3 bg-white rounded-lg border border-[#E3E8DC] space-y-1.5">
                    <span className="text-xs font-bold text-[#173F35] block flex items-center gap-1.5">
                      <FileCheck className="w-3.5 h-3.5 text-[#4E9B5F]" />
                      <span>{t.whatToInspectInField}</span>
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-xs text-[#566761]">
                      {(language === 'ta' ? diag.fieldInspectionChecklistTa : diag.fieldInspectionChecklist).map((check, cIdx) => (
                        <li key={cIdx}>{check}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Safety Caveat */}
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">
                      {language === 'ta' ? diag.safetyCaveatTa : diag.safetyCaveat}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Optional Gemini Vision Second Opinion Box */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#4E9B5F]" />
                <h3 className="font-bold text-sm text-[#173F35]">
                  {t.optionalAiVision}
                </h3>
              </div>
              <span className="text-[10px] text-[#83948E]">
                {language === 'ta' ? 'விருப்பத் தேர்வு' : 'Optional Extra Check'}
              </span>
            </div>

            <p className="text-xs text-[#566761] leading-relaxed">
              {t.aiVisionDisclaimer}
            </p>

            <button
              onClick={handleRunAiSecondOpinion}
              disabled={isAnalyzingAi || !imagePreview}
              className={`w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                !imagePreview
                  ? 'bg-stone-100 text-stone-400 cursor-not-allowed'
                  : 'bg-[#173F35] hover:bg-[#1E4D41] text-white shadow-xs'
              }`}
            >
              {isAnalyzingAi ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-[#65A66F]" />
                  <span>{language === 'ta' ? 'பகுப்பாய்வு செய்கிறது...' : 'Analyzing leaf with Gemini...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#65A66F]" />
                  <span>
                    {imagePreview 
                      ? (language === 'ta' ? 'ஏஐ காட்சி ஆலோசனையை பெறுக' : 'Run Optional AI Vision Analysis')
                      : (language === 'ta' ? 'முதலில் புகைப்படத்தை பதிவேற்றவும்' : 'Upload photo above to enable')}
                  </span>
                </>
              )}
            </button>

            {aiError && (
              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <p>{aiError}</p>
              </div>
            )}

            {aiResult && (
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-50 via-white to-emerald-50/50 border border-emerald-300 space-y-3.5 text-xs animate-in fade-in duration-200 shadow-sm">
                <div className="flex items-center justify-between pb-2 border-b border-emerald-200/60">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span className="font-extrabold text-emerald-950 text-sm">
                      {aiResult.source === 'gemini-3.8-flash' ? 'Gemini 3.8 Flash Vision Diagnosis' : 'TNAU Agronomic Assessment'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {aiResult.confidenceScore && (
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200">
                        {aiResult.confidenceScore}% {language === 'ta' ? 'நம்பகத்தன்மை' : 'Confidence'}
                      </span>
                    )}
                    {aiResult.urgency && (
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        aiResult.urgency === 'severe'
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : aiResult.urgency === 'moderate'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      }`}>
                        {aiResult.urgency}
                      </span>
                    )}
                  </div>
                </div>

                {/* Probable Diagnosis Banner */}
                {aiResult.probableDiagnosis && (
                  <div className="p-3 bg-emerald-100/60 rounded-xl border border-emerald-300/80">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">
                      {language === 'ta' ? 'கண்டறியப்பட்ட பயிர் நிலை:' : 'Probable Agronomic Finding:'}
                    </span>
                    <p className="text-sm font-bold text-emerald-950 mt-0.5">
                      {aiResult.probableDiagnosis}
                    </p>
                  </div>
                )}

                <div>
                  <span className="font-bold text-emerald-900 block">
                    {language === 'ta' ? 'காட்சி அமைப்பு விளக்கம்:' : 'Observed Visual Pattern:'}
                  </span>
                  <p className="text-emerald-950 mt-0.5 leading-relaxed bg-white/70 p-2.5 rounded-lg border border-emerald-200/50">
                    {aiResult.observedVisualPattern}
                  </p>
                </div>

                {/* Actionable Remedy */}
                {aiResult.actionableRemedy && (
                  <div className="p-3 bg-white rounded-xl border border-emerald-200 space-y-1">
                    <span className="font-bold text-emerald-900 block flex items-center gap-1.5">
                      <FileCheck className="w-3.5 h-3.5 text-[#4E9B5F]" />
                      <span>{language === 'ta' ? 'பரிந்துரைக்கப்படும் நடவடிக்கை (IPM):' : 'Actionable Cultural / IPM Remedy:'}</span>
                    </span>
                    <p className="text-emerald-950 leading-relaxed font-medium">
                      {aiResult.actionableRemedy}
                    </p>
                  </div>
                )}

                <div>
                  <span className="font-bold text-emerald-900 block">
                    {language === 'ta' ? 'சாத்தியமான காரணங்கள்:' : 'Probable Environmental / Pathogen Causes:'}
                  </span>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 text-emerald-950">
                    {aiResult.possibleCauses.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 bg-white/90 rounded-xl border border-emerald-200 text-emerald-900">
                  <span className="font-bold block text-xs">
                    {language === 'ta' ? 'வயலில் சோதிக்க வேண்டியவை:' : 'On-site Field Verification Steps:'}
                  </span>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px]">
                    {aiResult.fieldVerificationQuestions.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>

                {aiResult.tamilSummary && language === 'ta' && (
                  <div className="p-2.5 rounded-lg bg-emerald-100/50 border border-emerald-300 text-emerald-950 text-xs">
                    <span className="font-bold block">தமிழில் குறிப்பு:</span>
                    <p className="mt-0.5">{aiResult.tamilSummary}</p>
                  </div>
                )}

                <div className="pt-1 flex items-center justify-between text-[10px] text-stone-500 italic">
                  <span>{aiResult.cautionNotice}</span>
                  <span className="font-medium not-italic text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {aiResult.model || 'gemini-3.8-flash'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
