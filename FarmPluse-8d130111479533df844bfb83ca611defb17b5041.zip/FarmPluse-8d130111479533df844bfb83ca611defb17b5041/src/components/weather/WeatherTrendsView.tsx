import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { fetch7DayWeather, WeatherFetchResult } from '../../services/weatherService';
import { WeatherDay, HourlyWeather } from '../../types';
import { DEMO_HOURLY_WEATHER } from '../../data/demoData';
import { 
  CloudSun, 
  Droplets, 
  Thermometer, 
  RefreshCw, 
  Info, 
  Calendar, 
  Wind, 
  Layers, 
  Sparkles,
  Sun,
  Flame,
  CloudRain,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Compass,
  CheckCircle2,
  Activity,
  MapPin,
  Navigation
} from 'lucide-react';
import { REGIONAL_LOCATION_PRESETS } from '../../data/mandiAndCropData';

export const WeatherTrendsView: React.FC = () => {
  const { t, language, formatTemp, setActiveTab } = useApp();

  const [weatherData, setWeatherData] = useState<WeatherFetchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeMetric, setActiveMetric] = useState<'temp' | 'rain' | 'moisture' | 'et0'>('temp');
  const [selectedCluster, setSelectedCluster] = useState('kaveripakkam');
  const [isCustomMode, setIsCustomMode] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customLat, setCustomLat] = useState('16.3067');
  const [customLng, setCustomLng] = useState('80.4365');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsMessage, setGpsMessage] = useState<string | null>(null);

  const clusters = REGIONAL_LOCATION_PRESETS;

  const loadWeather = async (tryLive: boolean, lat?: number, lng?: number) => {
    setLoading(true);
    let targetLat = lat;
    let targetLng = lng;

    if (targetLat == null || targetLng == null) {
      if (isCustomMode && customLat && customLng) {
        targetLat = parseFloat(customLat);
        targetLng = parseFloat(customLng);
      } else {
        const targetCluster = clusters.find((c) => c.id === selectedCluster) || clusters[0];
        targetLat = targetCluster.lat;
        targetLng = targetCluster.lng;
      }
    }

    try {
      const res = await fetch7DayWeather(tryLive, targetLat, targetLng);
      setWeatherData(res);
    } catch {
      // fallback handled in service
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!isCustomMode) {
      loadWeather(true);
    }
  }, [selectedCluster, isCustomMode]);

  // Device GPS Geolocation
  const handleUseDeviceGps = () => {
    if (!navigator.geolocation) {
      setGpsMessage('Geolocation is not supported by your device or browser.');
      return;
    }
    setGpsLoading(true);
    setGpsMessage(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCustomLat(lat.toFixed(4));
        setCustomLng(lng.toFixed(4));
        setCustomName(`Field GPS (${lat.toFixed(2)}°, ${lng.toFixed(2)}°)`);
        setIsCustomMode(true);
        setGpsLoading(false);
        setGpsMessage('Acquired accurate GPS coordinates from your mobile device.');
        loadWeather(true, lat, lng);
      },
      (err) => {
        setGpsLoading(false);
        setGpsMessage(err.code === 1 ? 'Location permission was denied. Please enter coordinates manually.' : 'Unable to acquire GPS signal. Try manual entry.');
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleApplyCustomLocation = (e: React.FormEvent) => {
    e.preventDefault();
    const lat = parseFloat(customLat);
    const lng = parseFloat(customLng);
    if (!isNaN(lat) && !isNaN(lng)) {
      setIsCustomMode(true);
      loadWeather(true, lat, lng);
    }
  };

  const days: WeatherDay[] = weatherData?.days || [];
  const hourlyList: HourlyWeather[] = DEMO_HOURLY_WEATHER;

  const getWeatherIcon = (cond: string) => {
    switch (cond) {
      case 'rainy': return <CloudRain className="w-5 h-5 text-blue-600" />;
      case 'partly_cloudy': return <CloudSun className="w-5 h-5 text-amber-500" />;
      case 'hot_dry': return <Flame className="w-5 h-5 text-rose-500" />;
      default: return <Sun className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {t.navWeather}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {weatherData?.isLive ? 'Live Open-Meteo' : t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-xl">
            {weatherData?.disclaimer || 'High-precision agricultural meteorology and root-zone moisture tracking.'}
          </p>
        </div>

        {/* Location Selector & Refresh Buttons */}
        <div className="flex flex-col sm:items-end gap-2 self-start sm:self-auto w-full sm:w-auto">
          <div className="flex items-center gap-2 flex-wrap">
            {!isCustomMode ? (
              <select
                value={selectedCluster}
                onChange={(e) => {
                  setSelectedCluster(e.target.value);
                  setIsCustomMode(false);
                }}
                className="px-3 py-2 rounded-xl border border-[#E3E8DC] text-xs font-semibold bg-[#F7F8F4] text-[#173F35] focus:outline-hidden focus:border-[#4E9B5F]"
              >
                <optgroup label="Tamil Nadu">
                  {clusters.filter((c) => c.state === 'Tamil Nadu').map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Andhra Pradesh">
                  {clusters.filter((c) => c.state === 'Andhra Pradesh').map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Telangana">
                  {clusters.filter((c) => c.state === 'Telangana').map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </optgroup>
              </select>
            ) : (
              <div className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-300 text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                <span>{customName || `${customLat}°, ${customLng}°`}</span>
                <button
                  onClick={() => setIsCustomMode(false)}
                  className="ml-1 text-[10px] text-emerald-700 underline"
                >
                  Preset Hubs
                </button>
              </div>
            )}

            <button
              onClick={() => setIsCustomMode(!isCustomMode)}
              className="px-2.5 py-2 rounded-xl border border-[#E3E8DC] hover:border-[#4E9B5F] bg-[#F7F8F4] hover:bg-white text-xs font-semibold text-[#173F35] flex items-center gap-1 transition-colors"
              title="Enter manual coordinates or use GPS"
            >
              <Navigation className="w-3.5 h-3.5 text-[#4E9B5F]" />
              <span>{isCustomMode ? 'Presets' : 'Custom / GPS'}</span>
            </button>

            <button
              onClick={() => loadWeather(true)}
              disabled={loading}
              className="px-3 py-2 rounded-xl border border-[#E3E8DC] hover:border-[#4E9B5F] bg-[#F7F8F4] hover:bg-white text-xs font-semibold text-[#173F35] flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#4E9B5F]' : ''}`} />
              <span>{loading ? 'Updating...' : 'Sync'}</span>
            </button>

            <button
              onClick={() => setActiveTab('weathermap')}
              className="px-3.5 py-2 rounded-xl bg-[#173F35] hover:bg-[#255e50] text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Layers className="w-3.5 h-3.5 text-emerald-300" />
              <span>{language === 'ta' ? 'ரேடார் வரைபடம்' : (language === 'te' ? 'వాతావరణ పటం' : 'Radar Map')}</span>
            </button>
          </div>

          {/* Custom GPS / Manual Lat-Lng Drawer */}
          {isCustomMode && (
            <form onSubmit={handleApplyCustomLocation} className="flex items-center gap-2 pt-1 flex-wrap text-xs">
              <input
                type="text"
                placeholder="Lat (e.g. 16.30)"
                value={customLat}
                onChange={(e) => setCustomLat(e.target.value)}
                className="w-24 px-2.5 py-1.5 bg-[#F7F8F4] border border-[#E3E8DC] rounded-lg text-xs"
                required
              />
              <input
                type="text"
                placeholder="Lng (e.g. 80.43)"
                value={customLng}
                onChange={(e) => setCustomLng(e.target.value)}
                className="w-24 px-2.5 py-1.5 bg-[#F7F8F4] border border-[#E3E8DC] rounded-lg text-xs"
                required
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-[#173F35] text-white rounded-lg font-bold text-xs hover:bg-[#1E4D41]"
              >
                Apply
              </button>
              <button
                type="button"
                onClick={handleUseDeviceGps}
                disabled={gpsLoading}
                className="px-2.5 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg font-bold text-xs flex items-center gap-1 hover:bg-emerald-100"
              >
                <MapPin className="w-3 h-3 text-emerald-600" />
                <span>{gpsLoading ? 'Locating...' : 'Use My GPS'}</span>
              </button>
            </form>
          )}

          {gpsMessage && (
            <p className="text-[11px] text-emerald-700 italic">
              {gpsMessage}
            </p>
          )}
        </div>
      </div>

      {/* Agronomic Spray Window & Field Advisory Banner */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-white p-5 rounded-2xl border border-emerald-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#173F35] text-white">
              <ShieldCheck className="w-5 h-5 text-[#65A66F]" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
                {t.spraySuitabilityTitle}
              </h3>
              <p className="text-xs text-[#566761]">
                {t.spraySuitabilityDesc}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-lg border border-emerald-300 w-fit">
            Morning Window: Optimal
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
          <div className="p-3 rounded-xl bg-white/80 border border-emerald-200">
            <span className="font-bold text-emerald-950 block">06:00 AM – 09:00 AM (Recommended)</span>
            <p className="text-[#566761] mt-0.5">
              Wind speed is low (8–10 km/h) and temperature &lt; 28°C. Ideal for bio-fertilizer and foliar application.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-white/80 border border-amber-200">
            <span className="font-bold text-amber-950 block">11:30 AM – 03:30 PM (Avoid Field Sprays)</span>
            <p className="text-[#566761] mt-0.5">
              Peak heat reaches 36.5°C and relative humidity drops to 39%. High droplet evaporation risk.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-white/80 border border-blue-200">
            <span className="font-bold text-blue-950 block">05:30 PM – 07:30 PM (Irrigation Window)</span>
            <p className="text-[#566761] mt-0.5">
              Evaporative demand settles down to 0.4 mm/h. Optimal for canal water intake into paddy beds.
            </p>
          </div>
        </div>
      </div>

      {/* 24-Hour Hourly Forecast Strip */}
      <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#E3E8DC]">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
              {t.hourlyForecastTitle}
            </h3>
            <p className="text-xs text-[#566761]">
              {t.hourlyForecastDesc}
            </p>
          </div>
          <Clock className="w-4 h-4 text-[#4E9B5F]" />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 overflow-x-auto pt-1">
          {hourlyList.map((hr, idx) => {
            const isMiddayHeat = hr.tempC >= 35;
            return (
              <div
                key={idx}
                className={`p-3 rounded-xl border text-center flex flex-col justify-between transition-all ${
                  isMiddayHeat 
                    ? 'bg-rose-50/60 border-rose-200' 
                    : hr.spraySuitability === 'optimal' 
                    ? 'bg-emerald-50/50 border-emerald-200' 
                    : 'bg-[#F7F8F4] border-[#E3E8DC]'
                }`}
              >
                <span className="text-xs font-bold text-[#1C2723] block">{hr.hourLabel}</span>
                <span className="text-[11px] font-mono font-bold text-[#173F35] my-1">
                  {formatTemp(hr.tempC)}
                </span>

                <div className="text-[10px] space-y-0.5 text-[#566761] pt-1 border-t border-stone-200/60">
                  <div className="flex items-center justify-center gap-1 text-blue-700">
                    <Droplets className="w-2.5 h-2.5" />
                    <span>{hr.rainProbPercent}%</span>
                  </div>
                  <div className="flex items-center justify-center gap-1 text-stone-600">
                    <Wind className="w-2.5 h-2.5" />
                    <span>{hr.windSpeedKmh}kph</span>
                  </div>
                </div>

                <div className={`mt-2 py-0.5 px-1 rounded text-[9px] font-bold uppercase tracking-wider ${
                  hr.spraySuitability === 'optimal' ? 'bg-emerald-100 text-emerald-800' :
                  hr.spraySuitability === 'moderate' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                }`}>
                  {hr.spraySuitability}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Metric Selector Tabs for 7-Day Chart */}
      <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-[#E3E8DC] shadow-xs overflow-x-auto">
        <button
          onClick={() => setActiveMetric('temp')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
            activeMetric === 'temp'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4]'
          }`}
        >
          <Thermometer className="w-4 h-4" />
          <span>{language === 'ta' ? 'வெப்பநிலை (°C)' : 'Ambient Temperature'}</span>
        </button>

        <button
          onClick={() => setActiveMetric('rain')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
            activeMetric === 'rain'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4]'
          }`}
        >
          <Droplets className="w-4 h-4 text-blue-400" />
          <span>{language === 'ta' ? 'மழைப்பொழிவு (mm)' : 'Rainfall Precipitation'}</span>
        </button>

        <button
          onClick={() => setActiveMetric('moisture')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
            activeMetric === 'moisture'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4]'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" />
          <span>{language === 'ta' ? 'மண் ஈரப்பதம் (%)' : 'Soil Moisture (%)'}</span>
        </button>

        <button
          onClick={() => setActiveMetric('et0')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
            activeMetric === 'et0'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4]'
          }`}
        >
          <Activity className="w-4 h-4 text-purple-400" />
          <span>{language === 'ta' ? 'ஆவியாதல் (ET0)' : 'Evapotranspiration (ET0)'}</span>
        </button>
      </div>

      {/* Main 7-Day Chart Canvas */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E3E8DC] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
          <div>
            <h3 className="font-bold text-base text-[#173F35]">
              {activeMetric === 'temp' && (language === 'ta' ? '7 நாள் வெப்பநிலை போக்கு' : '7-Day Ambient Temperature Curve')}
              {activeMetric === 'rain' && (language === 'ta' ? '7 நாள் மழைப்பொழிவு வரத்து' : '7-Day Precipitation Inflow (mm)')}
              {activeMetric === 'moisture' && (language === 'ta' ? 'மண் ஈரப்பதம் போக்கு' : 'Root Zone Soil Moisture Trend (%)')}
              {activeMetric === 'et0' && (language === 'ta' ? 'தினசரி நீராவிப்போக்கு (ET0 மி.மீ/நாள்)' : 'Crop Evapotranspiration Rate (ET0 mm/day)')}
            </h3>
            <p className="text-xs text-[#566761] mt-0.5">
              {clusters.find((c) => c.id === selectedCluster)?.name} • Pilot Agronomic Baseline
            </p>
          </div>
        </div>

        {/* Dynamic Responsive SVG Bar Chart */}
        <div className="w-full h-56 pt-6 pb-2 px-2 flex items-end justify-between gap-3 sm:gap-6 bg-[#F7F8F4] rounded-xl border border-[#E3E8DC]">
          {days.map((day) => {
            let heightPercent = 20;
            let displayValue = '';
            let barColor = 'bg-[#173F35]';

            if (activeMetric === 'temp') {
              heightPercent = Math.max(15, Math.min(100, ((day.tempMaxC - 20) / 20) * 100));
              displayValue = formatTemp(day.tempMaxC);
              barColor = day.tempMaxC >= 35 ? 'bg-rose-500' : 'bg-amber-500';
            } else if (activeMetric === 'rain') {
              heightPercent = Math.max(10, Math.min(100, (day.rainfallMm / 15) * 100));
              displayValue = `${day.rainfallMm}mm`;
              barColor = 'bg-blue-600';
            } else if (activeMetric === 'moisture') {
              heightPercent = Math.max(15, Math.min(100, (day.soilMoisturePercent / 45) * 100));
              displayValue = `${day.soilMoisturePercent}%`;
              barColor = day.soilMoisturePercent < 20 ? 'bg-rose-500' : day.soilMoisturePercent < 28 ? 'bg-amber-500' : 'bg-[#2D8A4E]';
            } else {
              const et = day.evapotranspirationMm || 4.5;
              heightPercent = Math.max(20, Math.min(100, (et / 7) * 100));
              displayValue = `${et.toFixed(1)}mm`;
              barColor = et > 5.0 ? 'bg-purple-600' : 'bg-teal-600';
            }

            return (
              <div key={day.date} className="flex-1 flex flex-col items-center h-full justify-end group">
                <span className="text-[11px] font-bold text-[#1C2723] mb-1 group-hover:scale-110 transition-transform font-mono">
                  {displayValue}
                </span>

                <div className="w-full max-w-[48px] bg-white rounded-t-lg h-36 flex items-end p-1 border border-stone-200 shadow-2xs">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-md transition-all duration-500 ${barColor}`}
                  />
                </div>

                <span className="text-xs font-semibold text-[#566761] mt-2">
                  {language === 'ta' ? day.dayNameTa : day.dayName}
                </span>
                <span className="text-[10px] text-[#83948E]">
                  {day.date.split('-').slice(1).join('/')}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Multi-Depth Soil Moisture Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
          <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
            {t.soilMoistureDepthTitle}
          </h3>
          <p className="text-xs text-[#566761]">
            Dual-depth capacitance probe comparison showing moisture depletion dynamics.
          </p>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span>{t.surfaceSoil}</span>
                <span className="text-rose-700 font-bold font-mono">18% (Critical)</span>
              </div>
              <div className="h-2.5 w-full bg-stone-100 rounded-full overflow-hidden flex">
                <div style={{ width: '18%' }} className="bg-rose-500 rounded-full" />
              </div>
              <span className="text-[10px] text-[#83948E] mt-0.5 block">
                Directly impacted by sun exposure; micro-cracking observed.
              </span>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span>{t.rootZoneSoil}</span>
                <span className="text-amber-700 font-bold font-mono">23% (Watch)</span>
              </div>
              <div className="h-2.5 w-full bg-stone-100 rounded-full overflow-hidden flex">
                <div style={{ width: '23%' }} className="bg-amber-500 rounded-full" />
              </div>
              <span className="text-[10px] text-[#83948E] mt-0.5 block">
                Moderate dampness retained; root extraction active.
              </span>
            </div>
          </div>
        </div>

        {/* Agricultural Weather Advisory */}
        <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
          <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
            {language === 'ta' ? 'வேளாண் வானிலை வழிகாட்டுதல்' : 'Agronomic Actionable Brief'}
          </h3>
          <ul className="space-y-2 text-xs text-[#566761]">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4E9B5F] shrink-0 mt-0.5" />
              <span>
                Maintain bund compaction to prevent seepage into drainage ditches during high ET0 days.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4E9B5F] shrink-0 mt-0.5" />
              <span>
                Night temperatures are settling at 25–26°C, which supports healthy nocturnal respiration.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                Thursday Palar canal rotation is vital to recharge root zones across East Paddy and Canal Edge plots.
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
