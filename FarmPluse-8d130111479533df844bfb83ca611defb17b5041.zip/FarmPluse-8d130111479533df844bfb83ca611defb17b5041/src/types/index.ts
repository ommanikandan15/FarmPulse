export type RiskLevel = 'low' | 'watch' | 'high';

export type GrowthStage = 
  | 'nursery' 
  | 'tillering' 
  | 'panicle_initiation' 
  | 'flowering' 
  | 'grain_filling' 
  | 'mature';

export type DataSourceType = 'farmer' | 'weather_api' | 'satellite' | 'sensor' | 'demo';

export type SupportedLanguage = 'en' | 'ta' | 'te' | 'ml' | 'kn' | 'hi';

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  role: 'farmer' | 'fpo_manager' | 'agronomist' | 'buyer';
  roleLabel: string;
  village: string;
  fpoName?: string;
  avatarInitials: string;
  isLoggedIn: boolean;
}

export interface Observation {
  id: string;
  plotId: string;
  timestamp: string;
  daysWithoutRain: number;
  soilMoisturePercent: number;
  weeklyGreennessChangePercent: number;
  temperatureCelsius: number;
  humidityPercent: number;
  ndvi?: number | null; // Normalized Difference Vegetation Index (-1 to 1)
  ndwi?: number | null; // Normalized Difference Water Index (-1 to 1)
  sourceType: DataSourceType;
  notes?: string;
}

export interface EvidenceFactor {
  id: string;
  category: 'moisture' | 'rainfall' | 'greenness' | 'temperature' | 'satellite';
  title: string;
  titleTa: string;
  inputValue: string;
  thresholdRule: string;
  thresholdRuleTa: string;
  weight: number; // contribution score points (e.g. +30)
  contributionPercent: number;
  explanation: string;
  explanationTa: string;
  severity: 'low' | 'watch' | 'high' | 'info';
  isSatelliteContext?: boolean;
}

export type StressCategoryType = 'water' | 'nutrient' | 'pest_disease' | 'heat';

export interface CategoryStressResult {
  category: StressCategoryType;
  name: string;
  nameTa: string;
  riskLevel: RiskLevel; // 'low' | 'watch' | 'high'
  score: number; // 0 - 100
  supportingObservations: string[];
  supportingObservationsTa: string[];
  contributingFactors: string[];
  contributingFactorsTa: string[];
  explanation: string;
  explanationTa: string;
  recommendedNextStep: string;
  recommendedNextStepTa: string;
  missingInformation: string[];
  missingInformationTa: string[];
  sourceAndTimestamp: string;
  sourceAndTimestampTa: string;
}

export interface FiveExplainableQuestions {
  identifiedProblem: {
    title: string;
    titleTa: string;
    details: string;
    detailsTa: string;
  };
  whySuspected: {
    reasoning: string;
    reasoningTa: string;
    agronomicPrinciple: string;
    agronomicPrincipleTa: string;
  };
  supportingInputs: {
    inputSummary: string;
    inputSummaryTa: string;
    factors: {
      name: string;
      nameTa: string;
      value: string;
      contributionPercent: number;
      ruleTriggered: string;
    }[];
  };
  whatToCheckNext: {
    primaryCheck: string;
    primaryCheckTa: string;
    checklist: string[];
    checklistTa: string[];
    safetyWarning: string;
    safetyWarningTa: string;
  };
  reliabilityAndLimitations: {
    reliabilityScore: 'High (Direct Measurements)' | 'Moderate (Derived Proxies)' | 'Preliminary (Limited Inputs)';
    reliabilityScoreTa: string;
    confidencePercent: number;
    limitations: string[];
    limitationsTa: string[];
    transparencyNote: string;
    transparencyNoteTa: string;
  };
}

export interface AdvisoryResult {
  plotId: string;
  riskLevel: RiskLevel;
  stressScore: number; // 0 - 100 demo score
  headline: string;
  headlineTa: string;
  summary: string;
  summaryTa: string;
  primaryAction: string;
  primaryActionTa: string;
  actionChecklist: string[];
  actionChecklistTa: string[];
  evidenceList: EvidenceFactor[];
  dataCoveragePercent: number;
  availableFieldsCount: number;
  totalFieldsCount: number;
  missingFields: string[];
  missingFieldsTa: string[];
  uncertaintyNotes: string;
  uncertaintyNotesTa: string;
  assessedAt: string;
  officerConsultWarning: boolean;
  categories?: {
    waterStress: CategoryStressResult;
    nutrientStress: CategoryStressResult;
    pestDiseaseRisk: CategoryStressResult;
    heatStress: CategoryStressResult;
  };
  explainableQuestions?: FiveExplainableQuestions;
  farmInfo?: {
    farmName: string;
    location: string;
    cropType: string;
    growthStage: GrowthStage;
    plantingDate?: string;
  };
}

export interface FarmAnalysisInput {
  farmName: string;
  location: string;
  cropType: string;
  growthStage: GrowthStage;
  plantingDate?: string;
  soilMoisturePercent?: number | null;
  recentRainfallMm?: number | null;
  daysWithoutRain?: number | null;
  temperatureCelsius?: number | null;
  humidityPercent?: number | null;
  leafImage?: string | null;
  leafImageName?: string | null;
  notes?: string;
}

export interface SavedFarmAnalysis {
  id: string;
  timestamp: string;
  farmName: string;
  location: string;
  cropType: string;
  growthStage: GrowthStage;
  overallRisk: RiskLevel;
  overallScore: number;
  advisory: AdvisoryResult;
  isSample: boolean;
}

export interface PlotPolygonCoord {
  lat: number;
  lng: number;
}

export interface Plot {
  id: string;
  name: string;
  nameTa: string;
  nameTe?: string;
  farmerName: string;
  farmerNameTa: string;
  farmerNameTe?: string;
  farmerPhoneMasked: string;
  cropType?: string; // e.g. Paddy, Cotton, Groundnut, Maize, Chilli, Tomato, Sugarcane
  cropTypeTe?: string;
  cropTypeTa?: string;
  variety: string; // e.g. CR 1009, CO 51, ADT 45, BPT 5204
  varietyTa: string;
  varietyTe?: string;
  growthStage: GrowthStage;
  areaAcres: number;
  surveyNumber?: string;
  sowingDate?: string;
  soilType?: string;
  irrigationType?: string;
  locationName: string;
  locationNameTa: string;
  locationNameTe?: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  boundaryPolygon: PlotPolygonCoord[];
  latestObservation: Observation;
  advisory: AdvisoryResult;
  history: Observation[];
}

export interface HourlyWeather {
  time: string;
  hourLabel: string;
  tempC: number;
  rainProbPercent: number;
  rainfallMm: number;
  windSpeedKmh: number;
  humidityPercent: number;
  soilMoisture10cm: number;
  soilMoisture30cm: number;
  evapotranspirationMm: number;
  uvIndex: number;
  spraySuitability: 'optimal' | 'moderate' | 'unfavorable';
  sprayNote: string;
  sprayNoteTa: string;
}

export interface WeatherDay {
  date: string;
  dayName: string;
  dayNameTa: string;
  tempMaxC: number;
  tempMinC: number;
  rainfallMm: number;
  humidityPercent: number;
  soilMoisturePercent: number;
  evapotranspirationMm?: number;
  condition: 'sunny' | 'partly_cloudy' | 'rainy' | 'overcast' | 'hot_dry';
  conditionTa: string;
  isDemo: boolean;
  hourly?: HourlyWeather[];
}

export interface ClusterSummary {
  clusterName: string;
  clusterNameTa: string;
  district: string;
  state: string;
  totalPlots: number;
  totalAreaAcres: number;
  riskCounts: {
    low: number;
    watch: number;
    high: number;
  };
  cropBreakdown: {
    crop: string;
    cropTa: string;
    plots: number;
    acres: number;
    riskDistribution: { low: number; watch: number; high: number };
  }[];
  readinessTimeline: {
    period: string;
    periodTa: string;
    expectedHarvestAcres: number;
    status: 'on_track' | 'needs_inspection' | 'delayed_water';
    description: string;
    descriptionTa: string;
  }[];
  operationalRecommendations: {
    id: string;
    priority: 'high' | 'medium' | 'info';
    text: string;
    textTa: string;
  }[];
}

export interface AppSettings {
  language: SupportedLanguage;
  tempUnit: 'C' | 'F';
  areaUnit: 'acre' | 'ha';
  region: string;
  audioSpeechEnabled: boolean;
  highContrast: boolean;
  dataSourceMode: 'demo_synthetic' | 'open_meteo_live';
  mapMode: 'google_maps' | 'schematic';
  mapType: 'satellite' | 'hybrid' | 'roadmap';
}

export interface LeafSymptom {
  id: string;
  label: string;
  labelTa: string;
  description: string;
  descriptionTa: string;
}

export interface PossibleDiagnosis {
  name: string;
  nameTa: string;
  confidence: 'High match' | 'Moderate match' | 'Low match';
  confidenceTa: string;
  causeType: 'Nutrient Deficiency' | 'Fungal Disease' | 'Bacterial Infection' | 'Insect/Pest Damage' | 'Water Stress';
  causeTypeTa: string;
  description: string;
  descriptionTa: string;
  keyVisualSigns: string[];
  keyVisualSignsTa: string[];
  fieldInspectionChecklist: string[];
  fieldInspectionChecklistTa: string[];
  safetyCaveat: string;
  safetyCaveatTa: string;
}
