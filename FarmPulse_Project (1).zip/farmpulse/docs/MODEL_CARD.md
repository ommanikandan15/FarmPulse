# Model / decision-system card

**Name:** FarmPulse transparent rules v0.1  
**System type:** deterministic demonstration rules, not machine learning  
**Intended use:** student project demo and design validation  
**Not intended for:** autonomous irrigation scheduling, fertilizer prescriptions, pesticide recommendations, insurance, lending, or procurement commitments.

## Inputs
Days without rain, soil moisture percentage, weekly greenness change, temperature, humidity, optional NDVI/NDWI and crop-stage label.

## Outputs
Low / Watch / High priority, the factors that triggered rules, a field-verification step, and a data-coverage label.

## Limitations
Thresholds are illustrative. Soil-moisture readings vary by sensor, soil texture and placement. Vegetation indices are affected by clouds, field boundaries, growth stage and observation timing. Symptoms can have multiple causes. Coverage labels count available fields and are not calibrated predictive confidence. No real disease classifier or yield model is included.

## Validation required before deployment
Domain review; prospective field trials; false-positive/false-negative analysis by crop stage and geography; calibration; missing-data robustness; local-language comprehension tests; accessibility tests; privacy/security review.
