import React, { useState } from 'react';
import { Plot } from '../../types';
import { useApp } from '../../context/AppContext';
import { evaluateCropStress, EngineInput } from '../../services/advisoryEngine';
import { Sliders, RefreshCw, Play, Sparkles } from 'lucide-react';

interface InteractiveScenarioTesterProps {
  plot: Plot;
}

export const InteractiveScenarioTester: React.FC<InteractiveScenarioTesterProps> = ({ plot }) => {
  const { t, language, updatePlotAdvisory } = useApp();

  const obs = plot.latestObservation;

  const [daysWithoutRain, setDaysWithoutRain] = useState(obs.daysWithoutRain);
  const [soilMoisture, setSoilMoisture] = useState(obs.soilMoisturePercent);
  const [greennessChange, setGreennessChange] = useState(obs.weeklyGreennessChangePercent);
  const [temp, setTemp] = useState(obs.temperatureCelsius);
  const [humidity, setHumidity] = useState(obs.humidityPercent);
  const [hasSatelliteNdvi, setHasSatelliteNdvi] = useState(obs.ndvi !== null && obs.ndvi !== undefined);

  const handleSimulate = () => {
    const simulatedInput: EngineInput = {
      crop: plot.variety,
      growthStage: plot.growthStage,
      daysWithoutRain,
      soilMoisturePercent: soilMoisture,
      weeklyGreennessChangePercent: greennessChange,
      temperatureCelsius: temp,
      humidityPercent: humidity,
      ndvi: hasSatelliteNdvi ? 0.42 : null,
      ndwi: hasSatelliteNdvi ? -0.06 : null,
    };

    const newAdvisory = evaluateCropStress(simulatedInput);
    updatePlotAdvisory(plot.id, newAdvisory);
  };

  const handleReset = () => {
    setDaysWithoutRain(obs.daysWithoutRain);
    setSoilMoisture(obs.soilMoisturePercent);
    setGreennessChange(obs.weeklyGreennessChangePercent);
    setTemp(obs.temperatureCelsius);
    setHumidity(obs.humidityPercent);
    setHasSatelliteNdvi(obs.ndvi !== null && obs.ndvi !== undefined);

    const resetInput: EngineInput = {
      crop: plot.variety,
      growthStage: plot.growthStage,
      daysWithoutRain: obs.daysWithoutRain,
      soilMoisturePercent: obs.soilMoisturePercent,
      weeklyGreennessChangePercent: obs.weeklyGreennessChangePercent,
      temperatureCelsius: obs.temperatureCelsius,
      humidityPercent: obs.humidityPercent,
      ndvi: obs.ndvi,
      ndwi: obs.ndwi,
    };

    updatePlotAdvisory(plot.id, evaluateCropStress(resetInput));
  };

  return (
    <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
            <Sliders className="w-4 h-4 text-[#4E9B5F]" />
          </div>
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
              {t.interactiveScenarioTester}
            </h3>
            <p className="text-xs text-[#566761]">
              {language === 'ta'
                ? 'அளவீடுகளை மாற்றி ஆலோசனை விதிகள் எப்படி செயல்படுகின்றன என்று சோதிக்கவும்'
                : 'Simulate weather shifts or irrigation events to test deterministic rule responses.'}
            </p>
          </div>
        </div>

        <button
          onClick={handleReset}
          className="text-xs text-[#566761] hover:text-[#173F35] flex items-center gap-1 font-medium px-2 py-1 rounded hover:bg-[#F7F8F4]"
          title={t.resetToGroundValues}
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.resetToGroundValues}</span>
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Days without rain slider */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="slider-rain" className="font-medium text-[#1C2723]">
              {t.daysWithoutRain}
            </label>
            <span className="font-bold text-[#173F35] font-mono">{daysWithoutRain} days</span>
          </div>
          <input
            id="slider-rain"
            type="range"
            min="0"
            max="14"
            step="1"
            value={daysWithoutRain}
            onChange={(e) => setDaysWithoutRain(Number(e.target.value))}
            className="w-full accent-[#173F35]"
          />
          <span className="text-[10px] text-[#83948E] block">
            Rule trigger: &ge;7 days (High), 4–6 days (Watch)
          </span>
        </div>

        {/* Soil moisture slider */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="slider-moisture" className="font-medium text-[#1C2723]">
              {t.soilMoisture}
            </label>
            <span className="font-bold text-[#173F35] font-mono">{soilMoisture}%</span>
          </div>
          <input
            id="slider-moisture"
            type="range"
            min="10"
            max="45"
            step="1"
            value={soilMoisture}
            onChange={(e) => setSoilMoisture(Number(e.target.value))}
            className="w-full accent-[#173F35]"
          />
          <span className="text-[10px] text-[#83948E] block">
            Rule trigger: &lt;20% (High), 20–28% (Watch)
          </span>
        </div>

        {/* Weekly Greenness slider */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="slider-greenness" className="font-medium text-[#1C2723]">
              {t.weeklyGreenness}
            </label>
            <span className="font-bold text-[#173F35] font-mono">
              {greennessChange >= 0 ? '+' : ''}{greennessChange}%
            </span>
          </div>
          <input
            id="slider-greenness"
            type="range"
            min="-25"
            max="10"
            step="0.5"
            value={greennessChange}
            onChange={(e) => setGreennessChange(Number(e.target.value))}
            className="w-full accent-[#173F35]"
          />
          <span className="text-[10px] text-[#83948E] block">
            Rule trigger: &le;-12% (High), -6% to -11.9% (Watch)
          </span>
        </div>

        {/* Temperature slider */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="slider-temp" className="font-medium text-[#1C2723]">
              {t.temperature}
            </label>
            <span className="font-bold text-[#173F35] font-mono">{temp.toFixed(1)}°C</span>
          </div>
          <input
            id="slider-temp"
            type="range"
            min="26"
            max="42"
            step="0.5"
            value={temp}
            onChange={(e) => setTemp(Number(e.target.value))}
            className="w-full accent-[#173F35]"
          />
          <span className="text-[10px] text-[#83948E] block">
            Rule trigger: &ge;35°C (Thermal load)
          </span>
        </div>

        {/* Relative Humidity slider */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="slider-humidity" className="font-medium text-[#1C2723]">
              {t.humidity}
            </label>
            <span className="font-bold text-[#173F35] font-mono">{humidity}%</span>
          </div>
          <input
            id="slider-humidity"
            type="range"
            min="25"
            max="90"
            step="1"
            value={humidity}
            onChange={(e) => setHumidity(Number(e.target.value))}
            className="w-full accent-[#173F35]"
          />
          <span className="text-[10px] text-[#83948E] block">
            Rule trigger: &lt;40% (Vapor deficit)
          </span>
        </div>

        {/* Satellite coverage toggle */}
        <div className="space-y-1.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-[#1C2723]">Sentinel-2 Satellite Pass</span>
            <span className={`text-[11px] font-semibold ${hasSatelliteNdvi ? 'text-blue-700' : 'text-stone-400'}`}>
              {hasSatelliteNdvi ? 'Available' : 'Missing'}
            </span>
          </div>
          <label className="flex items-center gap-2 text-xs text-[#566761] cursor-pointer">
            <input
              type="checkbox"
              checked={hasSatelliteNdvi}
              onChange={(e) => setHasSatelliteNdvi(e.target.checked)}
              className="accent-[#173F35] rounded"
            />
            <span>Include optical NDVI & NDWI</span>
          </label>
          <span className="text-[10px] text-[#83948E] block">
            Tests graceful fallback when clouds block satellite pass.
          </span>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-[#E3E8DC] flex justify-end">
        <button
          onClick={handleSimulate}
          className="px-5 py-2.5 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors flex items-center gap-2"
        >
          <Play className="w-4 h-4 fill-white" />
          <span>{t.runSimulation}</span>
        </button>
      </div>
    </div>
  );
};
