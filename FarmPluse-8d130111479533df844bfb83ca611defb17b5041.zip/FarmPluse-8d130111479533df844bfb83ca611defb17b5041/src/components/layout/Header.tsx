import React, { useState } from 'react';
import { 
  Sprout, 
  Activity, 
  MapPin, 
  Calendar, 
  Bell, 
  Languages, 
  User, 
  ChevronDown, 
  Check, 
  ShieldCheck,
  AlertTriangle,
  Info,
  LogIn,
  UserCheck,
  Smartphone
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LANGUAGE_OPTIONS } from '../../data/translations';
import { SupportedLanguage } from '../../types';
import { ApkInstallModal } from '../pwa/ApkInstallModal';

export const Header: React.FC = () => {
  const { 
    t, 
    language, 
    setLanguage, 
    region, 
    setRegion, 
    notifications, 
    markNotificationsAsRead,
    currentUser,
    setIsLoginModalOpen
  } = useApp();

  const [showRegionMenu, setShowRegionMenu] = useState(false);
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const pilotRegions = [
    { id: 'kaveripakkam', label: 'Kaveripakkam Pilot Cluster, Ranipet', labelTa: 'காவேரிப்பாக்கம் மாதிரி வட்டம், ராணிப்பேட்டை' },
    { id: 'thanjavur', label: 'Thanjavur Delta Zone, Cauvery Basin', labelTa: 'தஞ்சாவூர் டெல்டா மண்டலம், காவிரிப் படுகை' },
    { id: 'madurai', label: 'Madurai Vaigai Sub-Basin', labelTa: 'மதுரை வைகை துணைப் படுகை' },
    { id: 'tirunelveli', label: 'Tamirabarani Upper Canal, Tirunelveli', labelTa: 'தாமிரபரணி மேல்மட்ட கால்வாய், திருநெல்வேலி' },
  ];

  const currentDateFormatted = language === 'ta' 
    ? 'புதன், 21 அக் 2026' 
    : 'Wed, 21 Oct 2026';

  const currentLangOption = LANGUAGE_OPTIONS.find((l) => l.code === language) || LANGUAGE_OPTIONS[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E3E8DC] px-3 sm:px-6 py-2.5 shadow-xs transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Logo & Tagline */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#173F35] flex items-center justify-center text-white shadow-xs relative overflow-hidden group">
              <Sprout className="w-5 h-5 text-[#65A66F] absolute transition-transform group-hover:scale-110" />
              <Activity className="w-3.5 h-3.5 text-white absolute bottom-1 right-1 opacity-90" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg font-extrabold tracking-tight text-[#173F35]">
                  FarmPulse
                </span>
                <span
                  style={{ color: '#ffffff', fontSize: '0px' }}
                  className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded border border-emerald-300"
                >
                  {t.demoBadge}
                </span>
              </div>
              <span className="hidden md:block text-[11px] text-[#566761] leading-none font-medium">
                {t.tagline}
              </span>
            </div>
          </div>
        </div>

        {/* Region Selector (Clean dropdown) */}
        <div className="relative hidden lg:block">
          <button
            onClick={() => setShowRegionMenu(!showRegionMenu)}
            className="flex items-center gap-1.5 text-xs font-medium text-[#1C2723] hover:text-[#173F35] bg-[#F7F8F4] hover:bg-[#EBF4ED] px-3 py-1.5 rounded-lg border border-[#E3E8DC] transition-colors"
            aria-label="Select Region"
          >
            <MapPin className="w-3.5 h-3.5 text-[#4E9B5F]" />
            <span className="max-w-[210px] truncate">{region}</span>
            <ChevronDown className="w-3.5 h-3.5 opacity-60" />
          </button>

          {showRegionMenu && (
            <div className="absolute left-0 mt-1.5 w-72 bg-white rounded-xl shadow-lg border border-[#E3E8DC] py-1 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3 py-1.5 border-b border-[#E3E8DC] text-[11px] font-semibold text-[#566761] uppercase tracking-wider">
                {language === 'ta' ? 'மாதிரி வேளாண் மண்டலங்கள்' : 'Tamil Nadu Pilot Clusters'}
              </div>
              {pilotRegions.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    setRegion(language === 'ta' ? r.labelTa : r.label);
                    setShowRegionMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-[#F7F8F4] flex items-center justify-between transition-colors text-[#1C2723]"
                >
                  <span>{language === 'ta' ? r.labelTa : r.label}</span>
                  {region.includes(r.id === 'kaveripakkam' ? 'Kaveripakkam' : '') && (
                    <Check className="w-3.5 h-3.5 text-[#4E9B5F]" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Action Icons: Date, Multi-Language Toggle, Notifications, User Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Team PRIME ELITE Badge */}
          <div className="hidden xl:flex items-center gap-1.5 text-xs font-bold text-emerald-900 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
            <span>TEAM PRIME ELITE</span>
          </div>

          {/* Date Label */}
          <div className="hidden sm:flex items-center gap-1 text-xs text-[#566761] bg-[#F7F8F4] px-2.5 py-1 rounded-lg border border-[#E3E8DC]">
            <Calendar className="w-3.5 h-3.5 text-[#4E9B5F]" />
            <span>{currentDateFormatted}</span>
          </div>

          {/* Android APK / App Install Trigger */}
          <button
            onClick={() => setShowApkModal(true)}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 text-xs font-bold rounded-lg border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 transition-all shadow-2xs hover:scale-[1.02]"
            title={language === 'ta' ? 'ஆண்ட்ராய்டு ஆப் / APK நிறுவல்' : 'Install Android App / APK'}
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="hidden sm:inline">{language === 'ta' ? 'ஆப் / APK' : 'Install App / APK'}</span>
            <span className="sm:hidden text-[11px]">APK</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          </button>

          {/* Multi-Language Dropdown Selector (Supports 6 Languages) */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg border border-[#E3E8DC] bg-[#F7F8F4] hover:bg-[#EBF4ED] text-[#173F35] transition-all shadow-2xs"
              title="Change Language / மொழி மாற்ற"
            >
              <Languages className="w-3.5 h-3.5 text-[#4E9B5F]" />
              <span>{currentLangOption.nativeLabel}</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-1.5 w-48 bg-white rounded-xl shadow-xl border border-[#E3E8DC] py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-1 border-b border-[#E3E8DC] text-[10px] font-bold text-[#566761] uppercase tracking-wider">
                  Select Language / भाषा चुनें
                </div>
                {LANGUAGE_OPTIONS.map((opt) => (
                  <button
                    key={opt.code}
                    onClick={() => {
                      setLanguage(opt.code);
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                      language === opt.code
                        ? 'bg-emerald-50 text-emerald-900 font-bold'
                        : 'text-[#1C2723] hover:bg-[#F7F8F4]'
                    }`}
                  >
                    <span>{opt.nativeLabel} ({opt.label})</span>
                    {language === opt.code && <Check className="w-3.5 h-3.5 text-[#2D8A4E]" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotificationMenu(!showNotificationMenu);
                if (!showNotificationMenu) markNotificationsAsRead();
              }}
              className="relative p-2 rounded-lg text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4] transition-colors"
              aria-label="Alerts"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              )}
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-600" />
              )}
            </button>

            {showNotificationMenu && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-[#E3E8DC] py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-1.5 border-b border-[#E3E8DC] flex items-center justify-between">
                  <span className="text-xs font-bold text-[#173F35]">
                    {language === 'ta' ? 'அறிவிப்புகள்' : 'Field Alerts'}
                  </span>
                  <span className="text-[11px] text-[#566761]">
                    {notifications.length} {language === 'ta' ? 'பதிவுகள்' : 'logged'}
                  </span>
                </div>
                <div className="divide-y divide-[#E3E8DC] max-h-64 overflow-y-auto">
                  {notifications.map((item) => (
                    <div key={item.id} className="p-3 hover:bg-[#F7F8F4] transition-colors">
                      <div className="flex items-start gap-2">
                        {item.level === 'high' ? (
                          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        ) : item.level === 'watch' ? (
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        ) : (
                          <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="text-xs font-medium text-[#1C2723] leading-snug">
                            {language === 'ta' ? item.titleTa : item.title}
                          </p>
                          <span className="text-[10px] text-[#83948E]">{item.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile & Login Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 pl-2 pr-1.5 py-1 rounded-lg hover:bg-[#F7F8F4] border border-transparent hover:border-[#E3E8DC] transition-colors"
              aria-label="User Profile Menu"
            >
              <div className="w-7 h-7 rounded-full bg-[#173F35] text-white flex items-center justify-center text-xs font-bold shadow-xs">
                {currentUser?.avatarInitials || 'M'}
              </div>
              <div className="hidden xl:block text-left text-xs leading-tight">
                <span className="font-semibold text-[#1C2723] block max-w-[130px] truncate">
                  {currentUser?.name || t.demoUser}
                </span>
                <span className="text-[10px] text-[#4E9B5F] font-medium">
                  {currentUser?.roleLabel || 'Smallholder Farmer'}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#566761] opacity-70" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-[#E3E8DC] py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-2 border-b border-[#E3E8DC]">
                  <p className="text-xs font-bold text-[#173F35]">{currentUser?.name}</p>
                  <p className="text-[11px] text-[#566761]">{currentUser?.phone}</p>
                  <p className="text-[10px] text-[#83948E] mt-0.5">{currentUser?.village}</p>
                </div>

                <div className="p-2 space-y-1">
                  <button
                    onClick={() => {
                      setIsLoginModalOpen(true);
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs font-semibold text-[#173F35] hover:bg-[#F7F8F4] rounded-lg flex items-center gap-2 transition-colors"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-[#4E9B5F]" />
                    <span>{t.switchProfile}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsLoginModalOpen(true);
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs font-medium text-[#566761] hover:bg-[#F7F8F4] rounded-lg flex items-center gap-2 transition-colors"
                  >
                    <LogIn className="w-3.5 h-3.5 text-stone-400" />
                    <span>{t.login}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <ApkInstallModal isOpen={showApkModal} onClose={() => setShowApkModal(false)} />
    </header>
  );
};
