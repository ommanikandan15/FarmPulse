import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEMO_PLOTS, DEFAULT_USER_PROFILES } from '../data/demoData';
import { translations, TranslationDictionary, LANGUAGE_OPTIONS } from '../data/translations';
import { evaluateCropStress } from '../services/advisoryEngine';
import { 
  AdvisoryResult, 
  Plot, 
  SupportedLanguage, 
  UserProfile, 
  SavedFarmAnalysis, 
  FarmAnalysisInput 
} from '../types';

export type NavigationTab = 
  | 'dashboard' 
  | 'analysis'
  | 'advisory' 
  | 'explanation'
  | 'ask-ai'
  | 'fieldmap'
  | 'plots' 
  | 'leafcheck' 
  | 'weather' 
  | 'weathermap'
  | 'mandi'
  | 'fpo' 
  | 'reports' 
  | 'settings';

export const SAMPLE_FARM_INPUT: FarmAnalysisInput = {
  farmName: 'Thiruvalam Model Paddy Field',
  location: 'Kaveripakkam Pilot Cluster, Ranipet, Tamil Nadu',
  cropType: 'Paddy (CO 51 - High Yield Short Duration)',
  growthStage: 'panicle_initiation',
  plantingDate: '2026-08-25',
  soilMoisturePercent: 18,
  recentRainfallMm: 0,
  daysWithoutRain: 8,
  temperatureCelsius: 36.5,
  humidityPercent: 38,
  leafImage: null,
  leafImageName: 'sample_paddy_leaf_roll.jpg',
  notes: 'Sandy clay loam soil; Palar canal water turn expected in 3 days; visual noon leaf rolling observed.',
};

export const createSampleAnalysis = (): SavedFarmAnalysis => {
  const advisory = evaluateCropStress({
    crop: SAMPLE_FARM_INPUT.cropType,
    growthStage: SAMPLE_FARM_INPUT.growthStage,
    daysWithoutRain: SAMPLE_FARM_INPUT.daysWithoutRain || 8,
    soilMoisturePercent: SAMPLE_FARM_INPUT.soilMoisturePercent,
    weeklyGreennessChangePercent: -13.5,
    temperatureCelsius: SAMPLE_FARM_INPUT.temperatureCelsius,
    humidityPercent: SAMPLE_FARM_INPUT.humidityPercent,
    ndvi: 0.42,
    ndwi: -0.08,
    farmName: SAMPLE_FARM_INPUT.farmName,
    location: SAMPLE_FARM_INPUT.location,
    plantingDate: SAMPLE_FARM_INPUT.plantingDate,
  });

  return {
    id: 'sample-analysis-01',
    timestamp: new Date().toISOString(),
    farmName: SAMPLE_FARM_INPUT.farmName,
    location: SAMPLE_FARM_INPUT.location,
    cropType: SAMPLE_FARM_INPUT.cropType,
    growthStage: SAMPLE_FARM_INPUT.growthStage,
    overallRisk: advisory.riskLevel,
    overallScore: advisory.stressScore,
    advisory,
    isSample: true,
  };
};

export interface AppContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: TranslationDictionary;
  tempUnit: 'C' | 'F';
  setTempUnit: (unit: 'C' | 'F') => void;
  areaUnit: 'acre' | 'ha';
  setAreaUnit: (unit: 'acre' | 'ha') => void;
  region: string;
  setRegion: (r: string) => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  plots: Plot[];
  selectedPlotId: string;
  setSelectedPlotId: (id: string) => void;
  selectedPlot: Plot;
  updatePlotAdvisory: (plotId: string, advisory: AdvisoryResult) => void;
  addPlot: (newPlot: Plot) => void;
  updatePlot: (updatedPlot: Plot) => void;
  deletePlot: (plotId: string) => void;
  resetDemoData: () => void;
  speakText: (text: string) => void;
  isSpeaking: boolean;
  stopSpeaking: () => void;
  speechSupported: boolean;
  formatTemp: (celsius: number) => string;
  formatArea: (acres: number) => string;
  notifications: { id: string; title: string; titleTa: string; time: string; read: boolean; level: 'high' | 'watch' | 'info' }[];
  markNotificationsAsRead: () => void;
  mapMode: 'google_maps' | 'schematic';
  setMapMode: (mode: 'google_maps' | 'schematic') => void;
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  analysesHistory: SavedFarmAnalysis[];
  activeAnalysis: SavedFarmAnalysis;
  setActiveAnalysis: (analysis: SavedFarmAnalysis) => void;
  saveFarmAnalysis: (analysis: SavedFarmAnalysis) => void;
  deleteHistoryItem: (id: string) => void;
  clearHistory: () => void;
  loadSampleFarmAnalysis: () => SavedFarmAnalysis;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    return (localStorage.getItem('farmpulse_lang') as SupportedLanguage) || 'en';
  });

  const [tempUnit, setTempUnitState] = useState<'C' | 'F'>(() => {
    return (localStorage.getItem('farmpulse_temp_unit') as 'C' | 'F') || 'C';
  });

  const [areaUnit, setAreaUnitState] = useState<'acre' | 'ha'>(() => {
    return (localStorage.getItem('farmpulse_area_unit') as 'acre' | 'ha') || 'acre';
  });

  const [region, setRegion] = useState<string>('Kaveripakkam Pilot Cluster, Tamil Nadu');
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [mapMode, setMapMode] = useState<'google_maps' | 'schematic'>('google_maps');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const [currentUser, setCurrentUserState] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('farmpulse_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEFAULT_USER_PROFILES[0];
      }
    }
    return DEFAULT_USER_PROFILES[0];
  });

  const [plots, setPlots] = useState<Plot[]>(() => {
    const saved = localStorage.getItem('farmpulse_plots');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEMO_PLOTS;
      }
    }
    return DEMO_PLOTS;
  });

  const [selectedPlotId, setSelectedPlotId] = useState<string>('plot-01');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [speechSupported, setSpeechSupported] = useState<boolean>(false);

  // Saved farm analyses in localStorage
  const [analysesHistory, setAnalysesHistory] = useState<SavedFarmAnalysis[]>(() => {
    const saved = localStorage.getItem('farmpulse_analysis_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch {
        // fallback
      }
    }
    return [createSampleAnalysis()];
  });

  const [activeAnalysis, setActiveAnalysis] = useState<SavedFarmAnalysis>(() => {
    return analysesHistory[0] || createSampleAnalysis();
  });

  const [notifications, setNotifications] = useState([
    {
      id: 'n-1',
      title: 'Plot 01: Moisture dropped below 20% threshold',
      titleTa: 'நிலம் 01: மண் ஈரப்பதம் 20% கீழே குறைந்தது',
      time: '15m ago',
      read: false,
      level: 'high' as const,
    },
    {
      id: 'n-2',
      title: 'Kaveripakkam Cluster: Palar canal rotation turn on Thursday',
      titleTa: 'காவேரிப்பாக்கம் வட்டம்: வியாழக்கிழமை பாலாறு கால்வாய் நீர் முறை',
      time: '2h ago',
      read: false,
      level: 'watch' as const,
    },
    {
      id: 'n-3',
      title: 'Google Maps satellite pass updated with cloud-free imagery',
      titleTa: 'கூகிள் மேப்ஸ் மேகமூட்டமில்லா செயற்கைக்கோள் பார்வை இணைக்கப்பட்டது',
      time: '3h ago',
      read: true,
      level: 'info' as const,
    },
  ]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setSpeechSupported(true);
    }
  }, []);

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('farmpulse_lang', lang);
    if (isSpeaking) {
      stopSpeaking();
    }
  };

  const setCurrentUser = (user: UserProfile) => {
    setCurrentUserState(user);
    localStorage.setItem('farmpulse_user', JSON.stringify(user));
  };

  const setTempUnit = (unit: 'C' | 'F') => {
    setTempUnitState(unit);
    localStorage.setItem('farmpulse_temp_unit', unit);
  };

  const setAreaUnit = (unit: 'acre' | 'ha') => {
    setAreaUnitState(unit);
    localStorage.setItem('farmpulse_area_unit', unit);
  };

  const t = translations[language] || translations.en;

  const selectedPlot = plots.find((p) => p.id === selectedPlotId) || plots[0];

  const updatePlotAdvisory = (plotId: string, advisory: AdvisoryResult) => {
    setPlots((prev) => {
      const updated = prev.map((p) => (p.id === plotId ? { ...p, advisory } : p));
      localStorage.setItem('farmpulse_plots', JSON.stringify(updated));
      return updated;
    });
  };

  const addPlot = (newPlot: Plot) => {
    setPlots((prev) => {
      const updated = [newPlot, ...prev];
      localStorage.setItem('farmpulse_plots', JSON.stringify(updated));
      return updated;
    });
    setSelectedPlotId(newPlot.id);
  };

  const updatePlot = (updatedPlot: Plot) => {
    setPlots((prev) => {
      const updated = prev.map((p) => (p.id === updatedPlot.id ? updatedPlot : p));
      localStorage.setItem('farmpulse_plots', JSON.stringify(updated));
      return updated;
    });
  };

  const deletePlot = (plotId: string) => {
    setPlots((prev) => {
      const updated = prev.filter((p) => p.id !== plotId);
      localStorage.setItem('farmpulse_plots', JSON.stringify(updated));
      return updated;
    });
    if (selectedPlotId === plotId && plots.length > 1) {
      const remaining = plots.filter((p) => p.id !== plotId);
      if (remaining[0]) {
        setSelectedPlotId(remaining[0].id);
      }
    }
  };

  const saveFarmAnalysis = (analysis: SavedFarmAnalysis) => {
    setAnalysesHistory((prev) => {
      // Prepend the new analysis and keep top 20
      const filtered = prev.filter((item) => item.id !== analysis.id);
      const updated = [analysis, ...filtered].slice(0, 20);
      localStorage.setItem('farmpulse_analysis_history', JSON.stringify(updated));
      return updated;
    });
    setActiveAnalysis(analysis);
  };

  const deleteHistoryItem = (id: string) => {
    setAnalysesHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      localStorage.setItem('farmpulse_analysis_history', JSON.stringify(updated));
      return updated;
    });
  };

  const clearHistory = () => {
    const sample = createSampleAnalysis();
    setAnalysesHistory([sample]);
    setActiveAnalysis(sample);
    localStorage.setItem('farmpulse_analysis_history', JSON.stringify([sample]));
  };

  const loadSampleFarmAnalysis = (): SavedFarmAnalysis => {
    const sample = createSampleAnalysis();
    setActiveAnalysis(sample);
    return sample;
  };

  const resetDemoData = () => {
    setPlots(DEMO_PLOTS);
    localStorage.removeItem('farmpulse_plots');
    setSelectedPlotId('plot-01');
    setCurrentUser(DEFAULT_USER_PROFILES[0]);
    clearHistory();
  };

  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const langOption = LANGUAGE_OPTIONS.find((l) => l.code === language);
    utterance.lang = langOption ? langOption.speechLocale : 'en-IN';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const targetLangPrefix = language;
    const matchingVoice = voices.find((v) => v.lang.toLowerCase().startsWith(targetLangPrefix));
    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const formatTemp = (celsius: number): string => {
    if (tempUnit === 'F') {
      const f = (celsius * 9) / 5 + 32;
      return `${Math.round(f)}°F`;
    }
    return `${celsius.toFixed(1)}°C`;
  };

  const formatArea = (acres: number): string => {
    if (areaUnit === 'ha') {
      const ha = acres * 0.404686;
      return `${ha.toFixed(2)} ha`;
    }
    return `${acres.toFixed(1)} ac`;
  };

  const markNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        tempUnit,
        setTempUnit,
        areaUnit,
        setAreaUnit,
        region,
        setRegion,
        activeTab,
        setActiveTab,
        plots,
        selectedPlotId,
        setSelectedPlotId,
        selectedPlot,
        updatePlotAdvisory,
        addPlot,
        updatePlot,
        deletePlot,
        resetDemoData,
        speakText,
        isSpeaking,
        stopSpeaking,
        speechSupported,
        formatTemp,
        formatArea,
        notifications,
        markNotificationsAsRead,
        mapMode,
        setMapMode,
        currentUser,
        setCurrentUser,
        isLoginModalOpen,
        setIsLoginModalOpen,
        analysesHistory,
        activeAnalysis,
        setActiveAnalysis,
        saveFarmAnalysis,
        deleteHistoryItem,
        clearHistory,
        loadSampleFarmAnalysis,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextType {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
