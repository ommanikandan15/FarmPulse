# Frontend

React + TypeScript + Vite responsive dashboard.

```bash
npm install
npm run dev
```

Vite proxies `/api` and `/health` to `http://127.0.0.1:8000`. Build with `npm run build`. The service worker is registered only in production builds. Offline support is a starter shell cache; API data is not guaranteed offline.
