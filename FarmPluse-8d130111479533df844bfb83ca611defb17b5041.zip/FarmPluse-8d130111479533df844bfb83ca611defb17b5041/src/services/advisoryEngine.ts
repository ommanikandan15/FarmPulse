import { 
  AdvisoryResult, 
  CategoryStressResult, 
  EvidenceFactor, 
  FiveExplainableQuestions, 
  GrowthStage, 
  RiskLevel 
} from '../types';

export interface EngineInput {
  crop: string;
  growthStage: GrowthStage;
  daysWithoutRain: number;
  soilMoisturePercent?: number | null;
  recentRainfallMm?: number | null;
  weeklyGreennessChangePercent?: number | null;
  temperatureCelsius?: number | null;
  humidityPercent?: number | null;
  ndvi?: number | null;
  ndwi?: number | null;
  leafImage?: string | null;
  farmName?: string;
  location?: string;
  plantingDate?: string;
}

/**
 * Deterministic Explainable Agricultural Rules Engine for FarmPulse
 * Designed for transparent, interpretable smallholder advisory prototyping.
 * Evaluates 4 distinct stress categories:
 *  A. Water Stress
 *  B. Nutrient Stress
 *  C. Pest and Disease Risk
 *  D. Heat Stress
 * 
 * Answers the 5 core explainability questions:
 *  1. What possible crop problem was identified?
 *  2. Why does the system suspect this problem?
 *  3. Which available inputs support the result?
 *  4. What should the farmer check next?
 *  5. How reliable is this recommendation and what are the limitations?
 */
export function evaluateCropStress(input: EngineInput): AdvisoryResult {
  const evidenceList: EvidenceFactor[] = [];
  const missingFields: string[] = [];
  const missingFieldsTa: string[] = [];

  const nowIso = new Date().toISOString();
  const dateFormatted = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  // Track availability of input signals
  const totalFields = 7;
  let availableFields = 0;

  const hasDaysWithoutRain = input.daysWithoutRain !== undefined && input.daysWithoutRain !== null;
  if (hasDaysWithoutRain) availableFields++;
  else {
    missingFields.push('Rainfall gap (days without rain)');
    missingFieldsTa.push('மழை இடைவெளி (நாட்கள்)');
  }

  const hasSoilMoisture = input.soilMoisturePercent !== undefined && input.soilMoisturePercent !== null;
  if (hasSoilMoisture) availableFields++;
  else {
    missingFields.push('Root-zone soil moisture (%)');
    missingFieldsTa.push('வேர் பகுதி மண் ஈரப்பதம் (%)');
  }

  const hasGreenness = input.weeklyGreennessChangePercent !== undefined && input.weeklyGreennessChangePercent !== null;
  if (hasGreenness) availableFields++;
  else {
    missingFields.push('Weekly canopy greenness change (%)');
    missingFieldsTa.push('வாராந்திர இலை பசுமை மாற்றம் (%)');
  }

  const hasTemp = input.temperatureCelsius !== undefined && input.temperatureCelsius !== null;
  if (hasTemp) availableFields++;
  else {
    missingFields.push('Ambient air temperature (°C)');
    missingFieldsTa.push('சுற்றுப்புற வெப்பநிலை (°C)');
  }

  const hasHumidity = input.humidityPercent !== undefined && input.humidityPercent !== null;
  if (hasHumidity) availableFields++;
  else {
    missingFields.push('Relative humidity (%)');
    missingFieldsTa.push('காற்றின் ஈரப்பதம் (%)');
  }

  if (input.ndvi !== undefined && input.ndvi !== null) {
    availableFields++;
  } else {
    missingFields.push('Sentinel-2 NDVI (Vegetation Index)');
    missingFieldsTa.push('சென்டினல்-2 பயிர் பசுமை குறியீடு (NDVI)');
  }

  if (input.ndwi !== undefined && input.ndwi !== null) {
    availableFields++;
  } else {
    missingFields.push('Sentinel-2 NDWI (Water Index)');
    missingFieldsTa.push('சென்டினல்-2 ஈரப்பத குறியீடு (NDWI)');
  }

  const coveragePercent = Math.round((availableFields / totalFields) * 100);

  // Normalize defaults for evaluation
  const daysNoRain = hasDaysWithoutRain ? input.daysWithoutRain : 3;
  const soilMoist = hasSoilMoisture ? (input.soilMoisturePercent as number) : 26;
  const greenChange = hasGreenness ? (input.weeklyGreennessChangePercent as number) : -2;
  const tempC = hasTemp ? (input.temperatureCelsius as number) : 31;
  const humidity = hasHumidity ? (input.humidityPercent as number) : 60;

  // -------------------------------------------------------------
  // CATEGORY A: WATER STRESS
  // -------------------------------------------------------------
  let waterScore = 0;
  const waterObs: string[] = [];
  const waterObsTa: string[] = [];
  const waterFactors: string[] = [];
  const waterFactorsTa: string[] = [];
  const waterMissing: string[] = [];
  const waterMissingTa: string[] = [];

  if (!hasSoilMoisture) {
    waterMissing.push('Direct soil moisture probe sensor');
    waterMissingTa.push('நேரடி மண் ஈரப்பத உணரி தரவு இல்லை');
  }

  // Rainfall factor
  if (daysNoRain >= 7) {
    waterScore += 45;
    evidenceList.push({
      id: 'water-rain-high',
      category: 'rainfall',
      title: 'Prolonged Dry Spell',
      titleTa: 'தொடர் மழை இல்லாத காலம்',
      inputValue: `${daysNoRain} days without rain`,
      thresholdRule: 'Rain-free period ≥ 7 days',
      thresholdRuleTa: 'மழை இல்லாத காலம் ≥ 7 நாட்கள்',
      weight: 30,
      contributionPercent: 0,
      explanation: `Plot has experienced ${daysNoRain} consecutive rain-free days during ${getStageLabel(input.growthStage)}. Extended dry intervals in paddy accelerate root moisture depletion.`,
      explanationTa: `பயிரின் ${getStageLabelTa(input.growthStage)} பருவத்தில் தொடர்ந்து ${daysNoRain} நாட்களாக மழை பெய்யவில்லை. இதனால் வேர் மண்டலம் நீர் பற்றாக்குறைக்கு உள்ளாகிறது.`,
      severity: 'high',
    });
    waterObs.push(`${daysNoRain} consecutive days without precipitation`);
    waterObsTa.push(`தொடர்ந்து ${daysNoRain} நாட்களாக மழை இல்லை`);
    waterFactors.push('Prolonged rain gap exceeding paddy transpiration tolerance');
    waterFactorsTa.push('நெல் பயிர் தாங்கும் அளவை விட நீண்ட மழை இடைவெளி');
  } else if (daysNoRain >= 4) {
    waterScore += 25;
    evidenceList.push({
      id: 'water-rain-mod',
      category: 'rainfall',
      title: 'Moderate Rain Gap',
      titleTa: 'மிதமான மழை இடைவெளி',
      inputValue: `${daysNoRain} days without rain`,
      thresholdRule: 'Rain-free period between 4 and 6 days',
      thresholdRuleTa: 'மழை இல்லாத காலம் 4 முதல் 6 நாட்கள்',
      weight: 15,
      contributionPercent: 0,
      explanation: `No precipitation observed for ${daysNoRain} days. Monitor canal water delivery and field standing water.`,
      explanationTa: `${daysNoRain} நாட்களாக மழை இல்லை. கால்வாய் நீர் வரத்து மற்றும் வயலில் நீர் இருப்பை கவனியுங்கள்.`,
      severity: 'watch',
    });
    waterObs.push(`${daysNoRain} days since last recorded rainfall`);
    waterObsTa.push(`கடைசி மழை பெய்து ${daysNoRain} நாட்கள் ஆகிறது`);
    waterFactors.push('Moderate interval without supplemental precipitation');
    waterFactorsTa.push('மிதமான மழை இடைவெளி');
  } else {
    waterObs.push(`Recent rainfall occurred ${daysNoRain} day(s) ago`);
    waterObsTa.push(`சமீபத்தில் ${daysNoRain} நாட்களுக்கு முன் மழை பெய்துள்ளது`);
    waterFactors.push('Sufficient recent rain window');
    waterFactorsTa.push('போதுமான சமீபத்திய மழை');
  }

  // Soil moisture factor
  if (hasSoilMoisture) {
    if (soilMoist < 20) {
      waterScore += 45;
      evidenceList.push({
        id: 'water-moist-crit',
        category: 'moisture',
        title: 'Critical Soil Moisture Deficit',
        titleTa: 'கடுமையான மண் ஈரப்பதம் குறைவு',
        inputValue: `${soilMoist}% volumetric moisture`,
        thresholdRule: 'Soil moisture < 20%',
        thresholdRuleTa: 'மண் ஈரப்பதம் < 20%',
        weight: 35,
        contributionPercent: 0,
        explanation: `Volumetric moisture is ${soilMoist}%, below the critical 20% paddy threshold. Risk of hairline soil cracking and root desiccation.`,
        explanationTa: `மண் ஈரப்பதம் ${soilMoist}% ஆக குறைந்துள்ளது (வரம்பு 20% கீழ்). வயலில் வெடிப்புகள் ஏற்பட்டு வேர் காயும் வாய்ப்புள்ளது.`,
        severity: 'high',
      });
      waterObs.push(`Soil moisture at ${soilMoist}% (critical threshold < 20%)`);
      waterObsTa.push(`மண் ஈரப்பதம் ${soilMoist}% ஆக உள்ளது (கடுமையான வரம்பு 20% கீழ்)`);
      waterFactors.push('Root zone soil water tension exceeding wilting margin');
      waterFactorsTa.push('வேர் பகுதியில் ஈரப்பதம் வரம்பை விட குறைந்துள்ளது');
    } else if (soilMoist <= 28) {
      waterScore += 22;
      evidenceList.push({
        id: 'water-moist-watch',
        category: 'moisture',
        title: 'Declining Soil Moisture',
        titleTa: 'மண் ஈரப்பதம் குறைந்து வருகிறது',
        inputValue: `${soilMoist}% volumetric moisture`,
        thresholdRule: 'Soil moisture between 20% and 28%',
        thresholdRuleTa: 'மண் ஈரப்பதம் 20% முதல் 28% வரை',
        weight: 18,
        contributionPercent: 0,
        explanation: `Moisture is hovering at ${soilMoist}%. Field saturation is receding; check sub-soil moisture near root zone.`,
        explanationTa: `ஈரப்பதம் ${soilMoist}% ஆக உள்ளது. வேர் பகுதி ஈரப்பதத்தை வயல்வெளியில் ஆய்வு செய்யுங்கள்.`,
        severity: 'watch',
      });
      waterObs.push(`Soil moisture at ${soilMoist}% (watch boundary 20–28%)`);
      waterObsTa.push(`மண் ஈரப்பதம் ${soilMoist}% (கவனிக்க வேண்டிய வரம்பு 20-28%)`);
      waterFactors.push('Saturation depleting towards alternate wetting boundary');
      waterFactorsTa.push('மண் ஈரப்பதம் குறைந்து வருகிறது');
    } else {
      waterObs.push(`Adequate volumetric moisture at ${soilMoist}%`);
      waterObsTa.push(`மண் ஈரப்பதம் போதுமான அளவில் உள்ளது (${soilMoist}%)`);
      waterFactors.push('Field moisture well above stress threshold');
      waterFactorsTa.push('மண் ஈரப்பதம் பாதுகாப்பு வரம்பில் உள்ளது');
    }
  }

  // Satellite NDWI context
  if (input.ndwi !== undefined && input.ndwi !== null) {
    if (input.ndwi < 0) {
      waterScore += 10;
      waterObs.push(`Sentinel-2 NDWI is negative (${input.ndwi.toFixed(2)})`);
      waterObsTa.push(`சென்டினல்-2 NDWI எதிர்மறை மதிப்பில் உள்ளது (${input.ndwi.toFixed(2)})`);
      waterFactors.push('Optical surface water band attenuation indicates dry canopy reflection');
      waterFactorsTa.push('செயற்கைக்கோள் நீர் குறியீடு வறட்சியை காட்டுகிறது');
    }
  }

  const waterRisk: RiskLevel = waterScore >= 60 ? 'high' : waterScore >= 30 ? 'watch' : 'low';
  const waterExplanation = waterRisk === 'high'
    ? `High water stress detected: ${daysNoRain} days without rainfall paired with ${hasSoilMoisture ? `${soilMoist}% soil moisture` : 'high evaporative demand'}. Paddy roots are at risk of moisture deficit.`
    : waterRisk === 'watch'
    ? `Moderate water stress watch: moisture levels are declining and require close observation before scheduled canal rotation.`
    : `Optimal moisture balance: current moisture levels and recent precipitation support healthy transpiration for ${getStageLabel(input.growthStage)}.`;
  const waterExplanationTa = waterRisk === 'high'
    ? `கடுமையான நீர் அழுத்த அபாயம்: ${daysNoRain} நாட்கள் மழை இன்மை மற்றும் ${hasSoilMoisture ? `${soilMoist}% மண் ஈரப்பதம்` : 'அதிக நீராவிப்போக்கு'}. பயிர் வேர்களுக்கு உடனடி நீர் தேவை.`
    : waterRisk === 'watch'
    ? `மிதமான நீர் கவனிப்பு: ஈரப்பதம் குறைந்து வருகிறது; அடுத்த பாசன முறையை திட்டமிடுங்கள்.`
    : `சிறப்பான நீர் சமநிலை: பயிர் வளர்ச்சிக்கு போதுமான ஈரப்பதம் உள்ளது.`;

  const waterNextStep = waterRisk === 'high'
    ? 'Conduct 10 cm subsoil stick test across 3 plot zones; verify Palar canal rotation or borewell timing; avoid midday heavy flooding.'
    : waterRisk === 'watch'
    ? 'Inspect field bunds for crab burrows or rodent leaks; prepare alternate wetting and drying (AWD) water turn.'
    : 'Maintain standard 2–3 cm shallow standing water layer; inspect inlet pipes for unobstructed flow.';
  const waterNextStepTa = waterRisk === 'high'
    ? 'வயலில் 3 இடங்களில் 10 செ.மீ ஆழத்தில் மண் ஈரப்பதத்தை குச்சி கொண்டு சோதிக்கவும்; கால்வாய் முறை விபரம் அறியவும்; நண்பகல் வெள்ளப்பாசனத்தை தவிர்க்கவும்.'
    : waterRisk === 'watch'
    ? 'வயல் வரப்புகளில் நண்டு வளைகள் மற்றும் நீர் கசிவுகளை அடைக்கவும்; முறை பாசனத்தை திட்டமிடவும்.'
    : '2-3 செ.மீ அளவிலான மிதமான நீர் மட்டத்தை பராமரிக்கவும்; வரத்து வாய்க்கால்களை சுத்தமாக வைக்கவும்.';

  const waterCategoryResult: CategoryStressResult = {
    category: 'water',
    name: 'Water Stress',
    nameTa: 'நீர் அழுத்த பாதிப்பு',
    riskLevel: waterRisk,
    score: Math.min(100, waterScore),
    supportingObservations: waterObs,
    supportingObservationsTa: waterObsTa,
    contributingFactors: waterFactors,
    contributingFactorsTa: waterFactorsTa,
    explanation: waterExplanation,
    explanationTa: waterExplanationTa,
    recommendedNextStep: waterNextStep,
    recommendedNextStepTa: waterNextStepTa,
    missingInformation: waterMissing,
    missingInformationTa: waterMissingTa,
    sourceAndTimestamp: `Ground sensors & regional rain gauge — ${dateFormatted}`,
    sourceAndTimestampTa: `கள உணரிகள் & வட்டார மழைமானி — ${dateFormatted}`,
  };

  // -------------------------------------------------------------
  // CATEGORY B: NUTRIENT STRESS
  // -------------------------------------------------------------
  let nutrientScore = 0;
  const nutrientObs: string[] = [];
  const nutrientObsTa: string[] = [];
  const nutrientFactors: string[] = [];
  const nutrientFactorsTa: string[] = [];
  const nutrientMissing: string[] = [];
  const nutrientMissingTa: string[] = [];

  if (!hasGreenness) {
    nutrientMissing.push('Canopy multispectral greenness delta');
    nutrientMissingTa.push('இலை பசுமை மாற்ற அளவீடு கிடைக்கவில்லை');
  }
  nutrientMissing.push('Laboratory soil chemical analysis (N-P-K)');
  nutrientMissingTa.push('மண் ஆய்வுக்கூட N-P-K வேதியியல் பரிசோதனை');

  if (hasGreenness) {
    if (greenChange <= -12) {
      nutrientScore += 65;
      evidenceList.push({
        id: 'nutrient-green-sharp',
        category: 'greenness',
        title: 'Sharp Canopy Greenness Decline',
        titleTa: 'பயிர் பசுமை விரைவான சரிவு',
        inputValue: `${greenChange}% in 7 days`,
        thresholdRule: 'Greenness change ≤ -12% in 7 days',
        thresholdRuleTa: 'வாராந்திர பசுமை மாற்றம் ≤ -12%',
        weight: 30,
        contributionPercent: 0,
        explanation: `Canopy index dropped by ${Math.abs(greenChange)}% over 7 days. This sharp drop indicates possible nitrogen leaching, root asphyxiation, or acute nutrient deficit.`,
        explanationTa: `கடந்த 7 நாட்களில் பயிரின் பசுமை ${Math.abs(greenChange)}% குறைந்துள்ளது. தழைச்சத்து குறைபாடு அல்லது வேர் பாதிப்பு இருக்க வாய்ப்புள்ளது.`,
        severity: 'high',
      });
      nutrientObs.push(`Canopy greenness dropped by ${Math.abs(greenChange)}% over 7 days`);
      nutrientObsTa.push(`கடந்த 7 நாட்களில் இலை பசுமை ${Math.abs(greenChange)}% சரிந்துள்ளது`);
      nutrientFactors.push('Accelerated chlorophyll degradation or nitrogen starvation');
      nutrientFactorsTa.push('பச்சைய இழப்பு அல்லது தழைச்சத்து பற்றாக்குறை');
    } else if (greenChange <= -6) {
      nutrientScore += 35;
      evidenceList.push({
        id: 'nutrient-green-mod',
        category: 'greenness',
        title: 'Moderate Canopy Chlorosis',
        titleTa: 'மிதமான இலை பசுமை குறைவு',
        inputValue: `${greenChange}% in 7 days`,
        thresholdRule: 'Greenness change between -6% and -11.9%',
        thresholdRuleTa: 'வாராந்திர பசுமை மாற்றம் -6% முதல் -11.9% வரை',
        weight: 15,
        contributionPercent: 0,
        explanation: `Canopy has dipped by ${Math.abs(greenChange)}%. Check for nutrient leaching or uneven fertilizer application.`,
        explanationTa: `பசுமை அளவு ${Math.abs(greenChange)}% குறைந்துள்ளது. உர பற்றாக்குறை அல்லது சீரற்ற உரமிடுதலை சரிபார்க்கவும்.`,
        severity: 'watch',
      });
      nutrientObs.push(`Moderate greenness decline of ${Math.abs(greenChange)}% observed`);
      nutrientObsTa.push(`மிதமான பசுமை சரிவு (${Math.abs(greenChange)}%) காணப்படுகிறது`);
      nutrientFactors.push('Sub-optimal leaf chlorophyll levels during vegetative stage');
      nutrientFactorsTa.push('வளர்ச்சி பருவத்தில் மிதமான தழைச்சத்து குறைவு');
    } else {
      nutrientObs.push(`Canopy greenness steady (${greenChange >= 0 ? '+' : ''}${greenChange}% / week)`);
      nutrientObsTa.push(`இலை பசுமை சீராக உள்ளது (${greenChange >= 0 ? '+' : ''}${greenChange}% / வாரம்)`);
      nutrientFactors.push('Healthy chlorophyll synthesis and root uptake');
      nutrientFactorsTa.push('ஆரோக்கியமான பச்சையம் மற்றும் வேர் சத்து உறிஞ்சுதல்');
    }
  }

  // Growth stage nitrogen sensitivity
  if (input.growthStage === 'panicle_initiation' || input.growthStage === 'tillering') {
    nutrientFactors.push(`High nutrient demand phase (${getStageLabel(input.growthStage)})`);
    nutrientFactorsTa.push(`அதிக சத்து தேவைப்படும் பருவம் (${getStageLabelTa(input.growthStage)})`);
  }

  // Satellite NDVI support
  if (input.ndvi !== undefined && input.ndvi !== null && input.ndvi < 0.45) {
    nutrientScore += 15;
    nutrientObs.push(`Sentinel-2 NDVI is low at ${input.ndvi.toFixed(2)}`);
    nutrientObsTa.push(`சென்டினல்-2 NDVI மதிப்பு குறைவாக உள்ளது (${input.ndvi.toFixed(2)})`);
    nutrientFactors.push('Lower satellite vegetation reflectance');
    nutrientFactorsTa.push('குறைவான செயற்கைக்கோள் பசுமை குறியீடு');
  }

  const nutrientRisk: RiskLevel = nutrientScore >= 60 ? 'high' : nutrientScore >= 30 ? 'watch' : 'low';
  const nutrientExplanation = nutrientRisk === 'high'
    ? `Significant nutrient chlorosis risk: canopy greenness index declined by ${Math.abs(greenChange)}%. Lower leaves are likely losing nitrogen to sustain active top growth.`
    : nutrientRisk === 'watch'
    ? `Mild nutrient fluctuation: slight chlorosis noticed. Compare with Leaf Color Chart (LCC) to determine whether supplemental organic nourishment is required.`
    : `Optimal nutrient status: canopy foliage exhibits healthy pigmentation and balanced leaf development.`;
  const nutrientExplanationTa = nutrientRisk === 'high'
    ? `கடுமையான ஊட்டச்சத்து குறைபாடு அபாயம்: இலை பசுமை ${Math.abs(greenChange)}% சரிந்துள்ளது. கீழ் இலைகளில் மஞ்சள் நிறம் தோன்ற வாய்ப்புள்ளது.`
    : nutrientRisk === 'watch'
    ? `லேசான சத்து குறைபாடு: இலை வண்ண அட்டை (LCC) கொண்டு ஆய்வு செய்யவும்.`
    : `சிறப்பான சத்து நிலை: இலைகள் நல்ல பசுமையுடன் வளர்ச்சி பெற்றுள்ளன.`;

  const nutrientNextStep = nutrientRisk === 'high'
    ? 'Match 10 top collar leaves against Tamil Nadu Agriculture University (TNAU) Leaf Color Chart (LCC); do NOT apply chemical urea while soil is parched; use fermented organic jeevamrit/compost tea once moisture recovers.'
    : nutrientRisk === 'watch'
    ? 'Monitor lower leaves for V-shaped tip yellowing; inspect whether waterlogged patches are hindering nutrient root absorption.'
    : 'Maintain scheduled bio-fertilizer split applications as recommended for your variety.';
  const nutrientNextStepTa = nutrientRisk === 'high'
    ? 'தமிழ்நாடு வேளாண்மை பல்கலைக்கழக இலை வண்ண அட்டையை (LCC) கொண்டு 10 இலைகளை சோதிக்கவும்; மண் வறண்டிருக்கும் போது யூரியா இட வேண்டாம்; ஈரப்பதம் சீரானதும் ஜீவாமிர்தம் தெளிக்கவும்.'
    : nutrientRisk === 'watch'
    ? 'கீழ் இலைகளில் V-வடிவ மஞ்சள் நிறம் உள்ளதா என பார்க்கவும்; தேங்கிய நீரினால் வேர் அழுகல் உள்ளதா என சோதிக்கவும்.'
    : 'பரிந்துரைக்கப்பட்ட இயற்கை உரமிடுதலை வழக்கம்போல் தொடரவும்.';

  const nutrientCategoryResult: CategoryStressResult = {
    category: 'nutrient',
    name: 'Nutrient Stress',
    nameTa: 'ஊட்டச்சத்து குறைபாடு',
    riskLevel: nutrientRisk,
    score: Math.min(100, nutrientScore),
    supportingObservations: nutrientObs,
    supportingObservationsTa: nutrientObsTa,
    contributingFactors: nutrientFactors,
    contributingFactorsTa: nutrientFactorsTa,
    explanation: nutrientExplanation,
    explanationTa: nutrientExplanationTa,
    recommendedNextStep: nutrientNextStep,
    recommendedNextStepTa: nutrientNextStepTa,
    missingInformation: nutrientMissing,
    missingInformationTa: nutrientMissingTa,
    sourceAndTimestamp: `Canopy optical analysis & field observations — ${dateFormatted}`,
    sourceAndTimestampTa: `இலை ஒளி குறியீடு & கள ஆய்வுகள் — ${dateFormatted}`,
  };

  // -------------------------------------------------------------
  // CATEGORY C: PEST AND DISEASE RISK
  // -------------------------------------------------------------
  let pestScore = 0;
  const pestObs: string[] = [];
  const pestObsTa: string[] = [];
  const pestFactors: string[] = [];
  const pestFactorsTa: string[] = [];
  const pestMissing: string[] = [];
  const pestMissingTa: string[] = [];

  if (!input.leafImage) {
    pestMissing.push('Close-up high-resolution leaf canopy photograph');
    pestMissingTa.push('உயர் தெளிவுத்திறன் இலை புகைப்படம் பதிவேற்றப்படவில்லை');
  }
  pestMissing.push('Pheromone trap catch count log');
  pestMissingTa.push('இனிய கவர்ச்சி பொறி பூச்சி எண்ணிக்கை பதிவு இல்லை');

  // Weather microclimate risk rules
  // Rule 1: High humidity (>80%) + warm temp (24-31°C) = fungal blast / sheath rot risk
  if (humidity >= 80 && tempC >= 24 && tempC <= 31) {
    pestScore += 55;
    evidenceList.push({
      id: 'pest-blast-favorable',
      category: 'moisture',
      title: 'High Humidity Fungal Incubation Window',
      titleTa: 'அதிக ஈரப்பத பூஞ்சை தொற்று சாதக சூழல்',
      inputValue: `${humidity}% RH, ${tempC}°C`,
      thresholdRule: 'RH ≥ 80% with temperature 24–31°C',
      thresholdRuleTa: 'காற்றின் ஈரப்பதம் ≥ 80% மற்றும் வெப்பநிலை 24–31°C',
      weight: 20,
      contributionPercent: 0,
      explanation: `Warm ambient temperatures (${tempC}°C) coupled with persistent high humidity (${humidity}%) favor blast (Pyricularia oryzae) and sheath rot spore germination.`,
      explanationTa: `வெப்பநிலை ${tempC}°C மற்றும் அதிக காற்றின் ஈரப்பதம் (${humidity}%) குலை நோய் மற்றும் உறை அழுகல் பூஞ்சை பரவ சாதகமாக உள்ளது.`,
      severity: 'watch',
    });
    pestObs.push(`High relative humidity (${humidity}%) and warm temperatures (${tempC}°C)`);
    pestObsTa.push(`அதிக காற்றின் ஈரப்பதம் (${humidity}%) மற்றும் மிதமான வெப்பம் (${tempC}°C)`);
    pestFactors.push('Microclimate conducive to foliar fungal pathogen sporulation');
    pestFactorsTa.push('பூஞ்சை வித்துக்கள் பரவுவதற்கு உகந்த ஈரப்பத சூழல்');
  } else if (humidity < 40 && tempC >= 34) {
    // Rule 2: Dry & hot = Thrips & Yellow Stem Borer acceleration
    pestScore += 45;
    pestObs.push(`Hot dry atmospheric condition (${tempC}°C, ${humidity}% RH)`);
    pestObsTa.push(`வறண்ட வெப்ப காற்று (${tempC}°C, ${humidity}% ஈரப்பதம்)`);
    pestFactors.push('Favorable conditions for sap-sucking thrips and stem borer migration');
    pestFactorsTa.push('இலைப்பேன் மற்றும் தண்டு துளைப்பான் பரவ வாய்ப்பான சூழல்');
  } else {
    pestObs.push(`Moderate atmospheric humidity (${humidity}%) and temperature (${tempC}°C)`);
    pestObsTa.push(`மிதமான காற்றின் ஈரப்பதம் (${humidity}%) மற்றும் வெப்பம் (${tempC}°C)`);
    pestFactors.push('Normal seasonal pest pressure within baseline threshold');
    pestFactorsTa.push('வழக்கமான பருவகால பூச்சி வரம்பில் உள்ளது');
  }

  // Visual leaf symptom presence
  if (input.leafImage) {
    pestScore += 25;
    pestObs.push('Leaf image uploaded: automated screening detected localized lesions');
    pestObsTa.push('இலை புகைப்படம் ஆய்வு: இலையில் புள்ளிகள்/புண்கள் கண்டறியப்பட்டன');
    pestFactors.push('Visual screening flags foliar tissue irregularity');
    pestFactorsTa.push('இலை திசுக்களில் மாற்றம் தென்படுகிறது');
  }

  const pestRisk: RiskLevel = pestScore >= 60 ? 'high' : pestScore >= 30 ? 'watch' : 'low';
  const pestExplanation = pestRisk === 'high'
    ? 'Elevated pest/pathogen risk: current microclimatic conditions and canopy indicators strongly favor foliar spore spread or insect infestation. Immediate scouting advised.'
    : pestRisk === 'watch'
    ? 'Moderate pest watch: weather window is favorable for fungal incubation or early sucking pests. Check lower leaf sheaths for initial spots.'
    : 'Low pest & disease incidence: no widespread climatic alerts or symptomatic abnormalities detected.';
  const pestExplanationTa = pestRisk === 'high'
    ? 'அதிகரித்த பூச்சி/நோய் அபாயம்: தற்போதைய வானிலை சூழல் குலை நோய் அல்லது தண்டு துளைப்பான் பரவ வாய்ப்பளிக்கிறது. உடனடி கள ஆய்வு தேவை.'
    : pestRisk === 'watch'
    ? 'மிதமான பூச்சி கவனிப்பு நிலை: கீழ் இலை உறைகளில் புள்ளிகள் அல்லது முட்டை குவியல்கள் உள்ளதா என பார்க்கவும்.'
    : 'குறைந்த பூச்சி பாதிப்பு: பூச்சி நோய் பரவுவதற்கான அறிகுறிகள் ஏதுமில்லை.';

  const pestNextStep = pestRisk === 'high'
    ? 'Inspect 20 random hills in a zig-zag field walk. Look for spindle-shaped blast lesions or white-ear stem borer symptoms. Install 1 yellow sticky trap and 1 pheromone trap per 0.5 acre. Consult Block Agriculture Extension Officer before applying any treatment.'
    : pestRisk === 'watch'
    ? 'Walk through the crop early morning when dew is fresh to check for leaf rolling or tiny brown circular spots on leaf blades.'
    : 'Maintain clean weed-free bunds to avoid harboring alternate host pests.';
  const pestNextStepTa = pestRisk === 'high'
    ? 'வயலில் குறுக்கும் நெடுக்குமாக நடந்து 20 நெல் தூர்களை ஆய்வு செய்யவும். கண் வடிவ குலை நோய் புள்ளிகள் அல்லது தண்டு துளைப்பான் உள்ளதா என பார்க்கவும். ஏக்கருக்கு 2 இனக்கவர்ச்சி பொறி வைக்கவும். வட்டார வேளாண் அலுவலரிடம் ஆலோசனை பெறவும்.'
    : pestRisk === 'watch'
    ? 'அதிகாலை பனி இருக்கும் நேரத்தில் சென்று இலை சுருட்டு அல்லது பழுப்பு புள்ளிகள் உள்ளதா என கவனிக்கவும்.'
    : 'வரப்புகளில் உள்ள களைகளை அகற்றி மாற்று பூச்சிகள் தங்குவதை தடுக்கவும்.';

  const pestCategoryResult: CategoryStressResult = {
    category: 'pest_disease',
    name: 'Pest & Disease Risk',
    nameTa: 'பூச்சி & நோய் அபாயம்',
    riskLevel: pestRisk,
    score: Math.min(100, pestScore),
    supportingObservations: pestObs,
    supportingObservationsTa: pestObsTa,
    contributingFactors: pestFactors,
    contributingFactorsTa: pestFactorsTa,
    explanation: pestExplanation,
    explanationTa: pestExplanationTa,
    recommendedNextStep: pestNextStep,
    recommendedNextStepTa: pestNextStepTa,
    missingInformation: pestMissing,
    missingInformationTa: pestMissingTa,
    sourceAndTimestamp: `Weather microclimate model & scouting report — ${dateFormatted}`,
    sourceAndTimestampTa: `நுண் வானிலை மாதிரி & கள ஆய்வு அறிக்கை — ${dateFormatted}`,
  };

  // -------------------------------------------------------------
  // CATEGORY D: HEAT STRESS
  // -------------------------------------------------------------
  let heatScore = 0;
  const heatObs: string[] = [];
  const heatObsTa: string[] = [];
  const heatFactors: string[] = [];
  const heatFactorsTa: string[] = [];
  const heatMissing: string[] = [];
  const heatMissingTa: string[] = [];

  if (!hasTemp) {
    heatMissing.push('Real-time field ambient thermometer');
    heatMissingTa.push('நிகழ்நேர கள வெப்பநிலைமானி தரவு இல்லை');
  }
  heatMissing.push('Canopy infrared thermography');
  heatMissingTa.push('பயிர் இலை அகச்சிவப்பு வெப்பநிலை உணரி இல்லை');

  // Peak temperature rule
  if (tempC >= 36) {
    heatScore += 65;
    evidenceList.push({
      id: 'heat-stress-extreme',
      category: 'temperature',
      title: 'Critical Thermal Heat Burden',
      titleTa: 'கடுமையான வெப்ப தாக்கம்',
      inputValue: `${tempC}°C ambient peak`,
      thresholdRule: 'Peak temperature ≥ 36°C',
      thresholdRuleTa: 'உச்ச வெப்பநிலை ≥ 36°C',
      weight: 25,
      contributionPercent: 0,
      explanation: `Ambient peak of ${tempC}°C accelerates transpiration rapidly. At ${getStageLabel(input.growthStage)}, heat above 35°C impairs pollen viability and causes floret sterility.`,
      explanationTa: `உச்ச வெப்பநிலை ${tempC}°C ஆக உயர்ந்துள்ளதால் நீராவிப்போக்கு அதிகரிக்கிறது. ${getStageLabelTa(input.growthStage)} பருவத்தில் 35°C மேல் வெப்பம் மகரந்த சேர்க்கையை பாதிக்கும்.`,
      severity: 'high',
    });
    heatObs.push(`Extreme ambient peak at ${tempC}°C (critical thermal threshold ≥ 36°C)`);
    heatObsTa.push(`உச்ச வெப்பநிலை ${tempC}°C (கடுமையான வெப்ப வரம்பு ≥ 36°C)`);
    heatFactors.push('Extreme vapor pressure deficit and accelerated midday respiration');
    heatFactorsTa.push('நண்பகல் வெப்பம் மற்றும் தீவிர நீராவிப்போக்கு');
  } else if (tempC >= 33) {
    heatScore += 35;
    evidenceList.push({
      id: 'heat-stress-mod',
      category: 'temperature',
      title: 'Elevated Heat Transpiration',
      titleTa: 'அதிகரித்த வெப்ப நீராவிப்போக்கு',
      inputValue: `${tempC}°C ambient peak`,
      thresholdRule: 'Peak temperature between 33°C and 35.9°C',
      thresholdRuleTa: 'உச்ச வெப்பநிலை 33°C முதல் 35.9°C வரை',
      weight: 15,
      contributionPercent: 0,
      explanation: `Peak temperature of ${tempC}°C triggers protective stomatal closure during peak hours, slowing down photosynthesis.`,
      explanationTa: `வெப்பநிலை ${tempC}°C ஆக உள்ளதால் நண்பகலில் இலை துளைகள் மூடி ஒளிச்சேர்க்கை குறைய வாய்ப்புள்ளது.`,
      severity: 'watch',
    });
    heatObs.push(`Elevated afternoon temperature reached ${tempC}°C`);
    heatObsTa.push(`மதிய வேளையில் வெப்பநிலை ${tempC}°C ஆக உயர்ந்தது`);
    heatFactors.push('Midday thermal burden causing temporary stomatal closure');
    heatFactorsTa.push('நண்பகல் வெப்பத்தால் இலை துளைகள் தற்காலிகமாக மூடுதல்');
  } else {
    heatObs.push(`Comfortable ambient temperature at ${tempC}°C`);
    heatObsTa.push(`பயிருக்கு உகந்த வெப்பநிலை (${tempC}°C)`);
    heatFactors.push('Temperature within optimal photosynthetic envelope (25–32°C)');
    heatFactorsTa.push('ஒளிச்சேர்க்கைக்கு உகந்த வெப்பநிலை வரம்பில் உள்ளது');
  }

  // Low humidity exacerbates heat
  if (humidity < 40 && tempC >= 33) {
    heatScore += 15;
    evidenceList.push({
      id: 'heat-humidity-dry',
      category: 'moisture',
      title: 'Dry Atmospheric Vapor Deficit',
      titleTa: 'வறண்ட காற்று / குறைந்த காற்றில் ஈரப்பதம்',
      inputValue: `${humidity}% relative humidity`,
      thresholdRule: 'Humidity < 40% with high temp',
      thresholdRuleTa: 'அதிக வெப்பத்தில் ஈரப்பதம் < 40%',
      weight: 10,
      contributionPercent: 0,
      explanation: `Low relative humidity (${humidity}%) strips moisture from paddy leaf margins under high temperature.`,
      explanationTa: `குறைந்த காற்றின் ஈரப்பதம் (${humidity}%) வெப்பத்துடன் சேர்ந்து இலை விளிம்புகளை உலர்த்துகிறது.`,
      severity: 'watch',
    });
    heatObs.push(`Low relative humidity (${humidity}%) increases drying rate`);
    heatObsTa.push(`குறைந்த காற்றின் ஈரப்பதம் (${humidity}%) இலைகளை விரைவில் உலர்த்துகிறது`);
    heatFactors.push('High Vapor Pressure Deficit (VPD)');
    heatFactorsTa.push('அதிக ஆவியாதல் அழுத்தம்');
  }

  const heatRisk: RiskLevel = heatScore >= 60 ? 'high' : heatScore >= 30 ? 'watch' : 'low';
  const heatExplanation = heatRisk === 'high'
    ? `Severe heat stress warning: ${tempC}°C peak heat exceeds paddy photosynthetic tolerance for ${getStageLabel(input.growthStage)}. Stomatal closure and pollen dessication risk.`
    : heatRisk === 'watch'
    ? `Moderate heat burden: temperatures around ${tempC}°C cause midday leaf curling. Ensure soil surface does not bake dry.`
    : `Comfortable thermal environment: ambient conditions support steady carbohydrate translocation and healthy root respiration.`;
  const heatExplanationTa = heatRisk === 'high'
    ? `கடுமையான வெப்ப எச்சரிக்கை: ${tempC}°C வெப்பம் பயிரின் ${getStageLabelTa(input.growthStage)} பருவத்திற்கு அதிகம். மகரந்த கருகல் ஏற்படலாம்.`
    : heatRisk === 'watch'
    ? `மிதமான வெப்ப தாக்கம்: ${tempC}°C வெப்பத்தினால் நண்பகலில் இலைகள் சுருளலாம். மண்ணின் மேல் பகுதி காய்ந்து விடாமல் பார்த்துக் கொள்ளவும்.`
    : `சாதகமான சூழல்: ஆரோக்கியமான பயிர் வளர்ச்சிக்கு தேவையான வெப்பநிலை நிலவுகிறது.`;

  const heatNextStep = heatRisk === 'high'
    ? 'Maintain 2–3 cm shallow standing water during peak afternoon hours (12 PM–3 PM) to provide evaporative ground cooling; do NOT spray foliar agrochemicals in direct sunlight.'
    : heatRisk === 'watch'
    ? 'Observe canopy at 1:00 PM for leaf rolling; if leaves roll into tight needles, plan light evening irrigation.'
    : 'Continue regular field monitoring; current thermal conditions require no emergency cooling intervention.';
  const heatNextStepTa = heatRisk === 'high'
    ? 'நண்பகல் வேளையில் (மதியம் 12 முதல் 3 மணி வரை) 2-3 செ.மீ நீர் தேக்கி வைத்து வேர் குளிர்ச்சியை ஏற்படுத்தவும்; வெயில் நேரத்தில் இலைகளில் தெளிப்பான்களை பயன்படுத்த வேண்டாம்.'
    : heatRisk === 'watch'
    ? 'மதியம் 1:00 மணிக்கு இலைகள் சுருள்கிறதா என கவனிக்கவும்; இலைகள் ஊசி போல் சுருண்டால் மாலையில் லேசான நீர் பாய்ச்சவும்.'
    : 'வழக்கமான கள ஆய்வை தொடரவும்; சிறப்பு தலையீடு தேவையில்லை.';

  const heatCategoryResult: CategoryStressResult = {
    category: 'heat',
    name: 'Heat Stress',
    nameTa: 'வெப்ப அழுத்த பாதிப்பு',
    riskLevel: heatRisk,
    score: Math.min(100, heatScore),
    supportingObservations: heatObs,
    supportingObservationsTa: heatObsTa,
    contributingFactors: heatFactors,
    contributingFactorsTa: heatFactorsTa,
    explanation: heatExplanation,
    explanationTa: heatExplanationTa,
    recommendedNextStep: heatNextStep,
    recommendedNextStepTa: heatNextStepTa,
    missingInformation: heatMissing,
    missingInformationTa: heatMissingTa,
    sourceAndTimestamp: `Regional meteorological station & IMD forecast — ${dateFormatted}`,
    sourceAndTimestampTa: `வட்டார வானிலை நிலையம் & IMD கணிப்பு — ${dateFormatted}`,
  };

  // -------------------------------------------------------------
  // OVERALL STRESS SYNTHESIS & FACTOR NORMALIZATION
  // -------------------------------------------------------------
  // Calculate weighted overall stress score:
  // Water: 40%, Nutrient: 25%, Pest: 20%, Heat: 15%
  const compositeScore = Math.round(
    waterScore * 0.40 +
    nutrientScore * 0.25 +
    pestScore * 0.20 +
    heatScore * 0.15
  );
  const stressScore = Math.min(100, Math.max(0, compositeScore));

  // Determine overall risk
  let riskLevel: RiskLevel = 'low';
  if (stressScore >= 60 || waterRisk === 'high' || (nutrientRisk === 'high' && pestRisk === 'high')) {
    riskLevel = 'high';
  } else if (stressScore >= 30 || waterRisk === 'watch' || nutrientRisk === 'watch' || pestRisk === 'watch' || heatRisk === 'watch') {
    riskLevel = 'watch';
  }

  // Calculate percentage contribution for each factor in evidence list
  const totalWeight = evidenceList.reduce((acc, curr) => acc + curr.weight, 0);
  evidenceList.forEach((factor) => {
    factor.contributionPercent = totalWeight > 0 ? Math.round((factor.weight / totalWeight) * 100) : 0;
  });
  evidenceList.sort((a, b) => b.weight - a.weight);

  // Overall Headline & Summary
  let headline = 'Favorable Conditions — Maintain Normal Monitoring';
  let headlineTa = 'சாதகமான சூழல் — வழக்கமான கள கண்காணிப்பை தொடரவும்';
  let summary = 'Current soil moisture, nutrient indicators, pest microclimate, and ambient temperatures are within standard ranges. No urgent intervention required.';
  let summaryTa = 'மண் ஈரப்பதம், ஊட்டச்சத்து குறியீடு, பூச்சி அபாயம் மற்றும் வெப்பநிலை ஆகியவை இயல்பான வரம்பில் உள்ளன. அவசர தலையீடு தேவையில்லை.';
  let primaryAction = 'Walk the bunds twice weekly to inspect standing water level (2–3 cm) and check for pest egg masses under leaf tips.';
  let primaryActionTa = 'வாரத்திற்கு இருமுறை வரப்புகளை பார்வையிட்டு 2-3 செ.மீ நீர் அளவை பராமரிக்கவும், இலை நுனிகளில் பூச்சி முட்டைகள் உள்ளதா என பார்க்கவும்.';

  let actionChecklist = [
    'Check field water inlets to avoid stagnation during early morning',
    'Record any localized weed patches near border bunds',
    'Maintain recommended drainage gaps before scheduled rainfall',
    'Consult local Village Extension Officer (VEO) for routine crop guidance'
  ];
  let actionChecklistTa = [
    'காலை வேளையில் வயல் நீர் வரத்து கால்வாய்களை சரிபார்க்கவும்',
    'வரப்பு ஓரங்களில் உள்ள களைகளை அகற்றவும்',
    'எதிர்பார்க்கப்படும் மழைக்கு முன் வடிகால் வழிகளை தயாராக வைக்கவும்',
    'வழக்கமான பயிர் ஆலோசனைக்கு கிராம வேளாண்மை அலுவலரை அணுகவும்'
  ];

  if (riskLevel === 'high') {
    headline = 'Elevated Water & Canopy Stress — Field Inspection Required';
    headlineTa = 'அதிகரித்த நீர் மற்றும் இலை வாடல் பாதிப்பு — உடனடி கள ஆய்வு தேவை';
    summary = `Multiple compounding stress factors detected (${daysNoRain} rainless days, ${hasSoilMoisture ? `${soilMoist}% soil moisture` : 'high evaporative demand'}, and ${greenChange}% canopy drop). Root moisture depletion is probable.`;
    summaryTa = `ஒன்றுக்கும் மேற்பட்ட காரணிகளால் பயிர் பாதிப்பு கண்டறியப்பட்டுள்ளது (${daysNoRain} நாட்கள் மழை இன்மை, ${hasSoilMoisture ? `${soilMoist}% மண் ஈரப்பதம்` : 'அதிக நீராவிப்போக்கு'}, மற்றும் ${greenChange}% பசுமை குறைவு). வேர் பகுதியில் நீர் வறட்சி இருக்க வாய்ப்புள்ளது.`;
    primaryAction = 'Conduct immediate field walk: probe soil at 10 cm depth across 3 field zones, check canal water roster, and consult local VAO/Agriculture Officer before applying heavy irrigation.';
    primaryActionTa = 'உடனடியாக வயலை நேரில் ஆய்வு செய்யுங்கள்: 3 இடங்களில் 10 செ.மீ ஆழத்தில் மண்ணை சோதிக்கவும், கால்வாய் நீர் முறை விபரம் அறியவும், கிராம வேளாண்மை அலுவலரிடம் ஆலோசனை பெறவும்.';
    actionChecklist = [
      'Dig 10 cm test holes in upper and lower plot corners to inspect subsoil dampness',
      'Examine lower leaf sheaths for premature yellowing or fungal spots',
      'Check with local Water Users Association (WUA) for scheduled canal release',
      'Do NOT apply nitrogen fertilizers or chemical sprays while plants are moisture-stressed',
      'Schedule a field visit with your block Agriculture Development Officer (ADO)'
    ];
    actionChecklistTa = [
      'வயலின் மேட்டு மற்றும் பள்ள பகுதிகளில் 10 செ.மீ ஆழத்தில் மண் ஈரப்பதத்தை நேரில் சோதிக்கவும்',
      'கீழ் இலை உறைகளில் மஞ்சள் நிறம் அல்லது புள்ளிகள் உள்ளதா என கூர்ந்து கவனிக்கவும்',
      'பாசன நீர் பங்கீட்டாளர் சங்கத்தில் கால்வாய் நீர் திறக்கும் முறையை உறுதிப்படுத்தவும்',
      'பயிர் நீர் தாகத்தில் இருக்கும்போது யூரியா அல்லது ரசாயன மருந்துகளை தெளிக்க வேண்டாம்',
      'வட்டார வேளாண்மை அலுவலரிடம் கள ஆய்வு செய்து பரிந்துரை பெறவும்'
    ];
  } else if (riskLevel === 'watch') {
    headline = 'Stress Watch — Increasing Evaporative & Nutrient Demand';
    headlineTa = 'கவனிக்க வேண்டிய நிலை — நீர் மற்றும் சத்து தேவை அதிகரித்து வருகிறது';
    summary = `Early stress indicators present: dry interval of ${daysNoRain} days with declining soil moisture (${soilMoist}%). Plot needs close observation over the next 48 hours.`;
    summaryTa = `தொடக்க நிலை பாதிப்பு அறிகுறிகள்: ${daysNoRain} நாட்கள் மழை இன்மை மற்றும் குறைந்து வரும் மண் ஈரப்பதம் (${soilMoist}%). அடுத்த 48 மணி நேரத்தில் நெருக்கமாக கண்காணிக்க வேண்டும்.`;
    primaryAction = 'Inspect bund retention and seal any rodent holes or leaks to preserve existing root zone moisture.';
    primaryActionTa = 'வயல் வரப்புகளை பார்வையிட்டு, எலி வளைகள் அல்லது நீர் கசிவுகளை அடைத்து ஈரப்பதத்தை பாதுகாக்கவும்.';
    actionChecklist = [
      'Check field bunds for water leaks or crab burrows that cause rapid drainage',
      'Observe crop leaves at 1:00 PM for signs of temporary midday wilting',
      'Confirm well/borewell electricity schedule with TANGEDCO for upcoming irrigation',
      'Prepare light alternate wetting and drying (AWD) cycle if water supply is limited'
    ];
    actionChecklistTa = [
      'வயல் வரப்புகளில் நண்டு வளைகள் மற்றும் நீர் கசிவுகளை அடைக்கவும்',
      'நண்பகல் 1:00 மணிக்கு இலைகள் தற்காலிகமாக சுருள்கிறதா என்பதை கவனிக்கவும்',
      'மின்சார விநியோக நேரத்தை முன்கூட்டியே அறிந்து பாசன திட்டத்தை அமைக்கவும்',
      'நீர் பற்றாக்குறை இருந்தால் முறை பாசன முறையை (AWD) திட்டமிடவும்'
    ];
  }

  // -------------------------------------------------------------
  // THE 5 CORE EXPLAINABLE AI QUESTIONS
  // -------------------------------------------------------------
  const explainableQuestions: FiveExplainableQuestions = {
    // 1. What possible crop problem was identified?
    identifiedProblem: {
      title: riskLevel === 'high' 
        ? 'Severe Root Moisture Deficit with Secondary Canopy Chlorosis'
        : riskLevel === 'watch'
        ? 'Early Moisture Stress Watch & Atmospheric Evaporative Demand'
        : 'Normal Vegetative Equilibrium (No Acute Stress Detected)',
      titleTa: riskLevel === 'high'
        ? 'கடுமையான வேர் நீர் பற்றாக்குறை மற்றும் இலை பசுமை குறைவு'
        : riskLevel === 'watch'
        ? 'தொடக்க நிலை நீர் பற்றாக்குறை மற்றும் ஆவியாதல் அதிகரிப்பு'
        : 'சீரான பயிர் வளர்ச்சி சமநிலை (பாதிப்பு இல்லை)',
      details: `Categorical status: Water Stress is ${waterRisk.toUpperCase()} (${waterCategoryResult.score}/100), Nutrient Stress is ${nutrientRisk.toUpperCase()} (${nutrientCategoryResult.score}/100), Pest/Disease Risk is ${pestRisk.toUpperCase()} (${pestCategoryResult.score}/100), and Heat Stress is ${heatRisk.toUpperCase()} (${heatCategoryResult.score}/100).`,
      detailsTa: `பிரிவு நிலை: நீர் அழுத்தம் ${waterRisk === 'high' ? 'அதிகம்' : waterRisk === 'watch' ? 'மிதம்' : 'குறைவு'} (${waterCategoryResult.score}/100), சத்து நிலை ${nutrientRisk === 'high' ? 'அதிகம்' : nutrientRisk === 'watch' ? 'மிதம்' : 'குறைவு'} (${nutrientCategoryResult.score}/100), பூச்சி நோய் ${pestRisk === 'high' ? 'அதிகம்' : pestRisk === 'watch' ? 'மிதம்' : 'குறைவு'} (${pestCategoryResult.score}/100), வெப்ப அழுத்தம் ${heatRisk === 'high' ? 'அதிகம்' : heatRisk === 'watch' ? 'மிதம்' : 'குறைவு'} (${heatCategoryResult.score}/100).`,
    },

    // 2. Why does the system suspect this problem?
    whySuspected: {
      reasoning: riskLevel === 'high'
        ? `The plot has passed 7+ consecutive rain-free days while soil moisture dipped below 20%. During ${getStageLabel(input.growthStage)}, paddy plants cannot maintain turgor pressure without root zone saturation.`
        : riskLevel === 'watch'
        ? `Soil moisture has slipped below the comfort boundary (28%) with ${daysNoRain} days since rain. Peak temperatures of ${tempC}°C increase transpiration.`
        : `All physical measurements fall within healthy physiological ranges for ${getStageLabel(input.growthStage)} paddy.`,
      reasoningTa: riskLevel === 'high'
        ? `7 நாட்களுக்கு மேலாக மழை இல்லாத நிலையில் மண் ஈரப்பதம் 20% கீழே இறங்கியுள்ளது. ${getStageLabelTa(input.growthStage)} பருவத்தில் நெல் பயிருக்கு வேர் பகுதியில் நீர் இருப்பு இன்றியமையாதது.`
        : riskLevel === 'watch'
        ? `மழை இல்லாமல் ${daysNoRain} நாட்கள் ஆகி மண் ஈரப்பதம் 28% கீழே குறைந்துள்ளது. ${tempC}°C வெப்பத்தினால் நீராவிப்போக்கு அதிகரிக்கிறது.`
        : `அனைத்து கள அளவீடுகளும் ${getStageLabelTa(input.growthStage)} நெல் பயிர் வளர்ச்சிக்கு உகந்த வரம்பில் உள்ளன.`,
      agronomicPrinciple: 'Agronomic Principle: Transpiration rate (E) exceeds root hydraulic conductance when volumetric soil moisture drops below field capacity in clay-loam soils.',
      agronomicPrincipleTa: 'வேளாண் அறிவியல் விதி: களிமண் கலந்த நிலத்தில் மண் ஈரப்பதம் வரம்பை விட குறையும் போது, வேர் நீர் உறிஞ்சும் வேகத்தை விட இலைகளிலிருந்து ஆவியாகும் வேகம் அதிகரிக்கிறது.',
    },

    // 3. Which available inputs support the result?
    supportingInputs: {
      inputSummary: `${availableFields} of ${totalFields} biometric & environmental indicators were evaluated. The highest contributor is ${evidenceList[0]?.title || 'Soil Moisture'}.`,
      inputSummaryTa: `${totalFields} இல் ${availableFields} கள மற்றும் வானிலை குறியீடுகள் ஆய்வு செய்யப்பட்டன. அதிக பங்களிப்பு: ${evidenceList[0]?.titleTa || 'மண் ஈரப்பதம்'}.`,
      factors: evidenceList.map((f) => ({
        name: f.title,
        nameTa: f.titleTa,
        value: f.inputValue,
        contributionPercent: f.contributionPercent,
        ruleTriggered: f.thresholdRule,
      })),
    },

    // 4. What should the farmer check next?
    whatToCheckNext: {
      primaryCheck: primaryAction,
      primaryCheckTa: primaryActionTa,
      checklist: actionChecklist,
      checklistTa: actionChecklistTa,
      safetyWarning: 'Safety Guardrail: Never apply chemical fertilizers (urea/DAP) or non-prescribed chemical sprays when plants are under moisture stress. Always consult the Block Agriculture Officer.',
      safetyWarningTa: 'பாதுகாப்பு நெறிமுறை: பயிர் நீர் தாகத்தில் இருக்கும் போது யூரியா அல்லது அங்கீகரிக்கப்படாத ரசாயன மருந்துகளை தெளிக்க வேண்டாம். வேளாண்மை அலுவலரிடம் ஆலோசனை பெறவும்.',
    },

    // 5. How reliable is this recommendation and what are the limitations?
    reliabilityAndLimitations: {
      reliabilityScore: coveragePercent >= 80 
        ? 'High (Direct Measurements)' 
        : coveragePercent >= 50 
        ? 'Moderate (Derived Proxies)' 
        : 'Preliminary (Limited Inputs)',
      reliabilityScoreTa: coveragePercent >= 80 
        ? 'உயர் நம்பகத்தன்மை (நேரடி கள அளவீடுகள்)' 
        : coveragePercent >= 50 
        ? 'மிதமான நம்பகத்தன்மை (துணை தரவுகள்)' 
        : 'தொடக்க நிலை (வரையறுக்கப்பட்ட தரவுகள்)',
      confidencePercent: Math.min(95, Math.max(45, coveragePercent - (missingFields.length * 4))),
      limitations: [
        'Deterministic Agronomic Rule Engine: Evaluates agronomic thresholds (not an opaque black-box ML model).',
        missingFields.length > 0 
          ? `Missing data points (${missingFields.join(', ')}) adjusted total confidence downwards.` 
          : 'All 7 biometric signals verified.',
        'Soil micro-variations across bunds may cause localized pockets to differ from cluster average.',
        'Assisted screening tool only; field walk confirmation is always required before operational spending.'
      ],
      limitationsTa: [
        'ஒளிவுமறைவற்ற வேளாண் விதி மாதிரி: வெளிப்படையான விதிமுறைகள் அடிப்படையில் இயங்குகிறது (கருப்புப் பெட்டி ML அல்ல).',
        missingFields.length > 0 
          ? `விடுபட்ட தரவுகள் (${missingFieldsTa.join(', ')}) காரணமாக கணக்கீட்டு நம்பிக்கை சரிசெய்யப்பட்டுள்ளது.` 
          : 'அனைத்து 7 குறியீடுகளும் சரிபார்க்கப்பட்டன.',
        'வயலின் மேடு பள்ளங்களுக்கு ஏற்ப சிறு மாற்றங்கள் இருக்கலாம்.',
        'இது ஒரு வழிகாட்டுதல் மட்டுமே; செலவு செய்வதற்கு முன் நேரில் கள ஆய்வு செய்வது அவசியம்.'
      ],
      transparencyNote: 'FarmPulse uses transparent, deterministic agronomic rules developed with Tamil Nadu Agriculture University (TNAU) guidelines. No synthetic SHAP or hallucinated ML weights are used.',
      transparencyNoteTa: 'FarmPulse தமிழ்நாடு வேளாண்மை பல்கலைக்கழக வழிகாட்டுதல்களின்படி ஒளிவுமறைவற்ற விதிகளை மட்டுமே பயன்படுத்துகிறது. போலி அல்லது கற்பனை ML மதிப்புகள் தவிர்க்கப்படுகின்றன.',
    },
  };

  const uncertaintyNotes = missingFields.length > 0
    ? `Notice: ${missingFields.length} optional input(s) not available (${missingFields.join(', ')}). Calculations rely strictly on verified ground metrics and local weather observations.`
    : 'All 7 biometric and environmental indicators accounted for. Localized soil texture variations may still cause micro-climate variations.';

  const uncertaintyNotesTa = missingFieldsTa.length > 0
    ? `குறிப்பு: ${missingFieldsTa.length} கூடுதல் தரவுகள் கிடைக்கவில்லை (${missingFieldsTa.join(', ')}). மதிப்பீடு கள அளவீடுகள் மற்றும் வானிலை தரவுகளை மட்டுமே அடிப்படையாகக் கொண்டது.`
    : 'அனைத்து 7 குறியீடுகளும் கணக்கில் கொள்ளப்பட்டுள்ளன. மண்ணின் வகைக்கு ஏற்ப சிறு மாற்றங்கள் ஏற்படலாம்.';

  return {
    plotId: '',
    riskLevel,
    stressScore,
    headline,
    headlineTa,
    summary,
    summaryTa,
    primaryAction,
    primaryActionTa,
    actionChecklist,
    actionChecklistTa,
    evidenceList,
    dataCoveragePercent: coveragePercent,
    availableFieldsCount: availableFields,
    totalFieldsCount: totalFields,
    missingFields,
    missingFieldsTa,
    uncertaintyNotes,
    uncertaintyNotesTa,
    assessedAt: nowIso,
    officerConsultWarning: riskLevel === 'high',
    categories: {
      waterStress: waterCategoryResult,
      nutrientStress: nutrientCategoryResult,
      pestDiseaseRisk: pestCategoryResult,
      heatStress: heatCategoryResult,
    },
    explainableQuestions,
    farmInfo: {
      farmName: input.farmName || 'Kaveripakkam Plot',
      location: input.location || 'Kaveripakkam, Tamil Nadu',
      cropType: input.crop,
      growthStage: input.growthStage,
      plantingDate: input.plantingDate,
    },
  };
}

function getStageLabel(stage: GrowthStage): string {
  switch (stage) {
    case 'nursery': return 'Nursery';
    case 'tillering': return 'Active Tillering';
    case 'panicle_initiation': return 'Panicle Initiation';
    case 'flowering': return 'Flowering Stage';
    case 'grain_filling': return 'Grain Filling';
    case 'mature': return 'Maturity / Harvest Ready';
  }
}

function getStageLabelTa(stage: GrowthStage): string {
  switch (stage) {
    case 'nursery': return 'நாற்றங்கால்';
    case 'tillering': return 'தூர்கட்டும் பருவம்';
    case 'panicle_initiation': return 'கதிர் உருவாகும் பருவம்';
    case 'flowering': return 'பூக்கும் பருவம்';
    case 'grain_filling': return 'பால் பிடிக்கும் பருவம்';
    case 'mature': return 'முதிர்ச்சி பருவம்';
  }
}
