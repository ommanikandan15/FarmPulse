import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Plot, GrowthStage, Observation } from '../../types';
import { CROP_TYPES, generateCadastralPolygon, CropTypeInfo } from '../../data/cropLandData';
import { evaluateCropStress } from '../../services/advisoryEngine';
import { 
  X, 
  MapPin, 
  Locate, 
  Check, 
  Sprout, 
  Calendar, 
  Ruler, 
  Droplets, 
  Layers, 
  Compass,
  AlertCircle
} from 'lucide-react';

interface MarkLandModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCoords?: { lat: number; lng: number };
}

export const MarkLandModal: React.FC<MarkLandModalProps> = ({
  isOpen,
  onClose,
  initialCoords,
}) => {
  const { language, addPlot } = useApp();

  const [step, setStep] = useState<1 | 2>(1);
  const [landName, setLandName] = useState('');
  const [surveyNumber, setSurveyNumber] = useState('');
  const [areaAcres, setAreaAcres] = useState('2.0');
  const [selectedCrop, setSelectedCrop] = useState<CropTypeInfo>(CROP_TYPES[0]);
  const [variety, setVariety] = useState(CROP_TYPES[0].defaultVarieties[0]);
  const [sowingDate, setSowingDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 40);
    return d.toISOString().split('T')[0];
  });
  const [growthStage, setGrowthStage] = useState<GrowthStage>('tillering');
  const [soilType, setSoilType] = useState('Clay Loam (మట్టి లోమ్)');
  const [irrigationSource, setIrrigationSource] = useState('Borewell + Canal');
  const [lat, setLat] = useState(initialCoords?.lat || 12.8982);
  const [lng, setLng] = useState(initialCoords?.lng || 79.4674);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setErrorMsg('GPS is not supported by your device.');
      return;
    }
    setGpsLoading(true);
    setErrorMsg(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        setLat(Number(pos.coords.latitude.toFixed(6)));
        setLng(Number(pos.coords.longitude.toFixed(6)));
      },
      (err) => {
        setGpsLoading(false);
        setErrorMsg(err.message || 'Could not fetch GPS location.');
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  const handleSelectCrop = (crop: CropTypeInfo) => {
    setSelectedCrop(crop);
    setVariety(crop.defaultVarieties[0] || crop.nameEn);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const acresNum = parseFloat(areaAcres) || 2.0;
    const finalLandName = landName.trim() || `Field ${Date.now().toString().slice(-4)} (${selectedCrop.nameEn})`;
    const finalSurvey = surveyNumber.trim() || `SF No. ${Math.floor(Math.random() * 200 + 50)}/1A`;

    // Construct polygon coordinates for the boundary
    const boundaryPolygon = generateCadastralPolygon(lat, lng, acresNum);

    // Initial baseline observation
    const newObservation: Observation = {
      id: `obs-${Date.now()}`,
      plotId: `plot-${Date.now()}`,
      timestamp: new Date().toISOString(),
      daysWithoutRain: 3,
      soilMoisturePercent: selectedCrop.waterNeed === 'High' ? 22 : 28,
      weeklyGreennessChangePercent: -2.5,
      temperatureCelsius: 32.5,
      humidityPercent: 55,
      ndvi: 0.52,
      ndwi: 0.05,
      sourceType: 'farmer',
      notes: `Newly registered land parcel. Sown on ${sowingDate}. Soil: ${soilType}.`,
    };

    const newAdvisory = evaluateCropStress({
      crop: `${selectedCrop.key} (${variety})`,
      growthStage,
      daysWithoutRain: 3,
      soilMoisturePercent: newObservation.soilMoisturePercent,
      weeklyGreennessChangePercent: -2.5,
      temperatureCelsius: 32.5,
      humidityPercent: 55,
      ndvi: 0.52,
      ndwi: 0.05,
      farmName: finalLandName,
      location: `Cadastral ${finalSurvey}`,
      plantingDate: sowingDate,
    });

    const newPlot: Plot = {
      id: `plot-custom-${Date.now()}`,
      name: finalLandName,
      nameTa: `${finalLandName} (${selectedCrop.nameTa})`,
      nameTe: `${finalLandName} (${selectedCrop.nameTe})`,
      farmerName: 'My Farm Land',
      farmerNameTa: 'என் பண்ணை நிலம்',
      farmerNameTe: 'నా వ్యవసాయ పొలం',
      farmerPhoneMasked: '+91 ••••• •••••',
      cropType: selectedCrop.key,
      cropTypeTe: selectedCrop.nameTe,
      cropTypeTa: selectedCrop.nameTa,
      variety: `${selectedCrop.key} (${variety})`,
      varietyTa: `${selectedCrop.nameTa} (${variety})`,
      varietyTe: `${selectedCrop.nameTe} (${variety})`,
      growthStage,
      areaAcres: acresNum,
      surveyNumber: finalSurvey,
      sowingDate,
      soilType,
      irrigationType: irrigationSource,
      locationName: `Village Land Parcel, ${finalSurvey}`,
      locationNameTa: `கிராம புல எண்: ${finalSurvey}`,
      locationNameTe: `గ్రామ సర్వే నంబర్: ${finalSurvey}`,
      coordinates: { lat, lng },
      boundaryPolygon,
      latestObservation: newObservation,
      advisory: newAdvisory,
      history: [newObservation],
    };

    addPlot(newPlot);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl border border-[#CCD6C6] shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden text-[#173F35]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#173F35] to-[#255e50] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center border border-white/20">
              <Compass className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold flex items-center gap-2">
                {language === 'te' 
                  ? 'నా పొలాన్ని గుర్తించండి (భూమి & పంట నమోదు)'
                  : language === 'ta'
                  ? 'என் நிலத்தைக் குறிக்கவும் (நிலம் & பயிர் பதிவு)'
                  : 'Mark My Land (Parcel & Crop Registration)'}
              </h2>
              <p className="text-xs text-emerald-100">
                {language === 'te'
                  ? 'పొలం సరిహద్దులు గుర్తించి, ఏ పంట నాటారో సులభంగా రికార్డ్ చేయండి'
                  : language === 'ta'
                  ? 'நிலத்தின் எல்லைகளைக் குறித்து என்ன பயிர் பயிரிடப்பட்டுள்ளது என்பதைப் பதிவு செய்யவும்'
                  : 'Mark boundaries on the map & record what crop is planted in this parcel.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-all"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Navigation Bar */}
        <div className="flex items-center border-b border-[#E3E8DC] bg-[#F7F8F4] px-5 py-2.5 text-xs font-bold text-[#566761] shrink-0">
          <button
            type="button"
            onClick={() => setStep(1)}
            className={`flex items-center gap-2 py-1 px-3 rounded-lg transition-all ${
              step === 1 ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]' : 'hover:text-[#173F35]'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step === 1 ? 'bg-[#173F35] text-white' : 'bg-gray-200'}`}>1</span>
            <span>{language === 'te' ? 'భూమి వివరాలు & సరిహద్దు' : language === 'ta' ? 'நில விவரம் & எல்லை' : 'Land & Location'}</span>
          </button>

          <span className="text-gray-300 mx-2">→</span>

          <button
            type="button"
            onClick={() => setStep(2)}
            className={`flex items-center gap-2 py-1 px-3 rounded-lg transition-all ${
              step === 2 ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]' : 'hover:text-[#173F35]'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step === 2 ? 'bg-[#173F35] text-white' : 'bg-gray-200'}`}>2</span>
            <span>{language === 'te' ? 'ఏ పంట నాటబడింది? (Crop)' : language === 'ta' ? 'என்ன பயிர் பயிரிடப்பட்டுள்ளது?' : 'What is Planted'}</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'పొలం / మడి పేరు' : language === 'ta' ? 'நிலத்தின் பெயர்' : 'Land / Parcel Name'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={landName}
                    onChange={(e) => setLandName(e.target.value)}
                    placeholder={language === 'te' ? 'ఉదా: తూర్పు కాలువ వరి పొలం' : language === 'ta' ? 'எ.கா: கிழக்கு வாய்க்கால் நிலம்' : 'e.g. East Canal Field'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'సర్వే నంబర్ (SF No.)' : language === 'ta' ? 'புல எண் (SF No.)' : 'Survey Number (SF No.)'}
                  </label>
                  <input
                    type="text"
                    value={surveyNumber}
                    onChange={(e) => setSurveyNumber(e.target.value)}
                    placeholder="e.g. SF No. 145/2A"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'భూమి విస్తీర్ణం (ఎకరాలు)' : language === 'ta' ? 'பரப்பளவு (ஏக்கர்)' : 'Total Land Area (Acres)'} *
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="100"
                      required
                      value={areaAcres}
                      onChange={(e) => setAreaAcres(e.target.value)}
                      className="w-full px-3.5 py-2.5 pr-14 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                    />
                    <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">
                      Acres
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'మట్టి రకం (Soil Series)' : language === 'ta' ? 'மண் வகை' : 'Soil Series / Soil Type'}
                  </label>
                  <select
                    value={soilType}
                    onChange={(e) => setSoilType(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  >
                    <option value="Clay Loam (మట్టి లోమ్)">Clay Loam (మట్టి లోమ్ / களிமண்)</option>
                    <option value="Red Sandy Loam (ఎర్ర ఇసుక నేల)">Red Sandy Loam (ఎర్ర నేల / செம்மண்)</option>
                    <option value="Black Cotton Soil (నల్లరేగడి)">Black Cotton Soil (నల్లరేగడి / கரிசல்)</option>
                    <option value="Alluvial Sandy (ఒండ్రు ఇసుక)">Alluvial Sandy Loam (ఒండ్రు నేల / வண்டல்)</option>
                  </select>
                </div>
              </div>

              {/* Coordinates & Location Pin */}
              <div className="p-4 rounded-2xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#173F35]">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'te' ? 'మ్యాప్ స్థానం / GPS కోఆర్డినేట్స్' : language === 'ta' ? 'ஜிபிஎஸ் வரைபட இருப்பிடம்' : 'GPS Coordinates & Pin'}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleLocateMe}
                    disabled={gpsLoading}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs"
                  >
                    <Locate className={`w-3.5 h-3.5 ${gpsLoading ? 'animate-spin' : ''}`} />
                    <span>{gpsLoading ? 'Locating...' : (language === 'te' ? 'ప్రస్తుత GPS తీసుకోండి' : language === 'ta' ? 'என் GPS எடுக்க' : 'Use Current GPS')}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-[11px] text-gray-500 font-medium">Latitude:</span>
                    <input
                      type="number"
                      step="0.000001"
                      value={lat}
                      onChange={(e) => setLat(parseFloat(e.target.value) || 0)}
                      className="w-full mt-1 px-3 py-1.5 rounded-lg border border-[#CCD6C6] bg-white font-mono text-xs font-semibold"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-gray-500 font-medium">Longitude:</span>
                    <input
                      type="number"
                      step="0.000001"
                      value={lng}
                      onChange={(e) => setLng(parseFloat(e.target.value) || 0)}
                      className="w-full mt-1 px-3 py-1.5 rounded-lg border border-[#CCD6C6] bg-white font-mono text-xs font-semibold"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-[#566761]">
                  💡 {language === 'te'
                    ? 'ఈ బిందువు ఆధారంగా ఖచ్చితమైన 4-మూలల క్యాడస్ట్రల్ సరిహద్దు మరియు విస్తీర్ణం లెక్కించబడుతుంది.'
                    : language === 'ta'
                    ? 'இந்த ஆயத்தொலைவை அடிப்படையாகக் கொண்டு வயலின் நான்கு மூலை எல்லைகள் தானாக வரையப்படும்.'
                    : 'The map will automatically generate 4-corner boundary stones based on these coordinates & acreage.'}
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-5 py-2.5 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-all flex items-center gap-1.5"
                >
                  <span>{language === 'te' ? 'తదుపరి: నాటిన పంట ఎంచుకోండి' : language === 'ta' ? 'அடுத்து: பயிர் தேர்வு' : 'Next: Select What is Planted'}</span>
                  <span>→</span>
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <label className="block text-xs font-bold text-[#173F35] mb-2 flex items-center gap-1.5">
                  <Sprout className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'te'
                      ? 'ఈ నేలలో ఏ పంట నాటారు? (పంట ఎంచుకోండి)'
                      : language === 'ta'
                      ? 'இந்த நிலத்தில் என்ன பயிர் பயிரிடப்பட்டுள்ளது?'
                      : 'What is planted in this land? (Select Crop)'}
                  </span>
                </label>

                {/* Visual Crop Selection Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {CROP_TYPES.map((crop) => {
                    const isSelected = selectedCrop.key === crop.key;
                    return (
                      <button
                        type="button"
                        key={crop.key}
                        onClick={() => handleSelectCrop(crop)}
                        className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                          isSelected
                            ? 'border-[#173F35] ring-2 ring-emerald-500 bg-emerald-50/60 shadow-sm'
                            : 'border-[#E3E8DC] hover:border-emerald-300 bg-white hover:bg-[#FAFAF8]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-2xl">{crop.emoji}</span>
                          {isSelected && (
                            <span className="w-5 h-5 rounded-full bg-[#173F35] text-white flex items-center justify-center">
                              <Check className="w-3 h-3" />
                            </span>
                          )}
                        </div>
                        <div className="mt-2">
                          <h4 className="text-xs font-extrabold text-[#173F35]">
                            {language === 'te' ? crop.nameTe : language === 'ta' ? crop.nameTa : crop.nameEn}
                          </h4>
                          <span className="text-[10px] text-[#566761] block mt-0.5">
                            {crop.key} • {crop.typicalDurationDays}d
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Variety & Sowing Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'పంట రకం / విత్తనం (Variety)' : language === 'ta' ? 'பயிர் ரகம்' : 'Crop Variety / Cultivar'}
                  </label>
                  <select
                    value={variety}
                    onChange={(e) => setVariety(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  >
                    {selectedCrop.defaultVarieties.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-500" />
                    <span>{language === 'te' ? 'విత్తిన / నాటిన తేదీ' : language === 'ta' ? 'விதைத்த தேதி' : 'Sowing / Planting Date'}</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={sowingDate}
                    onChange={(e) => setSowingDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  />
                </div>
              </div>

              {/* Growth Stage & Irrigation Source */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5">
                    {language === 'te' ? 'ప్రస్తుత పంట దశ (Growth Stage)' : language === 'ta' ? 'வளர்ச்சிப் பருவம்' : 'Current Growth Stage'}
                  </label>
                  <select
                    value={growthStage}
                    onChange={(e) => setGrowthStage(e.target.value as GrowthStage)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  >
                    <option value="nursery">{language === 'te' ? 'నారుమడి (Nursery - 0 to 25d)' : language === 'ta' ? 'நாற்று மேடை (Nursery)' : 'Nursery Bed (0 - 25 days)'}</option>
                    <option value="tillering">{language === 'te' ? 'పిలకల దశ (Tillering - 25 to 45d)' : language === 'ta' ? 'தூர்கட்டும் பருவம்' : 'Tillering (25 - 45 days)'}</option>
                    <option value="panicle_initiation">{language === 'te' ? 'చిరుపొట్ట / పూత ప్రారంభం (Panicle Initiation)' : language === 'ta' ? 'கதிர் உருவாகும் பருவம்' : 'Panicle Initiation (45 - 65 days)'}</option>
                    <option value="flowering">{language === 'te' ? 'పూత దశ (Flowering - 65 to 85d)' : language === 'ta' ? 'பூக்கும் பருவம்' : 'Flowering & Anthesis (65 - 85 days)'}</option>
                    <option value="grain_filling">{language === 'te' ? 'గింజ పాలుపోసుకునే దశ (Grain Filling)' : language === 'ta' ? 'பால் பிடிக்கும் பருவம்' : 'Grain / Pod Filling (85 - 105 days)'}</option>
                    <option value="mature">{language === 'te' ? 'కోతకు సిద్ధం (Harvest Ready)' : language === 'ta' ? 'அறுவடை பருவம்' : 'Harvest Ready (105+ days)'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#173F35] mb-1.5 flex items-center gap-1">
                    <Droplets className="w-3.5 h-3.5 text-blue-500" />
                    <span>{language === 'te' ? 'నీటి పారుదల వనరు' : language === 'ta' ? 'பாசன முறை' : 'Irrigation Source'}</span>
                  </label>
                  <select
                    value={irrigationSource}
                    onChange={(e) => setIrrigationSource(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#CCD6C6] text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
                  >
                    <option value="Borewell + Canal">Borewell + Canal (బోరుబావి + కాలువ)</option>
                    <option value="Drip Irrigation">Drip Irrigation (బిందు సేద్యం / சொட்டு நீர்)</option>
                    <option value="Sprinkler Irrigation">Sprinkler (తుంపర సేద్యం)</option>
                    <option value="Canal Feeder">Palar / Cauvery Canal (కాలువ నీరు)</option>
                    <option value="Rainfed">Rainfed (వర్షాధార / மானாவாரி)</option>
                  </select>
                </div>
              </div>

              {/* Planted Summary Card */}
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs flex items-center gap-3">
                <span className="text-3xl">{selectedCrop.emoji}</span>
                <div>
                  <p className="font-extrabold text-[#173F35]">
                    {language === 'te'
                      ? `గుర్తించబడిన భూమి: ${landName || 'పొలం'} (${areaAcres} ఎకరాలు)`
                      : language === 'ta'
                      ? `குறிக்கப்பட்ட நிலம்: ${landName || 'நிலம்'} (${areaAcres} ஏக்கர்)`
                      : `Marked Land: ${landName || 'Field'} (${areaAcres} Acres)`}
                  </p>
                  <p className="text-[11px] text-emerald-800 mt-0.5">
                    {language === 'te'
                      ? `నాటిన పంట: ${selectedCrop.nameTe} • రకం: ${variety} • నీటి అవసరం: ${selectedCrop.waterNeedTe}`
                      : language === 'ta'
                      ? `பயிரிடப்பட்ட பயிர்: ${selectedCrop.nameTa} • ரகம்: ${variety} • பாசனத் தேவை: ${selectedCrop.waterNeedTa}`
                      : `Planted Crop: ${selectedCrop.nameEn} • Variety: ${variety} • Water Need: ${selectedCrop.waterNeed}`}
                  </p>
                </div>
              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 text-xs font-bold text-[#566761] hover:text-[#173F35] bg-[#F7F8F4] rounded-xl border border-[#CCD6C6] transition-all"
                >
                  ← {language === 'te' ? 'వెనుకకు' : language === 'ta' ? 'முந்தையது' : 'Back'}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 text-xs font-bold text-gray-500 hover:text-gray-700 transition-all"
                  >
                    {language === 'te' ? 'రద్దు' : language === 'ta' ? 'ரத்து' : 'Cancel'}
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs sm:text-sm font-extrabold shadow-md transition-all flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>
                      {language === 'te' ? 'పొలం సరిహద్దు సేవ్ చేయండి' : language === 'ta' ? 'நிலத்தைச் சேமிக்கவும்' : 'Save Marked Land'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
