import os
import struct
import zlib
import math

def make_png(width, height, draw_func):
    raw_rows = []
    for y in range(height):
        row = bytearray(1 + width * 4)
        row[0] = 0 # No filter
        idx = 1
        for x in range(width):
            r, g, b, a = draw_func(x, y, width, height)
            row[idx] = r
            row[idx+1] = g
            row[idx+2] = b
            row[idx+3] = a
            idx += 4
        raw_rows.append(bytes(row))
    raw_data = b"".join(raw_rows)
    compressed = zlib.compress(raw_data, level=6)

    def chunk(tag, data):
        crc = zlib.crc32(tag + data) & 0xffffffff
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', crc)

    header = b'\x89PNG\r\n\x1a\n'
    ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
    idat = chunk(b'IDAT', compressed)
    iend = chunk(b'IEND', b'')
    return header + ihdr + idat + iend

def farmpulse_pixel(x, y, w, h, is_maskable=False):
    # Normalized coords (-1 to 1)
    nx = (x - w / 2) / (w / 2)
    ny = (y - h / 2) / (h / 2)
    dist = math.sqrt(nx * nx + ny * ny)

    # Base background: deep emerald gradient
    # Top: #1b4b3e, Bottom: #0e2721
    grad = (ny + 1.0) / 2.0
    bg_r = int(27 * (1 - grad) + 14 * grad)
    bg_g = int(75 * (1 - grad) + 39 * grad)
    bg_b = int(62 * (1 - grad) + 33 * grad)

    if is_maskable:
        # Full bleed background for Android adaptive icon clipping
        scale = 0.72 # Keep emblem inside 72% safe zone
    else:
        scale = 0.86
        if dist > 0.96:
            return (0, 0, 0, 0) # Smooth transparent border for rounded icon

    # Scaled coords for icon symbol
    sx = nx / scale
    sy = ny / scale
    s_dist = math.sqrt(sx * sx + sy * sy)

    # Subtle inner circular glow
    if s_dist < 1.0:
        glow = (1.0 - s_dist) * 0.15
        bg_r = min(255, int(bg_r + 40 * glow))
        bg_g = min(255, int(bg_g + 90 * glow))
        bg_b = min(255, int(bg_b + 60 * glow))

    # Outer golden ring
    if 0.88 <= s_dist <= 0.94:
        ring_alpha = 1.0 - abs(s_dist - 0.91) / 0.03
        return (
            int(bg_r * (1 - ring_alpha) + 218 * ring_alpha),
            int(bg_g * (1 - ring_alpha) + 165 * ring_alpha),
            int(bg_b * (1 - ring_alpha) + 64 * ring_alpha),
            255
        )

    # Leaf 1 (Left sprout)
    # Parametric heart/leaf shape centered around (-0.2, -0.05)
    lx1 = sx + 0.15
    ly1 = sy + 0.12
    # Rotated leaf
    rx1 = lx1 * 0.8 - ly1 * 0.6
    ry1 = lx1 * 0.6 + ly1 * 0.8
    in_leaf1 = (rx1 * rx1 * 3.5 + ry1 * ry1 * 1.8 < 0.18) and (ry1 > -0.35 and rx1 < 0.25)

    # Leaf 2 (Right sprout)
    lx2 = sx - 0.18
    ly2 = sy + 0.08
    rx2 = lx2 * 0.75 + ly2 * 0.65
    ry2 = -lx2 * 0.65 + ly2 * 0.75
    in_leaf2 = (rx2 * rx2 * 3.2 + ry2 * ry2 * 1.6 < 0.22) and (ry2 > -0.38 and rx2 > -0.22)

    # Central Stem
    in_stem = (abs(sx) < 0.055 and -0.1 <= sy <= 0.42) or (abs(sx + (sy - 0.1) * 0.15) < 0.045 and 0.1 <= sy <= 0.5)

    # Pulse / Vital wave in lower half
    # Sine wave pulse: y between 0.22 and 0.28
    wave_y = 0.25 + 0.08 * math.sin(sx * 9.0) * math.exp(-sx * sx * 3.0)
    in_pulse = abs(sy - wave_y) < 0.038 and abs(sx) < 0.75

    # Check for leaf rendering
    if in_leaf1 or in_leaf2:
        # Vibrant emerald green (#65A66F / #8BD498)
        return (101, 166, 111, 255)
    
    if in_stem:
        # Fresh light stem green (#8BD498)
        return (139, 212, 152, 255)

    if in_pulse:
        # Golden pulse signal (#F59E0B / #FBBF24)
        return (245, 158, 11, 255)

    # Default background
    return (bg_r, bg_g, bg_b, 255)

def main():
    os.makedirs('/app/applet/public', exist_ok=True)

    print("Generating pwa-192x192.png...")
    png192 = make_png(192, 192, lambda x, y, w, h: farmpulse_pixel(x, y, w, h, False))
    with open('/app/applet/public/pwa-192x192.png', 'wb') as f:
        f.write(png192)

    print("Generating pwa-512x512.png...")
    png512 = make_png(512, 512, lambda x, y, w, h: farmpulse_pixel(x, y, w, h, False))
    with open('/app/applet/public/pwa-512x512.png', 'wb') as f:
        f.write(png512)

    print("Generating pwa-maskable-512x512.png...")
    png_maskable = make_png(512, 512, lambda x, y, w, h: farmpulse_pixel(x, y, w, h, True))
    with open('/app/applet/public/pwa-maskable-512x512.png', 'wb') as f:
        f.write(png_maskable)

    print("Generating apple-touch-icon.png...")
    png_apple = make_png(180, 180, lambda x, y, w, h: farmpulse_pixel(x, y, w, h, False))
    with open('/app/applet/public/apple-touch-icon.png', 'wb') as f:
        f.write(png_apple)

    # Also create a small favicon.ico from 192x192 (or write png as favicon)
    with open('/app/applet/public/favicon.ico', 'wb') as f:
        f.write(png192)

    print("All PWA icons generated successfully!")

if __name__ == '__main__':
    main()
