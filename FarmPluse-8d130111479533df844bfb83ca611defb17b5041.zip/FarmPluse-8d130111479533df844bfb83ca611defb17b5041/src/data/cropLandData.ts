export interface CropTypeInfo {
  key: string;
  emoji: string;
  nameEn: string;
  nameTe: string;
  nameTa: string;
  defaultVarieties: string[];
  color: string;
  borderColor: string;
  bgColor: string;
  typicalDurationDays: number;
  waterNeed: 'High' | 'Medium' | 'Low';
  waterNeedTe: string;
  waterNeedTa: string;
  soilRecommendation: string;
  soilRecommendationTe: string;
  soilRecommendationTa: string;
}

export const CROP_TYPES: CropTypeInfo[] = [
  {
    key: 'Paddy',
    emoji: '🌾',
    nameEn: 'Paddy (Rice)',
    nameTe: 'వరి (వరి ధాన్యం)',
    nameTa: 'நெல் (அரிசி)',
    defaultVarieties: ['CO 51', 'ADT 45', 'BPT 5204 (Samba)', 'MTU 1010', 'IR 20', 'CR 1009 Sub-1'],
    color: '#16a34a',
    borderColor: '#15803d',
    bgColor: '#dcfce7',
    typicalDurationDays: 120,
    waterNeed: 'High',
    waterNeedTe: 'ఎక్కువ (నిరంతర తేమ)',
    waterNeedTa: 'அதிகம் (தொடர் பாசனம்)',
    soilRecommendation: 'Clay Loam / Alluvial (మట్టి లోమ్)',
    soilRecommendationTe: 'బంకమట్టి లోమ్ / ఒండ్రు నేలలు',
    soilRecommendationTa: 'வண்டல் மண் / களிமண்',
  },
  {
    key: 'Cotton',
    emoji: '🌿',
    nameEn: 'Cotton (Kapas)',
    nameTe: 'పత్తి (దూది)',
    nameTa: 'பருத்தி',
    defaultVarieties: ['Bt Cotton RCH-659', 'Bunny Bt', 'Mallika BG-II', 'SVPR 2'],
    color: '#0284c7',
    borderColor: '#0369a1',
    bgColor: '#e0f2fe',
    typicalDurationDays: 160,
    waterNeed: 'Medium',
    waterNeedTe: 'మధ్యస్థం (డ్రిప్ లేదా చాల్)',
    waterNeedTa: 'மிதமானது (சொட்டு நீர் பாசனம்)',
    soilRecommendation: 'Deep Black Cotton Soil (నల్లరేగడి)',
    soilRecommendationTe: 'లోతైన నల్లరేగడి నేలలు',
    soilRecommendationTa: 'ஆழமான கரிசல் மண்',
  },
  {
    key: 'Groundnut',
    emoji: '🥜',
    nameEn: 'Groundnut (Peanut)',
    nameTe: 'వేరుశనగ (పల్లీ)',
    nameTa: 'நிலக்கடலை',
    defaultVarieties: ['VRI 8 (Spanish Bunch)', 'Kadiri 6 (K6)', 'TMV 14', 'Dharani', 'TAG 24'],
    color: '#d97706',
    borderColor: '#b45309',
    bgColor: '#fef3c7',
    typicalDurationDays: 105,
    waterNeed: 'Medium',
    waterNeedTe: 'మధ్యస్థం (పూత మరియు కాయ దశలో నీరు ముఖ్యం)',
    waterNeedTa: 'மிதமானது (பூக்கும் போது பாசனம்)',
    soilRecommendation: 'Red Sandy Loam (ఎర్ర ఇసుక నేల)',
    soilRecommendationTe: 'ఎర్ర ఇసుక లోమ్ నేలలు',
    soilRecommendationTa: 'செம்மண் / மணற்பாங்கான நிலம்',
  },
  {
    key: 'Maize',
    emoji: '🌽',
    nameEn: 'Maize (Corn)',
    nameTe: 'మొక్కజొన్న',
    nameTa: 'மக்காச்சோளம்',
    defaultVarieties: ['Kaveri 50 Hybrid', 'Pioneer 3396', 'DKC 9108', 'CoHM 6'],
    color: '#ca8a04',
    borderColor: '#a16207',
    bgColor: '#fef9c3',
    typicalDurationDays: 100,
    waterNeed: 'Medium',
    waterNeedTe: 'మధ్యస్థం (గజ్జ మరియు పూత దశలో నీరు ముఖ్యం)',
    waterNeedTa: 'மிதமானது (கதிர் உருவாகும் தருணம்)',
    soilRecommendation: 'Well-drained Sandy Loam (ఇసుక లోమ్)',
    soilRecommendationTe: 'మురుగునీటి సదుపాయం గల ఇసుక నేలలు',
    soilRecommendationTa: 'வடிகால் வசதியுள்ள மணல் கலந்த வண்டல்',
  },
  {
    key: 'Tomato',
    emoji: '🍅',
    nameEn: 'Tomato',
    nameTe: 'టమోటా',
    nameTa: 'தக்காளி',
    defaultVarieties: ['Shivam F1 Hybrid', 'Arka Rakshak', 'US 440', 'PKM 1'],
    color: '#dc2626',
    borderColor: '#b91c1c',
    bgColor: '#fee2e2',
    typicalDurationDays: 90,
    waterNeed: 'Medium',
    waterNeedTe: 'నియంత్రిత డ్రిప్ నీరు',
    waterNeedTa: 'சொட்டு நீர் பாசனம்',
    soilRecommendation: 'Rich Loam with high organic matter',
    soilRecommendationTe: 'సేంద్రియ ఎరువులు గల లోమ్ నేలలు',
    soilRecommendationTa: 'செழுமையான வண்டல் மண்',
  },
  {
    key: 'Chilli',
    emoji: '🌶️',
    nameEn: 'Chilli (Mirchi)',
    nameTe: 'మిరప (మిర్చి)',
    nameTa: 'மிளகாய்',
    defaultVarieties: ['G4 (Bhagirathi)', 'Teja', 'Byadagi', 'LCA 334', 'K1'],
    color: '#e11d48',
    borderColor: '#be123c',
    bgColor: '#ffe4e6',
    typicalDurationDays: 150,
    waterNeed: 'Medium',
    waterNeedTe: 'క్రమబద్ధమైన తేమ, నీరు నిలవరాదు',
    waterNeedTa: 'சீரான பாசனம், நீர் தேங்கக் கூடாது',
    soilRecommendation: 'Sandy Loam to Clay (ఇసుక నుండి మట్టి వరకు)',
    soilRecommendationTe: 'ఎర్ర ఇసుక లేదా నల్ల నేలలు',
    soilRecommendationTa: 'வடிகால் வசதியுள்ள செம்மண்',
  },
  {
    key: 'Sugarcane',
    emoji: '🎋',
    nameEn: 'Sugarcane',
    nameTe: 'చెరకు',
    nameTa: 'கரும்பு',
    defaultVarieties: ['Co 86032 (Nayana)', 'Co 0212', 'CoC 24', 'Co 99004'],
    color: '#059669',
    borderColor: '#047857',
    bgColor: '#d1fae5',
    typicalDurationDays: 360,
    waterNeed: 'High',
    waterNeedTe: 'చాలా ఎక్కువ (10-12 రోజులకోసారి)',
    waterNeedTa: 'மிக அதிகம் (தொடர் பாசனம்)',
    soilRecommendation: 'Deep Heavy Loam to Clay',
    soilRecommendationTe: 'లోతైన బంకమట్టి నేలలు',
    soilRecommendationTa: 'ஆழமான களிமண் நிலம்',
  },
  {
    key: 'Pulses',
    emoji: '🫘',
    nameEn: 'Black Gram / Green Gram (Pulses)',
    nameTe: 'మినుములు / పెసలు (పప్పు ధాన్యాలు)',
    nameTa: 'உளுந்து / பாசிப்பயறு',
    defaultVarieties: ['VBN 8', 'ADT 5', 'PU 31', 'IPM 205-7 (Virat)'],
    color: '#7c3aed',
    borderColor: '#6d28d9',
    bgColor: '#ede9fe',
    typicalDurationDays: 75,
    waterNeed: 'Low',
    waterNeedTe: 'తక్కువ (అవశేష తేమతో సాగు)',
    waterNeedTa: 'குறைவு (நெல் தரிசில் குறைந்த நீர்)',
    soilRecommendation: 'Clay Loam with residual moisture',
    soilRecommendationTe: 'వరి కోత తర్వాతి అవశేష తేమ నేలలు',
    soilRecommendationTa: 'நெல் தரிசு நிலங்கள்',
  },
  {
    key: 'Banana',
    emoji: '🍌',
    nameEn: 'Banana',
    nameTe: 'అరటి',
    nameTa: 'வாழை',
    defaultVarieties: ['Grand Naine (G9)', 'Robusta', 'Poovan', 'Rasthali', 'Nendran'],
    color: '#65a30d',
    borderColor: '#4d7c0f',
    bgColor: '#ecfccb',
    typicalDurationDays: 330,
    waterNeed: 'High',
    waterNeedTe: 'ఎక్కువ (డ్రిప్ ఫెర్టిగేషన్)',
    waterNeedTa: 'அதிகம் (சொட்டு நீர் உரப்பாசனம்)',
    soilRecommendation: 'Deep fertile alluvial soil',
    soilRecommendationTe: 'లోతైన సారవంతమైన ఒండ్రు నేలలు',
    soilRecommendationTa: 'வளம் மிகுந்த ஆற்றுப்படுகை மண்',
  },
];

/**
 * Resolve crop metadata from any variety string or crop name
 */
export function getCropInfo(cropOrVarietyString?: string): CropTypeInfo {
  if (!cropOrVarietyString) return CROP_TYPES[0];
  const lower = cropOrVarietyString.toLowerCase();

  if (lower.includes('paddy') || lower.includes('rice') || lower.includes('நெல்') || lower.includes('వరి') || lower.includes('co 51') || lower.includes('adt') || lower.includes('bpt') || lower.includes('ir 20') || lower.includes('cr 1009')) {
    return CROP_TYPES[0];
  }
  if (lower.includes('cotton') || lower.includes('kapas') || lower.includes('பருத்தி') || lower.includes('పత్తి') || lower.includes('bt')) {
    return CROP_TYPES[1];
  }
  if (lower.includes('groundnut') || lower.includes('peanut') || lower.includes('நிலக்கடலை') || lower.includes('వేరుశనగ') || lower.includes('vri') || lower.includes('kadiri') || lower.includes('tmv')) {
    return CROP_TYPES[2];
  }
  if (lower.includes('maize') || lower.includes('corn') || lower.includes('மக்காச்சோளம்') || lower.includes('మొక్కజొన్న') || lower.includes('kaveri')) {
    return CROP_TYPES[3];
  }
  if (lower.includes('tomato') || lower.includes('தக்காளி') || lower.includes('టమోటా') || lower.includes('shivam')) {
    return CROP_TYPES[4];
  }
  if (lower.includes('chilli') || lower.includes('mirchi') || lower.includes('மிளகாய்') || lower.includes('మిరప')) {
    return CROP_TYPES[5];
  }
  if (lower.includes('sugar') || lower.includes('cane') || lower.includes('கரும்பு') || lower.includes('చెరకు')) {
    return CROP_TYPES[6];
  }
  if (lower.includes('gram') || lower.includes('pulse') || lower.includes('உளுந்து') || lower.includes('మినుములు')) {
    return CROP_TYPES[7];
  }
  if (lower.includes('banana') || lower.includes('வாழை') || lower.includes('అరటి')) {
    return CROP_TYPES[8];
  }

  // Fallback
  return CROP_TYPES[0];
}

/**
 * Calculate days since sowing and age formatted
 */
export function calculateDaysSinceSowing(sowingDateStr?: string): { days: number; text: string; textTe: string; textTa: string } {
  if (!sowingDateStr) {
    return { days: 45, text: 'approx. 45 days', textTe: 'సుమారు 45 రోజులు', textTa: 'சுமார் 45 நாட்கள்' };
  }
  const sowingDate = new Date(sowingDateStr);
  const now = new Date();
  const diffTime = Math.max(0, now.getTime() - sowingDate.getTime());
  const days = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return {
    days,
    text: `${days} days ago`,
    textTe: `${days} రోజుల క్రితం విత్తారు`,
    textTa: `${days} நாட்களுக்கு முன் விதைக்கப்பட்டது`,
  };
}

/**
 * Generate synthetic realistic 4-corner polygon around a center lat/lng for a given acreage
 */
export function generateCadastralPolygon(lat: number, lng: number, acres: number) {
  // Approx 1 acre = 63.6m x 63.6m box
  const sideMeters = Math.sqrt(acres * 4046.86);
  const deltaLat = (sideMeters / 111320) / 2;
  const deltaLng = (sideMeters / (111320 * Math.cos((lat * Math.PI) / 180))) / 2;

  // Add slight organic parcel skew for realism
  return [
    { lat: lat + deltaLat * 1.05, lng: lng - deltaLng * 0.95 },
    { lat: lat + deltaLat * 0.98, lng: lng + deltaLng * 1.08 },
    { lat: lat - deltaLat * 1.02, lng: lng + deltaLng * 0.92 },
    { lat: lat - deltaLat * 0.96, lng: lng - deltaLng * 1.04 },
  ];
}
