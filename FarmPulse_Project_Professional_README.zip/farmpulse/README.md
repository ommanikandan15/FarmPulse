# 🌾 FarmPulse

### Explainable Crop Stress Advisory for Tamil Nadu Paddy Farmers

> **Don't just tell the farmer what. Tell them why.**

FarmPulse is a demo-ready agricultural advisory application designed to
help paddy farmers and agricultural teams understand possible crop
stress signals through transparent, explainable recommendations. It
brings plot information, sample vegetation and water indicators, weather
context, and farmer observations into one simple dashboard.

**Project status:** Prototype / demonstration\
**Primary focus:** Explainable crop-stress awareness and decision
support\
**Initial use case:** Paddy plots in Tamil Nadu, India

------------------------------------------------------------------------

## 📌 Table of Contents

-   [Problem](#-problem)
-   [Our Solution](#-our-solution)
-   [Key Features](#-key-features)
-   [How It Works](#-how-it-works)
-   [Technology Stack](#-technology-stack)
-   [Project Structure](#-project-structure)
-   [Getting Started](#-getting-started)
-   [API Documentation](#-api-documentation)
-   [Running Tests](#-running-tests)
-   [Demo Data and Limitations](#-demo-data-and-limitations)
-   [Roadmap](#-roadmap)
-   [Responsible Use](#-responsible-use)
-   [Contributing](#-contributing)
-   [License](#-license)

------------------------------------------------------------------------

## 🌱 Problem

Paddy farmers may notice changes in crop condition only after visible
symptoms appear. Weather changes, water stress, field variability, and
delayed access to expert guidance can make it difficult to decide which
plots need attention first.

Many digital tools also show indicators without explaining what those
values might mean. FarmPulse is designed around a different principle:
**every advisory should show the signal, the reason, the confidence or
limitation, and a sensible next step.**

## 💡 Our Solution

FarmPulse is a lightweight web prototype that demonstrates how
plot-level information and transparent rules can be turned into
understandable crop-stress advisories. The interface is designed with
accessibility and future multilingual use in mind, including Tamil and
English support as a product goal.

The prototype uses sample data and rule-based logic so that the workflow
can be explored without claiming to provide a verified diagnosis of a
real field.

## ✨ Key Features

-   **Plot dashboard** --- view sample paddy plots and their current
    demo status.
-   **Explainable advisories** --- see which input signals triggered a
    recommendation and why.
-   **Water and vegetation indicators** --- demonstrate how indicators
    such as NDVI and NDWI could contribute to crop monitoring when
    reliable data sources are connected.
-   **Weather context** --- show how weather-related signals can support
    field observations.
-   **Farmer observations** --- provide a place in the workflow for
    farmer-reported symptoms and field notes.
-   **API-first backend** --- FastAPI endpoints support the dashboard
    and future integrations.
-   **Demo-ready interface** --- explore the concept locally without
    requiring external API keys.
-   **Future-ready design** --- documentation outlines possible
    integrations for satellite data, sensors, validated models, and
    supply-chain planning.

## 🔍 How It Works

1.  **Collect inputs:** plot details, weather context, sample
    vegetation/water indicators, and farmer observations.
2.  **Evaluate signals:** transparent rules assess the available demo
    inputs.
3.  **Explain the result:** the app presents the relevant signals and
    the reasoning behind the advisory.
4.  **Suggest a next step:** the advisory is intended to guide
    observation or consultation, not replace expert agronomic judgment.
5.  **Improve with validation:** future versions can be evaluated with
    field data and agricultural experts before real-world deployment.

## 🧰 Technology Stack

  Layer              Technology
  ------------------ --------------------------------
  Backend API        Python, FastAPI
  Frontend           HTML, CSS, JavaScript
  Data exchange      JSON
  Testing            pytest
  Local deployment   Uvicorn; optional Docker setup

## 📁 Project Structure

``` text
farmpulse/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application and API routes
│   └── static/
│       ├── index.html          # Dashboard interface
│       ├── style.css           # Responsive styling
│       └── app.js              # Frontend interactions
├── data/
│   └── demo_plots.json         # Sample plot data
├── docs/
│   ├── ARCHITECTURE.md         # System design overview
│   ├── DEMO_SCRIPT.md          # Suggested presentation flow
│   ├── MODEL_CARD.md           # Model and limitation notes
│   └── GOOGLE_AI_STUDIO_PROMPT.md
├── tests/
│   └── test_advisory.py        # Automated tests
├── .gitignore
├── Dockerfile
├── requirements.txt
└── README.md
```

## 🚀 Getting Started

### Prerequisites

-   Python 3.10 or newer (Python 3.11+ recommended)
-   `pip`
-   Git (optional, for version control)

### 1. Download or clone the repository

If you have already created the repository on GitHub, clone it:

``` bash
git clone https://github.com/<your-username>/FarmPulse.git
cd FarmPulse
```

Replace `<your-username>` with your GitHub username. If you downloaded
the project ZIP instead, extract it and open a terminal inside the
`farmpulse` folder.

### 2. Create a virtual environment

**Windows (PowerShell):**

``` powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**

``` bat
python -m venv .venv
.venv\Scripts\activate.bat
```

**macOS / Linux:**

``` bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

``` bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Start the application

Run this command from the project root (`farmpulse/`):

``` bash
uvicorn app.main:app --reload
```

Open the dashboard at:

-   **Web app:** http://127.0.0.1:8000
-   **Interactive API docs:** http://127.0.0.1:8000/docs
-   **OpenAPI schema:** http://127.0.0.1:8000/openapi.json

To stop the local server, press `Ctrl+C` in the terminal.

## 🔌 API Documentation

The backend exposes FastAPI routes for the prototype dashboard and
advisory workflow. Start the application and visit `/docs` to inspect
the endpoints and try requests interactively.

The API contract may evolve as the prototype develops. Treat all
responses based on included demo records as demonstration outputs, not
live field assessments.

## 🧪 Running Tests

From the project root, with the virtual environment activated:

``` bash
pytest -q
```

Tests help check the existing rule-based advisory behaviour. Passing
tests do **not** establish agronomic accuracy or suitability for
real-world decisions.

## 🧭 Demo Data and Limitations

This repository is a **prototype**, not a production agricultural
diagnosis system.

-   The included plot records are sample/demo data.
-   Live satellite imagery and current satellite-derived NDVI/NDWI are
    not connected by default.
-   Live weather feeds and real sensor streams are not connected by
    default.
-   No trained or independently validated crop-disease model is
    included.
-   Leaf-photo workflows must not be treated as confirmed disease
    identification.
-   Advisories are generated using transparent prototype rules and may
    not reflect the conditions of a real field.
-   Do not use demo outputs as the sole basis for irrigation,
    fertilizer, pesticide, or other crop-management decisions.

Before field deployment, the project needs reliable data integrations,
agronomist review, field validation across locations and seasons,
security and privacy review, and clear user-facing uncertainty
information.

## 🗺️ Roadmap

-   [ ] Add validated, documented weather-data integration.
-   [ ] Connect reliable satellite data and explain index quality, date,
    and resolution.
-   [ ] Add optional soil-moisture sensor integration with calibration
    and failure handling.
-   [ ] Improve Tamil and English language support, including accessible
    voice guidance.
-   [ ] Validate advisory rules with agricultural experts and field
    observations.
-   [ ] Evaluate any future ML or image model on representative,
    consented datasets.
-   [ ] Add plot history, downloadable reports, and responsible
    data-export controls.
-   [ ] Explore village-level aggregation for FPO and supply-chain
    planning while protecting farmer privacy.
-   [ ] Add deployment monitoring, error handling, and security
    hardening.

## 🛡️ Responsible Use

FarmPulse is intended to support observation and discussion---not
replace a qualified agricultural officer or agronomist. Confirm
important findings in the field and consult local agricultural experts
before taking consequential action. Any future data collection should be
transparent, consent-based, and limited to what is needed.

## 🤝 Contributing

Contributions are welcome, especially around usability, accessibility,
testing, documentation, reliable data integrations, and validation.

1.  Fork the repository.
2.  Create a branch: `git checkout -b feature/your-feature`.
3.  Make focused changes and add or update tests.
4.  Run `pytest -q`.
5.  Commit your changes and open a pull request describing the change
    and its limitations.

Please do not commit API keys, passwords, private farmer information, or
other secrets. Use environment variables for credentials when
integrations are added.

## 📄 License

No license has been selected yet. Unless a license is added to the
repository, the code is not automatically granted an open-source
license. Choose and add an appropriate license before inviting reuse or
redistribution.

------------------------------------------------------------------------

## 👩‍🌾 Project Vision

FarmPulse aims to make agricultural technology more understandable,
actionable, and farmer-centred. By pairing useful signals with clear
explanations and honest limitations, the project explores a path toward
more accessible crop monitoring and decision support.

**FarmPulse --- Don't just tell the farmer what. Tell them why.**
