import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Plot } from '../../types';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow 
} from '@vis.gl/react-google-maps';
import { 
  Search, 
  MapPin, 
  Locate, 
  Navigation, 
  Layers, 
  Maximize2, 
  Minimize2, 
  Sprout, 
  Droplets, 
  Thermometer, 
  ShieldAlert, 
  ArrowRight, 
  CheckCircle2, 
  Compass,
  FileText,
  Eye,
  Info,
  Plus,
  Calendar,
  Ruler,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  Trash2,
  Tag
} from 'lucide-react';
import { MarkLandModal } from './MarkLandModal';
import { getCropInfo, calculateDaysSinceSowing, CROP_TYPES } from '../../data/cropLandData';

export interface KnownPlace {
  id: string;
  name: string;
  nameTa: string;
  nameTe: string;
  taluk: string;
  district: string;
  state: string;
  agroZone: string;
  lat: number;
  lng: number;
  zoom: number;
  soilSeries: string;
  kvkCenter: string;
}

export const REGIONAL_FARM_HUBS: KnownPlace[] = [
  {
    id: 'kaveripakkam',
    name: 'Kaveripakkam',
    nameTa: 'காவேரிப்பாக்கம்',
    nameTe: 'కావేరిపాక్కం',
    taluk: 'Nemili',
    district: 'Ranipet',
    state: 'Tamil Nadu',
    agroZone: 'North Eastern Zone (Palar Sub-basin)',
    lat: 12.8982,
    lng: 79.4674,
    zoom: 15,
    soilSeries: 'Kaveripakkam Fine Clay Loam',
    kvkCenter: 'KVK Virinjipuram (Vellore/Ranipet)',
  },
  {
    id: 'guntur',
    name: 'Guntur Rural (Mirchi & Cotton)',
    nameTa: 'குண்டூர் பகுதி',
    nameTe: 'గుంటూరు గ్రామీణ (మిర్చి, పత్తి బెల్ట్)',
    taluk: 'Guntur Rural',
    district: 'Guntur',
    state: 'Andhra Pradesh',
    agroZone: 'Krishna Agro-Climatic Zone (Black Soils)',
    lat: 16.3067,
    lng: 80.4365,
    zoom: 14,
    soilSeries: 'Guntur Deep Black Cotton Clay',
    kvkCenter: 'KVK Lam / ANGRAU Regional Station',
  },
  {
    id: 'warangal',
    name: 'Warangal Delta & Cotton Hub',
    nameTa: 'வாரங்கல் பருத்தி பகுதி',
    nameTe: 'వరంగల్ కాటన్ & మొక్కజొన్న క్లస్టర్',
    taluk: 'Warangal Rural',
    district: 'Warangal',
    state: 'Telangana',
    agroZone: 'Central Telangana Zone (Godavari Basin)',
    lat: 17.9689,
    lng: 79.5941,
    zoom: 14,
    soilSeries: 'Warangal Red Sandy Loam & Chalkas',
    kvkCenter: 'KVK Malyal / PJTSAU Research Station',
  },
  {
    id: 'kurnool',
    name: 'Kurnool Groundnut Belt',
    nameTa: 'கர்னூல் நிலக்கடலை பகுதி',
    nameTe: 'కర్నూలు వేరుశనగ క్లస్టర్',
    taluk: 'Dhone / Kurnool',
    district: 'Kurnool',
    state: 'Andhra Pradesh',
    agroZone: 'Scarce Rainfall Zone (Rayalaseema)',
    lat: 15.8281,
    lng: 78.0373,
    zoom: 14,
    soilSeries: 'Rayalaseema Red Gravelly Loam',
    kvkCenter: 'KVK Yagantipalle (Kurnool)',
  },
  {
    id: 'thanjavur',
    name: 'Thanjavur Delta (Rice Bowl)',
    nameTa: 'தஞ்சாவூர் டெல்டா',
    nameTe: 'తంజావూరు కావేరి డెల్టా (వరి క్షేత్రం)',
    taluk: 'Thanjavur',
    district: 'Thanjavur',
    state: 'Tamil Nadu',
    agroZone: 'Cauvery Delta Zone (CDZ)',
    lat: 10.7870,
    lng: 79.1378,
    zoom: 14,
    soilSeries: 'Adanur Deep Alluvial Clay',
    kvkCenter: 'TRRI Aduthurai / KVK Sikkal',
  },
  {
    id: 'thiruvalam',
    name: 'Thiruvalam Ponnai Confluence',
    nameTa: 'திருவலம்',
    nameTe: 'తిరువలం పొన్నై సంగమం',
    taluk: 'Katpadi',
    district: 'Vellore',
    state: 'Tamil Nadu',
    agroZone: 'North Eastern Zone (Ponnai River)',
    lat: 12.9814,
    lng: 79.2392,
    zoom: 15,
    soilSeries: 'Ponnai Alluvial Sandy Loam',
    kvkCenter: 'KVK Virinjipuram',
  },
];

interface FieldPlaceMapViewProps {
  onSelectPlotDetail?: (plot: Plot) => void;
}

export const FieldPlaceMapView: React.FC<FieldPlaceMapViewProps> = ({ onSelectPlotDetail }) => {
  const { plots, selectedPlotId, setSelectedPlotId, setActiveTab, language, deletePlot } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeCenter, setActiveCenter] = useState({ lat: 12.8982, lng: 79.4674 });
  const [activeZoom, setActiveZoom] = useState(14);
  const [selectedPlaceInfo, setSelectedPlaceInfo] = useState<KnownPlace>(REGIONAL_FARM_HUBS[0]);
  const [mapEngine, setMapEngine] = useState<'cadastral_canvas' | 'google_maps'>('cadastral_canvas');
  const [googleMapType, setGoogleMapType] = useState<'hybrid' | 'satellite' | 'roadmap'>('hybrid');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMarkLandOpen, setIsMarkLandOpen] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Cadastral Canvas Interactive State (Pan & Zoom)
  const [canvasZoom, setCanvasZoom] = useState(1.15);
  const [canvasPan, setCanvasPan] = useState({ x: 0, y: 0 });
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });

  const activePlot = useMemo(() => {
    return plots.find((p) => p.id === selectedPlotId) || plots[0] || null;
  }, [plots, selectedPlotId]);

  const activeCropInfo = useMemo(() => {
    return activePlot ? getCropInfo(activePlot.variety || activePlot.cropType) : CROP_TYPES[0];
  }, [activePlot]);

  const activeSowingAge = useMemo(() => {
    return calculateDaysSinceSowing(activePlot?.sowingDate);
  }, [activePlot]);

  const apiKey = (import.meta as unknown as { env: Record<string, string> }).env?.VITE_GOOGLE_MAPS_API_KEY || 
                 'AIzaSyAG2GcmSByW4dTJeWukaabUChbBAhaQFEk';

  // Quick place switch
  const handleSelectPlace = (place: KnownPlace) => {
    setSelectedPlaceInfo(place);
    setActiveCenter({ lat: place.lat, lng: place.lng });
    setActiveZoom(place.zoom);
    const placeName = language === 'te' ? place.nameTe : language === 'ta' ? place.nameTa : place.name;
    setSearchQuery(placeName);
  };

  // Search filter
  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchQuery.toLowerCase().trim();
    if (!query) return;

    const matched = REGIONAL_FARM_HUBS.find(
      (p) => 
        p.name.toLowerCase().includes(query) ||
        p.nameTa.toLowerCase().includes(query) ||
        p.nameTe.toLowerCase().includes(query) ||
        p.district.toLowerCase().includes(query) ||
        p.state.toLowerCase().includes(query)
    );

    if (matched) {
      handleSelectPlace(matched);
    } else {
      // Parse coordinates if provided
      const coordMatch = query.match(/^(-?\d+(\.\d+)?),\s*(-?\d+(\.\d+)?)$/);
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1]);
        const lng = parseFloat(coordMatch[3]);
        setActiveCenter({ lat, lng });
        setActiveZoom(15);
      }
    }
  };

  // GPS Geolocation
  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return;
    }

    setGpsLoading(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setActiveCenter({ lat, lng });
        setActiveZoom(16);

        let closest = REGIONAL_FARM_HUBS[0];
        let minDist = 999999;
        REGIONAL_FARM_HUBS.forEach((p) => {
          const d = Math.hypot(p.lat - lat, p.lng - lng);
          if (d < minDist) {
            minDist = d;
            closest = p;
          }
        });
        setSelectedPlaceInfo({
          ...closest,
          name: 'My GPS Farm Coordinates',
          nameTa: 'எனது ஜிபிஎஸ் இருப்பிடம்',
          nameTe: 'నా ప్రస్తుత జీపీఎస్ లొకేషన్',
          lat,
          lng,
        });
      },
      (err) => {
        setGpsLoading(false);
        setGpsError(err.message || 'Unable to retrieve your location.');
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  // Center on a plot
  const handleFocusPlot = (plot: Plot) => {
    setSelectedPlotId(plot.id);
    setActiveCenter(plot.coordinates);
    setActiveZoom(16);
  };

  // Cadastral Canvas Mouse/Touch handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX - canvasPan.x, y: e.clientY - canvasPan.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    setCanvasPan({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y,
    });
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Relative SVG mapping coordinates for Cadastral Canvas
  const plotPositions = useMemo(() => {
    // Generate organic relative SVG coordinates (in a 900x600 viewBox)
    return plots.map((p, idx) => {
      const crop = getCropInfo(p.variety || p.cropType);
      // Pre-assigned positions on the farm map canvas
      const baseCoords = [
        { x: 180, y: 160, width: 220, height: 160, skew: 'polygon(0% 0%, 100% 5%, 95% 100%, 8% 92%)' },
        { x: 440, y: 140, width: 200, height: 170, skew: 'polygon(5% 0%, 98% 3%, 92% 98%, 0% 95%)' },
        { x: 150, y: 350, width: 260, height: 180, skew: 'polygon(2% 2%, 96% 0%, 100% 95%, 5% 100%)' },
        { x: 670, y: 180, width: 170, height: 160, skew: 'polygon(0% 8%, 100% 0%, 96% 96%, 3% 90%)' },
        { x: 450, y: 340, width: 240, height: 190, skew: 'polygon(4% 0%, 100% 6%, 94% 96%, 0% 92%)' },
        { x: 710, y: 360, width: 150, height: 170, skew: 'polygon(0% 2%, 98% 0%, 90% 98%, 4% 94%)' },
      ];
      const layout = baseCoords[idx % baseCoords.length];
      return {
        plot: p,
        crop,
        x: layout.x,
        y: layout.y,
        width: layout.width,
        height: layout.height,
        skew: layout.skew,
      };
    });
  }, [plots]);

  return (
    <div className={`space-y-4 pb-12 ${isFullscreen ? 'fixed inset-0 z-50 bg-[#F7F8F4] p-4 flex flex-col overflow-y-auto' : ''}`}>
      {/* Top Banner: Farm Pulse Land & Crop Mapping */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#173F35] to-[#2E6B56] text-white flex items-center justify-center shadow-xs">
              <Compass className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
                  {language === 'te' 
                    ? 'రైతు భూమి మ్యాప్ & పంట వివరాలు'
                    : language === 'ta'
                    ? 'புல வரைபடம் & பயிர் அறிதல்'
                    : 'Field Land Map & Planted Crops'}
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  {language === 'te' ? 'క్యాడస్ట్రల్ సరిహద్దులు' : language === 'ta' ? 'புல எல்லைகள்' : 'Cadastral Boundaries'}
                </span>
              </div>
              <p className="text-xs text-[#566761] mt-0.5">
                {language === 'te'
                  ? 'మీ భూమిని గుర్తించండి, ఏ మడిలో ఏ పంట నాటారో సులభంగా తెలుసుకోండి • కాలువ నీరు & నేల తేమ పర్యవేక్షణ'
                  : language === 'ta'
                  ? 'உங்கள் நிலத்தை வரைபடத்தில் குறித்து எந்த நிலத்தில் என்ன பயிர் உள்ளது என்பதை எளிதாக அறியவும்'
                  : 'Mark your land boundaries and easily inspect what crop is planted in each parcel with live moisture & stress status.'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls: Mark My Land + View Switcher */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsMarkLandOpen(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-[#173F35] to-[#255e50] hover:from-[#255e50] hover:to-[#173F35] text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-1.5 shadow-md transition-all hover:scale-[1.02] active:scale-98"
          >
            <Plus className="w-4 h-4 text-emerald-300" />
            <span>
              {language === 'te' ? '+ నా పొలం గుర్తించండి' : language === 'ta' ? '+ என் நிலத்தைக் குறிக்கவும்' : '+ Mark My Land'}
            </span>
          </button>

          {/* Map Engine Toggle */}
          <div className="flex items-center rounded-xl border border-[#CCD6C6] p-0.5 bg-[#F7F8F4] text-xs font-bold">
            <button
              onClick={() => setMapEngine('cadastral_canvas')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                mapEngine === 'cadastral_canvas' 
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]' 
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
              title="Aerial Cadastral Layout (Offline Ready)"
            >
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'te' ? 'క్యాడస్ట్రల్ వ్యూ' : language === 'ta' ? 'புல வரைபடம்' : 'Cadastral View'}</span>
            </button>
            <button
              onClick={() => setMapEngine('google_maps')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                mapEngine === 'google_maps' 
                  ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]' 
                  : 'text-[#566761] hover:text-[#173F35]'
              }`}
              title="Google Satellite / Hybrid Map"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-600" />
              <span>{language === 'te' ? 'గూగుల్ శాటిలైట్' : language === 'ta' ? 'கூகிள் செயற்கைக்கோள்' : 'Google Satellite'}</span>
            </button>
          </div>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 text-xs font-semibold rounded-xl border border-[#CCD6C6] bg-[#F7F8F4] text-[#173F35] hover:bg-gray-100 transition-all"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Quick Land Switcher Carousel: Farmer's Marked Parcels */}
      <div className="bg-white p-3.5 rounded-2xl border border-[#E3E8DC] shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#173F35] flex items-center gap-1.5">
            <Sprout className="w-4 h-4 text-emerald-600" />
            <span>
              {language === 'te' 
                ? 'గుర్తించబడిన మీ పొలాలు (ఈ నేలలో ఏమి నాటారు):' 
                : language === 'ta'
                ? 'உங்கள் நிலங்கள் (என்ன பயிர் பயிரிடப்பட்டுள்ளது):'
                : 'Your Marked Lands (What is Planted in Each Parcel):'}
            </span>
          </span>
          <span className="text-[11px] font-bold text-gray-500">
            {plots.length} {language === 'te' ? 'పొలాలు రికార్డయ్యాయి' : language === 'ta' ? 'நிலங்கள் பதிவு' : 'Parcels Recorded'}
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {plots.map((plot) => {
            const crop = getCropInfo(plot.variety || plot.cropType);
            const isSelected = activePlot?.id === plot.id;
            return (
              <button
                key={plot.id}
                onClick={() => handleFocusPlot(plot)}
                className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shrink-0 border transition-all ${
                  isSelected
                    ? 'bg-[#173F35] text-white border-[#173F35] shadow-sm scale-102'
                    : 'bg-[#FAFAF8] text-[#173F35] border-[#E3E8DC] hover:border-emerald-300 hover:bg-emerald-50/40'
                }`}
              >
                <span className="text-base">{crop.emoji}</span>
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold">
                      {language === 'te' && plot.nameTe ? plot.nameTe : language === 'ta' && plot.nameTa ? plot.nameTa : plot.name}
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {plot.areaAcres} ac
                    </span>
                  </div>
                  <div className={`text-[10px] ${isSelected ? 'text-emerald-200' : 'text-[#566761]'}`}>
                    {language === 'te' ? crop.nameTe : language === 'ta' ? crop.nameTa : crop.nameEn}
                    {plot.surveyNumber ? ` • ${plot.surveyNumber}` : ''}
                  </div>
                </div>
              </button>
            );
          })}

          <button
            onClick={() => setIsMarkLandOpen(true)}
            className="px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 border border-dashed border-emerald-400 bg-emerald-50/60 hover:bg-emerald-100/70 text-emerald-800 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'te' ? 'కొత్త పొలం మార్క్ చేయండి' : language === 'ta' ? 'புதிய நிலத்தைக் குறிக்க' : 'Mark New Land'}</span>
          </button>
        </div>
      </div>

      {/* Place Search Bar & Regional Hubs */}
      <div className="bg-white p-3.5 rounded-2xl border border-[#E3E8DC] shadow-xs space-y-2.5">
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#566761] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                language === 'te'
                  ? 'గ్రామం లేదా వ్యవసాయ జోన్ వెతకండి (ఉదా: గుంటూరు, కావేరిపాక్కం, వరంగల్, కర్నూలు, లేదా 12.898, 79.467)...'
                  : language === 'ta'
                  ? 'இடத்தைத் தேடுக (எ.கா: காவேரிப்பாக்கம், தஞ்சாவூர், திருவலம், அல்லது 12.898, 79.467)...'
                  : 'Search village, mandi zone, or GPS coordinates (e.g. Kaveripakkam, Guntur, Warangal, Kurnool)...'
              }
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-[#CCD6C6] focus:outline-hidden focus:ring-2 focus:ring-[#2D8A4E] bg-[#FAFAF8]"
            />
          </div>

          <button
            type="submit"
            className="px-4 py-2.5 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-all shrink-0"
          >
            {language === 'te' ? 'వెతకండి' : language === 'ta' ? 'தேடுக' : 'Find Place'}
          </button>

          <button
            type="button"
            onClick={handleLocateMe}
            disabled={gpsLoading}
            className="px-3 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-[#173F35] border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all shrink-0 disabled:opacity-50"
            title="Locate my GPS coordinates"
          >
            <Locate className={`w-4 h-4 text-emerald-700 ${gpsLoading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">
              {language === 'te' ? 'నా జీపీఎస్ స్థానం' : language === 'ta' ? 'என் இருப்பிடம்' : 'Locate My Place'}
            </span>
          </button>
        </form>

        {gpsError && (
          <p className="text-xs text-rose-600 bg-rose-50 p-2 rounded-lg border border-rose-200">
            {gpsError}
          </p>
        )}

        {/* Quick Regional Hub Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
          <span className="text-[11px] font-bold text-[#566761] mr-1 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            {language === 'te' ? 'ప్రముఖ వ్యవసాయ కేంద్రాలు:' : language === 'ta' ? 'முக்கிய இடங்கள்:' : 'Agri Hubs:'}
          </span>
          {REGIONAL_FARM_HUBS.map((p) => (
            <button
              key={p.id}
              onClick={() => handleSelectPlace(p)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                selectedPlaceInfo.id === p.id
                  ? 'bg-[#173F35] text-white border-[#173F35] shadow-xs'
                  : 'bg-[#F7F8F4] text-[#173F35] border-[#E3E8DC] hover:border-emerald-400'
              }`}
            >
              {language === 'te' ? p.nameTe : language === 'ta' ? p.nameTa : p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Visual Map View + Planted Crop Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Map Column (2 Cols) */}
        <div className="lg:col-span-2 bg-[#1b3d33] rounded-2xl border border-[#CCD6C6] overflow-hidden shadow-md relative min-h-[500px] h-[580px] flex flex-col">
          {/* Map Controls Floating Toolbar */}
          <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
            {mapEngine === 'cadastral_canvas' && (
              <div className="bg-white/95 backdrop-blur-xs p-1.5 rounded-xl border border-[#CCD6C6] shadow-md flex flex-col gap-1 text-[#173F35]">
                <button
                  onClick={() => setCanvasZoom((z) => Math.min(2.0, z + 0.15))}
                  className="p-1.5 rounded-lg hover:bg-gray-100 transition-all"
                  title="Zoom In"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setCanvasZoom((z) => Math.max(0.7, z - 0.15))}
                  className="p-1.5 rounded-lg hover:bg-gray-100 transition-all"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    setCanvasZoom(1.15);
                    setCanvasPan({ x: 0, y: 0 });
                  }}
                  className="p-1.5 rounded-lg hover:bg-gray-100 transition-all"
                  title="Reset View"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            )}

            {mapEngine === 'google_maps' && (
              <div className="bg-white/95 backdrop-blur-xs p-1 rounded-xl border border-[#CCD6C6] shadow-md flex items-center text-xs font-bold">
                <button
                  onClick={() => setGoogleMapType('hybrid')}
                  className={`px-2 py-1 rounded-lg ${googleMapType === 'hybrid' ? 'bg-[#173F35] text-white' : 'text-gray-700'}`}
                >
                  Hybrid
                </button>
                <button
                  onClick={() => setGoogleMapType('satellite')}
                  className={`px-2 py-1 rounded-lg ${googleMapType === 'satellite' ? 'bg-[#173F35] text-white' : 'text-gray-700'}`}
                >
                  Sat
                </button>
                <button
                  onClick={() => setGoogleMapType('roadmap')}
                  className={`px-2 py-1 rounded-lg ${googleMapType === 'roadmap' ? 'bg-[#173F35] text-white' : 'text-gray-700'}`}
                >
                  Road
                </button>
              </div>
            )}
          </div>

          {/* Floating Location Badge */}
          <div className="absolute top-4 left-4 z-20 bg-white/95 backdrop-blur-xs rounded-xl p-3 border border-[#CCD6C6] shadow-md text-xs space-y-1 max-w-xs pointer-events-auto">
            <div className="flex items-center gap-1.5 text-emerald-900 font-extrabold">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">
                {language === 'te' ? selectedPlaceInfo.nameTe : language === 'ta' ? selectedPlaceInfo.nameTa : selectedPlaceInfo.name}
              </span>
            </div>
            <p className="text-[11px] text-[#566761]">
              {selectedPlaceInfo.district}, {selectedPlaceInfo.state}
            </p>
            <p className="text-[10px] text-gray-500 font-mono">
              GPS: {activeCenter.lat.toFixed(4)}, {activeCenter.lng.toFixed(4)}
            </p>
          </div>

          {/* ENGINE 1: Interactive Cadastral Aerial Canvas (Always Works & Shows Exact Parcels & Crops) */}
          {mapEngine === 'cadastral_canvas' && (
            <div 
              className="w-full h-full relative cursor-grab active:cursor-grabbing select-none overflow-hidden bg-[#1f3f35]"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {/* Aerial Field Textured Background Grid */}
              <div 
                className="w-full h-full transition-transform duration-75 origin-center"
                style={{
                  transform: `translate(${canvasPan.x}px, ${canvasPan.y}px) scale(${canvasZoom})`,
                }}
              >
                <svg className="w-full h-full min-w-[950px] min-h-[600px]" viewBox="0 0 950 600">
                  <defs>
                    {/* Farmland grass & soil textures */}
                    <pattern id="farmland-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
                      <rect width="40" height="40" fill="#204b3e" />
                      <path d="M 0 20 L 40 20 M 20 0 L 20 40" stroke="#255546" strokeWidth="1" />
                      <circle cx="10" cy="10" r="1" fill="#2d6453" />
                      <circle cx="30" cy="30" r="1" fill="#2d6453" />
                    </pattern>

                    {/* Irrigation canal texture */}
                    <pattern id="canal-flow" width="20" height="20" patternUnits="userSpaceOnUse">
                      <rect width="20" height="20" fill="#1e3a5f" />
                      <path d="M 0 10 Q 5 5 10 10 T 20 10" stroke="#38bdf8" strokeWidth="1.5" fill="none" opacity="0.6" />
                    </pattern>
                  </defs>

                  {/* Base Landscape */}
                  <rect width="950" height="600" fill="url(#farmland-pattern)" />

                  {/* Main Irrigation Canal Distributary */}
                  <path
                    d="M 50 300 Q 300 280 480 320 T 900 290"
                    stroke="#0284c7"
                    strokeWidth="14"
                    fill="none"
                    strokeLinecap="round"
                    opacity="0.85"
                  />
                  <path
                    d="M 50 300 Q 300 280 480 320 T 900 290"
                    stroke="#38bdf8"
                    strokeWidth="4"
                    fill="none"
                    strokeDasharray="8 6"
                  />
                  <text x="320" y="275" fill="#7dd3fc" fontSize="11" fontWeight="bold" letterSpacing="1">
                    〰 {language === 'te' ? 'పాలార్ ప్రధాన సాగునీటి కాలువ' : language === 'ta' ? 'பாலாறு பாசன வாய்க்கால்' : 'Palar Irrigation Feeder Canal'}
                  </text>

                  {/* Village Rural Road */}
                  <path
                    d="M 120 40 Q 250 250 420 560"
                    stroke="#d4b483"
                    strokeWidth="8"
                    fill="none"
                    strokeLinecap="round"
                    opacity="0.7"
                  />

                  {/* North Village Pond */}
                  <ellipse cx="800" cy="90" rx="60" ry="35" fill="#0369a1" stroke="#38bdf8" strokeWidth="2" opacity="0.8" />
                  <text x="765" y="94" fill="#e0f2fe" fontSize="10" fontWeight="bold">
                    {language === 'te' ? 'గ్రామ చెరువు' : language === 'ta' ? 'ஊர் குளம்' : 'Village Tank'}
                  </text>

                  {/* Village Temple / KVK Grove */}
                  <rect x="70" y="70" width="45" height="40" rx="6" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
                  <text x="78" y="94" fill="#334155" fontSize="9" fontWeight="bold">
                    KVK
                  </text>

                  {/* Render Each Farmer's Land Parcel (Polygon & Crop Details) */}
                  {plotPositions.map(({ plot, crop, x, y, width, height }) => {
                    const isSelected = activePlot?.id === plot.id;
                    const strokeColor = isSelected ? '#ffffff' : crop.borderColor;
                    const fillColor = isSelected ? `${crop.color}dd` : `${crop.color}99`;

                    return (
                      <g
                        key={plot.id}
                        onClick={() => handleFocusPlot(plot)}
                        className="cursor-pointer transition-all duration-200 group"
                      >
                        {/* Land Boundary Parcel Polygon */}
                        <rect
                          x={x}
                          y={y}
                          width={width}
                          height={height}
                          rx="14"
                          fill={fillColor}
                          stroke={strokeColor}
                          strokeWidth={isSelected ? 4 : 2.5}
                          strokeDasharray={isSelected ? 'none' : '4 2'}
                          className="transition-all hover:filter hover:brightness-110"
                        />

                        {/* Four Boundary Survey Stones */}
                        <circle cx={x + 4} cy={y + 4} r={isSelected ? 5 : 3.5} fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
                        <circle cx={x + width - 4} cy={y + 4} r={isSelected ? 5 : 3.5} fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
                        <circle cx={x + width - 4} cy={y + height - 4} r={isSelected ? 5 : 3.5} fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
                        <circle cx={x + 4} cy={y + height - 4} r={isSelected ? 5 : 3.5} fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />

                        {/* Planted Crop Icon Badge (Center of Land) */}
                        <g transform={`translate(${x + width / 2}, ${y + height / 2 - 12})`}>
                          {/* Halo ring */}
                          <circle r="26" fill="#ffffff" opacity="0.95" stroke={crop.borderColor} strokeWidth="2.5" />
                          <text
                            textAnchor="middle"
                            dominantBaseline="central"
                            fontSize="24"
                          >
                            {crop.emoji}
                          </text>
                        </g>

                        {/* Crop Name & Land Label */}
                        <g transform={`translate(${x + width / 2}, ${y + height / 2 + 28})`}>
                          <rect
                            x="-70"
                            y="-11"
                            width="140"
                            height="22"
                            rx="7"
                            fill="#173F35"
                            stroke="#ffffff"
                            strokeWidth="1.5"
                            opacity="0.95"
                          />
                          <text
                            textAnchor="middle"
                            dominantBaseline="central"
                            fill="#ffffff"
                            fontSize="11"
                            fontWeight="bold"
                          >
                            {crop.emoji} {language === 'te' ? crop.nameTe.split(' ')[0] : language === 'ta' ? crop.nameTa.split(' ')[0] : crop.nameEn.split(' ')[0]} • {plot.areaAcres}ac
                          </text>
                        </g>

                        {/* Survey Number Tag */}
                        <text
                          x={x + 12}
                          y={y + 20}
                          fill="#ffffff"
                          fontSize="9"
                          fontWeight="bold"
                          opacity="0.9"
                        >
                          {plot.surveyNumber || `SF ${plot.id.slice(-2)}`}
                        </text>

                        {/* Risk status mini dot */}
                        <circle
                          cx={x + width - 15}
                          cy={y + 18}
                          r="5"
                          fill={plot.advisory.riskLevel === 'high' ? '#ef4444' : plot.advisory.riskLevel === 'watch' ? '#f59e0b' : '#22c55e'}
                          stroke="#ffffff"
                          strokeWidth="1"
                        />
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Bottom Instructions Footer */}
              <div className="absolute bottom-3 left-4 right-4 z-20 flex items-center justify-between text-[11px] text-white/90 bg-black/50 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-white/10 pointer-events-none">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>
                    {language === 'te'
                      ? 'ఈ మ్యాప్‌లో పొలంపై నొక్కి ఏ పంట నాటారో, నేల తేమను చూడండి'
                      : language === 'ta'
                      ? 'நிலத்தை தட்டி என்ன பயிர் உள்ளது மற்றும் ஈரப்பதத்தை அறியவும்'
                      : 'Click any parcel on the map to inspect what is planted and view water health.'}
                  </span>
                </span>
                <span className="hidden sm:inline text-gray-300">
                  {language === 'te' ? 'డ్రాగ్ చేసి జూమ్ చేయవచ్చు' : language === 'ta' ? 'நகர்த்தி பெரிதாக்கலாம்' : 'Drag to pan • Use + / - to zoom'}
                </span>
              </div>
            </div>
          )}

          {/* ENGINE 2: Google Maps Platform (Satellite / Hybrid with Markers) */}
          {mapEngine === 'google_maps' && (
            <div className="w-full h-full relative">
              <APIProvider apiKey={apiKey}>
                <Map
                  center={activeCenter}
                  zoom={activeZoom}
                  mapId="farmpulse-field-place-map"
                  mapTypeId={googleMapType}
                  className="w-full h-full"
                  gestureHandling="greedy"
                >
                  {plots.map((plot) => {
                    const crop = getCropInfo(plot.variety || plot.cropType);
                    const isSelected = activePlot?.id === plot.id;
                    return (
                      <AdvancedMarker
                        key={plot.id}
                        position={{ lat: plot.coordinates.lat, lng: plot.coordinates.lng }}
                        onClick={() => handleFocusPlot(plot)}
                      >
                        <div className={`p-1.5 rounded-full border-2 shadow-lg transition-transform ${
                          isSelected ? 'scale-125 ring-4 ring-emerald-400 bg-white' : 'bg-white hover:scale-110'
                        }`}
                        style={{ borderColor: crop.borderColor }}
                        >
                          <span className="text-xl">{crop.emoji}</span>
                        </div>
                      </AdvancedMarker>
                    );
                  })}

                  {/* Selected search place pin */}
                  <AdvancedMarker
                    position={{ lat: selectedPlaceInfo.lat, lng: selectedPlaceInfo.lng }}
                  >
                    <div className="bg-blue-600 text-white p-2 rounded-full ring-4 ring-blue-300 shadow-xl animate-bounce">
                      <Navigation className="w-4 h-4" />
                    </div>
                  </AdvancedMarker>
                </Map>
              </APIProvider>
            </div>
          )}
        </div>

        {/* Column 2: What is Planted in this Land Inspector (1 Col) */}
        <div className="bg-white rounded-2xl border border-[#CCD6C6] p-5 shadow-xs flex flex-col justify-between space-y-4">
          {activePlot ? (
            <div className="space-y-4">
              {/* Header: Planted Crop Card Banner */}
              <div className="pb-3 border-b border-[#E3E8DC]">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    {language === 'te' ? 'ఈ నేలలో నాటిన పంట' : language === 'ta' ? 'பயிரிடப்பட்ட பயிர்' : 'What is Planted Here'}
                  </span>
                  <span className="text-xs font-bold text-[#566761]">
                    {activePlot.surveyNumber || 'SF No. 142/2A'}
                  </span>
                </div>

                <div className="flex items-center gap-3 mt-2.5">
                  <span className="text-4xl p-2 rounded-2xl bg-emerald-50 border border-emerald-200">
                    {activeCropInfo.emoji}
                  </span>
                  <div>
                    <h3 className="font-extrabold text-lg sm:text-xl text-[#173F35] leading-tight">
                      {language === 'te' 
                        ? (activePlot.cropTypeTe || activeCropInfo.nameTe)
                        : language === 'ta'
                        ? (activePlot.cropTypeTa || activeCropInfo.nameTa)
                        : (activePlot.cropType || activeCropInfo.nameEn)}
                    </h3>
                    <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                      {activePlot.variety}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-[#566761] mt-1.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                  <span>{activePlot.locationName}</span>
                </p>
              </div>

              {/* Land Parcel Sizing & Cadastral Details */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                  <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'భూమి విస్తీర్ణం:' : language === 'ta' ? 'பரப்பளவு:' : 'Land Area:'}</span>
                  <strong className="text-sm text-[#173F35] font-extrabold">{activePlot.areaAcres} Acres</strong>
                </div>

                <div className="p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                  <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'విత్తిన వయస్సు:' : language === 'ta' ? 'விதைத்த காலம்:' : 'Planting Age:'}</span>
                  <strong className="text-sm text-[#173F35] font-extrabold">
                    {language === 'te' ? activeSowingAge.textTe : language === 'ta' ? activeSowingAge.textTa : activeSowingAge.text}
                  </strong>
                </div>

                <div className="p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                  <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'ప్రస్తుత పంట దశ:' : language === 'ta' ? 'பருவம்:' : 'Growth Stage:'}</span>
                  <strong className="text-xs text-[#173F35] font-bold capitalize">
                    {activePlot.growthStage.replace('_', ' ')}
                  </strong>
                </div>

                <div className="p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                  <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'సాగునీటి విధానం:' : language === 'ta' ? 'பாசனம்:' : 'Irrigation:'}</span>
                  <strong className="text-xs text-[#173F35] font-bold">
                    {activePlot.irrigationType || 'Canal + Borewell'}
                  </strong>
                </div>
              </div>

              {/* Soil & Water Status Dial */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#173F35]">
                    <Droplets className="w-4 h-4 text-blue-600" />
                    <span>{language === 'te' ? 'నేల తేమ & నీటి పరిస్థితి' : language === 'ta' ? 'மண் ஈரப்பதம் & நீர்வளம்' : 'Soil Moisture & Water'}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    activePlot.advisory.riskLevel === 'high' ? 'bg-rose-100 text-rose-800' :
                    activePlot.advisory.riskLevel === 'watch' ? 'bg-amber-100 text-amber-800' :
                    'bg-emerald-100 text-emerald-800'
                  }`}>
                    {activePlot.advisory.riskLevel.toUpperCase()} RISK
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                  <div>
                    <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'నేల తేమ శాతం:' : language === 'ta' ? 'மண் ஈரப்பதம்:' : 'Soil Moisture:'}</span>
                    <span className="text-base font-extrabold text-blue-800">
                      {activePlot.latestObservation.soilMoisturePercent}%
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-[#566761] block">{language === 'te' ? 'వర్షం లేని రోజులు:' : language === 'ta' ? 'மழையற்ற நாட்கள்:' : 'Dry Days:'}</span>
                    <span className="text-base font-extrabold text-[#173F35]">
                      {activePlot.latestObservation.daysWithoutRain} Days
                    </span>
                  </div>
                </div>

                {/* Agronomic recommendation */}
                <p className="text-xs text-[#173F35] pt-2 border-t border-emerald-200 leading-relaxed font-medium">
                  {language === 'ta' ? activePlot.advisory.summaryTa : activePlot.advisory.summary}
                </p>
              </div>

              {/* Soil Series Info */}
              <div className="p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] text-xs flex items-center justify-between">
                <span className="text-[#566761]">{language === 'te' ? 'నేల రకం:' : language === 'ta' ? 'மண் வகை:' : 'Soil Series:'}</span>
                <span className="font-bold text-[#173F35] text-right">{activePlot.soilType || selectedPlaceInfo.soilSeries}</span>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500">
              <Sprout className="w-8 h-8 mx-auto text-gray-400 mb-2" />
              <p className="text-sm font-bold">No plot selected</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-2 border-t border-[#E3E8DC] space-y-2">
            <button
              onClick={() => {
                if (activePlot) setSelectedPlotId(activePlot.id);
                setActiveTab('advisory');
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-[#173F35] hover:bg-[#255e50] text-white rounded-xl text-xs font-bold shadow-xs transition-all"
            >
              <span>{language === 'te' ? 'పంట ఒత్తిడి సలహా చూడండి' : language === 'ta' ? 'பயிர் ஆலோசனையை பார்க்க' : 'Open Crop Stress Advisory'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {onSelectPlotDetail && activePlot && (
              <button
                onClick={() => onSelectPlotDetail(activePlot)}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#566761] hover:text-[#173F35] bg-[#F7F8F4] hover:bg-gray-100 rounded-xl border border-[#CCD6C6] transition-all"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{language === 'te' ? 'పూర్తి పొలం రికార్డు తెరవండి' : language === 'ta' ? 'முழு புல விவரங்களை திறக்க' : 'View Full Cadastral Card'}</span>
              </button>
            )}

            {activePlot && activePlot.id.startsWith('plot-custom-') && (
              <button
                onClick={() => deletePlot(activePlot.id)}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{language === 'te' ? 'ఈ పొలాన్ని తొలగించండి' : language === 'ta' ? 'இந்த நிலத்தை நீக்கு' : 'Delete This Land'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mark Land Modal */}
      <MarkLandModal
        isOpen={isMarkLandOpen}
        onClose={() => setIsMarkLandOpen(false)}
        initialCoords={activeCenter}
      />
    </div>
  );
};
