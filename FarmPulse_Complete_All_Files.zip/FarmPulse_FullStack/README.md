# 🌾 FarmPulse — Full-Stack Crop Stress Advisory

**Tagline:** Don’t just tell the farmer what. Tell them why.

FarmPulse is a full-stack starter project for explainable crop-stress awareness for paddy plots in Tamil Nadu. It combines a React + TypeScript responsive web frontend with a FastAPI backend, transparent advisory rules, optional live weather lookup, and extension points for satellite data, ML, and persistence.

> **Prototype notice:** This is a demonstration and development starter, not an agronomic diagnosis product. Demo records are illustrative. Satellite ingestion, validated crop/disease models, and production database credentials are not included. Do not use demo outputs as the sole basis for farm-management decisions.

## Stack

| Layer | Technology | Status |
|---|---|---|
| Frontend | React, TypeScript, Vite, responsive mobile-first UI | Included |
| PWA | Manifest + service worker starter | Included; offline caching is basic |
| Backend | Python, FastAPI, Pydantic | Included |
| Explainability | Transparent rule-based advisory with reasons | Included |
| ML | scikit-learn example pipeline and SHAP extension point | Optional starter |
| Satellite | Sentinel Hub / Google Earth Engine adapter placeholders | Integration required |
| Weather | Open-Meteo API adapter | Optional live fetch; demo fallback |
| Storage | SQLite demo repository; PostgreSQL/Firebase guidance | SQLite included; alternatives require configuration |
| Tests | pytest and frontend build | Included |

## Project structure

```text
FarmPulse_FullStack/
├── docs/                        # Architecture, API, deployment, model card
├── frontend/                    # React + TypeScript + Vite PWA
│   ├── public/
│   │   ├── manifest.webmanifest
│   │   └── sw.js
│   ├── src/
│   │   ├── api.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── styles.css
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── schemas.py
│   │   ├── advisory.py
│   │   ├── weather.py
│   │   ├── storage.py
│   │   └── integrations/
│   │       └── satellite.py
│   ├── tests/
│   │   └── test_advisory.py
│   ├── requirements.txt
│   └── .env.example
├── ml/
│   ├── README.md
│   └── train_baseline.py
├── docker-compose.yml
├── .gitignore
└── README.md
```

## Requirements

- Python 3.11+
- Node.js 20+ and npm
- Git (optional)
- Docker Desktop (optional)

## Run locally

### 1. Start the backend

From the repository root:

**Windows PowerShell**
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload --port 8000
```

**macOS/Linux**
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

Backend URLs:
- API: http://127.0.0.1:8000
- Interactive API docs: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/health

### 2. Start the frontend

Open a second terminal from the repository root:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://localhost:5173). The Vite development server proxies `/api` to FastAPI.

### 3. Run tests

Backend:
```bash
cd backend
pytest -q
```

Frontend production build:
```bash
cd frontend
npm run build
```

### 4. Docker (optional)

From the repository root:
```bash
docker compose up --build
```

The API is available at `http://localhost:8000`. For local frontend development, use the Vite instructions above. The included compose file starts the API only; the frontend is intentionally run with npm to keep the development workflow straightforward.

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/api/plots` | List demo plots |
| GET | `/api/plots/{plot_id}` | Read one plot |
| POST | `/api/advisory` | Generate an explainable advisory |
| GET | `/api/weather?latitude=...&longitude=...` | Fetch Open-Meteo weather if enabled; otherwise return demo-safe fallback |

See `/docs` for interactive schemas.

## Data and safety notes

- Plot data is synthetic demonstration data.
- The advisory engine is transparent rule-based logic, not a trained crop-disease model.
- Weather integration uses Open-Meteo only when `ENABLE_LIVE_WEATHER=true`; a network failure returns a clear demo fallback.
- The Sentinel Hub / Google Earth Engine adapter is a documented integration point, not a live satellite connection.
- No API secrets are committed. Keep credentials in environment variables and never upload `.env`.
- Do not show pesticide dosage or present an image classification as a confirmed diagnosis.
- Before deployment, validate recommendations with agricultural experts and local field data; review privacy, consent, accessibility, and security.

## Environment configuration

See `backend/.env.example`. `ENABLE_LIVE_WEATHER=false` is the default. To enable the Open-Meteo request, set it to `true`; Open-Meteo's API is used without an API key for the included forecast endpoint, subject to its current service terms and availability.

For production storage, configure PostgreSQL or Firebase using a dedicated adapter and managed credentials. The current demo repository uses SQLite locally so the app runs without external accounts.

## ML roadmap

The `ml/` directory includes a minimal scikit-learn baseline training example on synthetic data to demonstrate the pipeline only. It is not a valid agronomic model and must not be used to make real decisions. Collect properly labeled, consented field observations, split evaluation data by farm/season where appropriate, assess calibration and error rates, and obtain domain-expert review before deploying ML. SHAP can be added for a fitted tree model to explain feature contributions; explanation methods do not prove that a model is correct.

## Contributing

1. Create a feature branch.
2. Make a focused change and add tests.
3. Run backend tests and frontend build.
4. Document any data, model, or integration limitations in the pull request.

## License

No license has been selected. Add a license before granting others explicit permission to reuse or redistribute the code.
