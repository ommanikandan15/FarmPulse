import React from 'react';
import { useApp } from '../../context/AppContext';
import { PlotMapSchematic } from './PlotMapSchematic';
import { GoogleMapsOverview } from './GoogleMapsOverview';
import { WeatherStrip } from './WeatherStrip';
import { WhyThisAlertCard } from './WhyThisAlertCard';
import { PriorityActionsList } from './PriorityActionsList';
import { StatusBadge } from '../common/StatusBadge';
import { 
  Sprout, 
  Layers, 
  AlertTriangle, 
  Database, 
  Activity, 
  ChevronRight,
  TrendingDown,
  Clock,
  Compass,
  Map as MapIcon,
  Grid
} from 'lucide-react';
import { Plot } from '../../types';

interface DashboardViewProps {
  onOpenExplainability: () => void;
  onSelectPlotDetail: (plot: Plot) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenExplainability,
  onSelectPlotDetail,
}) => {
  const { 
    plots, 
    selectedPlotId, 
    setSelectedPlotId, 
    setActiveTab, 
    t, 
    language, 
    formatArea,
    mapMode,
    setMapMode,
    currentUser
  } = useApp();

  const totalArea = plots.reduce((acc, p) => acc + p.areaAcres, 0);
  const highRiskCount = plots.filter((p) => p.advisory.riskLevel === 'high').length;
  const watchCount = plots.filter((p) => p.advisory.riskLevel === 'watch').length;
  const lowCount = plots.filter((p) => p.advisory.riskLevel === 'low').length;

  // Average data coverage
  const avgCoverage = Math.round(
    plots.reduce((acc, p) => acc + p.advisory.dataCoveragePercent, 0) / plots.length
  );

  const handlePlotSelect = (plot: Plot) => {
    setSelectedPlotId(plot.id);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Greeting Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#173F35] via-[#1E4D41] to-[#173F35] text-white p-5 sm:p-6 rounded-2xl shadow-xs">
        <div>
          <span className="text-xs uppercase tracking-wider text-[#65A66F] font-bold">
            {language === 'ta' ? 'கள நுண்ணறிவு சுருக்கம்' : 'Explainable Field Intelligence'}
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-0.5">
            {t.greetingFarmer}, {currentUser?.name?.split(' ')[0] || 'Farmer'}
          </h1>
          <p className="text-xs sm:text-sm text-stone-200 mt-1 max-w-xl">
            {t.greetingSubtitle}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Map view switcher */}
          <div className="flex items-center bg-black/20 p-1 rounded-xl border border-white/10 text-xs">
            <button
              onClick={() => setMapMode('google_maps')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                mapMode === 'google_maps'
                  ? 'bg-white text-[#173F35] shadow-xs'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>Google Maps</span>
            </button>
            <button
              onClick={() => setMapMode('schematic')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                mapMode === 'schematic'
                  ? 'bg-white text-[#173F35] shadow-xs'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Schematic</span>
            </button>
          </div>

          <button
            onClick={() => setActiveTab('advisory')}
            className="px-4 py-2 bg-[#65A66F] hover:bg-[#528d5c] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <span>{language === 'ta' ? 'ஆலோசனை இயந்திரம்' : 'Advisory Engine'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Monitored Plots */}
        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#566761]">{t.monitoredPlots}</span>
            <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
              <Sprout className="w-4 h-4 text-[#4E9B5F]" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1C2723]">{plots.length}</span>
            <span className="text-xs text-[#566761]">{language === 'ta' ? 'நிலங்கள்' : 'plots'}</span>
          </div>
          <span className="text-[11px] text-[#4E9B5F] mt-1 block font-medium">
            100% {language === 'ta' ? 'செயலில் உள்ளன' : 'active monitoring'}
          </span>
        </div>

        {/* Monitored Area */}
        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#566761]">{t.monitoredArea}</span>
            <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
              <Layers className="w-4 h-4 text-[#4E9B5F]" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1C2723]">{formatArea(totalArea)}</span>
          </div>
          <span className="text-[11px] text-[#566761] mt-1 block">
            {language === 'ta' ? 'பாலாறு பாசன வட்டாரம்' : 'Palar irrigation basin'}
          </span>
        </div>

        {/* High Priority Plots */}
        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#566761]">{t.highPriorityPlots}</span>
            <div className={`p-2 rounded-lg ${highRiskCount > 0 ? 'bg-rose-50 text-rose-700' : 'bg-[#EBF4ED] text-[#173F35]'}`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${highRiskCount > 0 ? 'text-rose-700' : 'text-[#1C2723]'}`}>
              {highRiskCount}
            </span>
            <span className="text-xs text-[#566761]">
              / {plots.length} {language === 'ta' ? 'நிலம்' : 'plot'}
            </span>
          </div>
          <span className="text-[11px] text-rose-700 mt-1 block font-medium">
            {highRiskCount > 0 
              ? (language === 'ta' ? 'உடனடி கள ஆய்வு தேவை' : 'Ground check required')
              : (language === 'ta' ? 'அனைத்தும் சீராக உள்ளன' : 'Stable status')}
          </span>
        </div>

        {/* Data Coverage */}
        <div className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#566761]">{t.dataCoverage}</span>
            <div className="p-2 rounded-lg bg-[#EBF4ED] text-[#173F35]">
              <Database className="w-4 h-4 text-[#4E9B5F]" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1C2723]">{avgCoverage}%</span>
          </div>
          <span className="text-[11px] text-[#566761] mt-1 block">
            {language === 'ta' ? 'சென்சார் + வானிலை தரவு' : 'Ground sensors & meteo'}
          </span>
        </div>
      </div>

      {/* 1-Click Try Sample Farm & 4-Category Intelligence Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-extrabold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
              PRIME ELITE AI
            </span>
            <span className="text-xs font-bold text-[#173F35]">
              {language === 'ta' ? '4 பயிர் அழுத்த பகுப்பாய்வு & மாதிரி பண்ணை' : 'Four-Category Crop Stress Intelligence'}
            </span>
          </div>
          <p className="text-xs text-[#566761] max-w-xl">
            {language === 'ta'
              ? 'நீர், சத்து, பூச்சி மற்றும் வெப்ப அழுத்தங்களை தனித்தனியாக ஆராய்ந்து, உண்மை விதிகளின்படி ஆலோசனைகளை அறியவும்.'
              : 'Independent explainability across Water Stress, Nutrient Stress, Pest & Disease Risk, and Heat Stress with transparent rule attribution.'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('analysis');
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all active:scale-95"
          >
            <span>{t.trySampleFarm}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('advisory')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-[#F7F8F4] hover:bg-[#EBF4ED] text-[#173F35] border border-[#E3E8DC] transition-colors"
          >
            <span>{language === 'ta' ? '4 அழுத்தங்களை காண்க' : 'View 4 Categories'}</span>
          </button>
        </div>
      </div>

      {/* Field Health Overview: Google Maps or Schematic Map */}
      {mapMode === 'google_maps' ? (
        <GoogleMapsOverview
          plots={plots}
          selectedPlotId={selectedPlotId}
          onSelectPlot={handlePlotSelect}
          onOpenPlotDetail={onSelectPlotDetail}
          onToggleToSchematic={() => setMapMode('schematic')}
        />
      ) : (
        <PlotMapSchematic
          plots={plots}
          selectedPlotId={selectedPlotId}
          onSelectPlot={handlePlotSelect}
        />
      )}

      {/* 2-Column Section: Why This Alert & Priority Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <WhyThisAlertCard
          onOpenExplainability={onOpenExplainability}
          onNavigateToAdvisory={() => setActiveTab('advisory')}
        />
        <PriorityActionsList />
      </div>

      {/* 7-Day Weather Strip */}
      <WeatherStrip />

      {/* Plot Status Table & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Plot Status Quick List */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <h3 className="font-bold text-sm sm:text-base text-[#173F35]">
              {t.plotStatusList}
            </h3>
            <button
              onClick={() => setActiveTab('plots')}
              className="text-xs font-semibold text-[#4E9B5F] hover:text-[#173F35] flex items-center gap-0.5"
            >
              <span>{language === 'ta' ? 'அனைத்தையும் காண்க' : 'View Plot Explorer'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-3 divide-y divide-[#E3E8DC]">
            {plots.map((plot) => (
              <div
                key={plot.id}
                onClick={() => onSelectPlotDetail(plot)}
                className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#F7F8F4] px-2 rounded-xl transition-colors cursor-pointer"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs sm:text-sm text-[#1C2723]">
                      {language === 'ta' ? plot.nameTa : plot.name}
                    </span>
                    <span className="text-[11px] text-[#566761]">
                      ({language === 'ta' ? plot.varietyTa : plot.variety})
                    </span>
                  </div>
                  <p className="text-[11px] text-[#83948E]">
                    {language === 'ta' ? plot.locationNameTa : plot.locationName} • {formatArea(plot.areaAcres)}
                  </p>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3">
                  <div className="text-left sm:text-right text-[11px]">
                    <span className="font-medium text-[#1C2723] block">
                      {plot.latestObservation.soilMoisturePercent}% moisture
                    </span>
                    <span className="text-[#83948E]">
                      {plot.latestObservation.daysWithoutRain}d rain-free
                    </span>
                  </div>
                  <StatusBadge level={plot.advisory.riskLevel} size="sm" />
                  <ChevronRight className="w-4 h-4 text-stone-400 hidden sm:block" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cluster Risk & Activity Log */}
        <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#173F35] pb-2 border-b border-[#E3E8DC]">
              {t.clusterRiskSummary}
            </h3>

            {/* Visual Risk Distribution Bar */}
            <div className="mt-3">
              <div className="h-3 rounded-full overflow-hidden flex bg-stone-100">
                <div style={{ width: `${(lowCount / plots.length) * 100}%` }} className="bg-[#2D8A4E]" title={`Low: ${lowCount}`} />
                <div style={{ width: `${(watchCount / plots.length) * 100}%` }} className="bg-[#D97706]" title={`Watch: ${watchCount}`} />
                <div style={{ width: `${(highRiskCount / plots.length) * 100}%` }} className="bg-[#DC2626]" title={`High: ${highRiskCount}`} />
              </div>

              <div className="mt-2 grid grid-cols-3 text-center text-xs">
                <div>
                  <span className="font-bold text-[#2D8A4E] block">{lowCount}</span>
                  <span className="text-[10px] text-[#566761]">{t.riskLow}</span>
                </div>
                <div>
                  <span className="font-bold text-[#D97706] block">{watchCount}</span>
                  <span className="text-[10px] text-[#566761]">{t.riskWatch}</span>
                </div>
                <div>
                  <span className="font-bold text-[#DC2626] block">{highRiskCount}</span>
                  <span className="text-[10px] text-[#566761]">{t.riskHigh}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity Log */}
          <div className="pt-2 border-t border-[#E3E8DC]">
            <h4 className="font-semibold text-xs text-[#566761] uppercase tracking-wider mb-2">
              {t.recentActivity}
            </h4>
            <div className="space-y-2.5 text-xs">
              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-[#4E9B5F] shrink-0 mt-0.5" />
                <div>
                  <p className="text-[#1C2723] font-medium leading-snug">
                    {language === 'ta' ? 'நிலம் 01 மண் மாதிரி அளவீடு பதிவு செய்யப்பட்டது' : 'Plot 01 ground sensor synced moisture (18%)'}
                  </p>
                  <span className="text-[10px] text-[#83948E]">06:30 AM • Sensor</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="text-[#1C2723] font-medium leading-snug">
                    {language === 'ta' ? 'கவிதா சா. வாய்க்கால் நீர் வரத்து பதிவு செய்தார்' : 'Kavitha S. submitted field water level update'}
                  </p>
                  <span className="text-[10px] text-[#83948E]">06:45 AM • Farmer</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                <div>
                  <p className="text-[#1C2723] font-medium leading-snug">
                    {language === 'ta' ? 'கூகிள் மேப்ஸ் செயற்கைக்கோள் பார்வை புதுப்பிக்கப்பட்டது' : 'Google Maps High-Res satellite tile synced'}
                  </p>
                  <span className="text-[10px] text-[#83948E]">Today • Google Maps</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
