from app.main import evaluate

def base():
    return {"crop":"paddy","days_without_rain":2,"soil_moisture_pct":40,"greenness_change_pct":0,"temperature_c":30,"humidity_pct":70,"growth_stage":"vegetative","ndvi":0.7,"ndwi":0.1}

def test_low_stress_when_inputs_are_normal():
    assert evaluate(base())["level"] == "Low"

def test_high_stress_explains_each_trigger():
    x=base(); x.update(days_without_rain=9,soil_moisture_pct=18,greenness_change_pct=-14,temperature_c=36)
    result=evaluate(x)
    assert result["level"] == "High"
    assert {"Rainfall gap","Soil moisture","Greenness trend","Heat"}.issubset({f["factor"] for f in result["factors"]})
    assert "consult a local agriculture officer" in result["action"]

def test_coverage_is_not_probability():
    assert "not a probability" in evaluate(base())["coverage_note"]
