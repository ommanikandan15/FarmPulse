import { WeatherDay } from '../types';
import { DEMO_WEATHER_STRIP } from '../data/demoData';

export interface WeatherFetchResult {
  days: WeatherDay[];
  source: 'open_meteo' | 'demo_synthetic';
  isLive: boolean;
  retrievedAt: string;
  locationLabel: string;
  disclaimer: string;
}

/**
 * Weather Service Adapter for Kaveripakkam (Lat: 12.8982, Lng: 79.4674)
 * Attempts to retrieve real 7-day meteorological data from Open-Meteo free API.
 * Gracefully falls back to high-fidelity demo data if network is unavailable or blocked.
 */
export async function fetch7DayWeather(
  useLiveIfAvailable = true,
  lat = 12.8982,
  lng = 79.4674
): Promise<WeatherFetchResult> {
  if (!useLiveIfAvailable) {
    return {
      days: DEMO_WEATHER_STRIP,
      source: 'demo_synthetic',
      isLive: false,
      retrievedAt: new Date().toISOString(),
      locationLabel: 'Kaveripakkam Pilot Zone (Synthetic Demo Baseline)',
      disclaimer: 'Showing calibrated sample demo weather for Kaveripakkam cluster. Not live sensor readings.',
    };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000); // 4s timeout

    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&current_weather=true&timezone=Asia%2FKolkata`;
    
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Open-Meteo responded with status ${response.status}`);
    }

    const data = await response.json();
    if (!data.daily || !data.daily.time || data.daily.time.length === 0) {
      throw new Error('Malformed Open-Meteo payload');
    }

    const days: WeatherDay[] = data.daily.time.slice(0, 7).map((dateStr: string, idx: number) => {
      const maxT = Math.round(data.daily.temperature_2m_max[idx] ?? 33);
      const minT = Math.round(data.daily.temperature_2m_min[idx] ?? 24);
      const rain = Math.round((data.daily.precipitation_sum[idx] ?? 0) * 10) / 10;
      
      const d = new Date(dateStr);
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const dayNamesTa = ['ஞாயிறு', 'திங்கள்', 'செவ்வாய்', 'புதன்', 'வியாழன்', 'வெள்ளி', 'சனி'];
      const dayIdx = d.getDay();

      let condition: WeatherDay['condition'] = 'sunny';
      let conditionTa = 'வெயில்';

      if (rain > 5) {
        condition = 'rainy';
        conditionTa = 'மழை';
      } else if (rain > 0.5) {
        condition = 'partly_cloudy';
        conditionTa = 'தூறல் / மேகமூட்டம்';
      } else if (maxT >= 35) {
        condition = 'hot_dry';
        conditionTa = 'அதிக வெப்பம்';
      }

      return {
        date: dateStr,
        dayName: idx === 0 ? 'Today' : dayNames[dayIdx],
        dayNameTa: idx === 0 ? 'இன்று' : dayNamesTa[dayIdx],
        tempMaxC: maxT,
        tempMinC: minT,
        rainfallMm: rain,
        humidityPercent: Math.max(35, Math.min(85, Math.round(75 - (maxT - 28) * 4))),
        soilMoisturePercent: Math.max(16, Math.min(40, Math.round(34 - idx * 2.5 + rain * 1.5))),
        condition,
        conditionTa,
        isDemo: false,
      };
    });

    return {
      days,
      source: 'open_meteo',
      isLive: true,
      retrievedAt: new Date().toISOString(),
      locationLabel: 'Kaveripakkam (Open-Meteo Public API)',
      disclaimer: 'Live meteorological forecast retrieved from Open-Meteo API. Micro-plot soil moisture remains estimated.',
    };
  } catch {
    // Graceful fallback to demo data
    return {
      days: DEMO_WEATHER_STRIP,
      source: 'demo_synthetic',
      isLive: false,
      retrievedAt: new Date().toISOString(),
      locationLabel: 'Kaveripakkam Pilot Zone (Synthetic Demo Baseline)',
      disclaimer: 'Open-Meteo external service unavailable or offline; display defaulted safely to sample demo metrics.',
    };
  }
}
