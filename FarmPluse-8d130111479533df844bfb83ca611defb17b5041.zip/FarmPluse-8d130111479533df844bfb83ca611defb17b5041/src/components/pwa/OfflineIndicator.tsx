import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';
import { useApp } from '../../context/AppContext';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { language } = useApp();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-6 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600/95 backdrop-blur-md px-3.5 py-2 text-xs font-semibold text-white shadow-xl border border-amber-400 animate-in slide-in-from-bottom-2 duration-200">
      <span className="h-2 w-2 rounded-full bg-white animate-ping" />
      <WifiOff className="w-4 h-4 shrink-0 text-amber-200" />
      <span>
        {language === 'ta'
          ? 'ஆஃப்லைன் பயன்முறை — உள் சேமிக்கப்பட்ட தரவு மற்றும் TNAU விதிகள் பயன்பாட்டில் உள்ளன.'
          : 'Offline Field Mode — Using locally cached TNAU rules & field data.'}
      </span>
    </div>
  );
};
