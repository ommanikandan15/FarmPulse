import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  MANDI_MARKET_PRICES, 
  CROP_CALENDARS, 
  MandiRecord, 
  CropSeasonalGuidance 
} from '../../data/mandiAndCropData';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Calendar, 
  Sprout, 
  Droplets, 
  Search, 
  Filter, 
  ShieldCheck, 
  Info, 
  CheckCircle2, 
  AlertTriangle, 
  Award, 
  Layers,
  ChevronRight,
  Clock,
  ExternalLink
} from 'lucide-react';

export const MandiAndCalendarView: React.FC = () => {
  const { language, t } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'mandi' | 'calendar'>('mandi');
  const [selectedState, setSelectedState] = useState<string>('ALL');
  const [selectedCommodity, setSelectedCommodity] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCropId, setSelectedCropId] = useState<string>(CROP_CALENDARS[0].id);

  // Filter Mandi records
  const filteredMandi = MANDI_MARKET_PRICES.filter((item) => {
    const matchState = selectedState === 'ALL' || item.stateCode === selectedState;
    const matchComm = selectedCommodity === 'ALL' || item.commodity.toLowerCase().includes(selectedCommodity.toLowerCase());
    const matchQuery = 
      item.marketName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.commodity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.variety.toLowerCase().includes(searchQuery.toLowerCase());

    return matchState && matchComm && matchQuery;
  });

  const selectedCrop = CROP_CALENDARS.find((c) => c.id === selectedCropId) || CROP_CALENDARS[0];

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {language === 'ta' 
                ? 'மண்டி சந்தை விலைகள் & பயிர் காலண்டர்' 
                : (language === 'te' ? 'మండీ మార్కెట్ ధరలు & పంట క్యాలెండర్' : 'Mandi Market Prices & Seasonal Crop Calendar')}
            </h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
              e-NAM / Agmarknet
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-2xl">
            {language === 'ta'
              ? 'அங்கீகரிக்கப்பட்ட ஒழுங்குமுறை விற்பனைக்கூட தினசரி விலை நிலவரங்கள் மற்றும் பருவ கால வேளாண் வழிகாட்டுதல்கள்.'
              : (language === 'te'
                ? 'అధీకృత ఏపీఎంసీ మరియు ఈ-నామ్ (e-NAM) మార్కెట్ యార్డుల తాజా ధరలు మరియు సీజనల్ పంటల సాగు సమగ్ర క్యాలెండర్.'
                : 'Verified daily wholesale APMC arrivals, modal mandi prices vs MSP benchmarks, and seasonal agronomy schedules.')}
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-[#F7F8F4] rounded-xl border border-[#E3E8DC] self-start md:self-auto">
          <button
            onClick={() => setActiveSubTab('mandi')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeSubTab === 'mandi'
                ? 'bg-[#173F35] text-white shadow-xs'
                : 'text-[#566761] hover:text-[#173F35]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'மண்டி விலைகள்' : (language === 'te' ? 'మండీ ధరలు' : 'Mandi Prices')}</span>
          </button>
          <button
            onClick={() => setActiveSubTab('calendar')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeSubTab === 'calendar'
                ? 'bg-[#173F35] text-white shadow-xs'
                : 'text-[#566761] hover:text-[#173F35]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{language === 'ta' ? 'பயிர் காலண்டர்' : (language === 'te' ? 'పంట క్యాలెండర్' : 'Farming Calendar')}</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: MANDI MARKET PRICES */}
      {activeSubTab === 'mandi' && (
        <div className="space-y-4">
          {/* Controls: State, Commodity, Search */}
          <div className="bg-white p-4 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#83948E]" />
              <input
                type="text"
                placeholder={language === 'te' ? 'మార్కెట్ లేదా పంట పేరు శోధించండి...' : 'Search mandi, district, variety...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-[#F7F8F4] border border-[#E3E8DC] rounded-xl text-xs text-[#1C2723] focus:outline-hidden focus:border-[#4E9B5F]"
              />
            </div>

            {/* State filter */}
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-[#566761]">{language === 'te' ? 'రాష్ట్రం:' : 'State:'}</span>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="px-2.5 py-2 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] font-semibold text-[#173F35] focus:outline-hidden"
              >
                <option value="ALL">{language === 'te' ? 'అన్ని రాష్ట్రాలు' : 'All States (AP, TS, TN)'}</option>
                <option value="AP">Andhra Pradesh</option>
                <option value="TS">Telangana</option>
                <option value="TN">Tamil Nadu</option>
              </select>
            </div>

            {/* Commodity filter */}
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-[#566761]">{language === 'te' ? 'పంట:' : 'Crop:'}</span>
              <select
                value={selectedCommodity}
                onChange={(e) => setSelectedCommodity(e.target.value)}
                className="px-2.5 py-2 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] font-semibold text-[#173F35] focus:outline-hidden"
              >
                <option value="ALL">{language === 'te' ? 'అన్ని పంటలు' : 'All Commodities'}</option>
                <option value="Paddy">Paddy / Rice</option>
                <option value="Cotton">Cotton / Kapas</option>
                <option value="Chilli">Chilli / Mirchi</option>
                <option value="Maize">Maize / Makka</option>
                <option value="Groundnut">Groundnut</option>
                <option value="Turmeric">Turmeric</option>
                <option value="Tomato">Tomato</option>
                <option value="Red Gram">Red Gram / Tur</option>
              </select>
            </div>
          </div>

          {/* Mandi Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMandi.map((item) => {
              const diffFromMsp = item.mspPerQtl ? item.modalPricePerQtl - item.mspPerQtl : null;

              return (
                <div 
                  key={item.id} 
                  className="bg-white rounded-2xl p-4 border border-[#E3E8DC] shadow-xs hover:border-[#4E9B5F]/40 transition-all flex flex-col justify-between space-y-3"
                >
                  {/* Top line: Commodity & State Badge */}
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold text-sm text-[#173F35]">
                        {item.commodity}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#F7F8F4] border border-[#E3E8DC] text-[#566761]">
                        {item.state}
                      </span>
                    </div>
                    <div className="text-xs text-[#566761] mt-0.5 font-medium">
                      {item.marketName} • <span className="font-semibold text-[#1C2723]">{item.district}</span>
                    </div>
                    <div className="text-[11px] text-[#83948E] mt-0.5">
                      Variety: <span className="font-medium text-[#566761]">{item.variety}</span>
                    </div>
                  </div>

                  {/* Middle Price Box */}
                  <div className="bg-[#F7F8F4] rounded-xl p-3 border border-[#E3E8DC] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#83948E] block">
                        Modal Price (₹/Qtl)
                      </span>
                      <div className="text-xl font-black text-[#173F35]">
                        ₹{item.modalPricePerQtl.toLocaleString('en-IN')}
                      </div>
                      <span className="text-[10px] text-[#566761] block mt-0.5">
                        Range: ₹{item.minPricePerQtl} – ₹{item.maxPricePerQtl}
                      </span>
                    </div>

                    <div className="text-right">
                      {item.priceTrend === 'up' && (
                        <div className="inline-flex items-center gap-1 text-emerald-700 font-bold text-xs bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200">
                          <TrendingUp className="w-3.5 h-3.5" />
                          <span>+{item.changePercent}%</span>
                        </div>
                      )}
                      {item.priceTrend === 'down' && (
                        <div className="inline-flex items-center gap-1 text-rose-700 font-bold text-xs bg-rose-50 px-2 py-1 rounded-lg border border-rose-200">
                          <TrendingDown className="w-3.5 h-3.5" />
                          <span>{item.changePercent}%</span>
                        </div>
                      )}
                      {item.priceTrend === 'stable' && (
                        <div className="inline-flex items-center gap-1 text-amber-700 font-bold text-xs bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
                          <Minus className="w-3.5 h-3.5" />
                          <span>Steady</span>
                        </div>
                      )}
                      <span className="text-[10px] text-[#83948E] block mt-1">
                        Arrivals: {item.arrivalVolumeQuintals} Qtl
                      </span>
                    </div>
                  </div>

                  {/* MSP Comparison & Footer */}
                  <div className="pt-2 border-t border-[#E3E8DC] flex items-center justify-between text-[11px]">
                    <div>
                      {item.mspPerQtl ? (
                        <span className={`font-semibold ${diffFromMsp && diffFromMsp >= 0 ? 'text-emerald-700' : 'text-amber-700'}`}>
                          MSP: ₹{item.mspPerQtl} {diffFromMsp && diffFromMsp >= 0 ? `(+₹${diffFromMsp})` : `(-₹${Math.abs(diffFromMsp || 0)})`}
                        </span>
                      ) : (
                        <span className="text-[#83948E]">Market Determined</span>
                      )}
                    </div>
                    <div className="text-[#83948E] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{item.lastUpdated}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredMandi.length === 0 && (
            <div className="bg-white rounded-2xl p-8 border border-[#E3E8DC] text-center space-y-2">
              <Info className="w-6 h-6 text-[#83948E] mx-auto" />
              <p className="text-sm font-bold text-[#173F35]">No mandi records match your current filter</p>
              <p className="text-xs text-[#566761]">Try changing the state or commodity selector above.</p>
            </div>
          )}

          {/* Official Mandi Transparency Note */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold block">
                {language === 'te' ? 'ధరల నిర్ధారణ మరియు అధికారిక నోటీసు' : 'Verified APMC / e-NAM Benchmark Note'}
              </span>
              <p className="leading-relaxed text-emerald-900">
                {language === 'te'
                  ? 'ధరలు కేంద్ర ప్రభుత్వ అగ్‌మార్క్‌నెట్ (Agmarknet) మరియు ఈ-నామ్ (e-NAM) మార్కెట్ యార్డుల నుండి సేకరించబడినవి. పంట తేమ శాతం, ధాన్యపు నాణ్యత (FAQ Standards) ఆధారంగా అసలు కొనుగోలు ధర మారుతుంది.'
                  : 'Wholesale mandi rates are derived from Agmarknet / e-NAM APMC daily arrival reports across Andhra Pradesh, Telangana, and Tamil Nadu. Final transaction prices at mandi yards depend on Fair Average Quality (FAQ) standards, clean moisture level, and daily physical arrivals.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: SEASONAL CROP GUIDANCE & CALENDAR */}
      {activeSubTab === 'calendar' && (
        <div className="space-y-4">
          {/* Crop Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {CROP_CALENDARS.map((crop) => (
              <button
                key={crop.id}
                onClick={() => setSelectedCropId(crop.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 border ${
                  selectedCropId === crop.id
                    ? 'bg-[#173F35] text-white border-[#173F35] shadow-xs'
                    : 'bg-white text-[#566761] border-[#E3E8DC] hover:bg-[#F7F8F4]'
                }`}
              >
                <Sprout className="w-3.5 h-3.5" />
                <span>
                  {language === 'ta' ? crop.cropNameTa : (language === 'te' ? crop.cropNameTe : crop.cropName)}
                </span>
              </button>
            ))}
          </div>

          {/* Selected Crop Overview Banner */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-[#E3E8DC]">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#4E9B5F] block">
                  Season: {selectedCrop.season}
                </span>
                <h2 className="text-lg font-black text-[#173F35]">
                  {language === 'ta' ? selectedCrop.cropNameTa : (language === 'te' ? selectedCrop.cropNameTe : selectedCrop.cropName)}
                </h2>
                <p className="text-xs text-[#566761] mt-0.5">
                  Sowing: <span className="font-semibold text-[#1C2723]">{selectedCrop.sowingWindow}</span> • Harvest: <span className="font-semibold text-[#1C2723]">{selectedCrop.harvestWindow}</span> • Duration: {selectedCrop.durationDays}
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-3 py-1 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-bold">
                  Water: {selectedCrop.waterRequirementMm}
                </span>
              </div>
            </div>

            {/* Recommended certified varieties */}
            <div className="text-xs space-y-1">
              <span className="font-bold text-[#173F35] block">
                {language === 'te' ? 'సిఫార్సు చేసిన విత్తన రకాలు:' : 'Recommended High-Yield Certified Varieties:'}
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                {selectedCrop.recommendedVarieties.map((v, idx) => (
                  <span key={idx} className="px-2.5 py-1 bg-[#F7F8F4] border border-[#E3E8DC] rounded-lg font-medium text-[#1C2723]">
                    {v}
                  </span>
                ))}
              </div>
            </div>

            {/* Critical Water Sensitivity Stages */}
            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-xs text-blue-950 space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold text-blue-900">
                <Droplets className="w-4 h-4 text-blue-600" />
                <span>
                  {language === 'te' ? 'కీలక నీటిపారుదల దశలు (నీటి కొరత రానివ్వకూడదు):' : 'Critical Moisture Stages (Zero-Moisture Deficit Window):'}
                </span>
              </div>
              <ul className="list-disc list-inside space-y-0.5 text-blue-900/90 pl-1">
                {selectedCrop.criticalWaterStages.map((stage, idx) => (
                  <li key={idx}>{stage}</li>
                ))}
              </ul>
              <div className="pt-1 text-[11px] font-semibold text-blue-800">
                Water conservation tip: {selectedCrop.waterSavingTechnique}
              </div>
            </div>
          </div>

          {/* Month-by-Month Agricultural Operations */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#E3E8DC]">
              <Calendar className="w-4 h-4 text-[#4E9B5F]" />
              <h3 className="font-bold text-sm text-[#173F35]">
                {language === 'te' ? 'నెలల వారీగా వ్యవసాయ పనులు & మార్గదర్శకాలు' : 'Month-by-Month Crop Management Checklist'}
              </h3>
            </div>

            <div className="space-y-4">
              {selectedCrop.keyOperationsByMonth.map((op, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-extrabold text-xs uppercase tracking-wider text-[#173F35]">
                      {op.month} — <span className="text-[#4E9B5F]">{op.stage}</span>
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white border border-[#E3E8DC] text-[#566761]">
                      Stage {idx + 1}
                    </span>
                  </div>

                  <ul className="space-y-1.5 text-xs text-[#1C2723]">
                    {(language === 'te' && op.actionsTe ? op.actionsTe : (language === 'ta' && op.actionsTa ? op.actionsTa : op.actions)).map((act, actIdx) => (
                      <li key={actIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#4E9B5F] shrink-0 mt-0.5" />
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Pests, Diseases, and IPM Prevention */}
          <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-3 border-b border-[#E3E8DC]">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-sm text-[#173F35]">
                {language === 'te' ? 'ముఖ్యమైన చీడపీడలు & జీవ నియంత్రణ సూచనలు' : 'Major Pests, Visual Indicators & Safe IPM Prevention'}
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {selectedCrop.majorPestsAndDiseases.map((pest, pIdx) => (
                <div key={pIdx} className="p-3.5 rounded-xl bg-amber-50/50 border border-amber-200/80 space-y-1.5">
                  <div className="font-bold text-amber-950">
                    {pest.name}
                  </div>
                  <p className="text-[#566761]">
                    <span className="font-semibold text-[#1C2723]">Symptoms:</span> {pest.symptoms}
                  </p>
                  <p className="text-emerald-900 bg-white p-2 rounded-lg border border-emerald-200">
                    <span className="font-bold text-emerald-800">Action:</span> {pest.prevention}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
