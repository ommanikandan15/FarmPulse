import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import { RiskLevel, SavedFarmAnalysis } from '../../types';
import { 
  FileText, 
  Download, 
  Printer, 
  Filter, 
  Calendar, 
  Layers, 
  CheckCircle2, 
  AlertTriangle,
  Info,
  Clock,
  Trash2,
  GitCompare,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Droplet,
  Leaf,
  Bug,
  ThermometerSun,
  X
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { 
    plots, 
    t, 
    language, 
    formatArea, 
    formatTemp, 
    analysesHistory, 
    setActiveAnalysis, 
    deleteHistoryItem, 
    clearHistory,
    setActiveTab 
  } = useApp();

  const [activeReportTab, setActiveReportTab] = useState<'history' | 'plots'>('history');
  const [selectedPlotFilter, setSelectedPlotFilter] = useState<string>('all');
  const [selectedRiskFilter, setSelectedRiskFilter] = useState<'all' | RiskLevel>('all');
  const [selectedCropFilter, setSelectedCropFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<string>('7d');

  // Compare mode state
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  const availableCrops = useMemo(() => {
    return Array.from(new Set(plots.map((p) => p.variety)));
  }, [plots]);

  const filteredPlots = useMemo(() => {
    return plots.filter((plot) => {
      if (selectedPlotFilter !== 'all' && plot.id !== selectedPlotFilter) return false;
      if (selectedRiskFilter !== 'all' && plot.advisory.riskLevel !== selectedRiskFilter) return false;
      if (selectedCropFilter !== 'all' && plot.variety !== selectedCropFilter) return false;
      return true;
    });
  }, [plots, selectedPlotFilter, selectedRiskFilter, selectedCropFilter]);

  const handleToggleCompare = (id: string) => {
    setSelectedForCompare((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      }
      if (prev.length >= 2) {
        return [prev[1], id];
      }
      return [...prev, id];
    });
  };

  const handleLoadAnalysis = (item: SavedFarmAnalysis) => {
    setActiveAnalysis(item);
    setActiveTab('advisory');
  };

  const handleDownloadCsv = () => {
    if (activeReportTab === 'history') {
      const headers = [
        'Report Type',
        'Analysis ID',
        'Farm Name',
        'Location',
        'Crop Type',
        'Growth Stage',
        'Overall Risk',
        'Overall Stress Score',
        'Water Stress Score',
        'Nutrient Stress Score',
        'Pest Risk Score',
        'Heat Stress Score',
        'Timestamp',
        'Primary Safe Action',
        'Watermark'
      ];

      const rows = analysesHistory.map((a) => [
        '"FarmPulse Farm Analysis History Log"',
        `"${a.id}"`,
        `"${a.farmName}"`,
        `"${a.location}"`,
        `"${a.cropType}"`,
        `"${a.growthStage}"`,
        `"${a.overallRisk.toUpperCase()}"`,
        `"${a.overallScore}"`,
        `"${a.advisory.categories?.waterStress.score ?? 'N/A'}"`,
        `"${a.advisory.categories?.nutrientStress.score ?? 'N/A'}"`,
        `"${a.advisory.categories?.pestDiseaseRisk.score ?? 'N/A'}"`,
        `"${a.advisory.categories?.heatStress.score ?? 'N/A'}"`,
        `"${a.timestamp}"`,
        `"${a.advisory.primaryAction.replace(/"/g, '""')}"`,
        `"DEMO ONLY — PRIME ELITE PILOT"`
      ]);

      const csvString = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `FarmPulse_Analyses_History_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return;
    }

    const headers = [
      'Report Type',
      'Plot ID',
      'Plot Name',
      'Crop Variety',
      'Growth Stage',
      'Acreage',
      'Risk Level',
      'Demo Stress Score',
      'Data Coverage %',
      'Days Without Rain',
      'Soil Moisture %',
      'Greenness Change %',
      'Peak Temp C',
      'Triggered Rules Count',
      'Primary Safe Action',
      'Timestamp',
      'Watermark'
    ];

    const rows = filteredPlots.map((p) => [
      '"FarmPulse Explainable Advisory Log"',
      `"${p.id}"`,
      `"${p.name}"`,
      `"${p.variety}"`,
      `"${p.growthStage}"`,
      `"${p.areaAcres}"`,
      `"${p.advisory.riskLevel.toUpperCase()}"`,
      `"${p.advisory.stressScore}"`,
      `"${p.advisory.dataCoveragePercent}%"`,
      `"${p.latestObservation.daysWithoutRain}"`,
      `"${p.latestObservation.soilMoisturePercent}%"`,
      `"${p.latestObservation.weeklyGreennessChangePercent}%"`,
      `"${p.latestObservation.temperatureCelsius}°C"`,
      `"${p.advisory.evidenceList.length}"`,
      `"${p.advisory.primaryAction.replace(/"/g, '""')}"`,
      `"${p.latestObservation.timestamp}"`,
      `"SYNTHETIC DEMO DATA — PRIME ELITE PILOT"`
    ]);

    const csvString = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `FarmPulse_Cluster_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  // Compare Items
  const compareItems = useMemo(() => {
    return analysesHistory.filter((item) => selectedForCompare.includes(item.id));
  }, [analysesHistory, selectedForCompare]);

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
              PRIME ELITE
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {language === 'ta' ? 'அறிக்கைகள் & வரலாற்று பதிவுகள்' : 'Reports & Historical Analytics'}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-xl">
            {language === 'ta'
              ? 'உங்கள் முந்தைய பண்ணை ஆய்வுகள், விளக்கமளிக்கும் பதிவுகள் மற்றும் ஒப்பீட்டு அறிக்கைகளை பார்வையிடுங்கள்.'
              : 'Review past field analyses, compare multi-factor stress deltas, and export printable summaries.'}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 self-start sm:self-auto flex-wrap">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl border border-[#E3E8DC] hover:border-[#4E9B5F] bg-[#F7F8F4] hover:bg-white text-xs font-semibold text-[#173F35] flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4 text-[#4E9B5F]" />
            <span>{t.printReport}</span>
          </button>

          <button
            onClick={handleDownloadCsv}
            className="px-4 py-2 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{t.downloadCsv}</span>
          </button>
        </div>
      </div>

      {/* Tabs Selector: Recent History vs Monitored Plots */}
      <div className="flex items-center gap-2 border-b border-[#E3E8DC] pb-2 no-print">
        <button
          type="button"
          onClick={() => setActiveReportTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeReportTab === 'history'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>{language === 'ta' ? 'பண்ணை ஆய்வுகள் வரலாறு' : 'Farm Analyses History'}</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-900/20 text-current font-extrabold">
            {analysesHistory.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveReportTab('plots')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeReportTab === 'plots'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{language === 'ta' ? 'கண்காணிக்கப்படும் நிலங்கள்' : 'Monitored Plots Log'}</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-900/20 text-current font-extrabold">
            {plots.length}
          </span>
        </button>
      </div>

      {/* TAB 1: FARM ANALYSES HISTORY LOG */}
      {activeReportTab === 'history' && (
        <div className="space-y-4">
          {/* Top Actions: Compare Trigger & Clear History */}
          <div className="flex items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-[#E3E8DC] shadow-xs no-print">
            <div className="flex items-center gap-2 text-xs text-[#566761]">
              <GitCompare className="w-4 h-4 text-[#4E9B5F]" />
              <span>
                {language === 'ta'
                  ? 'இரண்டு ஆய்வுகளை தேர்வு செய்து ஒப்பீடு செய்க:'
                  : 'Select 2 analyses to compare side-by-side:'}
              </span>
              <span className="font-bold text-[#173F35]">
                {selectedForCompare.length}/2 {language === 'ta' ? 'தேர்வு' : 'selected'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {selectedForCompare.length === 2 && (
                <button
                  type="button"
                  onClick={() => setShowCompareModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <GitCompare className="w-3.5 h-3.5" />
                  <span>{language === 'ta' ? 'ஒப்பீடு காண்க' : 'View Comparison'}</span>
                </button>
              )}
              {analysesHistory.length > 1 && (
                <button
                  type="button"
                  onClick={clearHistory}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2.5 py-1.5 rounded-lg hover:bg-rose-50"
                  title="Clear history and keep sample only"
                >
                  {language === 'ta' ? 'வரலாறு அழிக்க' : 'Reset History'}
                </button>
              )}
            </div>
          </div>

          {/* History Items List */}
          <div className="space-y-3">
            {analysesHistory.map((item) => {
              const isSelected = selectedForCompare.includes(item.id);
              const cats = item.advisory.categories;

              return (
                <div
                  key={item.id}
                  className={`bg-white rounded-2xl border p-4 sm:p-5 shadow-xs transition-all ${
                    isSelected ? 'border-emerald-600 ring-2 ring-emerald-500/20' : 'border-[#E3E8DC]'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E3E8DC]">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleCompare(item.id)}
                        className="mt-1 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-gray-300"
                        title="Select for side-by-side comparison"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-extrabold text-[#173F35]">{item.farmName}</h3>
                          <StatusBadge level={item.overallRisk} size="sm" />
                          {item.isSample && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                              {language === 'ta' ? 'மாதிரி' : 'Sample'}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#566761] mt-0.5">
                          {item.location} • {item.cropType} • {new Date(item.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto">
                      <button
                        type="button"
                        onClick={() => handleLoadAnalysis(item)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors"
                      >
                        <span>{language === 'ta' ? 'ஆலோசனையை திறக்க' : 'Inspect Advisory'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                      {!item.isSample && (
                        <button
                          type="button"
                          onClick={() => deleteHistoryItem(item.id)}
                          className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Delete from history"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 4 Stress Scores Row */}
                  {cats && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-3 pt-1">
                      <div className="p-2 rounded-xl bg-[#F7F8F4] flex items-center justify-between text-xs">
                        <span className="text-[#566761] font-semibold flex items-center gap-1">
                          <Droplet className="w-3 h-3 text-blue-600" />
                          <span>{t.waterStress}</span>
                        </span>
                        <span className="font-extrabold text-[#173F35]">{cats.waterStress.score}/100</span>
                      </div>
                      <div className="p-2 rounded-xl bg-[#F7F8F4] flex items-center justify-between text-xs">
                        <span className="text-[#566761] font-semibold flex items-center gap-1">
                          <Leaf className="w-3 h-3 text-emerald-600" />
                          <span>{t.nutrientStress}</span>
                        </span>
                        <span className="font-extrabold text-[#173F35]">{cats.nutrientStress.score}/100</span>
                      </div>
                      <div className="p-2 rounded-xl bg-[#F7F8F4] flex items-center justify-between text-xs">
                        <span className="text-[#566761] font-semibold flex items-center gap-1">
                          <Bug className="w-3 h-3 text-rose-600" />
                          <span>{t.pestDiseaseRisk}</span>
                        </span>
                        <span className="font-extrabold text-[#173F35]">{cats.pestDiseaseRisk.score}/100</span>
                      </div>
                      <div className="p-2 rounded-xl bg-[#F7F8F4] flex items-center justify-between text-xs">
                        <span className="text-[#566761] font-semibold flex items-center gap-1">
                          <ThermometerSun className="w-3 h-3 text-amber-600" />
                          <span>{t.heatStress}</span>
                        </span>
                        <span className="font-extrabold text-[#173F35]">{cats.heatStress.score}/100</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: MONITORED PLOTS EXPORT CANVAS (Printable) */}
      {activeReportTab === 'plots' && (
        <div className="space-y-4">
          {/* Filter Bar (Hidden in print) */}
          <div className="bg-white p-4 rounded-2xl border border-[#E3E8DC] shadow-xs no-print space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-[#566761] block">
                  {t.filterByPlot}
                </label>
                <select
                  value={selectedPlotFilter}
                  onChange={(e) => setSelectedPlotFilter(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723]"
                >
                  <option value="all">{t.allPlots}</option>
                  {plots.map((p) => (
                    <option key={p.id} value={p.id}>
                      {language === 'ta' ? p.nameTa : p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-[#566761] block">
                  {t.filterAllRisk}
                </label>
                <select
                  value={selectedRiskFilter}
                  onChange={(e) => setSelectedRiskFilter(e.target.value as 'all' | RiskLevel)}
                  className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723]"
                >
                  <option value="all">{t.filterAllRisk}</option>
                  <option value="low">{t.riskLow}</option>
                  <option value="watch">{t.riskWatch}</option>
                  <option value="high">{t.riskHigh}</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-[#566761] block">
                  {t.filterAllCrops}
                </label>
                <select
                  value={selectedCropFilter}
                  onChange={(e) => setSelectedCropFilter(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723]"
                >
                  <option value="all">{t.filterAllCrops}</option>
                  {availableCrops.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-[#566761] block">
                  {t.filterByDateRange}
                </label>
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white text-[#1C2723]"
                >
                  <option value="7d">Past 7 Days (Oct 15 - 21)</option>
                  <option value="14d">Past 14 Days</option>
                  <option value="30d">Current Crop Cycle</option>
                </select>
              </div>
            </div>
          </div>

          {/* Printable Report Canvas */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#E3E8DC] shadow-xs space-y-6 relative">
            {/* Subtle Print Watermark */}
            <div className="absolute right-6 top-6 text-stone-200 font-extrabold text-2xl tracking-widest select-none pointer-events-none uppercase">
              DEMO DATA — PRIME ELITE
            </div>

            {/* Report Header */}
            <div className="border-b-2 border-[#173F35] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                    PRIME ELITE
                  </span>
                  <h2 className="text-xl font-extrabold text-[#173F35]">
                    FarmPulse — Explainable Crop Stress Advisory Report
                  </h2>
                </div>
                <p className="text-xs text-[#566761] mt-0.5">
                  Pilot Cluster: Kaveripakkam, Ranipet Dist., Tamil Nadu • Generated: {new Date().toLocaleDateString()}
                </p>
              </div>
            </div>

            {/* Table of Filtered Plots */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#E3E8DC] text-[#566761] bg-[#F7F8F4]">
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'நிலம்' : 'Plot'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'பயிர் / ரகம்' : 'Crop / Variety'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'பரப்பளவு' : 'Acreage'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'பாதிப்பு நிலை' : 'Risk Level'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'மழை இடைவெளி' : 'Rain Gap'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'மண் ஈரப்பதம்' : 'Soil Moisture'}</th>
                    <th className="py-2.5 px-3 font-semibold">{language === 'ta' ? 'முதன்மை நடவடிக்கை' : 'Primary Safe Action'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E8DC]">
                  {filteredPlots.map((plot) => (
                    <tr key={plot.id} className="hover:bg-[#F7F8F4] transition-colors">
                      <td className="py-3 px-3 font-bold text-[#1C2723]">
                        {language === 'ta' ? plot.nameTa : plot.name}
                      </td>
                      <td className="py-3 px-3 text-[#566761]">
                        {language === 'ta' ? plot.varietyTa : plot.variety}
                      </td>
                      <td className="py-3 px-3 text-[#566761]">{formatArea(plot.areaAcres)}</td>
                      <td className="py-3 px-3">
                        <StatusBadge level={plot.advisory.riskLevel} size="sm" />
                      </td>
                      <td className="py-3 px-3 text-[#566761]">
                        {plot.latestObservation.daysWithoutRain} {language === 'ta' ? 'நாட்கள்' : 'days'}
                      </td>
                      <td className="py-3 px-3 text-[#566761]">
                        {plot.latestObservation.soilMoisturePercent}%
                      </td>
                      <td className="py-3 px-3 text-[#1C2723] max-w-xs truncate" title={plot.advisory.primaryAction}>
                        {language === 'ta' ? plot.advisory.primaryActionTa : plot.advisory.primaryAction}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Disclaimer & Watermark Footer */}
            <div className="pt-4 border-t border-[#E3E8DC] flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#83948E]">
              <span>Team PRIME ELITE • FarmPulse Explainable Advisory Engine</span>
              <span className="font-semibold text-emerald-800">
                PROTOTYPE DEMONSTRATION — ZERO CHEMICAL PROMOTION GUARANTEE
              </span>
            </div>
          </div>
        </div>
      )}

      {/* SIDE-BY-SIDE COMPARISON MODAL */}
      {showCompareModal && compareItems.length === 2 && (
        <div 
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setShowCompareModal(false)}
        >
          <div 
            className="bg-white rounded-2xl max-w-4xl w-full p-6 space-y-5 shadow-2xl border border-[#E3E8DC] animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
              <div className="flex items-center gap-2">
                <GitCompare className="w-5 h-5 text-[#4E9B5F]" />
                <h3 className="text-base font-extrabold text-[#173F35]">
                  {language === 'ta' ? 'பண்ணை ஆய்வுகள் பக்கவாட்டு ஒப்பீடு' : 'Side-by-Side Analysis Comparison'}
                </h3>
              </div>
              <button
                onClick={() => setShowCompareModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {compareItems.map((item, idx) => (
                <div key={item.id} className="p-4 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#83948E]">
                      Scenario {idx + 1}
                    </span>
                    <StatusBadge level={item.overallRisk} size="sm" />
                  </div>

                  <div>
                    <h4 className="text-sm font-extrabold text-[#173F35]">{item.farmName}</h4>
                    <p className="text-[11px] text-[#566761]">{item.cropType}</p>
                    <p className="text-[10px] text-[#83948E]">{new Date(item.timestamp).toLocaleDateString()}</p>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-[#E3E8DC] text-xs">
                    <div className="flex justify-between">
                      <span className="text-[#566761]">{t.waterStress}:</span>
                      <strong className="text-[#173F35]">{item.advisory.categories?.waterStress.score ?? 'N/A'}/100</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#566761]">{t.nutrientStress}:</span>
                      <strong className="text-[#173F35]">{item.advisory.categories?.nutrientStress.score ?? 'N/A'}/100</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#566761]">{t.pestDiseaseRisk}:</span>
                      <strong className="text-[#173F35]">{item.advisory.categories?.pestDiseaseRisk.score ?? 'N/A'}/100</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#566761]">{t.heatStress}:</span>
                      <strong className="text-[#173F35]">{item.advisory.categories?.heatStress.score ?? 'N/A'}/100</strong>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#E3E8DC]">
                    <span className="text-[10px] font-bold text-[#566761] block mb-1">
                      {language === 'ta' ? 'முதன்மை நடவடிக்கை:' : 'Primary Action:'}
                    </span>
                    <p className="text-[11px] text-[#1C2723] leading-snug">
                      {language === 'ta' ? item.advisory.primaryActionTa : item.advisory.primaryAction}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setShowCompareModal(false)}
                className="px-4 py-2 rounded-xl bg-[#173F35] text-white text-xs font-bold"
              >
                {language === 'ta' ? 'மூடுக' : 'Close Comparison'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
