import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Sprout,
  Sparkles, 
  HelpCircle,
  Map, 
  ScanSearch, 
  CloudSun, 
  Truck, 
  FileText, 
  Settings, 
  ShieldCheck,
  ChevronRight,
  Flame,
  Award,
  Bot,
  Compass,
  CloudRain,
  Smartphone,
  TrendingUp
} from 'lucide-react';
import { useApp, NavigationTab } from '../../context/AppContext';
import { ApkInstallModal } from '../pwa/ApkInstallModal';

interface SidebarProps {
  onOpenExplainability: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenExplainability }) => {
  const { activeTab, setActiveTab, t, language } = useApp();
  const [showApkModal, setShowApkModal] = useState(false);

  const navItems: { id: NavigationTab; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'analysis', label: t.navAnalysis, icon: Sprout, badge: 'New' },
    { id: 'advisory', label: t.navAdvisory, icon: Sparkles, badge: '4 Types' },
    { id: 'explanation', label: t.navExplanation, icon: HelpCircle, badge: '5 Rules' },
    { id: 'ask-ai', label: t.navAskAi, icon: Bot, badge: 'AI Copilot' },
    { id: 'fieldmap', label: t.navFieldMap, icon: Compass, badge: 'Know Place' },
    { id: 'plots', label: t.navPlots, icon: Map },
    { id: 'leafcheck', label: t.navLeafCheck, icon: ScanSearch },
    { id: 'weather', label: t.navWeather, icon: CloudSun },
    { id: 'weathermap', label: t.navWeatherMap, icon: CloudRain, badge: 'Radar' },
    { id: 'mandi', label: t.navMandi, icon: TrendingUp, badge: 'APMC/eNAM' },
    { id: 'reports', label: t.navReports, icon: FileText },
    { id: 'fpo', label: t.navFpo, icon: Truck },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 bg-white border-r border-[#E3E8DC] min-h-[calc(100vh-57px)] p-4 justify-between transition-all select-none">
      <div className="space-y-5">
        {/* Team PRIME ELITE Header Tag */}
        <div className="p-2.5 rounded-xl bg-gradient-to-r from-[#173F35] to-[#255e50] text-white flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-[#65A66F]" />
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider block text-emerald-200">
                Created by
              </span>
              <span className="text-xs font-black tracking-wide">PRIME ELITE</span>
            </div>
          </div>
          <span className="text-[9px] font-bold bg-[#65A66F] text-[#173F35] px-1.5 py-0.5 rounded">
            AI AGRI
          </span>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all group ${
                  isActive
                    ? 'bg-[#173F35] text-white shadow-xs'
                    : 'text-[#566761] hover:text-[#173F35] hover:bg-[#F7F8F4]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-[#65A66F]' : 'text-[#83948E] group-hover:text-[#4E9B5F]'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge && !isActive && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 opacity-60" />}
              </button>
            );
          })}
        </nav>

        {/* Explainability Quick Primer */}
        <div className="p-3.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-[#173F35]">
            <HelpCircle className="w-4 h-4 text-[#4E9B5F]" />
            <span>{t.howThisWasAssessed}</span>
          </div>
          <p className="text-[11px] text-[#566761] leading-relaxed">
            {language === 'ta'
              ? 'விவசாயிகளுக்கு ஒளிவுமறைவற்ற விதிகள் மூலம் ஆலோசனை வழங்கப்படுகிறது. சூத்திரத்தை பார்க்க கிளிக் செய்க.'
              : 'FarmPulse maps deterministic ground rules to stress indicators. Tap to inspect rule weights.'}
          </p>
          <button
            onClick={onOpenExplainability}
            className="w-full text-center text-xs font-semibold py-1.5 px-2 bg-white hover:bg-emerald-50 text-[#173F35] border border-[#E3E8DC] hover:border-emerald-300 rounded-lg transition-colors"
          >
            {language === 'ta' ? 'சூத்திரத்தை காண்க' : 'Inspect Rules & Math'}
          </button>
        </div>

        {/* Android APK & Install Card */}
        <div className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-50 to-[#F7F8F4] border border-emerald-300 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
              <Smartphone className="w-4 h-4 text-emerald-700" />
              <span>{language === 'ta' ? 'ஆண்ட்ராய்டு APK' : 'Android APK / App'}</span>
            </div>
            <span className="text-[9px] font-bold bg-emerald-600 text-white px-1.5 py-0.2 rounded">
              v2.4
            </span>
          </div>
          <p className="text-[11px] text-[#566761] leading-relaxed">
            {language === 'ta'
              ? 'உங்கள் கைபேசியில் முழுத்திரை செயலியாக நிறுவலாம்.'
              : 'Install standalone app on Android home screen with offline caching.'}
          </p>
          <button
            onClick={() => setShowApkModal(true)}
            className="w-full text-center text-xs font-bold py-1.5 px-2 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#8BD498]" />
            <span>{language === 'ta' ? 'APK நிறுவுதல்' : 'Install Android App'}</span>
          </button>
        </div>
      </div>

      {/* Footer Info Box */}
      <div className="pt-4 border-t border-[#E3E8DC] space-y-2 text-[11px] text-[#83948E]">
        <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>{language === 'ta' ? 'காவேரிப்பாக்கம் உழவர் குழு' : 'Kaveripakkam FPO Node'}</span>
        </div>
        <p className="leading-tight">
          {language === 'ta' 
            ? 'அங்கீகரிக்கப்படாத பூச்சிக்கொல்லி வணிக பரிந்துரைகள் தவிர்க்கப்படுகின்றன.' 
            : 'Zero chemical brand endorsements. Farmer safety first.'}
        </p>
      </div>

      <ApkInstallModal isOpen={showApkModal} onClose={() => setShowApkModal(false)} />
    </aside>
  );
};
