# Backend

FastAPI service for FarmPulse.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Windows PowerShell: Copy-Item .env.example .env
uvicorn app.main:app --reload --port 8000
```

Docs: `http://127.0.0.1:8000/docs`. The local demo plot repository is in-memory and resets when the server restarts. Persistent PostgreSQL/Firebase support is not wired in this starter.
