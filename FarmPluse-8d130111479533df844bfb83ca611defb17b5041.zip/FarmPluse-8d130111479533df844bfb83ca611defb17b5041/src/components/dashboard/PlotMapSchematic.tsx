import React from 'react';
import { useApp } from '../../context/AppContext';
import { Plot } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { MapPin, Info, ArrowUpRight } from 'lucide-react';

import { getCropInfo } from '../../data/cropLandData';

interface PlotMapSchematicProps {
  plots: Plot[];
  selectedPlotId: string;
  onSelectPlot: (plot: Plot) => void;
}

export const PlotMapSchematic: React.FC<PlotMapSchematicProps> = ({
  plots,
  selectedPlotId,
  onSelectPlot,
}) => {
  const { t, language, formatArea, setActiveTab } = useApp();

  return (
    <div className="bg-white rounded-2xl p-5 border border-[#E3E8DC] shadow-xs">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#E3E8DC]">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-base text-[#173F35]">
              {language === 'te' ? 'పొలాల ఆరోగ్యం & నాటిన పంటలు' : t.fieldHealthOverview}
            </h3>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-0.5 flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span>{language === 'te' ? 'ప్రతి పొలంలో ఏ పంట నాటారో మరియు నేల తేమ వివరాలు' : t.illustrativeMapNote}</span>
          </p>
        </div>

        {/* Action button & Legend */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('fieldmap')}
            className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
          >
            <span>{language === 'te' ? 'భూమి మ్యాప్ తెరవండి' : language === 'ta' ? 'புல வரைபடம்' : 'Open Land Map'}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          <div className="hidden sm:flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2D8A4E]" />
              <span className="text-[#566761]">{t.riskLow}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D97706]" />
              <span className="text-[#566761]">{t.riskWatch}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626]" />
              <span className="text-[#566761]">{t.riskHigh}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Schematic Field Grid Canvas */}
      <div className="mt-4 relative bg-[#F7F8F4] border border-[#E3E8DC] rounded-xl p-4 sm:p-6 overflow-hidden">
        {/* Subtle agrarian background patterns */}
        <div 
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#4E9B5F 0.75px, transparent 0.75px), radial-gradient(#4E9B5F 0.75px, #F7F8F4 0.75px)`,
            backgroundSize: '24px 24px',
            backgroundPosition: '0 0, 12px 12px',
          }}
        />

        {/* Schematic Canal Line */}
        <div className="hidden sm:flex items-center justify-between text-[11px] text-[#4E9B5F] font-semibold mb-3 px-2 border-b border-dashed border-[#BDDFCA] pb-1">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            {language === 'ta' ? 'பாலாறு பாசன கிளை கால்வாய்' : 'Palar Feeder Canal Line (North Branch)'}
          </span>
          <span className="text-[10px] text-[#83948E]">
            {language === 'ta' ? 'அடுத்த நீர் வரத்து: வியாழன்' : 'Next rotation: Thursday'}
          </span>
        </div>

        {/* Interactive Schematic Plot Cards / Polygons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 relative z-10">
          {plots.map((plot) => {
            const isSelected = plot.id === selectedPlotId;
            const risk = plot.advisory.riskLevel;

            const borderColor = {
              low: isSelected ? 'border-[#2D8A4E] ring-2 ring-[#2D8A4E]/20' : 'border-[#BDDFCA] hover:border-[#2D8A4E]',
              watch: isSelected ? 'border-[#D97706] ring-2 ring-[#D97706]/20' : 'border-[#F7DEB2] hover:border-[#D97706]',
              high: isSelected ? 'border-[#DC2626] ring-2 ring-[#DC2626]/20' : 'border-[#F8B4B4] hover:border-[#DC2626]',
            }[risk];

            const bgGlow = {
              low: 'bg-white hover:bg-[#F3FAF5]',
              watch: 'bg-white hover:bg-[#FFFDF7]',
              high: 'bg-white hover:bg-[#FEF7F7]',
            }[risk];

            const crop = getCropInfo(plot.variety || plot.cropType);

            return (
              <button
                key={plot.id}
                onClick={() => onSelectPlot(plot)}
                className={`text-left p-4 rounded-xl border transition-all shadow-xs relative ${borderColor} ${bgGlow} cursor-pointer group`}
                aria-label={`Select plot ${plot.name}`}
              >
                {/* Header inside card */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <span className="text-2xl p-1 rounded-lg bg-emerald-50 border border-emerald-200 shrink-0">
                      {crop.emoji}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-mono font-semibold text-[#566761]">
                          {plot.id.toUpperCase()}
                        </span>
                        {plot.surveyNumber && (
                          <span className="text-[10px] bg-gray-100 text-gray-700 font-bold px-1.5 py-0.2 rounded">
                            {plot.surveyNumber}
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm text-[#1C2723] group-hover:text-[#173F35]">
                        {language === 'te' && plot.nameTe ? plot.nameTe : language === 'ta' ? plot.nameTa : plot.name}
                      </h4>
                    </div>
                  </div>
                  <StatusBadge level={risk} size="sm" />
                </div>

                {/* Plot Meta */}
                <div className="mt-2 text-xs text-[#566761] space-y-1">
                  <div className="flex items-center justify-between">
                    <span>{language === 'ta' ? 'ரகம்' : 'Crop'}:</span>
                    <span className="font-medium text-[#1C2723]">
                      {language === 'ta' ? plot.varietyTa : plot.variety}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>{language === 'ta' ? 'பரப்பு' : 'Area'}:</span>
                    <span className="font-medium text-[#1C2723]">{formatArea(plot.areaAcres)}</span>
                  </div>
                </div>

                {/* Metric Bars */}
                <div className="mt-3 pt-2.5 border-t border-[#E3E8DC] grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[#83948E] block text-[10px]">
                      {t.soilMoisture}
                    </span>
                    <span className={`font-bold ${plot.latestObservation.soilMoisturePercent < 20 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
                      {plot.latestObservation.soilMoisturePercent}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[#83948E] block text-[10px]">
                      {t.daysWithoutRain}
                    </span>
                    <span className={`font-bold ${plot.latestObservation.daysWithoutRain >= 7 ? 'text-rose-600' : 'text-[#1C2723]'}`}>
                      {plot.latestObservation.daysWithoutRain}d dry
                    </span>
                  </div>
                </div>

                {/* Click indicator */}
                <div className="mt-2.5 flex items-center justify-end text-[11px] font-semibold text-[#4E9B5F] group-hover:translate-x-0.5 transition-transform">
                  <span>{t.viewPlotDetails}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
