import React, { useState } from 'react';
import { 
  Sprout, 
  MapPin, 
  Calendar, 
  Droplet, 
  CloudRain, 
  Thermometer, 
  Wind, 
  Upload, 
  Sparkles, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  ArrowRight, 
  FileText, 
  ShieldAlert,
  HelpCircle,
  Camera,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useApp, SAMPLE_FARM_INPUT } from '../../context/AppContext';
import { GrowthStage, FarmAnalysisInput } from '../../types';
import { evaluateCropStress } from '../../services/advisoryEngine';

const PADDY_VARIETIES = [
  { id: 'co51', label: 'Paddy (CO 51) – Short Duration (105-110d)', durationDays: 105 },
  { id: 'cr1009', label: 'Paddy (CR 1009 / Savitri) – Long Duration (155-160d)', durationDays: 155 },
  { id: 'adt45', label: 'Paddy (ADT 45) – Kuruvai / Summer (110-115d)', durationDays: 110 },
  { id: 'bpt5204', label: 'Paddy (BPT 5204 / Samba Mahsuri) – Premium Grain (145d)', durationDays: 145 },
  { id: 'tkm13', label: 'Paddy (TKM 13) – Drought Resistant (130d)', durationDays: 130 },
  { id: 'other', label: 'Other Paddy / Millets / Pulses Variety', durationDays: 120 },
];

const GROWTH_STAGES: { id: GrowthStage; label: string; labelTa: string; daysRange: string; desc: string }[] = [
  { id: 'nursery', label: 'Nursery (Seedling)', labelTa: 'நாற்றங்கால் பருவம்', daysRange: '1–25 days', desc: 'Delicate root establishment, requires constant shallow saturation.' },
  { id: 'tillering', label: 'Active Tillering', labelTa: 'தூர்கட்டும் பருவம்', daysRange: '26–50 days', desc: 'Rapid tiller production, sensitive to nutrient & moisture deficit.' },
  { id: 'panicle_initiation', label: 'Panicle Initiation', labelTa: 'கதிர் உருவாகும் பருவம்', daysRange: '51–75 days', desc: 'CRITICAL stage! Water deficit here directly reduces grain count.' },
  { id: 'flowering', label: 'Flowering / Anthesis', labelTa: 'பூக்கும் பருவம்', daysRange: '76–95 days', desc: 'High thermal sensitivity (>35°C causes spikelet sterility).' },
  { id: 'grain_filling', label: 'Grain Filling (Milky)', labelTa: 'பால் பிடிக்கும் பருவம்', daysRange: '96–115 days', desc: 'Requires moist soil; avoiding premature drying prevents chaffy grain.' },
  { id: 'mature', label: 'Maturity / Harvest', labelTa: 'முதிர்ச்சி பருவம்', daysRange: '116+ days', desc: 'Terminal drainage before harvest; low water requirement.' },
];

export const FarmAnalysisView: React.FC = () => {
  const { 
    t, 
    language, 
    setActiveTab, 
    saveFarmAnalysis, 
    activeAnalysis, 
    loadSampleFarmAnalysis,
    formatTemp
  } = useApp();

  // Form State initialized with either active analysis input or sample input
  const [formData, setFormData] = useState<FarmAnalysisInput>(() => {
    return {
      farmName: activeAnalysis?.farmName || SAMPLE_FARM_INPUT.farmName,
      location: activeAnalysis?.location || SAMPLE_FARM_INPUT.location,
      cropType: activeAnalysis?.cropType || SAMPLE_FARM_INPUT.cropType,
      growthStage: activeAnalysis?.growthStage || SAMPLE_FARM_INPUT.growthStage,
      plantingDate: activeAnalysis?.advisory.farmInfo?.plantingDate || SAMPLE_FARM_INPUT.plantingDate || '2026-08-25',
      soilMoisturePercent: 18,
      recentRainfallMm: 0,
      daysWithoutRain: 8,
      temperatureCelsius: 36.5,
      humidityPercent: 38,
      leafImage: null,
      leafImageName: 'sample_paddy_leaf_roll.jpg',
      notes: 'Palar sub-basin plot; clay loam; noon leaf tip rolling noticed by farmer.',
    };
  });

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSampleLoaded, setIsSampleLoaded] = useState<boolean>(true);
  const [analysisRan, setAnalysisRan] = useState<boolean>(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.farmName.trim()) {
      errors.farmName = language === 'ta' ? 'பண்ணை பெயரை உள்ளிடவும்' : 'Farm name is required';
    }
    if (!formData.location.trim()) {
      errors.location = language === 'ta' ? 'இடத்தை உள்ளிடவும்' : 'Location is required';
    }
    if (formData.daysWithoutRain !== null && formData.daysWithoutRain !== undefined && formData.daysWithoutRain < 0) {
      errors.daysWithoutRain = language === 'ta' ? 'செல்லுபடியாகும் நாட்கள் உள்ளிடவும்' : 'Cannot be negative';
    }
    if (formData.soilMoisturePercent !== null && formData.soilMoisturePercent !== undefined) {
      if (formData.soilMoisturePercent < 0 || formData.soilMoisturePercent > 100) {
        errors.soilMoisturePercent = language === 'ta' ? '0 முதல் 100 வரை இருக்க வேண்டும்' : 'Must be between 0% and 100%';
      }
    }
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleLoadSample = () => {
    setFormData({ ...SAMPLE_FARM_INPUT });
    setImagePreview(null);
    setIsSampleLoaded(true);
    setValidationErrors({});
    loadSampleFarmAnalysis();
  };

  const handleResetForm = () => {
    setFormData({
      farmName: '',
      location: 'Ranipet, Tamil Nadu',
      cropType: PADDY_VARIETIES[0].label,
      growthStage: 'panicle_initiation',
      plantingDate: '',
      soilMoisturePercent: null,
      recentRainfallMm: null,
      daysWithoutRain: null,
      temperatureCelsius: null,
      humidityPercent: null,
      leafImage: null,
      leafImageName: null,
      notes: '',
    });
    setImagePreview(null);
    setIsSampleLoaded(false);
    setValidationErrors({});
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        setFormData((prev) => ({
          ...prev,
          leafImage: reader.result as string,
          leafImageName: file.name,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunAnalysis = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const advisory = evaluateCropStress({
      crop: formData.cropType,
      growthStage: formData.growthStage,
      daysWithoutRain: formData.daysWithoutRain ?? 4,
      soilMoisturePercent: formData.soilMoisturePercent,
      recentRainfallMm: formData.recentRainfallMm,
      temperatureCelsius: formData.temperatureCelsius,
      humidityPercent: formData.humidityPercent,
      weeklyGreennessChangePercent: formData.soilMoisturePercent && formData.soilMoisturePercent < 20 ? -12.5 : -4.0,
      ndvi: 0.44,
      ndwi: -0.06,
      leafImage: formData.leafImage,
      farmName: formData.farmName,
      location: formData.location,
      plantingDate: formData.plantingDate,
    });

    const newAnalysis = {
      id: `analysis-${Date.now()}`,
      timestamp: new Date().toISOString(),
      farmName: formData.farmName,
      location: formData.location,
      cropType: formData.cropType,
      growthStage: formData.growthStage,
      overallRisk: advisory.riskLevel,
      overallScore: advisory.stressScore,
      advisory,
      isSample: isSampleLoaded,
    };

    saveFarmAnalysis(newAnalysis);
    setAnalysisRan(true);
  };

  // Missing data signals analysis
  const missingSensors = [
    {
      name: language === 'ta' ? 'மண் ஈரப்பத அளவீடு' : 'Soil Moisture Sensor',
      present: formData.soilMoisturePercent !== null && formData.soilMoisturePercent !== undefined,
      note: language === 'ta' 
        ? 'இல்லை எனில் மழை இடைவெளி மற்றும் பயிர் பருவத்தை வைத்து கணக்கிடப்படும்' 
        : 'If omitted, engine estimates stress from rain-gap and crop stage demand without fabricating sensor values.',
    },
    {
      name: language === 'ta' ? 'சமீபத்திய மழை அளவு' : 'Recent Rainfall Gauge',
      present: formData.recentRainfallMm !== null && formData.recentRainfallMm !== undefined,
      note: language === 'ta' 
        ? 'மழை இடைவெளி நாட்கள் அடிப்படையில் மதிப்பிடப்படுகிறது' 
        : 'Rainfall deficit estimated using rain-free days interval.',
    },
    {
      name: language === 'ta' ? 'வெப்பநிலை & காற்றின் ஈரப்பதம்' : 'Microclimate Thermometer / RH',
      present: formData.temperatureCelsius !== null && formData.temperatureCelsius !== undefined,
      note: language === 'ta' 
        ? 'இல்லை எனில் வட்டார வானிலை நிலைய கணிப்பு பயன்படுத்தப்படும்' 
        : 'If omitted, local IMD automated weather station readings are referenced.',
    },
    {
      name: language === 'ta' ? 'இலை நெருக்கப் புகைப்படம்' : 'Close-up Leaf Photo',
      present: Boolean(formData.leafImage || formData.leafImageName),
      note: language === 'ta' 
        ? 'பதிவேற்றினால் பூச்சி மற்றும் நோய் அறிகுறி துல்லியம் கூடும்' 
        : 'Provides visual confirmation for foliar lesions, blast spots, and leaf rolling.',
    },
  ];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Title & PRIME ELITE Team Header */}
      <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                Team PRIME ELITE
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#173F35] text-white">
                Explainable AI Core
              </span>
              {isSampleLoaded && (
                <span className="text-xs font-medium px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                  {language === 'ta' ? 'மாதிரி பண்ணை சுமை' : 'Sample Farm Loaded'}
                </span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35] tracking-tight">
              {language === 'ta' ? 'பண்ணை தகவல் & பயிர் அழுத்த ஆய்வு' : 'Farm Information & Multi-Factor Stress Analysis'}
            </h1>
            <p className="text-xs sm:text-sm text-[#566761] mt-1 leading-relaxed">
              {language === 'ta'
                ? 'உங்கள் பண்ணையின் உண்மை அளவீடுகளை உள்ளிடுங்கள். விடுபட்ட தகவல்களை தானாக புனையாமல், உள்ளீடுகளின் அடிப்படையில் 4 வகை பயிர் அழுத்தங்கள் கணக்கிடப்படும்.'
                : 'Enter field observations to evaluate 4 stress categories (Water, Nutrient, Pest/Disease, Heat). Missing values are never silently invented.'}
            </p>
          </div>

          {/* Quick Action Buttons: Try Sample Farm & Reset */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleLoadSample}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all active:scale-95"
              title="Prepopulate with verified Tamil Nadu paddy data"
            >
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>{t.trySampleFarm}</span>
            </button>
            <button
              type="button"
              onClick={handleResetForm}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-[#F7F8F4] hover:bg-[#EBF4ED] text-[#566761] hover:text-[#173F35] border border-[#E3E8DC] transition-all"
              title="Clear all fields"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{language === 'ta' ? 'அழிக்க' : 'Reset Form'}</span>
            </button>
          </div>
        </div>

        {/* Informative Guidance Banner */}
        <div className="mt-4 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] flex items-start gap-2.5 text-xs text-[#566761]">
          <Info className="w-4 h-4 text-[#4E9B5F] shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-[#173F35]">
              {language === 'ta' ? 'விளக்கக் கோட்பாடு:' : 'Explainability Discipline:'}
            </strong>{' '}
            {language === 'ta'
              ? 'FarmPulse எந்த சென்சார் அளவீட்டையும் போலியாக உருவாக்காது. சென்சார் இல்லையென்றால், அது வெளிப்படையாக விடுபட்டதாக குறிக்கப்பட்டு வானிலை & வளர்ச்சி பருவ விதிகள் மூலம் ஆய்வு செய்யப்படும்.'
              : 'FarmPulse strictly avoids synthetic sensor fabrication. Missing readings are highlighted transparently and evaluated using validated agronomic thresholds.'}
          </p>
        </div>
      </div>

      {/* Main Analysis Form */}
      <form onSubmit={handleRunAnalysis} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1: Farm Identification & Crop Details */}
          <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 space-y-4 shadow-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-[#E3E8DC]">
              <Sprout className="w-5 h-5 text-[#4E9B5F]" />
              <h2 className="text-sm font-bold text-[#173F35]">
                {language === 'ta' ? '1. பண்ணை & பயிர் விவரங்கள்' : '1. Farm & Crop Identification'}
              </h2>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'பண்ணை / நிலத்தின் பெயர் *' : 'Farm or Plot Name *'}
              </label>
              <input
                type="text"
                value={formData.farmName}
                onChange={(e) => setFormData({ ...formData, farmName: e.target.value })}
                placeholder="e.g. Marimuthu East Field"
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
              {validationErrors.farmName && (
                <p className="text-[11px] text-rose-600 mt-1">{validationErrors.farmName}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'அமைவிடம் / கிராமம் *' : 'Location / Village *'}
              </label>
              <div className="relative">
                <MapPin className="w-3.5 h-3.5 text-[#83948E] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g. Kaveripakkam, Ranipet, Tamil Nadu"
                  className="w-full text-xs pl-8 pr-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
                />
              </div>
              {validationErrors.location && (
                <p className="text-[11px] text-rose-600 mt-1">{validationErrors.location}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'பயிர் & ரகம்' : 'Crop Type & Variety'}
              </label>
              <select
                value={formData.cropType}
                onChange={(e) => setFormData({ ...formData, cropType: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              >
                {PADDY_VARIETIES.map((v) => (
                  <option key={v.id} value={v.label}>
                    {v.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'பயிர் வளர்ச்சி பருவம்' : 'Crop Growth Stage'}
              </label>
              <select
                value={formData.growthStage}
                onChange={(e) => setFormData({ ...formData, growthStage: e.target.value as GrowthStage })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              >
                {GROWTH_STAGES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {language === 'ta' ? `${s.labelTa} (${s.daysRange})` : `${s.label} (${s.daysRange})`}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-[#566761] mt-1 italic">
                {GROWTH_STAGES.find((s) => s.id === formData.growthStage)?.desc}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'விதைத்த / நாற்று நட்ட தேதி (தெரிந்தால்)' : 'Planting Date (if known)'}
              </label>
              <div className="relative">
                <Calendar className="w-3.5 h-3.5 text-[#83948E] absolute left-3 top-2.5" />
                <input
                  type="date"
                  value={formData.plantingDate || ''}
                  onChange={(e) => setFormData({ ...formData, plantingDate: e.target.value })}
                  className="w-full text-xs pl-8 pr-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
                />
              </div>
            </div>
          </div>

          {/* Column 2: Sensor & Environmental Inputs (Optional with Clear Validation) */}
          <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 space-y-4 shadow-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-[#E3E8DC]">
              <Droplet className="w-5 h-5 text-[#4E9B5F]" />
              <h2 className="text-sm font-bold text-[#173F35]">
                {language === 'ta' ? '2. கள அளவீடுகள் & வானிலை' : '2. Field & Weather Readings'}
              </h2>
            </div>

            {/* Soil Moisture */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-[#1C2723] flex items-center gap-1">
                  <Droplet className="w-3.5 h-3.5 text-blue-600" />
                  <span>{language === 'ta' ? 'மண் ஈரப்பதம் (%)' : 'Soil Moisture (%)'}</span>
                </label>
                <span className="text-[10px] text-[#83948E]">
                  {formData.soilMoisturePercent !== null ? `${formData.soilMoisturePercent}%` : language === 'ta' ? 'இணைக்கப்படவில்லை' : 'Not measured'}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="100"
                step="0.5"
                value={formData.soilMoisturePercent ?? ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    soilMoisturePercent: e.target.value === '' ? null : parseFloat(e.target.value),
                  })
                }
                placeholder="e.g. 18 (Leave blank if no sensor)"
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
              <p className="text-[10px] text-[#83948E] mt-1">
                {language === 'ta' ? 'பரிந்துரை: நெல் வளர்ச்சிக்கு 20%க்கு மேல் தேவை.' : 'Paddy threshold: <20% triggers acute water deficit.'}
              </p>
            </div>

            {/* Days without rain */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-[#1C2723] flex items-center gap-1">
                  <CloudRain className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{language === 'ta' ? 'மழை இல்லாத நாட்கள்' : 'Days Without Rain'}</span>
                </label>
                <span className="text-[10px] text-[#83948E]">
                  {formData.daysWithoutRain !== null ? `${formData.daysWithoutRain} days` : '0 days'}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="60"
                value={formData.daysWithoutRain ?? ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    daysWithoutRain: e.target.value === '' ? null : parseInt(e.target.value, 10),
                  })
                }
                placeholder="e.g. 8"
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
            </div>

            {/* Ambient Temperature */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-[#1C2723] flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                  <span>{language === 'ta' ? 'உச்ச வெப்பநிலை (°C)' : 'Ambient Peak Temp (°C)'}</span>
                </label>
                <span className="text-[10px] text-[#83948E]">
                  {formData.temperatureCelsius !== null && formData.temperatureCelsius !== undefined 
                    ? formatTemp(formData.temperatureCelsius) 
                    : 'IMD station default'}
                </span>
              </div>
              <input
                type="number"
                min="15"
                max="50"
                step="0.5"
                value={formData.temperatureCelsius ?? ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    temperatureCelsius: e.target.value === '' ? null : parseFloat(e.target.value),
                  })
                }
                placeholder="e.g. 36.5"
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
              <p className="text-[10px] text-[#83948E] mt-1">
                {language === 'ta' ? '≥36°C பூக்கும் பருவத்தில் மகரந்த கருகலை ஏற்படுத்தும்.' : '≥36°C during panicle initiation triggers heat stress.'}
              </p>
            </div>

            {/* Relative Humidity */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-[#1C2723] flex items-center gap-1">
                  <Wind className="w-3.5 h-3.5 text-teal-600" />
                  <span>{language === 'ta' ? 'காற்றின் ஈரப்பதம் (%)' : 'Relative Humidity (%)'}</span>
                </label>
                <span className="text-[10px] text-[#83948E]">
                  {formData.humidityPercent !== null ? `${formData.humidityPercent}%` : 'Station baseline'}
                </span>
              </div>
              <input
                type="number"
                min="10"
                max="100"
                value={formData.humidityPercent ?? ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    humidityPercent: e.target.value === '' ? null : parseFloat(e.target.value),
                  })
                }
                placeholder="e.g. 38"
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
            </div>
          </div>

          {/* Column 3: Optional Leaf Photo & Sensor Validation Breakdown */}
          <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 space-y-4 shadow-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-[#E3E8DC]">
              <Camera className="w-5 h-5 text-[#4E9B5F]" />
              <h2 className="text-sm font-bold text-[#173F35]">
                {language === 'ta' ? '3. இலை படம் & தரவு சரிபார்ப்பு' : '3. Leaf Photo & Data Integrity'}
              </h2>
            </div>

            {/* Photo Uploader */}
            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'பயிரின் இலை புகைப்படம் (விருப்பம்)' : 'Crop Leaf Photo (Optional)'}
              </label>

              {imagePreview || formData.leafImageName ? (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {imagePreview ? (
                      <img
                        src={imagePreview}
                        alt="Uploaded leaf"
                        className="w-12 h-12 object-cover rounded-lg border border-emerald-300"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800 font-bold text-xs">
                        JPG
                      </div>
                    )}
                    <div>
                      <p className="text-xs font-bold text-emerald-900 truncate max-w-[150px]">
                        {formData.leafImageName || 'leaf_photo.jpg'}
                      </p>
                      <p className="text-[10px] text-emerald-700">
                        {language === 'ta' ? 'இலை ஸ்கிரீனிங்கிற்கு தயார்' : 'Ready for foliar screening'}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setImagePreview(null);
                      setFormData({ ...formData, leafImage: null, leafImageName: null });
                    }}
                    className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1"
                  >
                    {language === 'ta' ? 'நீக்கு' : 'Remove'}
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-[#E3E8DC] hover:border-emerald-500 rounded-xl cursor-pointer bg-[#F7F8F4] hover:bg-emerald-50/50 transition-colors">
                  <Upload className="w-6 h-6 text-[#83948E] mb-1.5" />
                  <span className="text-xs font-semibold text-[#173F35]">
                    {language === 'ta' ? 'இலை புகைப்படத்தை பதிவேற்றுக' : 'Upload close-up leaf photo'}
                  </span>
                  <span className="text-[10px] text-[#83948E] mt-0.5">JPG or PNG (max 5MB)</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {/* Field Notes */}
            <div>
              <label className="block text-xs font-semibold text-[#1C2723] mb-1">
                {language === 'ta' ? 'கள குறிப்புகள்' : 'Field Observations / Notes'}
              </label>
              <textarea
                rows={2}
                value={formData.notes || ''}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="e.g. Irrigation canal turn is delayed; noticed yellowing on border rows..."
                className="w-full text-xs px-3 py-2 rounded-xl border border-[#E3E8DC] focus:outline-none focus:ring-2 focus:ring-[#173F35] bg-[#FDFDFD]"
              />
            </div>

            {/* Sensor & Input Coverage Transparency Card */}
            <div className="pt-2 border-t border-[#E3E8DC] space-y-2">
              <span className="text-xs font-bold text-[#173F35] block">
                {language === 'ta' ? 'உள்ளீட்டு தரவு நம்பகத்தன்மை நிலை:' : 'Input Integrity & Sensor Coverage:'}
              </span>
              <div className="space-y-1.5">
                {missingSensors.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start justify-between text-[11px] p-1.5 rounded-lg bg-[#F7F8F4]"
                  >
                    <div>
                      <span className="font-semibold text-[#1C2723] block">{item.name}</span>
                      <span className="text-[10px] text-[#566761] leading-tight block">{item.note}</span>
                    </div>
                    {item.present ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded shrink-0">
                        <CheckCircle2 className="w-3 h-3" />
                        {language === 'ta' ? 'கிடைத்தது' : 'Active'}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-medium text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded shrink-0">
                        <AlertCircle className="w-3 h-3" />
                        {language === 'ta' ? 'விடுபட்டது' : 'Missing'}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Submit Bar */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-2 text-xs text-[#566761]">
            <ShieldAlert className="w-4 h-4 text-[#4E9B5F]" />
            <span>
              {language === 'ta'
                ? 'அனைத்து கணக்கீடுகளும் தமிழ்நாடு வேளாண்மை பல்கலைக்கழக கள வழிகாட்டுதல்களின்படி ஆய்வு செய்யப்படும்.'
                : 'Deterministic calculations run across Water, Nutrient, Pest, and Heat dimensions.'}
            </span>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#173F35] hover:bg-[#1f5245] text-white text-sm font-bold shadow-md transition-all active:scale-98"
          >
            <span>{t.runAnalysis}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </form>

      {/* Post-Analysis Result Preview Card (If run or loaded) */}
      {activeAnalysis && (
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center font-extrabold text-sm ${
                  activeAnalysis.overallRisk === 'high'
                    ? 'bg-rose-100 text-rose-800'
                    : activeAnalysis.overallRisk === 'watch'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {activeAnalysis.overallScore}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-extrabold text-[#173F35]">
                    {language === 'ta' ? activeAnalysis.advisory.headlineTa : activeAnalysis.advisory.headline}
                  </h3>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      activeAnalysis.overallRisk === 'high'
                        ? 'bg-rose-600 text-white'
                        : activeAnalysis.overallRisk === 'watch'
                        ? 'bg-amber-500 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {activeAnalysis.overallRisk.toUpperCase()} RISK
                  </span>
                </div>
                <p className="text-xs text-[#566761] mt-0.5">
                  {activeAnalysis.farmName} • {activeAnalysis.location} • {activeAnalysis.cropType}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('advisory')}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors"
              >
                <span>{language === 'ta' ? '4 பயிர் அழுத்தங்களை காண்க' : 'View 4 Stress Categories'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('explanation')}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-[#F7F8F4] hover:bg-[#EBF4ED] text-[#173F35] border border-[#E3E8DC] transition-colors"
              >
                <span>{language === 'ta' ? '5 விளக்க கேள்விகள்' : '5 Explainable Questions'}</span>
              </button>
            </div>
          </div>

          {/* Quick 4-Category Preview Badges */}
          {activeAnalysis.advisory.categories && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
              {/* Water */}
              <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                <span className="text-[10px] text-[#566761] font-semibold uppercase tracking-wider block">
                  {t.waterStress}
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-extrabold text-[#173F35]">
                    {activeAnalysis.advisory.categories.waterStress.score}/100
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      activeAnalysis.advisory.categories.waterStress.riskLevel === 'high'
                        ? 'bg-rose-100 text-rose-800'
                        : activeAnalysis.advisory.categories.waterStress.riskLevel === 'watch'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {activeAnalysis.advisory.categories.waterStress.riskLevel.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Nutrient */}
              <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                <span className="text-[10px] text-[#566761] font-semibold uppercase tracking-wider block">
                  {t.nutrientStress}
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-extrabold text-[#173F35]">
                    {activeAnalysis.advisory.categories.nutrientStress.score}/100
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      activeAnalysis.advisory.categories.nutrientStress.riskLevel === 'high'
                        ? 'bg-rose-100 text-rose-800'
                        : activeAnalysis.advisory.categories.nutrientStress.riskLevel === 'watch'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {activeAnalysis.advisory.categories.nutrientStress.riskLevel.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Pest */}
              <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                <span className="text-[10px] text-[#566761] font-semibold uppercase tracking-wider block">
                  {t.pestDiseaseRisk}
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-extrabold text-[#173F35]">
                    {activeAnalysis.advisory.categories.pestDiseaseRisk.score}/100
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      activeAnalysis.advisory.categories.pestDiseaseRisk.riskLevel === 'high'
                        ? 'bg-rose-100 text-rose-800'
                        : activeAnalysis.advisory.categories.pestDiseaseRisk.riskLevel === 'watch'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {activeAnalysis.advisory.categories.pestDiseaseRisk.riskLevel.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Heat */}
              <div className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
                <span className="text-[10px] text-[#566761] font-semibold uppercase tracking-wider block">
                  {t.heatStress}
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-extrabold text-[#173F35]">
                    {activeAnalysis.advisory.categories.heatStress.score}/100
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      activeAnalysis.advisory.categories.heatStress.riskLevel === 'high'
                        ? 'bg-rose-100 text-rose-800'
                        : activeAnalysis.advisory.categories.heatStress.riskLevel === 'watch'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {activeAnalysis.advisory.categories.heatStress.riskLevel.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
