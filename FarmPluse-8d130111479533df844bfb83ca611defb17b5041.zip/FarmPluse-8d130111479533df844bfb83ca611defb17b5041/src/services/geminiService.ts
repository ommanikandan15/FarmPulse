import { SupportedLanguage } from '../types';

export interface AiVisionResult {
  observedVisualPattern: string;
  possibleCauses: string[];
  fieldVerificationQuestions: string[];
  safetyAdvisory: string;
  cautionNotice: string;
  probableDiagnosis?: string;
  confidenceScore?: number;
  urgency?: 'mild' | 'moderate' | 'severe';
  actionableRemedy?: string;
  tamilSummary?: string;
  source?: string;
  model?: string;
}

export interface GeminiStatusInfo {
  configured: boolean;
  model: string;
  version: string;
  provider: string;
  serverSide: boolean;
  capabilities: string[];
}

export async function analyzeLeafImageWithGemini(
  base64Data: string,
  mimeType: string,
  userSelectedSymptoms: string[],
  language: SupportedLanguage = 'en',
  cropType: string = 'Paddy / Rice'
): Promise<AiVisionResult> {
  const response = await fetch('/api/gemini-leaf-analyze', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      imageBase64: base64Data,
      mimeType: mimeType || 'image/jpeg',
      symptoms: userSelectedSymptoms,
      cropType,
      language,
    }),
  });

  if (!response.ok) {
    throw new Error(`Server returned HTTP ${response.status}`);
  }

  const data = await response.json();
  if (data.result) {
    return {
      ...data.result,
      source: data.source,
      model: data.model,
    };
  }
  throw new Error('Invalid response structure from visual diagnosis endpoint');
}

export async function getGeminiStatus(): Promise<GeminiStatusInfo> {
  try {
    const res = await fetch('/api/gemini-status');
    if (!res.ok) throw new Error('Status failed');
    return await res.json();
  } catch {
    return {
      configured: false,
      model: 'gemini-3.8-flash',
      version: 'Gemini 3.8 Flash (Fallback)',
      provider: 'FarmPulse Hybrid Agronomy',
      serverSide: true,
      capabilities: ['text-advisory', 'multimodal-leaf-vision'],
    };
  }
}
