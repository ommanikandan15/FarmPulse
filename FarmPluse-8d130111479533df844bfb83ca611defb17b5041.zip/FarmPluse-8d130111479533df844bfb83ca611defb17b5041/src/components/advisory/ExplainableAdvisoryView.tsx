import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import { DataSourceBadge } from '../common/DataSourceBadge';
import { VoicePlayerButton } from '../common/VoicePlayerButton';
import { FactorContributionChart } from './FactorContributionChart';
import { InteractiveScenarioTester } from './InteractiveScenarioTester';
import { 
  HelpCircle, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Info,
  Layers,
  Sparkles,
  Droplet,
  Leaf,
  Bug,
  ThermometerSun,
  Clock,
  ArrowRight,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { CategoryStressResult, RiskLevel } from '../../types';

interface ExplainableAdvisoryViewProps {
  onOpenExplainability: () => void;
}

export const ExplainableAdvisoryView: React.FC<ExplainableAdvisoryViewProps> = ({
  onOpenExplainability,
}) => {
  const { 
    plots, 
    selectedPlotId, 
    setSelectedPlotId, 
    selectedPlot, 
    activeAnalysis,
    t, 
    language, 
    formatArea, 
    formatTemp,
    setActiveTab,
    speakText
  } = useApp();

  const [showScenarioTester, setShowScenarioTester] = useState(false);
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<'all' | 'water' | 'nutrient' | 'pest_disease' | 'heat'>('all');

  // Use either the active farm analysis advisory or selected plot advisory
  const currentAdvisory = activeAnalysis?.advisory || selectedPlot.advisory;
  const categories = currentAdvisory.categories;

  const spokenOverview = language === 'ta'
    ? `${activeAnalysis?.farmName || selectedPlot.nameTa}. ${currentAdvisory.headlineTa}. ${currentAdvisory.summaryTa}. முதன்மை நடவடிக்கை: ${currentAdvisory.primaryActionTa}`
    : `${activeAnalysis?.farmName || selectedPlot.name}. ${currentAdvisory.headline}. ${currentAdvisory.summary}. Primary action: ${currentAdvisory.primaryAction}`;

  const getRiskBadge = (level: RiskLevel) => {
    switch (level) {
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300">
            <AlertTriangle className="w-3 h-3 text-rose-600" />
            {t.riskHigh}
          </span>
        );
      case 'watch':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            {t.riskWatch}
          </span>
        );
      case 'low':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            {t.riskLow}
          </span>
        );
    }
  };

  const renderCategoryCard = (
    cat: CategoryStressResult,
    icon: React.ReactNode,
    accentColor: string
  ) => {
    const speechText = language === 'ta'
      ? `${cat.nameTa}: ${cat.explanationTa}. பரிந்துரைக்கப்பட்ட நடவடிக்கை: ${cat.recommendedNextStepTa}`
      : `${cat.name}: ${cat.explanation}. Recommended next step: ${cat.recommendedNextStep}`;

    return (
      <div 
        key={cat.category}
        className={`bg-white rounded-2xl border ${
          cat.riskLevel === 'high' 
            ? 'border-rose-300 shadow-sm ring-1 ring-rose-200' 
            : cat.riskLevel === 'watch'
            ? 'border-amber-300'
            : 'border-[#E3E8DC]'
        } p-5 sm:p-6 space-y-4 transition-all`}
      >
        {/* Category Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E3E8DC]">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${accentColor}`}>
              {icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-[#173F35]">
                  {language === 'ta' ? cat.nameTa : cat.name}
                </h3>
                {getRiskBadge(cat.riskLevel)}
              </div>
              <span className="text-[11px] text-[#566761]">
                {language === 'ta' ? 'அழுத்த மதிப்பீடு:' : 'Stress Score:'}{' '}
                <strong className="text-[#173F35] font-bold">{cat.score}/100</strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => speakText(speechText)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#F7F8F4] hover:bg-emerald-50 text-[#173F35] border border-[#E3E8DC] transition-colors"
              title="Read this category aloud in Tamil or English"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'ta' ? 'கேட்க' : 'Listen'}</span>
            </button>
          </div>
        </div>

        {/* Plain Language Explanation */}
        <div className="p-3.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#566761] block mb-1">
            {language === 'ta' ? 'எளிய மொழி விளக்கம்:' : 'Plain Language Explanation:'}
          </span>
          <p className="text-xs sm:text-sm text-[#1C2723] leading-relaxed font-medium">
            {language === 'ta' ? cat.explanationTa : cat.explanation}
          </p>
        </div>

        {/* Observations & Contributing Factors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Supporting Observations */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-[#173F35] flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#4E9B5F]" />
              {language === 'ta' ? 'ஆதார அளவீடுகள் & கள அறிகுறிகள்:' : 'Supporting Observations:'}
            </span>
            <ul className="space-y-1 text-xs text-[#566761]">
              {(language === 'ta' ? cat.supportingObservationsTa : cat.supportingObservations).map((obs, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-[#4E9B5F] font-bold">•</span>
                  <span>{obs}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Likely Contributing Factors */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-[#173F35] flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              {language === 'ta' ? 'வாய்ப்புள்ள காரணிகள்:' : 'Likely Contributing Factors:'}
            </span>
            <ul className="space-y-1 text-xs text-[#566761]">
              {(language === 'ta' ? cat.contributingFactorsTa : cat.contributingFactors).map((fac, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>{fac}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Recommended Next Step (Safe, non-chemical, actionable) */}
        <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
          <div className="flex items-center gap-1.5 mb-1 text-xs font-bold text-emerald-900">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>{language === 'ta' ? 'பரிந்துரைக்கப்பட்ட அடுத்த நடவடிக்கை:' : 'Recommended Next Step:'}</span>
          </div>
          <p className="text-xs text-emerald-900 leading-relaxed font-semibold">
            {language === 'ta' ? cat.recommendedNextStepTa : cat.recommendedNextStep}
          </p>
        </div>

        {/* Missing Info, Limitations, and Data Source Footer */}
        <div className="pt-3 border-t border-[#E3E8DC] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-[#83948E]">
          <div className="flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>
              <strong className="text-[#566761]">
                {language === 'ta' ? 'விடுபட்டவை:' : 'Missing Info / Limitations:'}
              </strong>{' '}
              {cat.missingInformation.length > 0 
                ? (language === 'ta' ? cat.missingInformationTa.join(', ') : cat.missingInformation.join(', '))
                : (language === 'ta' ? 'அனைத்து அளவீடுகளும் சரிபார்க்கப்பட்டன' : 'All parameters verified')}
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Clock className="w-3 h-3" />
            <span>{language === 'ta' ? cat.sourceAndTimestampTa : cat.sourceAndTimestamp}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Bar with Plot / Farm Switcher & Explanation Link */}
      <div className="bg-white p-5 rounded-2xl border border-[#E3E8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
              PRIME ELITE
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35]">
              {language === 'ta' ? '4 பயிர் அழுத்த ஆலோசனைகள்' : 'Four Crop-Stress Advisory Categories'}
            </h1>
            <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
              {t.demoBadge}
            </span>
          </div>
          <p className="text-xs text-[#566761] mt-1 max-w-2xl leading-relaxed">
            {language === 'ta'
              ? 'நீர் அழுத்தம், ஊட்டச்சத்து குறைபாடு, பூச்சி & நோய் அபாயம், மற்றும் வெப்ப தாக்கம் ஆகிய 4 தனித்துவ பிரிவுகளுக்கான சுயாதீன ஆய்வு.'
              : 'Independent explainable evaluation across Water Stress, Nutrient Stress, Pest/Disease Risk, and Heat Stress.'}
          </p>
        </div>

        {/* Quick Nav Buttons */}
        <div className="flex items-center gap-2 flex-wrap self-start md:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('analysis')}
            className="px-3 py-2 text-xs font-bold rounded-xl bg-[#F7F8F4] hover:bg-[#EBF4ED] text-[#173F35] border border-[#E3E8DC] transition-colors"
          >
            {language === 'ta' ? 'பண்ணை தரவு திருத்து' : 'Edit Farm Data'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('explanation')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-[#173F35] hover:bg-[#1f5245] text-white shadow-xs transition-colors"
          >
            <span>{language === 'ta' ? '5 விளக்கக் கேள்விகள்' : '5 Explainability Answers'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Overall Advisory Banner */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E3E8DC] shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E3E8DC]">
          <div className="flex items-center gap-3 flex-wrap">
            <StatusBadge level={currentAdvisory.riskLevel} size="lg" />
            <div className="flex items-center gap-1.5 text-xs text-[#566761]">
              <span className="font-semibold text-[#1C2723]">
                {activeAnalysis?.farmName || (language === 'ta' ? selectedPlot.nameTa : selectedPlot.name)}
              </span>
              <span>•</span>
              <span>{activeAnalysis?.cropType || (language === 'ta' ? selectedPlot.varietyTa : selectedPlot.variety)}</span>
              <span>•</span>
              <span>{activeAnalysis?.location || selectedPlot.locationName}</span>
            </div>
          </div>

          <VoicePlayerButton textToRead={spokenOverview} />
        </div>

        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-[#173F35] tracking-tight">
            {language === 'ta' ? currentAdvisory.headlineTa : currentAdvisory.headline}
          </h2>
          <p className="text-xs sm:text-sm text-[#566761] mt-1.5 leading-relaxed">
            {language === 'ta' ? currentAdvisory.summaryTa : currentAdvisory.summary}
          </p>
        </div>

        {/* Primary Safe Action Box */}
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>{language === 'ta' ? 'முதன்மை நடவடிக்கை:' : 'Primary Recommended Action:'}</span>
          </div>
          <p className="text-xs sm:text-sm text-emerald-950 font-semibold leading-relaxed">
            {language === 'ta' ? currentAdvisory.primaryActionTa : currentAdvisory.primaryAction}
          </p>
        </div>

        {/* Consult Agricultural Extension Officer Banner if High Risk */}
        {currentAdvisory.officerConsultWarning && (
          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                {language === 'ta' 
                  ? 'கள ஆய்வு ஆலோசனை: வேளாண்மை விரிவாக்க அலுவலரை அணுகவும்' 
                  : 'Safety Notice: Consult Block Agriculture Development Officer (ADO)'}
              </p>
              <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                {language === 'ta'
                  ? 'பயிர் வறட்சியில் இருக்கும் போது யூரியா போன்ற உரங்களையோ அல்லது ரசாயன பூச்சிக்கொல்லிகளையோ தன்னிச்சையாக தெளிக்க வேண்டாம். உள்ளூர் வேளாண் அதிகாரியின் ஒப்புதல் பெறவும்.'
                  : 'Do not apply synthetic fertilizers or unauthorized chemical sprays during severe water tension. Verify subsoil with local extension officers first.'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 4 CATEGORIES FILTER TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setSelectedCategoryTab('all')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
            selectedCategoryTab === 'all'
              ? 'bg-[#173F35] text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-[#173F35] border border-[#E3E8DC]'
          }`}
        >
          {language === 'ta' ? 'அனைத்து 4 பிரிவுகள்' : 'All 4 Categories'}
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategoryTab('water')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
            selectedCategoryTab === 'water'
              ? 'bg-blue-700 text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-blue-700 border border-[#E3E8DC]'
          }`}
        >
          <Droplet className="w-3.5 h-3.5 text-blue-500" />
          <span>{t.waterStress}</span>
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategoryTab('nutrient')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
            selectedCategoryTab === 'nutrient'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-emerald-700 border border-[#E3E8DC]'
          }`}
        >
          <Leaf className="w-3.5 h-3.5 text-emerald-500" />
          <span>{t.nutrientStress}</span>
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategoryTab('pest_disease')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
            selectedCategoryTab === 'pest_disease'
              ? 'bg-rose-700 text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-rose-700 border border-[#E3E8DC]'
          }`}
        >
          <Bug className="w-3.5 h-3.5 text-rose-500" />
          <span>{t.pestDiseaseRisk}</span>
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategoryTab('heat')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
            selectedCategoryTab === 'heat'
              ? 'bg-amber-700 text-white shadow-xs'
              : 'bg-white text-[#566761] hover:text-amber-700 border border-[#E3E8DC]'
          }`}
        >
          <ThermometerSun className="w-3.5 h-3.5 text-amber-500" />
          <span>{t.heatStress}</span>
        </button>
      </div>

      {/* RENDER THE 4 CROP-STRESS CATEGORY CARDS */}
      {categories ? (
        <div className="space-y-6">
          {(selectedCategoryTab === 'all' || selectedCategoryTab === 'water') && (
            renderCategoryCard(
              categories.waterStress,
              <Droplet className="w-5 h-5 text-blue-700" />,
              'bg-blue-100'
            )
          )}

          {(selectedCategoryTab === 'all' || selectedCategoryTab === 'nutrient') && (
            renderCategoryCard(
              categories.nutrientStress,
              <Leaf className="w-5 h-5 text-emerald-700" />,
              'bg-emerald-100'
            )
          )}

          {(selectedCategoryTab === 'all' || selectedCategoryTab === 'pest_disease') && (
            renderCategoryCard(
              categories.pestDiseaseRisk,
              <Bug className="w-5 h-5 text-rose-700" />,
              'bg-rose-100'
            )
          )}

          {(selectedCategoryTab === 'all' || selectedCategoryTab === 'heat') && (
            renderCategoryCard(
              categories.heatStress,
              <ThermometerSun className="w-5 h-5 text-amber-700" />,
              'bg-amber-100'
            )
          )}
        </div>
      ) : (
        <div className="p-8 text-center bg-white rounded-2xl border border-[#E3E8DC]">
          <p className="text-sm text-[#566761]">
            {language === 'ta' ? 'பகுப்பாய்வு இயங்கவில்லை.' : 'Evaluating category stress metrics...'}
          </p>
        </div>
      )}

      {/* Evidence Factor Breakdown Chart */}
      <FactorContributionChart factors={currentAdvisory.evidenceList} />

      {/* Action Checklist */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#E3E8DC] shadow-xs space-y-3">
        <h3 className="text-sm font-extrabold text-[#173F35]">
          {language === 'ta' ? 'வயல் ஆய்வில் சரிபார்க்க வேண்டியவை:' : 'Farmer Field Inspection Checklist:'}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {(language === 'ta' ? currentAdvisory.actionChecklistTa : currentAdvisory.actionChecklist).map((step, idx) => (
            <div
              key={idx}
              className="flex items-start gap-2.5 p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC]"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                {idx + 1}
              </div>
              <p className="text-xs text-[#1C2723] font-medium leading-relaxed">{step}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Scenario Tester Collapsible */}
      <div className="bg-white rounded-2xl border border-[#E3E8DC] shadow-xs overflow-hidden">
        <button
          type="button"
          onClick={() => setShowScenarioTester(!showScenarioTester)}
          className="w-full flex items-center justify-between p-4 sm:p-5 text-left bg-white hover:bg-[#F7F8F4] transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-[#4E9B5F]" />
            <div>
              <h3 className="text-sm font-bold text-[#173F35]">
                {language === 'ta' ? 'ஊடாடும் மாதிரி உருவகப்படுத்துதல் (Scenario Sandbox)' : 'Interactive Scenario Tester'}
              </h3>
              <p className="text-[11px] text-[#566761]">
                {language === 'ta' 
                  ? 'மழை இடைவெளி, மண் ஈரப்பதம் மற்றும் வெப்பநிலையை மாற்றி விளைவுகளை உடனுக்குடன் சோதிக்கவும்.' 
                  : 'Test how advisory rules respond to different rainfall, moisture, and temperature inputs.'}
              </p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-[#F7F8F4] text-[#173F35] border border-[#E3E8DC]">
            {showScenarioTester ? (language === 'ta' ? 'மறைக்க' : 'Hide') : (language === 'ta' ? 'திறக்க' : 'Open')}
          </span>
        </button>

        {showScenarioTester && (
          <div className="p-5 border-t border-[#E3E8DC] bg-[#FAFBF8]">
            <InteractiveScenarioTester plot={selectedPlot} />
          </div>
        )}
      </div>
    </div>
  );
};
