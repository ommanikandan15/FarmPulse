import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DEFAULT_USER_PROFILES } from '../../data/demoData';
import { UserProfile } from '../../types';
import { 
  X, 
  User, 
  Phone, 
  ShieldCheck, 
  Check, 
  LogIn, 
  Sprout, 
  Building, 
  Award, 
  ArrowRight,
  UserPlus
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { t, language, currentUser, setCurrentUser } = useApp();

  const [activeTab, setActiveTab] = useState<'profiles' | 'phone' | 'google' | 'custom'>('profiles');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customVillage, setCustomVillage] = useState('Kaveripakkam');
  const [customRole, setCustomRole] = useState<UserProfile['role']>('farmer');

  if (!isOpen) return null;

  const handleSelectProfile = (profile: UserProfile) => {
    setCurrentUser(profile);
    onClose();
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length >= 10) {
      setOtpSent(true);
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: UserProfile = {
      id: `user-phone-${Date.now()}`,
      name: customName.trim() || `Farmer ${phoneNumber.slice(-4)}`,
      phone: `+91 ${phoneNumber}`,
      role: 'farmer',
      roleLabel: 'Smallholder Farmer',
      village: 'Kaveripakkam Pilot Zone',
      avatarInitials: 'F',
      isLoggedIn: true,
    };
    setCurrentUser(newUser);
    onClose();
  };

  const handleGoogleSignIn = () => {
    const googleUser: UserProfile = {
      id: 'user-google-oauth',
      name: 'Marimuthu G. (Google Verified)',
      phone: '+91 98421 68427',
      role: 'farmer',
      roleLabel: 'Verified Agri User',
      village: 'Kaveripakkam East',
      avatarInitials: 'M',
      isLoggedIn: true,
    };
    setCurrentUser(googleUser);
    onClose();
  };

  const handleCustomRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const roleLabels: Record<UserProfile['role'], string> = {
      farmer: 'Smallholder Farmer',
      fpo_manager: 'FPO Executive',
      agronomist: 'Agriculture Extension Officer',
      buyer: 'Procurement Representative',
    };

    const newUser: UserProfile = {
      id: `user-custom-${Date.now()}`,
      name: customName.trim(),
      phone: phoneNumber || '+91 98000 ••••0',
      role: customRole,
      roleLabel: roleLabels[customRole],
      village: customVillage.trim() || 'Tamil Nadu',
      avatarInitials: customName.trim().slice(0, 2).toUpperCase(),
      isLoggedIn: true,
    };
    setCurrentUser(newUser);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="login-modal-title"
    >
      <div 
        className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#E3E8DC] p-6 text-[#1C2723]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#E3E8DC] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#173F35] text-white">
              <LogIn className="w-5 h-5 text-[#65A66F]" />
            </div>
            <div>
              <h3 id="login-modal-title" className="text-lg font-bold text-[#173F35]">
                {t.loginModalTitle}
              </h3>
              <p className="text-xs text-[#566761]">
                {t.loginModalSubtitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Method Selector Tabs */}
        <div className="mt-4 grid grid-cols-3 gap-1 bg-[#F7F8F4] p-1 rounded-xl border border-[#E3E8DC] text-xs">
          <button
            onClick={() => setActiveTab('profiles')}
            className={`py-2 px-1 rounded-lg font-bold transition-all text-center ${
              activeTab === 'profiles'
                ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                : 'text-[#566761] hover:text-[#173F35]'
            }`}
          >
            {language === 'ta' ? 'உடனடி சுயவிவரம்' : 'Instant Profiles'}
          </button>
          <button
            onClick={() => setActiveTab('phone')}
            className={`py-2 px-1 rounded-lg font-bold transition-all text-center ${
              activeTab === 'phone'
                ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                : 'text-[#566761] hover:text-[#173F35]'
            }`}
          >
            {language === 'ta' ? 'மொபைல் OTP' : 'Mobile OTP'}
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`py-2 px-1 rounded-lg font-bold transition-all text-center ${
              activeTab === 'custom'
                ? 'bg-white text-[#173F35] shadow-xs border border-[#E3E8DC]'
                : 'text-[#566761] hover:text-[#173F35]'
            }`}
          >
            {language === 'ta' ? 'புதிய பதிவு' : 'Register New'}
          </button>
        </div>

        {/* Tab 1: Instant Profiles (Farmer / FPO / ADO) */}
        {activeTab === 'profiles' && (
          <div className="mt-4 space-y-3">
            <span className="text-xs font-semibold text-[#566761] block">
              {t.instantDemoProfiles}
            </span>

            {DEFAULT_USER_PROFILES.map((profile) => {
              const isCurrent = currentUser?.id === profile.id;
              const RoleIcon = profile.role === 'farmer' ? Sprout : profile.role === 'fpo_manager' ? Building : Award;

              return (
                <button
                  key={profile.id}
                  onClick={() => handleSelectProfile(profile)}
                  className={`w-full p-3.5 rounded-xl border flex items-center justify-between text-left transition-all ${
                    isCurrent
                      ? 'bg-emerald-50/70 border-[#2D8A4E] ring-2 ring-[#2D8A4E]/20'
                      : 'bg-[#F7F8F4] border-[#E3E8DC] hover:bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#173F35] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                      {profile.avatarInitials}
                    </div>
                    <div>
                      <span className="font-bold text-xs sm:text-sm text-[#1C2723] block">
                        {profile.name}
                      </span>
                      <span className="text-[11px] text-[#566761] block">
                        {profile.roleLabel} • {profile.village}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isCurrent ? (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                        Active
                      </span>
                    ) : (
                      <ArrowRight className="w-4 h-4 text-stone-400" />
                    )}
                  </div>
                </button>
              );
            })}

            {/* Google One-Click alternative */}
            <div className="pt-2">
              <button
                onClick={handleGoogleSignIn}
                className="w-full py-2.5 px-4 rounded-xl border border-[#E3E8DC] bg-white hover:bg-stone-50 text-xs font-bold text-[#1C2723] flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/>
                  <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
                  <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.04 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
                  <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                </svg>
                <span>{t.signInWithGoogle}</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Mobile Phone OTP */}
        {activeTab === 'phone' && (
          <form onSubmit={otpSent ? handleVerifyOtp : handleSendOtp} className="mt-4 space-y-3 text-xs">
            <div>
              <label htmlFor="mobile-input" className="font-semibold text-[#1C2723] block mb-1">
                {t.enterMobileNumber}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500 font-bold">+91</span>
                <input
                  id="mobile-input"
                  type="tel"
                  maxLength={10}
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="9842168427"
                  className="w-full pl-12 pr-3 py-2.5 rounded-xl border border-[#E3E8DC] text-xs font-mono font-bold focus:outline-hidden focus:border-[#4E9B5F]"
                  required
                />
              </div>
            </div>

            {otpSent && (
              <div className="space-y-2 animate-in fade-in duration-200">
                <p className="text-[11px] text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                  {t.otpSentNotice}
                </p>
                <div>
                  <label htmlFor="otp-input" className="font-semibold text-[#1C2723] block mb-1">
                    {t.verifyOtp}
                  </label>
                  <input
                    id="otp-input"
                    type="text"
                    maxLength={4}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E3E8DC] text-xs font-mono font-bold tracking-widest text-center focus:outline-hidden focus:border-[#4E9B5F]"
                    required
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              {otpSent ? t.verifyOtp : t.sendOtp}
            </button>
          </form>
        )}

        {/* Tab 3: Custom Registration */}
        {activeTab === 'custom' && (
          <form onSubmit={handleCustomRegister} className="mt-4 space-y-3 text-xs">
            <div>
              <label htmlFor="name-input" className="font-semibold text-[#1C2723] block mb-1">
                {t.fullName}
              </label>
              <input
                id="name-input"
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder="e.g. Ramesh K."
                className="w-full px-3 py-2 rounded-xl border border-[#E3E8DC] text-xs focus:outline-hidden focus:border-[#4E9B5F]"
                required
              />
            </div>

            <div>
              <label htmlFor="village-input" className="font-semibold text-[#1C2723] block mb-1">
                {t.villageName}
              </label>
              <input
                id="village-input"
                type="text"
                value={customVillage}
                onChange={(e) => setCustomVillage(e.target.value)}
                placeholder="e.g. Kaveripakkam, Ranipet"
                className="w-full px-3 py-2 rounded-xl border border-[#E3E8DC] text-xs focus:outline-hidden focus:border-[#4E9B5F]"
                required
              />
            </div>

            <div>
              <label htmlFor="role-select" className="font-semibold text-[#1C2723] block mb-1">
                {t.role}
              </label>
              <select
                id="role-select"
                value={customRole}
                onChange={(e) => setCustomRole(e.target.value as UserProfile['role'])}
                className="w-full px-3 py-2 rounded-xl border border-[#E3E8DC] text-xs bg-white focus:outline-hidden focus:border-[#4E9B5F]"
              >
                <option value="farmer">Smallholder Farmer</option>
                <option value="fpo_manager">FPO Coordinator / Manager</option>
                <option value="agronomist">Agriculture Extension Officer (ADO)</option>
                <option value="buyer">Paddy Mill / Procurement Buyer</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#173F35] hover:bg-[#1E4D41] text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              Save & Sign In
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
