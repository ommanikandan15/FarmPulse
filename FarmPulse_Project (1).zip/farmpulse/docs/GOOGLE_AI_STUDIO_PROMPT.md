# Google AI Studio Build Prompt — FarmPulse

Copy the entire prompt below into Google AI Studio (Build mode). Ask it to generate the app, then test every screen and fix any build errors before exporting.

---

You are a senior product designer, full-stack engineer, applied AI engineer, and agricultural technology product architect. Build a complete, polished, responsive web application named **FarmPulse — Explainable Crop Stress Advisory**. This must be a real, runnable application, not a static mockup or a landing page only.

## 1. Product mission
FarmPulse helps smallholder farmers and Farmer Producer Organizations (FPOs) monitor crop plots, understand possible crop stress, and decide what to check next. Its defining feature is **explainability**: never show a stress score without showing the observations and rules/evidence behind it.

Tagline: **“Don’t just tell the farmer what. Tell them why.”**
Pilot scenario: paddy plots in Tamil Nadu, India. Design for mobile-first use, low bandwidth, and users who may prefer Tamil voice-friendly explanations.

## 2. Required technology
- React + TypeScript + Vite.
- Use a clean component architecture and reusable typed components.
- Use Tailwind CSS if available in the environment; otherwise use well-organized CSS modules/global CSS.
- Use Recharts for charts if available; otherwise implement accessible SVG/CSS charts without breaking the build.
- Use Lucide icons if available; otherwise use simple inline SVG icons.
- Use localStorage for demo preferences and saved demo notes only; do not store sensitive personal data.
- The app must run without secret keys. If a Gemini API key or external API is not configured, the main application must still work in Demo Mode.
- Include a README with setup, scripts, architecture, environment variables, limitations, and deployment guidance.

## 3. Visual design direction
Create a premium AgriTech SaaS dashboard with a distinctive identity, not a generic admin template.
- Brand: FarmPulse; icon concept: a leaf combined with a pulse/field line.
- Palette: deep forest green (#173F35), fresh leaf green (#65A66F), warm off-white (#F6F7F1), muted sage, amber for watch, restrained red for high risk, dark charcoal text.
- Use generous spacing, clear hierarchy, rounded 14–20px cards, subtle borders, tasteful shadows, clean typography, and small purposeful animations.
- Dashboard should feel professional enough for a national-level hackathon demo but remain readable on budget Android phones.
- Responsive sidebar on desktop; compact top/bottom navigation on mobile.
- Include loading skeletons, empty states, error states, keyboard focus states, accessible labels, and tooltips.
- Avoid excessive gradients, neon effects, clutter, and fake enterprise metrics.

## 4. App shell and navigation
Build these pages/routes or equivalent navigable views:
1. Overview Dashboard
2. My Fields / Plot Explorer
3. Explainable Advisory
4. Leaf Check (photo upload demo)
5. Weather & Trends
6. FPO Supply-Chain Outlook
7. Reports
8. Settings

Header includes FarmPulse logo, region selector (default: Kaveripakkam demo cluster, Tamil Nadu), date label, notification indicator, language toggle (English / தமிழ்), and a user menu marked “Demo Farmer”. Make all navigation links work.

## 5. Dashboard page
Display:
- Greeting: “Good morning, Farmer” with short supportive copy.
- Summary cards: Monitored plots, Area monitored (acres), High-priority plots, Data coverage.
- A large “Field Health Overview” plot map/panel. If no real map provider is configured, create an attractive schematic field map with clickable plot polygons/cards and a clear “Illustrative demo map — not GPS boundaries” label. Do not invent real geographic precision.
- A plot status list with Green / Watch / High risk indicators.
- A 7-day weather strip showing rainfall and temperature demo values, clearly labelled demo.
- “Why this alert?” compact evidence preview.
- “Priority actions today” checklist.
- Recent activity panel.
- Cluster-level risk summary.
Use realistic demo values, but consistently label synthetic/sample data as “Demo data”.

## 6. Plot Explorer
Provide at least 4 sample plots, for example Plot 01 – East Paddy, Plot 02 – Canal Edge, Plot 03 – North Field, Plot 04 – Seedling Block. Each plot has crop, growth stage, acreage, last observation time, rainfall gap, soil moisture, greenness trend, temperature, optional NDVI/NDWI, and data-source labels.
- Search, status filters, crop filters, sort, and a grid/list toggle must work.
- Clicking a plot opens a detailed view with field summary, observations, trend chart, advisory level, evidence, action, and last updated time.
- Make clear these are fictional demo plots, not a real farmer’s data.

## 7. Explainable advisory engine — mandatory real functionality
Implement a deterministic, testable rules engine in TypeScript or a small service module. Do not pretend a trained model exists.
Inputs: crop, growth stage, days without rain, soil moisture percentage, weekly greenness change percentage, temperature, humidity, optional NDVI and NDWI, and a list of missing data fields.
Illustrative demo rules (state clearly that agronomists must validate these before real-world use):
- Rain-free period >= 7 days: add high-priority evidence; 4–6 days: moderate evidence.
- Soil moisture < 20%: add high-priority evidence; 20–28%: moderate evidence.
- Greenness change <= -12% over the week: add high-priority field-inspection evidence; -6% to -11.9%: moderate evidence.
- Temperature >= 35°C: add heat-watch evidence.
- Optional NDWI below 0 can be shown as context only, not definitive proof of water stress.
Calculate a simple transparent demo score from triggered rules and map it to Low / Watch / High. Explain the score formula in a “How this was assessed” popover. Do not present this score as a probability. Avoid claiming that greenness alone identifies a disease or its cause.

Every advisory result must show:
- Risk level and status badge.
- “Why we think this” list of evidence with the actual input value, the rule/threshold, and a plain-language explanation.
- “What to do next” with one safe, prioritized action.
- Data coverage badge and a note: “Coverage indicates available inputs; it is not prediction accuracy.”
- Uncertainty and missing-data notes.
- “Review with local agriculture officer” warning for high-impact actions.
- A “View all factors” button and factor contribution chart. Since this is a rule-based demo, label the chart “Rule contributions (demo)” — do not call it SHAP. Only call a future trained model’s explanations SHAP after a real model exists.

Safety: do not give pesticide names, chemical dosages, guaranteed yield estimates, or exact irrigation amounts as authoritative recommendations. For high stress, suggest field inspection, checking water availability and soil conditions, and consulting a local agriculture officer before deciding irrigation depth or treatments.

## 8. Leaf Check page
- Allow drag-and-drop or click-to-upload a leaf photo; validate image type and size, show preview, remove/reset control.
- Since no verified disease model is bundled, default to a **visual inspection assistant demo** that asks the user to select observed symptoms (yellowing, spots, curling, wilting, holes, other) and then provides cautious possible causes plus a checklist of what to inspect next.
- If Gemini vision integration is added, it must be optional, explicitly disclosed, and only activated when the user configures a key. Never claim the image result is a confirmed diagnosis. Never prescribe pesticide products or dosage. Show “Possible causes — confirm with an agronomist.”
- Include privacy text: do not upload identifiable people or sensitive documents; explain that demo image processing may be local and avoid sending photos to a server unless the user opts in.

## 9. Weather & Trends
- Show 7-day charts for temperature, rainfall, and moisture observations.
- Use sample data in Demo Mode and label it clearly.
- Provide an optional integration adapter for Open-Meteo only if practical. If API fetch fails or internet is unavailable, show a friendly fallback to demo data and disclose the data source.
- Do not hardcode the claim that the weather values are live.
- Include trend explanation and an observation timeline.

## 10. FPO Supply-Chain Outlook
Create a useful cluster-level planning dashboard with:
- Total demo plots and area covered.
- Counts of Low / Watch / High plots.
- Aggregated risk by crop/field cluster.
- A procurement-readiness timeline using broad windows, not precise promises.
- Suggested operational steps: prioritize field verification, contact farmers with consent, check local crop calendars, confirm harvest volume before dispatch planning.
- Exportable CSV report using browser-side generation.
- Strong caveat: “Planning signal only. Validate with field visits, farmer reports, crop calendars and buyer/FPO coordination. Not a guaranteed yield forecast.”
- Never expose a farmer’s exact location or individual records in a cluster view without consent.

## 11. Reports
Create a report page with:
- Filter by date range, plot, risk level, crop.
- Summary of advisories and evidence.
- Download CSV button that actually downloads the filtered data.
- Print-friendly report view.
- “Demo data” watermark/label on every export.

## 12. Language and accessibility
- Implement a working English / Tamil UI toggle for all main navigation, labels, risk labels, key action text, and the sample advisory explanation. Store language preference locally.
- Tamil should be natural, simple, and farmer-friendly; do not show untranslated technical jargon without explanation.
- Add a “Read advisory aloud” button using browser speech synthesis when supported. Use Tamil locale for Tamil and English locale for English; gracefully handle unsupported browsers.
- Respect reduced-motion preferences and provide sufficient color contrast. Never rely on color alone to convey risk.

## 13. Data model and integrations
Create typed models for Plot, Observation, EvidenceFactor, Advisory, WeatherDay, ClusterSummary, and AppSettings.
- Put demo data in a separate file, not scattered across components.
- Create a clean adapter interface for future satellite, weather, sensor and model providers.
- Add source badges: Farmer input / Weather API / Satellite / Sensor / Demo.
- Sentinel-2 / NDVI / NDWI values must be optional and include cloud/recency caveats. Do not fabricate a real satellite connection. Provide a clearly labelled “Integration not configured” state where appropriate.
- No API keys in source code. Use environment variables and document setup. App must run without external credentials.

## 14. Settings
- Language, units (°C/°F and acres/hectares), notification preferences, demo/live data mode label, privacy information, about/version.
- Units toggle should actually change displayed values where conversion is appropriate.
- Add reset-demo-data and reset-preferences actions with confirmation.

## 15. Quality requirements
- Generate every required file and all source code, not just a plan.
- No dead buttons, placeholder links, fake loading forever, or console errors.
- TypeScript types should be valid; handle null/missing fields.
- Keep components reasonably small and code readable.
- Include a README with install/run/build commands and a file tree.
- Include tests for the rule engine: low-risk case, high-risk case, missing optional satellite data, and uncertainty/coverage handling.
- Add `.env.example` only if environment variables are used.
- Provide a clear final list of created files and exact commands to run the app.
- If a dependency is unavailable, implement a reliable alternative instead of leaving a broken import.

## 16. Acceptance checklist
Before finishing, verify:
1. App starts successfully.
2. Dashboard renders without API keys.
3. Every navigation item works.
4. Search, filters, language toggle, units toggle, plot details and CSV export work.
5. Rule engine produces evidence that matches its rules.
6. Leaf upload preview and symptom checklist work.
7. Mobile layout is usable at 360px width.
8. Empty/error/loading states are handled.
9. All sample data is clearly marked demo.
10. No unvalidated agronomic advice is presented as authoritative.

Now build the complete app. Start by creating the project files, implement the app end-to-end, run/build/test it where the environment supports it, fix errors, and only then present the final result. Do not stop after generating a design description.
