import React, { useState } from 'react';
import { 
  Sparkles, 
  HelpCircle, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Layers, 
  Scale, 
  FileCheck, 
  Info, 
  ArrowRight,
  BookOpen,
  Volume2,
  ChevronDown,
  ChevronUp,
  Cpu,
  ShieldAlert,
  Percent
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { FiveExplainableQuestions } from '../../types';

export const ExplanationInsightsView: React.FC = () => {
  const { 
    activeAnalysis, 
    selectedPlot, 
    language, 
    t, 
    speakText, 
    setActiveTab 
  } = useApp();

  const [expandedSection, setExpandedSection] = useState<number | null>(null);

  const advisory = activeAnalysis?.advisory || selectedPlot.advisory;
  const questions: FiveExplainableQuestions | undefined = advisory.explainableQuestions;

  const toggleSection = (idx: number) => {
    setExpandedSection(expandedSection === idx ? null : idx);
  };

  const handleReadQuestion = (title: string, body: string) => {
    speakText(`${title}. ${body}`);
  };

  if (!questions) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-[#E3E8DC] text-center">
        <p className="text-sm text-[#566761]">
          {language === 'ta' ? 'விளக்கக் கேள்விகள் தயார் செய்யப்படுகின்றன...' : 'Compiling explainability metrics...'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Banner & PRIME ELITE Differentiation Showcase */}
      <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                PRIME ELITE Core
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#173F35] text-white">
                Explainable AI (XAI)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#173F35] tracking-tight">
              {language === 'ta' ? 'விளக்கமளிக்கும் செயற்கை நுண்ணறிவு & உட்பார்வை' : 'Explainability Engine: The 5 Core Answers'}
            </h1>
            <p className="text-xs sm:text-sm text-[#566761] mt-1 leading-relaxed">
              <strong className="text-[#173F35]">“Don’t just tell the farmer what. Tell them why.”</strong> —{' '}
              {language === 'ta'
                ? 'விவசாயிகளுக்கு கருப்புப் பெட்டி பரிந்துரைகள் இன்றி, ஒவ்வொரு முடிவுக்குப் பின்னணியிலும் உள்ள வேளாண் விதிகள், அளவீட்டு பங்களிப்பு மற்றும் வரம்புகள் வெளிப்படையாக விளக்கப்படுகின்றன.'
                : 'Every advisory is transparently mapped to ground rules, biometric measurements, and physical agronomic limits.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('advisory')}
              className="px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors"
            >
              {language === 'ta' ? '4 பயிர் அழுத்தங்களை காண்க' : 'View 4 Stress Categories'}
            </button>
          </div>
        </div>

        {/* Honest Rule-Based Attribution Badge */}
        <div className="mt-4 p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-start gap-2.5 text-xs text-emerald-950">
          <Scale className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">
              {language === 'ta' ? 'வெளிப்படையான வேளாண்மை விதி மாதிரி:' : 'Honest, Rule-Based Agronomic Intelligence:'}
            </p>
            <p className="text-[11px] text-emerald-800 mt-0.5 leading-relaxed">
              {language === 'ta' ? questions.reliabilityAndLimitations.transparencyNoteTa : questions.reliabilityAndLimitations.transparencyNote}
            </p>
          </div>
        </div>
      </div>

      {/* THE 5 CORE EXPLAINABLE QUESTIONS (CARD DECK) */}
      <div className="space-y-4">
        {/* QUESTION 1: WHAT POSSIBLE CROP PROBLEM WAS IDENTIFIED? */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center font-extrabold text-sm">
                1
              </div>
              <h2 className="text-sm sm:text-base font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? '1. என்ன பயிர் பிரச்சனை கண்டறியப்பட்டுள்ளது?' 
                  : '1. What possible crop problem was identified?'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() =>
                handleReadQuestion(
                  language === 'ta' ? 'என்ன பயிர் பிரச்சனை கண்டறியப்பட்டுள்ளது' : 'What crop problem was identified',
                  language === 'ta' ? questions.identifiedProblem.detailsTa : questions.identifiedProblem.details
                )
              }
              className="p-1.5 rounded-lg bg-[#F7F8F4] hover:bg-emerald-50 text-[#173F35] border border-[#E3E8DC] transition-colors"
              title="Listen aloud"
            >
              <Volume2 className="w-4 h-4 text-[#4E9B5F]" />
            </button>
          </div>

          <div className="p-4 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-1.5">
            <h3 className="text-sm font-extrabold text-[#173F35]">
              {language === 'ta' ? questions.identifiedProblem.titleTa : questions.identifiedProblem.title}
            </h3>
            <p className="text-xs text-[#566761] leading-relaxed">
              {language === 'ta' ? questions.identifiedProblem.detailsTa : questions.identifiedProblem.details}
            </p>
          </div>
        </div>

        {/* QUESTION 2: WHY DOES THE SYSTEM SUSPECT THIS PROBLEM? */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center font-extrabold text-sm">
                2
              </div>
              <h2 className="text-sm sm:text-base font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? '2. கணினி ஏன் இந்த பிரச்சனையை சந்தேகிக்கிறது?' 
                  : '2. Why does the system suspect this problem?'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() =>
                handleReadQuestion(
                  language === 'ta' ? 'கணினி ஏன் இதை சந்தேகிக்கிறது' : 'Why system suspects this',
                  language === 'ta' ? questions.whySuspected.reasoningTa : questions.whySuspected.reasoning
                )
              }
              className="p-1.5 rounded-lg bg-[#F7F8F4] hover:bg-emerald-50 text-[#173F35] border border-[#E3E8DC] transition-colors"
              title="Listen aloud"
            >
              <Volume2 className="w-4 h-4 text-[#4E9B5F]" />
            </button>
          </div>

          <div className="space-y-3">
            <p className="text-xs sm:text-sm text-[#1C2723] font-medium leading-relaxed">
              {language === 'ta' ? questions.whySuspected.reasoningTa : questions.whySuspected.reasoning}
            </p>

            <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-xs text-blue-950 flex items-start gap-2">
              <BookOpen className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">
                  {language === 'ta' ? 'அடிப்படை வேளாண் அறிவியல் கொள்கை:' : 'Underlying Agronomic Science:'}
                </span>
                <span className="text-[11px] text-blue-900 mt-0.5 block leading-relaxed">
                  {language === 'ta' ? questions.whySuspected.agronomicPrincipleTa : questions.whySuspected.agronomicPrinciple}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* QUESTION 3: WHICH AVAILABLE INPUTS SUPPORT THE RESULT? (FACTOR BREAKDOWN) */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center font-extrabold text-sm">
                3
              </div>
              <h2 className="text-sm sm:text-base font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? '3. எந்த உள்ளீடுகள் இந்த முடிவுக்கு ஆதரவளிக்கின்றன?' 
                  : '3. Which available inputs support the result?'}
              </h2>
            </div>
            <span className="text-xs text-[#566761] font-semibold">
              {questions.supportingInputs.factors.length} {language === 'ta' ? 'காரணிகள்' : 'factors evaluated'}
            </span>
          </div>

          <p className="text-xs text-[#566761]">
            {language === 'ta' ? questions.supportingInputs.inputSummaryTa : questions.supportingInputs.inputSummary}
          </p>

          {/* Visual Percentage Contribution Stack */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between text-xs font-bold text-[#173F35]">
              <span>{language === 'ta' ? 'காரணி பங்களிப்பு விகிதம் (%):' : 'Factor Contribution Breakdown:'}</span>
              <span className="text-[11px] text-[#83948E]">Normalized Sum = 100%</span>
            </div>

            <div className="space-y-2">
              {questions.supportingInputs.factors.map((factor, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#1C2723]">
                      {language === 'ta' ? factor.nameTa : factor.name}
                    </span>
                    <span className="font-extrabold text-[#173F35]">
                      {factor.contributionPercent}% {language === 'ta' ? 'பங்களிப்பு' : 'contribution'}
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-[#E3E8DC] h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${Math.max(5, factor.contributionPercent)}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#566761]">
                    <span>
                      {language === 'ta' ? 'உள்ளீடு மதிப்பு:' : 'Measured value:'}{' '}
                      <strong className="text-[#1C2723]">{factor.value}</strong>
                    </span>
                    <span className="text-[10px] text-[#83948E]">
                      {language === 'ta' ? 'விதி:' : 'Trigger:'} {factor.ruleTriggered}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* QUESTION 4: WHAT SHOULD THE FARMER CHECK NEXT? */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center font-extrabold text-sm">
                4
              </div>
              <h2 className="text-sm sm:text-base font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? '4. விவசாயி அடுத்து என்ன ஆய்வு செய்ய வேண்டும்?' 
                  : '4. What should the farmer check next?'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() =>
                handleReadQuestion(
                  language === 'ta' ? 'அடுத்து என்ன செய்ய வேண்டும்' : 'What to check next',
                  language === 'ta' ? questions.whatToCheckNext.primaryCheckTa : questions.whatToCheckNext.primaryCheck
                )
              }
              className="p-1.5 rounded-lg bg-[#F7F8F4] hover:bg-emerald-50 text-[#173F35] border border-[#E3E8DC] transition-colors"
              title="Listen aloud"
            >
              <Volume2 className="w-4 h-4 text-[#4E9B5F]" />
            </button>
          </div>

          {/* Primary Action Box */}
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block mb-1">
              {language === 'ta' ? 'முக்கிய கள ஆய்வு:' : 'Primary On-Field Inspection:'}
            </span>
            <p className="text-xs sm:text-sm text-emerald-950 font-bold leading-relaxed">
              {language === 'ta' ? questions.whatToCheckNext.primaryCheckTa : questions.whatToCheckNext.primaryCheck}
            </p>
          </div>

          {/* Sequential Checklist */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-[#173F35]">
              {language === 'ta' ? 'படிப்படியான கள வழிகாட்டுதல்:' : 'Step-by-Step Field Checklist:'}
            </span>
            <div className="space-y-1.5">
              {(language === 'ta' ? questions.whatToCheckNext.checklistTa : questions.whatToCheckNext.checklist).map(
                (step, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] text-xs"
                  >
                    <div className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                      {i + 1}
                    </div>
                    <span className="text-[#1C2723]">{step}</span>
                  </div>
                )
              )}
            </div>
          </div>

          {/* Safety Guardrail Notice */}
          <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200 text-xs text-rose-950 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-rose-900 font-bold">
                {language === 'ta' ? 'பாதுகாப்பு எச்சரிக்கை:' : 'Safety Guardrail:'}
              </strong>{' '}
              {language === 'ta' ? questions.whatToCheckNext.safetyWarningTa : questions.whatToCheckNext.safetyWarning}
            </p>
          </div>
        </div>

        {/* QUESTION 5: HOW RELIABLE IS THIS RECOMMENDATION AND WHAT ARE THE LIMITATIONS? */}
        <div className="bg-white rounded-2xl border border-[#E3E8DC] p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E3E8DC]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#173F35] text-white flex items-center justify-center font-extrabold text-sm">
                5
              </div>
              <h2 className="text-sm sm:text-base font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? '5. இந்த பரிந்துரை எவ்வளவு நம்பகமானது & வரம்புகள் என்ன?' 
                  : '5. How reliable is this recommendation and what are the limitations?'}
              </h2>
            </div>
            <span className="text-xs font-extrabold text-[#173F35] px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300">
              {questions.reliabilityAndLimitations.confidencePercent}% {language === 'ta' ? 'நம்பிக்கை' : 'Confidence'}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-[#F7F8F4] border border-[#E3E8DC] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold text-[#83948E] uppercase tracking-wider block">
                {language === 'ta' ? 'நம்பகத்தன்மை தரம்:' : 'Reliability Category:'}
              </span>
              <span className="text-sm font-extrabold text-[#173F35]">
                {language === 'ta' 
                  ? questions.reliabilityAndLimitations.reliabilityScoreTa 
                  : questions.reliabilityAndLimitations.reliabilityScore}
              </span>
            </div>
            <span className="text-xs text-[#566761]">
              {language === 'ta' 
                ? 'சரிபார்க்கப்பட்ட கள மற்றும் வானிலை அளவீடுகள் அடிப்படையில் சரிசெய்யப்பட்டது.' 
                : 'Adjusted based on availability of verified sensor signals.'}
            </span>
          </div>

          {/* List of Limitations */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-[#173F35] flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-amber-600" />
              {language === 'ta' ? 'முக்கிய வரம்புகள் & எல்லைகள்:' : 'Operational Limitations & Boundaries:'}
            </span>
            <div className="space-y-1.5">
              {(language === 'ta' ? questions.reliabilityAndLimitations.limitationsTa : questions.reliabilityAndLimitations.limitations).map(
                (lim, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-[#FAFBF8] border border-[#E3E8DC] text-xs text-[#566761] flex items-start gap-2"
                  >
                    <span className="text-amber-600 font-bold">•</span>
                    <span>{lim}</span>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
