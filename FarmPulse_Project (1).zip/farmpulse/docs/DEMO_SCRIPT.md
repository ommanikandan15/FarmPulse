# 4-minute project demo script

1. **Problem (30 sec):** farmers may receive a stress score without knowing why it was raised or what to verify.
2. **Dashboard (45 sec):** introduce the plot cards, sample-data banner and status labels.
3. **Explainability (60 sec):** select Plot P-02. Walk through rainfall gap, soil moisture, greenness trend and heat. Point out that every factor includes the measured value and the rule explanation.
4. **Responsible action (45 sec):** show that the system recommends a field visit and validation, rather than prescribing a fixed irrigation quantity or chemical treatment.
5. **Supply chain (30 sec):** show aggregated high/watch plot counts as a planning signal, not a guaranteed yield forecast.
6. **Roadmap (30 sec):** real satellite/weather ingestion, agronomist-validated thresholds, Tamil voice UX, and a properly evaluated ML model.

**Closing line:** “FarmPulse turns a crop-stress alert into a transparent conversation: what changed, why it matters, and what to verify next.”
