# FarmPulse Android Studio & APK Release Guide

This document describes the native Android implementation, architecture, security audit findings, and step-by-step instructions for compiling and signing the production release APK.

---

## 1. Project Architecture & Android SDK Specifications

- **Package Name**: `com.farmpulse.app`
- **Application Name**: `FarmPulse`
- **Compile SDK**: `34` (Android 14)
- **Target SDK**: `34` (Android 14)
- **Min SDK**: `24` (Android 7.0 Nougat) — covers 98.7% of active Android devices in India
- **Language / Runtime**: Java 17 / AndroidX + WebKit 1.10.0 + Modern PWA Service Worker caching
- **Architecture**: Hybrid native shell with hardened Android `WebView`, DOM Storage offline caching, HTML5 Geolocation bridge, and isolated Camera/File Chooser intent handling.

---

## 2. Android Security & Permissions Audit

| Permission | Purpose | Severity / Review |
|---|---|---|
| `android.permission.INTERNET` | Live weather (Open-Meteo), Agmarknet/e-NAM mandi rates, Gemini Vision proxy | Standard (Required) |
| `android.permission.ACCESS_NETWORK_STATE` | Detects offline field mode and triggers cached agronomy engine | Low / Best practice |
| `android.permission.ACCESS_FINE_LOCATION` | Field GPS coordinates for weather & advisory | Runtime prompt only (Declared optional in hardware) |
| `android.permission.CAMERA` | Leaf diagnosis photo capture | Runtime prompt only (`required="false"`) |
| `android.permission.POST_NOTIFICATIONS` | Severe weather risk alerts & irrigation reminders | Target SDK 33+ requirement |

### Security Hardening Measures Implemented:
1. **`android:allowBackup="false"`**: Prevents extracting private farmer cache data via ADB backup.
2. **`android:usesCleartextTraffic="false"`**: Blocks unencrypted HTTP traffic to prevent MITM attacks.
3. **`setAllowFileAccess(false)` & `setAllowUniversalAccessFromFileURLs(false)`**: Closes local file inclusion vulnerabilities inside WebView.
4. **Server-Side API Key Proxy**: All Gemini AI calls route through `/api/gemini-leaf-analyze` on Express server. **Zero private API keys are compiled into the Android APK binary.**

---

## 3. How to Open the Project in Android Studio

1. Launch **Android Studio** (Koala, Jellyfish, or Iguana recommended).
2. Select **File > Open** and browse to the `/android` folder inside this project root.
3. Allow Gradle to sync dependencies (`com.android.application`, `androidx.webkit`, `material`).
4. Select your target device or Android Virtual Device (AVD, API 24–34).
5. Click **Run > Run 'app'** (`Shift + F10`) to launch debug build.

---

## 4. How to Generate a Signed Release APK

### Step 1: Create a Release Keystore (if not already existing)
Run this command in your terminal:
```bash
keytool -genkey -v -keystore farmpulse-release.keystore \
  -alias farmpulse \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=FarmPulse, OU=AgriTech, O=FarmPulse, L=Ranipet, ST=TamilNadu, C=IN"
```

### Step 2: Configure Gradle Signing
In `android/gradle.properties` or environment variables:
```properties
RELEASE_STORE_FILE=/path/to/farmpulse-release.keystore
RELEASE_STORE_PASSWORD=your_keystore_password
RELEASE_KEY_ALIAS=farmpulse
RELEASE_KEY_PASSWORD=your_key_password
```

### Step 3: Compile Signed Release APK
Run via terminal inside the `/android` folder:
```bash
./gradlew assembleRelease
```
The compiled, optimized, and signed APK will be generated at:
```
android/app/build/outputs/apk/release/app-release.apk
```

### Step 4: Install APK on Android Device
Connect your Android phone via USB with USB Debugging enabled, and run:
```bash
adb install -r app/build/outputs/apk/release/app-release.apk
```

---

## 5. Instant 1-Tap PWA / WebAPK Alternative (No Android Studio Needed)

For smallholder farmers and field extension workers:
1. Open the application URL in **Chrome for Android** or Samsung Internet.
2. A bottom install banner appears automatically: *"Install FarmPulse App (v1.0.0)"*.
3. Tap **Install App**.
4. Android generates an authenticated **WebAPK** package and places the official FarmPulse green sprout icon on the phone's home screen.
5. Works 100% offline in remote fields using pre-cached Service Worker assets.
