import { SupportedLanguage } from '../types';

export interface TranslationDictionary {
  appName: string;
  tagline: string;
  taglineSub: string;
  demoClusterLabel: string;
  demoClusterNotice: string;
  demoUser: string;
  demoBadge: string;
  readAloud: string;
  readingAloud: string;
  stopAudio: string;
  unsupportedSpeech: string;
  
  // Auth & User Switcher
  login: string;
  logout: string;
  switchProfile: string;
  loginModalTitle: string;
  loginModalSubtitle: string;
  signInWithGoogle: string;
  signInWithPhone: string;
  enterMobileNumber: string;
  sendOtp: string;
  verifyOtp: string;
  enterOtpPlaceholder: string;
  otpSentNotice: string;
  instantDemoProfiles: string;
  profileFarmer: string;
  profileFpo: string;
  profileAdo: string;
  customSignIn: string;
  fullName: string;
  villageName: string;
  role: string;
  loggedInAs: string;

  // Navigation
  navDashboard: string;
  navAnalysis: string;
  navAdvisory: string;
  navExplanation: string;
  navAskAi: string;
  navFieldMap: string;
  navPlots: string;
  navLeafCheck: string;
  navWeather: string;
  navWeatherMap: string;
  navFpo: string;
  navMandi: string;
  navReports: string;
  navSettings: string;

  // Team & Core features
  teamBadge: string;
  trySampleFarm: string;
  runAnalysis: string;
  resetSample: string;
  waterStress: string;
  nutrientStress: string;
  pestDiseaseRisk: string;
  heatStress: string;

  // Statuses & Risk
  riskLow: string;
  riskWatch: string;
  riskHigh: string;
  riskLowDesc: string;
  riskWatchDesc: string;
  riskHighDesc: string;

  // Data Sources
  sourceFarmer: string;
  sourceSensor: string;
  sourceSatellite: string;
  sourceWeatherApi: string;
  sourceDemo: string;

  // Dashboard & Maps
  greetingFarmer: string;
  greetingSubtitle: string;
  monitoredPlots: string;
  monitoredArea: string;
  highPriorityPlots: string;
  dataCoverage: string;
  fieldHealthOverview: string;
  illustrativeMapNote: string;
  plotStatusList: string;
  weatherStripTitle: string;
  whyThisAlertTitle: string;
  priorityActionsToday: string;
  recentActivity: string;
  clusterRiskSummary: string;
  viewPlotDetails: string;
  actionCompleted: string;
  actionPending: string;
  mapViewSatellite: string;
  mapViewHybrid: string;
  mapViewRoadmap: string;
  mapToggleGoogle: string;
  mapToggleSchematic: string;
  gpsCoordinates: string;
  
  // Plot Explorer
  plotSearchPlaceholder: string;
  filterAllRisk: string;
  filterAllCrops: string;
  sortByRecent: string;
  sortByRisk: string;
  sortByArea: string;
  viewGrid: string;
  viewList: string;
  noPlotsFound: string;
  growthStage: string;
  lastObservation: string;
  soilMoisture: string;
  daysWithoutRain: string;
  weeklyGreenness: string;
  temperature: string;
  humidity: string;

  // Advisory View
  advisoryEngineTitle: string;
  advisoryEngineSubtitle: string;
  howThisWasAssessed: string;
  howFormulaWorks: string;
  whyWeThinkThis: string;
  whatToDoNext: string;
  ruleContributions: string;
  coverageBadgeNote: string;
  missingDataNotes: string;
  officerConsultWarningTitle: string;
  officerConsultWarningBody: string;
  interactiveScenarioTester: string;
  resetToGroundValues: string;
  runSimulation: string;

  // Leaf Check
  leafCheckTitle: string;
  leafCheckSubtitle: string;
  dragDropPhoto: string;
  browsePhoto: string;
  photoFormatLimit: string;
  removePhoto: string;
  symptomsObserved: string;
  selectSymptomsHint: string;
  possibleCausesTitle: string;
  confirmWithAgronomist: string;
  whatToInspectInField: string;
  privacyNoticeTitle: string;
  privacyNoticeBody: string;
  optionalAiVision: string;
  aiVisionDisclaimer: string;

  // Weather & Trends
  spraySuitabilityTitle: string;
  spraySuitabilityDesc: string;
  hourlyForecastTitle: string;
  hourlyForecastDesc: string;
  soilMoistureDepthTitle: string;
  surfaceSoil: string;
  rootZoneSoil: string;
  rainProbability: string;
  windSpeed: string;

  // FPO
  fpoTitle: string;
  fpoSubtitle: string;
  totalPlotsCovered: string;
  totalAreaCovered: string;
  cropRiskBreakdown: string;
  procurementTimeline: string;
  suggestedOperations: string;
  exportFpoCsv: string;
  fpoCaveatTitle: string;
  fpoCaveatText: string;

  // Reports
  reportsTitle: string;
  reportsSubtitle: string;
  filterByDateRange: string;
  filterByPlot: string;
  downloadCsv: string;
  printReport: string;
  advisoryHistoryTable: string;
  allPlots: string;

  // Settings
  settingsTitle: string;
  settingsSubtitle: string;
  prefLanguage: string;
  prefUnits: string;
  prefRegion: string;
  prefSpeech: string;
  resetDemoData: string;
  resetDemoConfirm: string;
  resetSuccess: string;
  aboutTitle: string;
  aboutBody: string;
  close: string;
}

export const LANGUAGE_OPTIONS: { code: SupportedLanguage; label: string; nativeLabel: string; speechLocale: string }[] = [
  { code: 'en', label: 'English', nativeLabel: 'English', speechLocale: 'en-IN' },
  { code: 'ta', label: 'Tamil', nativeLabel: 'தமிழ்', speechLocale: 'ta-IN' },
  { code: 'te', label: 'Telugu', nativeLabel: 'తెలుగు', speechLocale: 'te-IN' },
  { code: 'hi', label: 'Hindi', nativeLabel: 'हिन्दी', speechLocale: 'hi-IN' },
  { code: 'ml', label: 'Malayalam', nativeLabel: 'മലയാളം', speechLocale: 'ml-IN' },
  { code: 'kn', label: 'Kannada', nativeLabel: 'ಕನ್ನಡ', speechLocale: 'kn-IN' },
];

export const translations: Record<SupportedLanguage, TranslationDictionary> = {
  en: {
    appName: 'FarmPulse',
    tagline: 'Don’t just tell the farmer what. Tell them why.',
    taglineSub: 'Explainable Crop Stress Advisory for smallholders & FPOs',
    demoClusterLabel: 'Kaveripakkam Pilot Cluster, Tamil Nadu',
    demoClusterNotice: 'Satellite imagery powered by Google Maps Platform',
    demoUser: 'Marimuthu G. (Smallholder Farmer)',
    demoBadge: 'Demo Data',
    readAloud: 'Read advisory aloud',
    readingAloud: 'Reading aloud...',
    stopAudio: 'Stop audio',
    unsupportedSpeech: 'Speech synthesis not supported in this browser.',

    login: 'Sign In / Switch',
    logout: 'Sign Out',
    switchProfile: 'Switch User Profile',
    loginModalTitle: 'Access FarmPulse',
    loginModalSubtitle: 'Sign in to access your farm plots, cluster analytics, and tailored advisories.',
    signInWithGoogle: 'Continue with Google',
    signInWithPhone: 'Sign In with Mobile OTP',
    enterMobileNumber: 'Enter 10-digit mobile number',
    sendOtp: 'Send OTP SMS',
    verifyOtp: 'Verify & Enter',
    enterOtpPlaceholder: 'Enter 4-digit OTP (e.g. 1234)',
    otpSentNotice: 'OTP sent to mobile! Enter 1234 to proceed.',
    instantDemoProfiles: 'Or Select an Instant Profile:',
    profileFarmer: 'Farmer (Marimuthu G. - 2.4 ac)',
    profileFpo: 'FPO Manager (Senthil Kumar - Kaveripakkam)',
    profileAdo: 'Agronomist / ADO (Dr. Anitha R.)',
    customSignIn: 'New Farmer Registration',
    fullName: 'Full Name',
    villageName: 'Village / Cluster',
    role: 'Primary Role',
    loggedInAs: 'Signed in as',

    navDashboard: 'Dashboard',
    navAnalysis: 'Farm Analysis',
    navAdvisory: 'Crop Stress Advisory',
    navExplanation: 'Explanation & Insights',
    navAskAi: 'Ask AI (Copilot)',
    navFieldMap: 'Land Map & Crops',
    navPlots: 'Plot Explorer',
    navLeafCheck: 'Leaf Check',
    navWeather: 'Weather & Trends',
    navWeatherMap: 'Weather Map',
    navFpo: 'FPO Supply Chain',
    navMandi: 'Mandi Prices & Calendar',
    navReports: 'Reports & History',
    navSettings: 'Settings',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'Try Sample Farm',
    runAnalysis: 'Run Comprehensive Analysis',
    resetSample: 'Reset to Sample',
    waterStress: 'Water Stress',
    nutrientStress: 'Nutrient Stress',
    pestDiseaseRisk: 'Pest & Disease Risk',
    heatStress: 'Heat Stress',

    riskLow: 'Low Stress',
    riskWatch: 'Watch List',
    riskHigh: 'High Risk',
    riskLowDesc: 'Favorable crop conditions; normal routine checks.',
    riskWatchDesc: 'Early moisture or heat deficit; inspect within 48h.',
    riskHighDesc: 'Compound stress detected; immediate ground verification advised.',

    sourceFarmer: 'Farmer Input',
    sourceSensor: 'IoT Ground Sensor',
    sourceSatellite: 'Sentinel-2 Satellite',
    sourceWeatherApi: 'Weather Service',
    sourceDemo: 'Synthetic Demo',

    greetingFarmer: 'Good morning',
    greetingSubtitle: 'Here is your real-time explainable field intelligence briefing for Kaveripakkam.',
    monitoredPlots: 'Monitored Plots',
    monitoredArea: 'Monitored Area',
    highPriorityPlots: 'High Priority Plots',
    dataCoverage: 'Data Coverage',
    fieldHealthOverview: 'Field Health Overview (Google Maps Satellite)',
    illustrativeMapNote: 'High-resolution Google Maps imagery with verified plot boundaries',
    plotStatusList: 'Plot Status & Quick Insights',
    weatherStripTitle: '7-Day Micro-Climate Strip',
    whyThisAlertTitle: 'Why this alert? — Evidence Snapshot',
    priorityActionsToday: 'Priority Actions Today',
    recentActivity: 'Recent Field Logs',
    clusterRiskSummary: 'Cluster Risk Distribution',
    viewPlotDetails: 'View Full Analysis',
    actionCompleted: 'Completed',
    actionPending: 'Pending action',
    mapViewSatellite: 'Satellite',
    mapViewHybrid: 'Hybrid',
    mapViewRoadmap: 'Roadmap',
    mapToggleGoogle: 'Google Maps View',
    mapToggleSchematic: 'Schematic Grid',
    gpsCoordinates: 'GPS Coordinates',

    plotSearchPlaceholder: 'Search by plot name, variety, or farmer...',
    filterAllRisk: 'All Risk Levels',
    filterAllCrops: 'All Varieties',
    sortByRecent: 'Most Recent Observation',
    sortByRisk: 'Highest Risk First',
    sortByArea: 'Largest Area First',
    viewGrid: 'Grid View',
    viewList: 'List View',
    noPlotsFound: 'No plots match your active filters.',
    growthStage: 'Growth Stage',
    lastObservation: 'Last Logged',
    soilMoisture: 'Soil Moisture',
    daysWithoutRain: 'Rain-free Days',
    weeklyGreenness: 'Weekly Greenness Trend',
    temperature: 'Ambient Peak',
    humidity: 'Relative Humidity',

    advisoryEngineTitle: 'Explainable Crop Stress Advisory',
    advisoryEngineSubtitle: 'Transparent, rule-backed assessment showing real factors and thresholds.',
    howThisWasAssessed: 'How this was assessed',
    howFormulaWorks: 'FarmPulse assesses crop stress using deterministic, agronomist-aligned threshold rules across ground soil moisture, consecutive rain-free days, canopy greenness changes, and atmospheric thermal load. The stress score (0–100) sums weighted rule violations. It is a decision-support indicator, NOT a probabilistic model or guaranteed yield forecast.',
    whyWeThinkThis: 'Why we think this (Evidence & Rules)',
    whatToDoNext: 'What to do next (Prioritized Action)',
    ruleContributions: 'Rule contributions (demo)',
    coverageBadgeNote: 'Coverage indicates available inputs; it is not prediction accuracy.',
    missingDataNotes: 'Uncertainty & Missing Data Notes',
    officerConsultWarningTitle: 'Agronomist Consultation Recommended',
    officerConsultWarningBody: 'Before purchasing inputs, changing chemical treatments, or applying heavy deep flooding, consult your local Village Administrative Officer or Block Agriculture Extension Officer.',
    interactiveScenarioTester: 'Interactive Scenario Tester (What-If)',
    resetToGroundValues: 'Reset to Ground Truth',
    runSimulation: 'Calculate Advisory',

    leafCheckTitle: 'Leaf Visual Inspection Assistant',
    leafCheckSubtitle: 'Upload a leaf photo and select symptoms for safe, cautious field guidance.',
    dragDropPhoto: 'Drag & drop a leaf photo here, or click to browse',
    browsePhoto: 'Select Photo',
    photoFormatLimit: 'JPEG, PNG, WebP up to 5 MB. Please do not photograph faces or private documents.',
    removePhoto: 'Remove photo',
    symptomsObserved: 'What symptoms do you observe in the field?',
    selectSymptomsHint: 'Select all visual signs that match what you see on the leaf:',
    possibleCausesTitle: 'Possible Causes & Differential Diagnosis',
    confirmWithAgronomist: 'Possible causes — confirm with an agronomist before taking action.',
    whatToInspectInField: 'What to inspect on-site before deciding:',
    privacyNoticeTitle: 'Farmer Privacy & Data Protection',
    privacyNoticeBody: 'Photo analysis is processed locally in your browser. No personal identifiable images are stored on external servers without consent.',
    optionalAiVision: 'Optional AI Visual Second Opinion',
    aiVisionDisclaimer: 'Experimental visual preview. Never purchase commercial chemicals based solely on automated image classification.',

    spraySuitabilityTitle: 'Agronomic Field Operations & Spray Window',
    spraySuitabilityDesc: 'Guidance based on ambient temperature, humidity, and wind speed.',
    hourlyForecastTitle: '24-Hour Micro-Climate & Rain Trajectory',
    hourlyForecastDesc: 'Hourly temperature, rain probability, and root-zone moisture tension.',
    soilMoistureDepthTitle: 'Soil Moisture by Depth Profile',
    surfaceSoil: 'Surface Layer (0–10 cm)',
    rootZoneSoil: 'Active Root Zone (10–30 cm)',
    rainProbability: 'Rain Prob.',
    windSpeed: 'Wind',

    fpoTitle: 'FPO Supply-Chain & Cluster Outlook',
    fpoSubtitle: 'Aggregate planning signals for farmer producer organizations and procurement managers.',
    totalPlotsCovered: 'Total Plots Tracked',
    totalAreaCovered: 'Total Acreage Tracked',
    cropRiskBreakdown: 'Crop & Variety Risk Breakdown',
    procurementTimeline: 'Procurement-Readiness Timeline',
    suggestedOperations: 'Suggested FPO Operations',
    exportFpoCsv: 'Export Cluster Outlook (CSV)',
    fpoCaveatTitle: 'Aggregated Planning Signal Only',
    fpoCaveatText: 'Validate with field visits, farmer reports, crop calendars and buyer/FPO coordination. Not a guaranteed yield forecast. Individual plot locations are protected.',

    reportsTitle: 'Reports & Export Center',
    reportsSubtitle: 'Generate printable advisories, filter field logs, and download compliance CSV files.',
    filterByDateRange: 'Date Range',
    filterByPlot: 'Select Plot',
    downloadCsv: 'Download Filtered CSV',
    printReport: 'Print / Save PDF',
    advisoryHistoryTable: 'Advisory Logs & Ground Evidence',
    allPlots: 'All Monitored Plots',

    settingsTitle: 'Application Settings & Preferences',
    settingsSubtitle: 'Configure language, measurement units, audio preferences, and demo mode.',
    prefLanguage: 'Application Language',
    prefUnits: 'Measurement Units',
    prefRegion: 'Pilot Region / District',
    prefSpeech: 'Audio Voice Readout',
    resetDemoData: 'Reset Demo Data to Initial State',
    resetDemoConfirm: 'Are you sure you want to reset all demo plots and custom notes?',
    resetSuccess: 'Demo data has been reset to defaults.',
    aboutTitle: 'About FarmPulse',
    aboutBody: 'FarmPulse was built as an explainable agricultural intelligence platform. Unlike black-box models, FarmPulse exposes every metric, threshold, and source behind its alerts so farmers and extension officers can make informed, safe decisions.',
    close: 'Close',
  },

  ta: {
    appName: 'ஃபார்ம்பல்ஸ் (FarmPulse)',
    tagline: 'என்ன நடக்கிறது என்று மட்டும் சொல்லாதீர்கள். ஏன் நடக்கிறது என்று விளக்குங்கள்.',
    taglineSub: 'விவசாயிகள் மற்றும் உழவர் உற்பத்தியாளர் அமைப்புகளுக்கான விளக்கமளிக்கும் பயிர் ஆலோசனை',
    demoClusterLabel: 'காவேரிப்பாக்கம் மாதிரி வேளாண் வட்டம், தமிழ்நாடு',
    demoClusterNotice: 'கூகிள் மேப்ஸ் செயற்கைக்கோள் வரைபட தொழில்நுட்பம்',
    demoUser: 'மாரிமுத்து கு. (விவசாயி)',
    demoBadge: 'மாதிரி தரவு',
    readAloud: 'ஆலோசனையை குரலில் கேட்க',
    readingAloud: 'வாசிக்கிறது...',
    stopAudio: 'ஆடியோவை நிறுத்து',
    unsupportedSpeech: 'இந்த உலாவியில் குரல் வாசிப்பு வசதி இல்லை.',

    login: 'உள்நுழைக / மாற்று',
    logout: 'வெளியேறு',
    switchProfile: 'பயனர் சுயவிவரத்தை மாற்றுக',
    loginModalTitle: 'ஃபார்ம்பல்ஸ் உள்நுழைவு',
    loginModalSubtitle: 'உங்கள் வயல்கள், பயிர் ஆலோசனை மற்றும் வரைபடங்களை அணுக உள்நுழையவும்.',
    signInWithGoogle: 'கூகிள் மூலம் உள்நுழைக',
    signInWithPhone: 'கைபேசி OTP மூலம் உள்நுழைக',
    enterMobileNumber: '10 இலக்க கைபேசி எண்ணை உள்ளிடவும்',
    sendOtp: 'OTP அனுப்புக',
    verifyOtp: 'சரிபார்த்து உள்நுழைக',
    enterOtpPlaceholder: '4 இலக்க OTP (எ.கா. 1234)',
    otpSentNotice: 'OTP அனுப்பப்பட்டது! தொடர 1234 ஐ உள்ளிடவும்.',
    instantDemoProfiles: 'அல்லது மாதிரி சுயவிவரத்தை தேர்வு செய்க:',
    profileFarmer: 'விவசாயி (மாரிமுத்து கு. - 2.4 ஏக்கர்)',
    profileFpo: 'FPO மேலாளர் (செந்தில் குமார் - காவேரிப்பாக்கம்)',
    profileAdo: 'வேளாண்மை அலுவலர் (முனைவர் அனிதா ரா.)',
    customSignIn: 'புதிய விவசாயி பதிவு',
    fullName: 'முழு பெயர்',
    villageName: 'கிராமம் / வட்டம்',
    role: 'முதன்மை பங்கு',
    loggedInAs: 'உள்நுழைந்துள்ள கணக்கு',

    navDashboard: 'முகப்பு பலகை',
    navAnalysis: 'பண்ணை ஆய்வு',
    navAdvisory: 'பயிர் பாதிப்பு ஆலோசனை',
    navExplanation: 'விளக்கம் & பகுப்பாய்வு',
    navAskAi: 'வேளாண் AI உதவியாளர்',
    navFieldMap: 'புல வரைபடம் & பயிர்கள்',
    navPlots: 'நிலங்கள் ஆய்வு',
    navLeafCheck: 'இலை ஆய்வு',
    navWeather: 'வானிலை & போக்குகள்',
    navWeatherMap: 'வானிலை வரைபடம்',
    navFpo: 'உழவர் உற்பத்தியாளர் அமைப்பு',
    navMandi: 'மண்டி சந்தை & பயிர் காலண்டர்',
    navReports: 'அறிக்கைகள் & வரலாறு',
    navSettings: 'அமைப்புகள்',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'மாதிரி பண்ணையை சோதிக்க',
    runAnalysis: 'முழுமையான ஆய்வு செய்க',
    resetSample: 'மாதிரிக்கு மீட்டமைக்க',
    waterStress: 'நீர் அழுத்த பாதிப்பு',
    nutrientStress: 'ஊட்டச்சத்து குறைபாடு',
    pestDiseaseRisk: 'பூச்சி & நோய் அபாயம்',
    heatStress: 'வெப்ப அழுத்த பாதிப்பு',

    riskLow: 'குறைந்த பாதிப்பு',
    riskWatch: 'கவனிக்க வேண்டியவை',
    riskHigh: 'அதிக பாதிப்பு',
    riskLowDesc: 'பயிர் வளர்ச்சி சாதகமாக உள்ளது; வழக்கமான கள ஆய்வு போதுமானது.',
    riskWatchDesc: 'ஆரம்ப நிலை நீர் அல்லது வெப்ப பற்றாக்குறை; 48 மணி நேரத்தில் கவனிக்கவும்.',
    riskHighDesc: 'அதிகரித்த பயிர் பாதிப்பு; உடனடியாக வயலை நேரில் ஆய்வு செய்யவும்.',

    sourceFarmer: 'விவசாயி பதிவு',
    sourceSensor: 'மண் சென்சார் அளவீடு',
    sourceSatellite: 'சென்டினல்-2 செயற்கைக்கோள்',
    sourceWeatherApi: 'வானிலை சேவை',
    sourceDemo: 'மாதிரி தரவு',

    greetingFarmer: 'வணக்கம்',
    greetingSubtitle: 'காவேரிப்பாக்கம் வட்டாரத்திற்கான இன்றைய பயிர் நிலை மற்றும் கூகிள் மேப்ஸ் நேரலை அறிக்கை.',
    monitoredPlots: 'கண்காணிக்கப்படும் நிலங்கள்',
    monitoredArea: 'மொத்த பரப்பளவு',
    highPriorityPlots: 'அவசர கவன நிலங்கள்',
    dataCoverage: 'கிடைத்த தரவு அளவு',
    fieldHealthOverview: 'வயல்வெளி கூகிள் மேப்ஸ் செயற்கைக்கோள் பார்வை',
    illustrativeMapNote: 'உயர் துல்லிய கூகிள் மேப்ஸ் செயற்கைக்கோள் காட்சி மற்றும் நில எல்லைகள்',
    plotStatusList: 'நிலங்களின் தற்போதைய நிலை',
    weatherStripTitle: '7 நாள் உள்ளூர் வானிலை நிலவரம்',
    whyThisAlertTitle: 'ஏன் இந்த எச்சரிக்கை? — முக்கிய ஆதாரங்கள்',
    priorityActionsToday: 'இன்று செய்ய வேண்டிய முக்கிய பணிகள்',
    recentActivity: 'சமீபத்திய கள பதிவுகள்',
    clusterRiskSummary: 'வட்டார அளவிலான பயிர் பாதிப்பு விபரம்',
    viewPlotDetails: 'முழு விவரங்களை பார்க்க',
    actionCompleted: 'முடிந்தது',
    actionPending: 'நிலுவையில் உள்ள பணி',
    mapViewSatellite: 'செயற்கைக்கோள்',
    mapViewHybrid: 'கலப்பு பார்வை',
    mapViewRoadmap: 'சாலை வரைபடம்',
    mapToggleGoogle: 'கூகிள் மேப்ஸ் பார்வை',
    mapToggleSchematic: 'கட்ட வரைபடம்',
    gpsCoordinates: 'ஜிபிஎஸ் இருப்பிடம்',

    plotSearchPlaceholder: 'நிலம், நெல் ரகம் அல்லது விவசாயி பெயரை தேடவும்...',
    filterAllRisk: 'அனைத்து பாதிப்பு நிலைகள்',
    filterAllCrops: 'அனைத்து நெல் ரகங்கள்',
    sortByRecent: 'சமீபத்திய பதிவு',
    sortByRisk: 'அதிக பாதிப்பு முதலில்',
    sortByArea: 'அதிக பரப்பளவு முதலில்',
    viewGrid: 'கட்ட அமைப்பில் பார்க்க',
    viewList: 'பட்டியல் அமைப்பில் பார்க்க',
    noPlotsFound: 'தேடலுக்குரிய நிலங்கள் எதுவும் இல்லை.',
    growthStage: 'பயிர் வளர்ச்சி பருவம்',
    lastObservation: 'கடைசி பதிவு நேரம்',
    soilMoisture: 'மண் ஈரப்பதம்',
    daysWithoutRain: 'மழை இல்லாத நாட்கள்',
    weeklyGreenness: 'வாராந்திர பசுமை மாற்றம்',
    temperature: 'உச்ச வெப்பநிலை',
    humidity: 'காற்றின் ஈரப்பதம்',

    advisoryEngineTitle: 'விளக்கமளிக்கும் பயிர் ஆலோசனை இயந்திரம்',
    advisoryEngineSubtitle: 'வெளிப்படையான விதிகள் மற்றும் உண்மை ஆதாரங்களை விளக்கும் அறிக்கை.',
    howThisWasAssessed: 'இது எவ்வாறு கணக்கிடப்பட்டது?',
    howFormulaWorks: 'ஃபார்ம்பல்ஸ் முறை மண் ஈரப்பதம், மழை பெய்யாத நாட்கள், பயிர் பசுமை மாற்றம் மற்றும் வெப்பநிலையை அடிப்படையாகக் கொண்டு விவசாயிகளுக்கான வெளிப்படையான விதிகளால் கணக்கிடப்படுகிறது. இந்த 0-100 மதிப்பீடு ஒரு வழிகாட்டுதல் குறியீடு மட்டுமே; இது உத்தேச மகசூல் கணிப்பு அல்ல.',
    whyWeThinkThis: 'ஏன் இப்படி பரிந்துரைக்கிறோம்? (காரணங்கள் & விதிகள்)',
    whatToDoNext: 'அடுத்து என்ன செய்ய வேண்டும்? (பாதுகாப்பான முன்னுரிமை நடவடிக்கை)',
    ruleContributions: 'விதிகளின் பங்களிப்பு (மாதிரி)',
    coverageBadgeNote: 'கிடைத்த தரவுகளின் சதவீதத்தை குறிக்கிறது; இது கணிப்பு துல்லியம் அல்ல.',
    missingDataNotes: 'கிடைக்காத தரவுகள் & குறிப்புகள்',
    officerConsultWarningTitle: 'வேளாண்மை அலுவலரிடம் ஆலோசனை பெறவும்',
    officerConsultWarningBody: 'ரசாயன மருந்துகளை வாங்குவதற்கு முன்போ அல்லது திடீரென அதிக தண்ணீர் பாய்ச்சுவதற்கு முன்போ கிராம நிர்வாக அலுவலர் அல்லது வட்டார வேளாண்மை அலுவலரிடம் ஆலோசனை பெறவும்.',
    interactiveScenarioTester: 'சுய ஆய்வு பரிசோதனை கருவி (What-If)',
    resetToGroundValues: 'இயல்பு நிலைக்கு மீட்டமைக்க',
    runSimulation: 'ஆலோசனையை கணக்கிடு',

    leafCheckTitle: 'இலை காட்சி ஆய்வு உதவியாளர்',
    leafCheckSubtitle: 'இலையின் புகைப்படத்தை பதிவேற்றி, அறிகுறிகளை தேர்வு செய்து பாதுகாப்பான வழிகாட்டுதலைப் பெறுங்கள்.',
    dragDropPhoto: 'இலை புகைப்படத்தை இங்கே இழுத்து விடவும் அல்லது கிளிக் செய்து தேர்வு செய்யவும்',
    browsePhoto: 'புகைப்படத்தை தேர்வு செய்க',
    photoFormatLimit: 'JPEG, PNG, WebP அதிகபட்சம் 5 எம்பி. நபர்களின் முகம் அல்லது ஆவணங்களை பதிவேற்ற வேண்டாம்.',
    removePhoto: 'புகைப்படத்தை நீக்கு',
    symptomsObserved: 'வயலில் நீங்கள் என்ன அறிகுறிகளைக் காண்கிறீர்கள்?',
    selectSymptomsHint: 'இலையில் தென்படும் பொருத்தமான அறிகுறிகளைத் தேர்ந்தெடுக்கவும்:',
    possibleCausesTitle: 'சாத்தியமான காரணங்கள் & ஆரம்பகட்ட ஆய்வு',
    confirmWithAgronomist: 'சாத்தியமான காரணங்கள் மட்டுமே — முடிவெடுக்கும் முன் வேளாண் அதிகாரியிடம் உறுதிப்படுத்தவும்.',
    whatToInspectInField: 'முடிவெடுப்பதற்கு முன் வயலில் நேரில் சரிபார்க்க வேண்டியவை:',
    privacyNoticeTitle: 'விவசாயி தனியுரிமை & பாதுகாப்பு',
    privacyNoticeBody: 'புகைப்பட ஆய்வு உங்கள் உலாவியிலேயே நடைபெறுகிறது. உங்கள் அனுமதி இல்லாமல் எந்த தனிப்பட்ட படங்களும் வெளிப்புற சர்வர்களுக்கு அனுப்பப்படாது.',
    optionalAiVision: 'கூடுதல் ஏஐ (AI) காட்சி கருத்து',
    aiVisionDisclaimer: 'சோதனை ரீதியான காட்சி வழிகாட்டுதல் மட்டுமே. தானியங்கி முடிவுகளை மட்டுமே நம்பி ரசாயன மருந்துகளை வாங்க வேண்டாம்.',

    spraySuitabilityTitle: 'மருந்து தெளிப்பு & பாசனத்திற்கான உகந்த நேரம்',
    spraySuitabilityDesc: 'வெப்பநிலை, காற்றின் வேகம் மற்றும் ஈரப்பதத்தை அடிப்படையாகக் கொண்ட கள வழிகாட்டல்.',
    hourlyForecastTitle: '24 மணி நேர மணிநேர வானிலை & மழை வாய்ப்பு',
    hourlyForecastDesc: 'மணிநேர வெப்பநிலை, மழைப்பொழிவு சதவீதம் மற்றும் வேர் பகுதி ஈரப்பதம்.',
    soilMoistureDepthTitle: 'ஆழம் வாரியான மண் ஈரப்பதம்',
    surfaceSoil: 'மேல்மண் அடுக்கு (0–10 செ.மீ)',
    rootZoneSoil: 'வேர் மண்டல அடுக்கு (10–30 செ.மீ)',
    rainProbability: 'மழை வாய்ப்பு',
    windSpeed: 'காற்று வேகம்',

    fpoTitle: 'உழவர் உற்பத்தியாளர் அமைப்பு சப்ளை செயின் கண்ணோட்டம்',
    fpoSubtitle: 'உழவர் அமைப்புகள் மற்றும் கொள்முதல் திட்டமிடலுக்கான வட்டார அளவிலான வழிகாட்டுதல்.',
    totalPlotsCovered: 'கண்காணிக்கப்படும் நிலங்கள்',
    totalAreaCovered: 'மொத்த பயிர் பரப்பளவு',
    cropRiskBreakdown: 'நெல் ரகம் வாரியான பாதிப்பு விபரம்',
    procurementTimeline: 'கொள்முதல் தயார்நிலை காலக்கோடு',
    suggestedOperations: 'உழவர் அமைப்பிற்கான பரிந்துரைக்கப்படும் செயல்பாடுகள்',
    exportFpoCsv: 'வட்டார அறிக்கையை பதிவிறக்கு (CSV)',
    fpoCaveatTitle: 'திட்டமிடல் வழிகாட்டி மட்டுமே',
    fpoCaveatText: 'கள ஆய்வுகள், விவசாயிகளின் நேரடி தகவல் மற்றும் பயிர் கால அட்டவணையை ஒப்பிட்டு உறுதிப்படுத்தவும். இது உறுதியான மகசூல் கணிப்பு அல்ல. விவசாயிகளின் தனிநபர் இருப்பிடம் பாதுகாக்கப்படும்.',

    reportsTitle: 'அறிக்கைகள் & பதிவிறக்க மையம்',
    reportsSubtitle: 'அச்சிடத்தக்க ஆலோசனைகள், கள பதிவுகள் மற்றும் CSV கோப்புகளைப் பெறுங்கள்.',
    filterByDateRange: 'தேதி வரம்பு',
    filterByPlot: 'நிலத்தை தேர்வு செய்க',
    downloadCsv: 'வடிகட்டிய CSV கோப்பை பதிவிறக்கு',
    printReport: 'அச்சிடு / PDF சேமி',
    advisoryHistoryTable: 'ஆலோசனை பதிவுகள் & கள சான்றுகள்',
    allPlots: 'அனைத்து நிலங்களும்',

    settingsTitle: 'செயலி அமைப்புகள் & விருப்பத்தேர்வுகள்',
    settingsSubtitle: 'மொழி, அளவீட்டு அலகுகள், குரல் வாசிப்பு மற்றும் மாதிரி அமைப்புகளை மாற்றவும்.',
    prefLanguage: 'பயன்பாட்டு மொழி',
    prefUnits: 'அளவீட்டு அலகுகள்',
    prefRegion: 'பயிற்சி வட்டம் / மாவட்டம்',
    prefSpeech: 'குரல் வாசிப்பு வசதி',
    resetDemoData: 'மாதிரி தரவுகளை மீண்டும் தொடக்க நிலைக்கு மாற்ற',
    resetDemoConfirm: 'அனைத்து மாதிரி நிலங்கள் மற்றும் குறிப்புகளை தொடக்க நிலைக்கு மாற்ற விரும்புகிறீர்களா?',
    resetSuccess: 'மாதிரி தரவுகள் வெற்றிகரமாக மீட்டமைக்கப்பட்டன.',
    aboutTitle: 'ஃபார்ம்பல்ஸ் பற்றி',
    aboutBody: 'ஃபார்ம்பல்ஸ் விவசாயிகளுக்கு ஒளிவுமறைவற்ற விளக்கமளிக்கும் நோக்குடன் உருவாக்கப்பட்டது. சாதாரண மாடல்கள் போல வெறும் எண்களை மட்டும் தராமல், எதனால் இந்த முடிவு எடுக்கப்பட்டது என்ற காரணத்தை விளக்கி விவசாயிகளுக்கு துணை நிற்கிறது.',
    close: 'மூடுக',
  },

  te: {
    appName: 'ఫార్మ్‌పల్స్ (FarmPulse)',
    tagline: 'ఏమి జరుగుతుందో మాత్రమే కాదు, ఎందుకు జరుగుతుందో వివరించండి.',
    taglineSub: 'రైతులు మరియు రైతు ఉత్పత్తిదారుల సంస్థల కోసం వివరణాత్మక పంట సలహా',
    demoClusterLabel: 'కావేరిపాక్కం పైలట్ క్లస్టర్, తమిళనాడు',
    demoClusterNotice: 'గూగుల్ మ్యాప్స్ ఉపగ్రహ చిత్రాలు',
    demoUser: 'మారిముత్తు జి. (రైతు)',
    demoBadge: 'డెమో డేటా',
    readAloud: 'సలహాను గట్టిగా చదవండి',
    readingAloud: 'చదువుతోంది...',
    stopAudio: 'ఆడియో ఆపు',
    unsupportedSpeech: 'ఈ బ్రౌజర్‌లో వాయిస్ రీడింగ్ సదుపాయం లేదు.',

    login: 'లాగిన్ / మార్చు',
    logout: 'లాగౌట్',
    switchProfile: 'యూజర్ ప్రొఫైల్ మార్చు',
    loginModalTitle: 'ఫార్మ్‌పల్స్ ప్రవేశం',
    loginModalSubtitle: 'మీ పొలాలు, పంట సలహాలు మరియు మ్యాప్‌లను చూడటానికి లాగిన్ అవ్వండి.',
    signInWithGoogle: 'గూగుల్‌తో కొనసాగండి',
    signInWithPhone: 'మొబైల్ OTP తో లాగిన్ అవ్వండి',
    enterMobileNumber: '10 అంకెల మొబైల్ నంబర్ నమోదు చేయండి',
    sendOtp: 'OTP పంపండి',
    verifyOtp: 'ధృవీకరించి ప్రవేశించండి',
    enterOtpPlaceholder: '4 అంకెల OTP (ఉదా: 1234)',
    otpSentNotice: 'OTP పంపబడింది! కొనసాగడానికి 1234 ను నమోదు చేయండి.',
    instantDemoProfiles: 'లేదా ఒక డెమో ప్రొఫైల్‌ను ఎంచుకోండి:',
    profileFarmer: 'రైతు (మారిముత్తు జి. - 2.4 ఎకరాలు)',
    profileFpo: 'ఎఫ్.పి.ఓ మేనేజర్ (సెంథిల్ కుమార్)',
    profileAdo: 'వ్యవసాయ అధికారి (డాక్టర్ అనిత ఆర్.)',
    customSignIn: 'కొత్త రైతు నమోదు',
    fullName: 'పూర్తి పేరు',
    villageName: 'గ్రామం / మండలం',
    role: 'పాత్ర',
    loggedInAs: 'లాగిన్ అయ్యారు',

    navDashboard: 'డ్యాష్‌బోర్డ్',
    navAnalysis: 'పొలం విశ్లేషణ',
    navAdvisory: 'పంట ఒత్తిడి సలహా',
    navExplanation: 'వివరణ & అంతర్దృష్టులు',
    navAskAi: 'అగ్రి AI సహాయకుడు',
    navFieldMap: 'భూమి మ్యాప్ & పంటలు',
    navPlots: 'పొలాలు పరిశోధన',
    navLeafCheck: 'ఆకు తనిఖీ',
    navWeather: 'వాతావరణం & పోకడలు',
    navWeatherMap: 'వాతావరణ పటం',
    navFpo: 'రైతు సంస్థ సప్లై చైన్',
    navMandi: 'మండీ ధరలు & పంట క్యాలెండర్',
    navReports: 'నివేదికలు & చరిత్ర',
    navSettings: 'సెట్టింగ్‌లు',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'నమూనా పొలం పరిశీలించండి',
    runAnalysis: 'సమగ్ర విశ్లేషణ ప్రారంభించండి',
    resetSample: 'నమూనాకు రీసెట్ చేయండి',
    waterStress: 'నీటి ఒత్తిడి',
    nutrientStress: 'పోషకాల లోపం',
    pestDiseaseRisk: 'పురుగు & తెగులు ప్రమాదం',
    heatStress: 'వేడిమి ఒత్తిడి',

    riskLow: 'తక్కువ ఒత్తిడి',
    riskWatch: 'గమనించవలసినవి',
    riskHigh: 'అధిక ప్రమాదం',
    riskLowDesc: 'పంట పరిస్థితులు అనుకూలంగా ఉన్నాయి.',
    riskWatchDesc: 'నీటి లేదా ఉష్ణోగ్రత కొరత ప్రారంభ దశ.',
    riskHighDesc: 'తీవ్రమైన ఒత్తిడి; వెంటనే క్షేత్ర తనిఖీ చేయండి.',

    sourceFarmer: 'రైతు నమోదు',
    sourceSensor: 'నేల సెన్సార్',
    sourceSatellite: 'సెంటినెల్-2 ఉపగ్రహం',
    sourceWeatherApi: 'వాతావరణ సేవ',
    sourceDemo: 'డెమో డేటా',

    greetingFarmer: 'శుభోదయం',
    greetingSubtitle: 'కావేరిపాక్కం క్లస్టర్ కోసం నేటి పంట సమాచారం.',
    monitoredPlots: 'పర్యవేక్షించే పొలాలు',
    monitoredArea: 'మొత్తం వైశాల్యం',
    highPriorityPlots: 'అత్యవసర పొలాలు',
    dataCoverage: 'డేటా కవరేజ్',
    fieldHealthOverview: 'పొలాల ఆరోగ్యం (గూగుల్ మ్యాప్స్ శాటిలైట్)',
    illustrativeMapNote: 'గూగుల్ మ్యాప్స్ ఆధారిత ఖచ్చితమైన పొలాల ఉపగ్రహ చిత్రం',
    plotStatusList: 'పొలాల తాజా స్థితి',
    weatherStripTitle: '7 రోజుల వాతావరణం',
    whyThisAlertTitle: 'ఈ హెచ్చరిక ఎందుకు? — సాక్ష్యాలు',
    priorityActionsToday: 'ఈ రోజు ప్రాధాన్యత చర్యలు',
    recentActivity: 'ఇటీవలి చర్యలు',
    clusterRiskSummary: 'ప్రాంతీయ ప్రమాద విశ్లేషణ',
    viewPlotDetails: 'పూర్తి వివరాలు చూడండి',
    actionCompleted: 'పూర్తయింది',
    actionPending: 'పెండింగ్ పని',
    mapViewSatellite: 'శాటిలైట్',
    mapViewHybrid: 'హైబ్రిడ్',
    mapViewRoadmap: 'రోడ్ మ్యాప్',
    mapToggleGoogle: 'గూగుల్ మ్యాప్స్',
    mapToggleSchematic: 'గ్రిడ్ వ్యూ',
    gpsCoordinates: 'జీపీఎస్ స్థానం',

    plotSearchPlaceholder: 'పొలం, రకం లేదా రైతు పేరును శోధించండి...',
    filterAllRisk: 'అన్ని ప్రమాద స్థాయిలు',
    filterAllCrops: 'అన్ని పంట రకాలు',
    sortByRecent: 'ఇటీవలి సమయం',
    sortByRisk: 'అధిక ప్రమాదం మొదట',
    sortByArea: 'పెద్ద వైశాల్యం మొదట',
    viewGrid: 'గ్రిడ్ రూపం',
    viewList: 'జాబితా రూపం',
    noPlotsFound: 'పొలాలు కనుగొనబడలేదు.',
    growthStage: 'పంట దశ',
    lastObservation: 'చివరి నమోదు',
    soilMoisture: 'నేల తేమ',
    daysWithoutRain: 'వర్షం లేని రోజులు',
    weeklyGreenness: 'వారం పచ్చదనం మార్పు',
    temperature: 'ఉష్ణోగ్రత',
    humidity: 'గాలిలో తేమ',

    advisoryEngineTitle: 'వివరణాత్మక పంట సలహా ఇంజిన్',
    advisoryEngineSubtitle: 'పారదర్శకమైన నిబంధనలతో కూడిన సలహా.',
    howThisWasAssessed: 'ఇది ఎలా లెక్కించబడింది?',
    howFormulaWorks: 'ఫార్మ్‌పల్స్ స్పష్టమైన నిబంధనలతో నేల తేమ, వర్షం లేని రోజులు, పచ్చదనం మరియు ఉష్ణోగ్రతను విశ్లేషిస్తుంది.',
    whyWeThinkThis: 'ఎందుకు ఇలా సిఫార్సు చేస్తున్నాము?',
    whatToDoNext: 'తర్వాత ఏమి చేయాలి?',
    ruleContributions: 'నిబంధనల వాటా (డెమో)',
    coverageBadgeNote: 'డేటా లభ్యత శాతాన్ని సూచిస్తుంది.',
    missingDataNotes: 'అందుబాటులో లేని డేటా వివరాలు',
    officerConsultWarningTitle: 'వ్యవసాయ అధికారితో సంప్రదించండి',
    officerConsultWarningBody: 'రసాయన మందులు చల్లే ముందు లేదా నీరు పారించే ముందు వ్యవసాయ అధికారిని సంప్రదించండి.',
    interactiveScenarioTester: 'వాట్-ఇఫ్ ప్రయోగ సాధనం',
    resetToGroundValues: 'తిరిగి సెట్ చేయండి',
    runSimulation: 'లెక్కింపు చేయండి',

    leafCheckTitle: 'ఆకు దృశ్య తనిఖీ సహాయకుడు',
    leafCheckSubtitle: 'ఆకు ఫోటోను అప్‌లోడ్ చేసి లక్షణాలను ఎంచుకోండి.',
    dragDropPhoto: 'ఆకు ఫోటోను ఇక్కడ లాగి వదలండి',
    browsePhoto: 'ఫోటోను ఎంచుకోండి',
    photoFormatLimit: 'JPEG, PNG, WebP గరిష్టంగా 5 MB.',
    removePhoto: 'ఫోటో తొలగించండి',
    symptomsObserved: 'పొలంలో మీరు ఏమి గమనించారు?',
    selectSymptomsHint: 'ఆకుపై కనిపించే లక్షణాలను ఎంచుకోండి:',
    possibleCausesTitle: 'సాధ్యమయ్యే కారణాలు',
    confirmWithAgronomist: 'నిర్ధారణకు వ్యవసాయ అధికారిని సంప్రదించండి.',
    whatToInspectInField: 'క్షేత్రంలో తనిఖీ చేయవలసినవి:',
    privacyNoticeTitle: 'రైతు గోప్యత & భద్రత',
    privacyNoticeBody: 'ఫోటో విశ్లేషణ మీ బ్రౌజర్‌లోనే జరుగుతుంది.',
    optionalAiVision: 'ఐచ్ఛిక AI అభిప్రాయం',
    aiVisionDisclaimer: 'ఇది ప్రయోగాత్మక అంచనా మాత్రమే.',

    spraySuitabilityTitle: 'మందుల పిచికారీ మరియు నీటిపారుదల సమయం',
    spraySuitabilityDesc: 'ఉష్ణోగ్రత, గాలి వేగం మరియు తేమ ఆధారంగా మార్గదర్శకత్వం.',
    hourlyForecastTitle: '24 గంటల వాతావరణం & వర్షపు సూచన',
    hourlyForecastDesc: 'గంటల వారీ ఉష్ణోగ్రత, వర్షపు శాతం మరియు నేల తేమ.',
    soilMoistureDepthTitle: 'లోతు ప్రకారం నేల తేమ',
    surfaceSoil: 'పైపొర (0–10 సెం.మీ)',
    rootZoneSoil: 'వేరు పొర (10–30 సెం.మీ)',
    rainProbability: 'వర్షం శాతం',
    windSpeed: 'గాలి వేగం',

    fpoTitle: 'రైతు ఉత్పత్తిదారుల సంస్థ సరఫరా చైన్',
    fpoSubtitle: 'సేకరణ ప్రణాళిక కోసం ప్రాంతీయ సూచనలు.',
    totalPlotsCovered: 'పర్యవేక్షించే పొలాలు',
    totalAreaCovered: 'మొత్తం పంట వైశాల్యం',
    cropRiskBreakdown: 'రకాల వారీగా విశ్లేషణ',
    procurementTimeline: 'కోత సంసిద్ధత సమయ రేఖ',
    suggestedOperations: 'సిఫార్సు చేసిన కార్యకలాపాలు',
    exportFpoCsv: 'నివేదికను ఎగుమతి చేయండి (CSV)',
    fpoCaveatTitle: 'ప్రణాళిక మార్గదర్శి మాత్రమే',
    fpoCaveatText: 'క్షేత్ర పర్యటనలతో సరిచూసుకోండి.',

    reportsTitle: 'నివేదికలు & డౌన్‌లోడ్',
    reportsSubtitle: 'ప్రింట్ చేయదగిన సలహాలు మరియు CSV ఫైల్స్.',
    filterByDateRange: 'తేదీ వ్యవధి',
    filterByPlot: 'పొలాన్ని ఎంచుకోండి',
    downloadCsv: 'CSV డౌన్‌లోడ్ చేయండి',
    printReport: 'ప్రింట్ / PDF',
    advisoryHistoryTable: 'సలహా చరిత్ర',
    allPlots: 'అన్ని పొలాలు',

    settingsTitle: 'సెట్టింగ్‌లు & ప్రాధాన్యతలు',
    settingsSubtitle: 'భాష, యూనిట్లు మరియు వాయిస్ రీడింగ్ మార్చండి.',
    prefLanguage: 'యాప్ భాష',
    prefUnits: 'కొలత ప్రమాణాలు',
    prefRegion: 'పైలట్ క్లస్టర్',
    prefSpeech: 'వాయిస్ రీడింగ్',
    resetDemoData: 'డేటాను రీసెట్ చేయండి',
    resetDemoConfirm: 'డేటాను ప్రాథమిక స్థితికి మార్చాలా?',
    resetSuccess: 'డేటా విజయవంతంగా రీసెట్ చేయబడింది.',
    aboutTitle: 'ఫార్మ్‌పల్స్ గురించి',
    aboutBody: 'ఫార్మ్‌పల్స్ రైతులకు పారదర్శకమైన సాంకేతిక సలహా అందించే వేదిక.',
    close: 'మూసివేయి',
  },

  hi: {
    appName: 'फार्मपल्स (FarmPulse)',
    tagline: 'सिर्फ यह मत बताइए कि क्या हो रहा है। यह भी समझाइए कि क्यों हो रहा है।',
    taglineSub: 'किसानों और एफपीओ के लिए पारदर्शी और व्याख्या योग्य फसल सलाह',
    demoClusterLabel: 'कावेरीपक्कम पायलट क्लस्टर, तमिलनाडु',
    demoClusterNotice: 'गूगल मैप्स प्लेटफॉर्म उपग्रह इमेजरी',
    demoUser: 'मारिमुथु जी. (किसान)',
    demoBadge: 'डेमो डेटा',
    readAloud: 'सलाह को बोलकर सुनें',
    readingAloud: 'पढ़ा जा रहा है...',
    stopAudio: 'ऑडियो रोकें',
    unsupportedSpeech: 'इस ब्राउज़र में वॉयस वाचन समर्थित नहीं है।',

    login: 'लॉग इन / बदलें',
    logout: 'लॉग आउट',
    switchProfile: 'उपयोगकर्ता प्रोफाइल बदलें',
    loginModalTitle: 'फार्मपल्स प्रवेश',
    loginModalSubtitle: 'अपने खेतों, उपग्रह मानचित्र और फसल सलाह देखने के लिए साइन इन करें।',
    signInWithGoogle: 'गूगल के साथ जारी रखें',
    signInWithPhone: 'मोबाइल ओटीपी से लॉग इन करें',
    enterMobileNumber: '10 अंकों का मोबाइल नंबर दर्ज करें',
    sendOtp: 'ओटीपी भेजें',
    verifyOtp: 'सत्यापित करें और प्रवेश करें',
    enterOtpPlaceholder: '4 अंकों का ओटीपी (उदा. 1234)',
    otpSentNotice: 'ओटीपी भेजा गया! जारी रखने के लिए 1234 दर्ज करें।',
    instantDemoProfiles: 'या तुरंत प्रोफाइल चुनें:',
    profileFarmer: 'किसान (मारिमुथु जी. - 2.4 एकड़)',
    profileFpo: 'एफपीओ प्रबंधक (सेंथिल कुमार)',
    profileAdo: 'कृषि अधिकारी (डॉ. अनिता आर.)',
    customSignIn: 'नया किसान पंजीकरण',
    fullName: 'पूरा नाम',
    villageName: 'गाँव / ब्लॉक',
    role: 'मुख्य भूमिका',
    loggedInAs: 'सत्यापित उपयोगकर्ता',

    navDashboard: 'डैशबोर्ड',
    navAnalysis: 'खेत विश्लेषण',
    navAdvisory: 'फसल तनाव सलाह',
    navExplanation: 'व्याख्या और अंतर्दृष्टि',
    navAskAi: 'कृषि AI सहायक',
    navFieldMap: 'खेत और स्थान मानचित्र',
    navPlots: 'खेत अन्वेषक',
    navLeafCheck: 'पत्ती जाँच',
    navWeather: 'मौसम और रुझान',
    navWeatherMap: 'मौसम मानचित्र',
    navFpo: 'एफपीओ आपूर्ति श्रृंखला',
    navMandi: 'मंडी भाव व फसल कैलेंडर',
    navReports: 'रिपोर्ट और इतिहास',
    navSettings: 'सेटिंग्स',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'नमूना खेत आज़माएँ',
    runAnalysis: 'व्यापक विश्लेषण करें',
    resetSample: 'नमूने पर रीसेट करें',
    waterStress: 'जल तनाव',
    nutrientStress: 'पोषक तत्व तनाव',
    pestDiseaseRisk: 'कीट और रोग जोखिम',
    heatStress: 'ताप तनाव',

    riskLow: 'कम तनाव',
    riskWatch: 'निगरानी सूची',
    riskHigh: 'उच्च जोखिम',
    riskLowDesc: 'फसल की स्थिति अनुकूल है; सामान्य निगरानी रखें।',
    riskWatchDesc: 'नमी या गर्मी का प्रारंभिक तनाव; 48 घंटे में निरीक्षण करें।',
    riskHighDesc: 'गंभीर तनाव; तत्काल खेत का निरीक्षण करें।',

    sourceFarmer: 'किसान प्रविष्टि',
    sourceSensor: 'मृदा सेंसर',
    sourceSatellite: 'सेंटिनल-2 उपग्रह',
    sourceWeatherApi: 'मौसम सेवा',
    sourceDemo: 'डेमो डेटा',

    greetingFarmer: 'शुभ प्रभात',
    greetingSubtitle: 'कावेरीपक्कम क्लस्टर के लिए आपका दैनिक खेत विश्लेषण और गूगल मैप्स ओवरव्यू।',
    monitoredPlots: 'निगरानी किए गए खेत',
    monitoredArea: 'कुल क्षेत्रफल',
    highPriorityPlots: 'प्राथमिकता वाले खेत',
    dataCoverage: 'डेटा कवरेज',
    fieldHealthOverview: 'खेत स्वास्थ्य अवलोकन (गूगल मैप्स सैटेलाइट)',
    illustrativeMapNote: 'उच्च-रिज़ॉल्यूशन गूगल मैप्स सैटेलाइट इमेजरी और खेत सीमाएँ',
    plotStatusList: 'खेतों की वर्तमान स्थिति',
    weatherStripTitle: '7 दिवसीय स्थानीय मौसम',
    whyThisAlertTitle: 'यह चेतावनी क्यों? — प्रमाण और नियम',
    priorityActionsToday: 'आज के मुख्य कार्य',
    recentActivity: 'हालिया गतिविधियाँ',
    clusterRiskSummary: 'क्लस्टर जोखिम वितरण',
    viewPlotDetails: 'पूर्ण विवरण देखें',
    actionCompleted: 'पूर्ण हुआ',
    actionPending: 'लंबित कार्य',
    mapViewSatellite: 'सैटेलाइट',
    mapViewHybrid: 'हाइब्रिड',
    mapViewRoadmap: 'सड़क मानचित्र',
    mapToggleGoogle: 'गूगल मैप्स दृश्य',
    mapToggleSchematic: 'ग्रिड दृश्य',
    gpsCoordinates: 'जीपीएस निर्देशांक',

    plotSearchPlaceholder: 'खेत, किस्म या किसान का नाम खोजें...',
    filterAllRisk: 'सभी जोखिम स्तर',
    filterAllCrops: 'सभी फसल किस्में',
    sortByRecent: 'नवीनतम प्रविष्टि',
    sortByRisk: 'उच्चतम जोखिम पहले',
    sortByArea: 'बड़ा क्षेत्रफल पहले',
    viewGrid: 'ग्रिड दृश्य',
    viewList: 'सूची दृश्य',
    noPlotsFound: 'कोई खेत नहीं मिला।',
    growthStage: 'फसल विकास अवस्था',
    lastObservation: 'अंतिम निरीक्षण',
    soilMoisture: 'मृदा नमी',
    daysWithoutRain: 'बिना बारिश के दिन',
    weeklyGreenness: 'साप्ताहिक हरियाली बदलाव',
    temperature: 'अधिकतम तापमान',
    humidity: 'सापेक्ष आर्द्रता',

    advisoryEngineTitle: 'व्याख्या योग्य फसल तनाव सलाह',
    advisoryEngineSubtitle: 'पारदर्शी और नियमों पर आधारित वैज्ञानिक सलाह।',
    howThisWasAssessed: 'इसका आकलन कैसे किया गया?',
    howFormulaWorks: 'फार्मपल्स मृदा नमी, वर्षा अंतराल, हरियाली परिवर्तन और तापमान के आधार पर पारदर्शी नियमों से स्कोर निकालता है।',
    whyWeThinkThis: 'हम ऐसा क्यों मानते हैं? (प्रमाण और नियम)',
    whatToDoNext: 'आगे क्या करें? (प्राथमिकता कार्य)',
    ruleContributions: 'नियमों का योगदान (डेमो)',
    coverageBadgeNote: 'कवरेज उपलब्ध इनपुट को दर्शाता है, सटीकता को नहीं।',
    missingDataNotes: 'अनुपलब्ध डेटा और अनिश्चितता नोट्स',
    officerConsultWarningTitle: 'कृषि अधिकारी से परामर्श लें',
    officerConsultWarningBody: 'दवाओं का छिड़काव करने या भारी सिंचाई करने से पहले स्थानीय कृषि अधिकारी से परामर्श अवश्य लें।',
    interactiveScenarioTester: 'इंटरएक्टिव परिदृश्य परीक्षक (What-If)',
    resetToGroundValues: 'मूल मान पर रीसेट करें',
    runSimulation: 'सिमुलेशन चलाएं',

    leafCheckTitle: 'पत्ती दृश्य निरीक्षण सहायक',
    leafCheckSubtitle: 'पत्ती का फोटो अपलोड करें और सुरक्षित सलाह के लिए लक्षण चुनें।',
    dragDropPhoto: 'पत्ती का फोटो यहाँ खींचें या ब्राउज़ करें',
    browsePhoto: 'फोटो चुनें',
    photoFormatLimit: 'JPEG, PNG, WebP अधिकतम 5 MB.',
    removePhoto: 'फोटो हटाएं',
    symptomsObserved: 'आप खेत में क्या लक्षण देख रहे हैं?',
    selectSymptomsHint: 'पत्ती पर दिखने वाले सभी लक्षण चुनें:',
    possibleCausesTitle: 'संभावित कारण और प्राथमिक विश्लेषण',
    confirmWithAgronomist: 'संभावित कारण — निर्णय लेने से पहले कृषि विशेषज्ञ से पुष्टि करें।',
    whatToInspectInField: 'खेत में मौके पर क्या जांचें:',
    privacyNoticeTitle: 'किसान गोपनीयता और डेटा सुरक्षा',
    privacyNoticeBody: 'फोटो विश्लेषण आपके ब्राउज़र में ही होता है। कोई निजी फोटो सर्वर पर नहीं भेजी जाती।',
    optionalAiVision: 'वैकल्पिक AI दृश्य राय',
    aiVisionDisclaimer: 'यह केवल प्रायोगिक राय है। केवल इसके आधार पर रासायनिक दवाएं न खरीदें।',

    spraySuitabilityTitle: 'छिड़काव और सिंचाई के लिए उपयुक्त समय',
    spraySuitabilityDesc: 'तापमान, हवा की गति और नमी पर आधारित कृषि सलाह।',
    hourlyForecastTitle: '24 घंटे का प्रति घंटा मौसम और बारिश की संभावना',
    hourlyForecastDesc: 'प्रति घंटा तापमान, वर्षा प्रतिशत और जड़ क्षेत्र की नमी।',
    soilMoistureDepthTitle: 'गहराई के अनुसार मृदा नमी',
    surfaceSoil: 'ऊपरी परत (0–10 सेमी)',
    rootZoneSoil: 'जड़ क्षेत्र (10–30 सेमी)',
    rainProbability: 'बारिश की संभावना',
    windSpeed: 'हवा की गति',

    fpoTitle: 'एफपीओ आपूर्ति श्रृंखला और क्लस्टर आउटलुक',
    fpoSubtitle: 'किसान उत्पादक संगठनों और खरीद प्रबंधकों के लिए योजना संकेत।',
    totalPlotsCovered: 'ट्रैक किए गए कुल खेत',
    totalAreaCovered: 'कुल फसल क्षेत्रफल',
    cropRiskBreakdown: 'किस्म वार जोखिम विवरण',
    procurementTimeline: 'कटाई तैयारी समयरेखा',
    suggestedOperations: 'सुझाए गए एफपीओ परिचालन',
    exportFpoCsv: 'क्लस्टर आउटलुक डाउनलोड करें (CSV)',
    fpoCaveatTitle: 'केवल योजना संकेत',
    fpoCaveatText: 'खेत निरीक्षण और फसल कैलेंडर के साथ पुष्टि करें। यह गारंटीकृत उपज पूर्वानुमान नहीं है।',

    reportsTitle: 'रिपोर्ट और निर्यात केंद्र',
    reportsSubtitle: 'प्रिंट करने योग्य सलाह और अनुपालन सीएसवी फाइलें डाउनलोड करें।',
    filterByDateRange: 'तारीख सीमा',
    filterByPlot: 'खेत चुनें',
    downloadCsv: 'सीएसवी डाउनलोड करें',
    printReport: 'प्रिंट / पीडीएफ सेव करें',
    advisoryHistoryTable: 'सलाह लॉग और प्रमाण',
    allPlots: 'सभी खेत',

    settingsTitle: 'ऐप सेटिंग्स और प्राथमिकताएं',
    settingsSubtitle: 'भाषा, माप इकाइयां, वॉयस वाचन और डेमो मोड प्रबंधित करें।',
    prefLanguage: 'ऐप की भाषा',
    prefUnits: 'माप इकाइयां',
    prefRegion: 'पायलट क्लस्टर / जिला',
    prefSpeech: 'वॉयस वाचन',
    resetDemoData: 'डेमो डेटा रीसेट करें',
    resetDemoConfirm: 'क्या आप सभी डेमो डेटा को रीसेट करना चाहते हैं?',
    resetSuccess: 'डेमो डेटा सफलतापूर्वक रीसेट हो गया।',
    aboutTitle: 'फार्मपल्स के बारे में',
    aboutBody: 'फार्मपल्स किसानों को पारदर्शी और समझने योग्य तकनीकी सलाह देने के लिए बनाया गया है।',
    close: 'बंद करें',
  },

  ml: {
    appName: 'ഫാംപൾസ് (FarmPulse)',
    tagline: 'എന്താണ് സംഭവിക്കുന്നതെന്ന് മാത്രമല്ല, എന്തുകൊണ്ട് എന്ന് വിശദീകരിക്കുക.',
    taglineSub: 'കർഷകർക്കും എഫ്‌പി‌ഒകൾക്കുമായി സുതാര്യമായ വിള ഉപദേശം',
    demoClusterLabel: 'കാവേരിപ്പാക്കം പൈലറ്റ് ക്ലസ്റ്റർ, തമിഴ്‌നാട്',
    demoClusterNotice: 'ഗൂഗിൾ മാപ്‌സ് ഉപഗ്രഹ സാങ്കേതികവിദ്യ',
    demoUser: 'മാരിമുത്തു ജി. (കർഷകൻ)',
    demoBadge: 'ഡെമോ ഡാറ്റ',
    readAloud: 'ഉപദേശം ഉച്ചത്തിൽ കേൾക്കുക',
    readingAloud: 'വായിക്കുന്നു...',
    stopAudio: 'ഓഡിയോ നിർത്തുക',
    unsupportedSpeech: 'ഈ ബ്രൗസറിൽ വോയ്‌സ് റീഡിംഗ് ലഭ്യമല്ല.',

    login: 'ലോഗിൻ / മാറ്റുക',
    logout: 'ലോഗ് ഔട്ട്',
    switchProfile: 'യൂസർ പ്രൊഫൈൽ മാറ്റുക',
    loginModalTitle: 'ഫാംപൾസ് പ്രവേശനം',
    loginModalSubtitle: 'നിങ്ങളുടെ കൃഷിയിടങ്ങളും ഉപദേശങ്ങളും പരിശോധിക്കാൻ ലോഗിൻ ചെയ്യുക.',
    signInWithGoogle: 'ഗൂഗിൾ വഴി ലോഗിൻ ചെയ്യുക',
    signInWithPhone: 'മൊബൈൽ OTP വഴി ലോഗിൻ ചെയ്യുക',
    enterMobileNumber: '10 അക്ക മൊബൈൽ നമ്പർ നൽകുക',
    sendOtp: 'OTP അയക്കുക',
    verifyOtp: 'സ്ഥിരീകരിക്കുക',
    enterOtpPlaceholder: '4 അക്ക OTP (ഉദാ: 1234)',
    otpSentNotice: 'OTP അയച്ചു! തുടരാൻ 1234 നൽകുക.',
    instantDemoProfiles: 'അല്ലെങ്കിൽ തൽക്ഷണ പ്രൊഫൈൽ തിരഞ്ഞെടുക്കുക:',
    profileFarmer: 'കർഷകൻ (മാരിമുത്തു ജി. - 2.4 ഏക്കർ)',
    profileFpo: 'എഫ്‌പി‌ഒ മാനേജർ (സെന്തിൽ കുമാർ)',
    profileAdo: 'കൃഷി ഓഫീസർ (ഡോ. അനിത ആർ.)',
    customSignIn: 'പുതിയ കർഷക രജിസ്ട്രേഷൻ',
    fullName: 'മുഴുവൻ പേര്',
    villageName: 'ഗ്രാമം / പഞ്ചായത്ത്',
    role: 'റോൾ',
    loggedInAs: 'ലോഗിൻ ചെയ്തത്',

    navDashboard: 'ഡാഷ്‌ബോർഡ്',
    navAnalysis: 'ഫാം അനാലിസിസ്',
    navAdvisory: 'വിള പ്രതിസന്ധി ഉപദേശം',
    navExplanation: 'വിശദീകരണവും വിവരങ്ങളും',
    navAskAi: 'അഗ്രി AI അസിസ്റ്റന്റ്',
    navFieldMap: 'ഫീൽഡ് & ലൊക്കേഷൻ മാപ്പ്',
    navPlots: 'കൃഷിയിടങ്ങൾ',
    navLeafCheck: 'ഇല പരിശോധന',
    navWeather: 'കാലാവസ്ഥ & മാറ്റങ്ങൾ',
    navWeatherMap: 'കാലാവസ്ഥാ മാപ്പ്',
    navFpo: 'എഫ്‌പി‌ഒ സപ്ലൈ ചെയിൻ',
    navMandi: 'വിപണി വിലകളും വിള കലണ്ടറും',
    navReports: 'റിപ്പോർട്ടുകൾ & ചരിത്രം',
    navSettings: 'ക്രമീകരണങ്ങൾ',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'മാതൃകാ കൃഷിയിടം പരിശോധിക്കുക',
    runAnalysis: 'പൂർണ്ണ വിശകലനം നടത്തുക',
    resetSample: 'മാതൃകയിലേക്ക് പുനഃസ്ഥാപിക്കുക',
    waterStress: 'ജല സമ്മർദ്ദം',
    nutrientStress: 'പോഷക കുറവ്',
    pestDiseaseRisk: 'കീട-രോഗ സാധ്യത',
    heatStress: 'താപ സമ്മർദ്ദം',

    riskLow: 'കുറഞ്ഞ പ്രതിസന്ധി',
    riskWatch: 'നിരീക്ഷണ പട്ടിക',
    riskHigh: 'ഉയർന്ന പ്രതിസന്ധി',
    riskLowDesc: 'വിള അനുകൂലാവസ്ഥയിലാണ്.',
    riskWatchDesc: 'ജല അല്ലെങ്കിൽ താപ കുറവ്.',
    riskHighDesc: 'ഗുരുതരമായ പ്രശ്നം; ഉടൻ നേരിൽ പരിശോധിക്കുക.',

    sourceFarmer: 'കർഷക രേഖ',
    sourceSensor: 'സോയിൽ സെൻസർ',
    sourceSatellite: 'സെന്റിനൽ-2 സാറ്റലൈറ്റ്',
    sourceWeatherApi: 'കാലാവസ്ഥ സേവനം',
    sourceDemo: 'ഡെമോ ഡാറ്റ',

    greetingFarmer: 'സുപ്രഭാതം',
    greetingSubtitle: 'കാവേരിപ്പാക്കം പ്രദേശത്തെ ഇന്നത്തെ വിള സ്ഥിതി വിവരങ്ങൾ.',
    monitoredPlots: 'നിരീക്ഷിക്കുന്ന കൃഷിയിടങ്ങൾ',
    monitoredArea: 'ആകെ വിസ്തീർണ്ണം',
    highPriorityPlots: 'അടിയന്തിര ശ്രദ്ധയുള്ളവ',
    dataCoverage: 'ഡാറ്റാ കവറേജ്',
    fieldHealthOverview: 'കൃഷിയിട അവലോകനം (ഗൂഗിൾ മാപ്‌സ് സാറ്റലൈറ്റ്)',
    illustrativeMapNote: 'ഗൂഗിൾ മാപ്‌സ് കൃത്യമായ സാറ്റലൈറ്റ് ചിത്രങ്ങൾ',
    plotStatusList: 'കൃഷിയിടങ്ങളുടെ നിലവിലെ സ്ഥിതി',
    weatherStripTitle: '7 ദിവസത്തെ കാലാവസ്ഥ',
    whyThisAlertTitle: 'എന്തുകൊണ്ട് ഈ മുന്നറിയിപ്പ്? — തെളിവുകൾ',
    priorityActionsToday: 'ഇന്നത്തെ പ്രധാന ജോലികൾ',
    recentActivity: 'സമീപകാല വിവരങ്ങൾ',
    clusterRiskSummary: 'മേഖലാതല അപായസാധ്യത',
    viewPlotDetails: 'പൂർണ്ണ വിവരങ്ങൾ കാണുക',
    actionCompleted: 'പൂർത്തിയായി',
    actionPending: 'ബാക്കിയുള്ള ജോലി',
    mapViewSatellite: 'സാറ്റലൈറ്റ്',
    mapViewHybrid: 'ഹൈബ്രിഡ്',
    mapViewRoadmap: 'റോഡ് മാപ്പ്',
    mapToggleGoogle: 'ഗൂഗിൾ മാപ്‌സ് കാഴ്ച',
    mapToggleSchematic: 'ഗ്രിഡ് കാഴ്ച',
    gpsCoordinates: 'ജിപിഎസ് സ്ഥാനം',

    plotSearchPlaceholder: 'കൃഷിയിടം അല്ലെങ്കിൽ നെല്ലിനം തിരയുക...',
    filterAllRisk: 'എല്ലാ അപായ നിലകളും',
    filterAllCrops: 'എല്ലാ ഇനങ്ങളും',
    sortByRecent: 'ഏറ്റവും പുതിയത്',
    sortByRisk: 'കൂടിയ അപായം ആദ്യം',
    sortByArea: 'കൂടിയ വിസ്തീർണ്ണം ആദ്യം',
    viewGrid: 'ഗ്രിഡ് കാഴ്ച',
    viewList: 'ലിസ്റ്റ് കാഴ്ച',
    noPlotsFound: 'കൃഷിയിടങ്ങൾ കണ്ടെത്താനായില്ല.',
    growthStage: 'വിള ഘട്ടം',
    lastObservation: 'അവസാന പരിശോധന',
    soilMoisture: 'മണ്ണിലെ ഈർപ്പം',
    daysWithoutRain: 'മഴയില്ലാത്ത ദിവസങ്ങൾ',
    weeklyGreenness: 'ആഴ്ചയിലെ പച്ചപ്പ് മാറ്റം',
    temperature: 'താപനില',
    humidity: 'അന്തരീക്ഷ ഈർപ്പം',

    advisoryEngineTitle: 'വിശദീകരണ വിള ഉപദേശ എഞ്ചിൻ',
    advisoryEngineSubtitle: 'സുതാര്യമായ കൃഷി നിയമങ്ങളെ അടിസ്ഥാനമാക്കിയുള്ള ഉപദേശം.',
    howThisWasAssessed: 'ഇത് എങ്ങനെ കണക്കാക്കി?',
    howFormulaWorks: 'ഫാംപൾസ് മണ്ണിലെ ഈർപ്പം, മഴക്കുറവ്, പച്ചപ്പ് എന്നിവ വിശകലനം ചെയ്യുന്നു.',
    whyWeThinkThis: 'എന്തുകൊണ്ട് ഞങ്ങൾ ഇത് ശുപാർശ ചെയ്യുന്നു?',
    whatToDoNext: 'അടുത്തതായി എന്തുചെയ്യണം?',
    ruleContributions: 'നിയമങ്ങളുടെ പങ്ക് (ഡെമോ)',
    coverageBadgeNote: 'ഡാറ്റ ലഭ്യതയുടെ ശതമാനം സൂചിപ്പിക്കുന്നു.',
    missingDataNotes: 'ലഭ്യമല്ലാത്ത വിവരങ്ങൾ',
    officerConsultWarningTitle: 'കൃഷി ഓഫീസറുമായി ആലോചിക്കുക',
    officerConsultWarningBody: 'മരുന്ന് തളിക്കുന്നതിനോ വലിയ തോതിൽ നനയ്ക്കുന്നതിനോ മുൻപ് കൃഷി ഓഫീസറുടെ ഉപദേശം തേടുക.',
    interactiveScenarioTester: 'സിമുലേഷൻ പരീക്ഷണ ഉപകരണം',
    resetToGroundValues: 'യഥാർത്ഥ നിലയിലേക്ക് റീസെറ്റ് ചെയ്യുക',
    runSimulation: 'കണക്കുകൂട്ടുക',

    leafCheckTitle: 'ഇല പരിശോധന സഹായി',
    leafCheckSubtitle: 'ഇലയുടെ ചിത്രം നൽകി ലക്ഷണങ്ങൾ തിരഞ്ഞെടുക്കുക.',
    dragDropPhoto: 'ഇലയുടെ ചിത്രം ഇവിടെ നൽകുക',
    browsePhoto: 'ചിത്രം തിരഞ്ഞെടുക്കുക',
    photoFormatLimit: 'JPEG, PNG, WebP പരമാവധി 5 MB.',
    removePhoto: 'ചിത്രം ഒഴിവാക്കുക',
    symptomsObserved: 'പാടത്ത് നിങ്ങൾ എന്തൊക്കെ ലക്ഷണങ്ങൾ കാണുന്നു?',
    selectSymptomsHint: 'ഇലയിൽ കാണുന്ന ലക്ഷണങ്ങൾ തിരഞ്ഞെടുക്കുക:',
    possibleCausesTitle: 'സാധ്യമായ കാരണങ്ങൾ',
    confirmWithAgronomist: 'കൃഷി ശാസ്ത്രജ്ഞരുമായി സംസാരിച്ച് ഉറപ്പാക്കുക.',
    whatToInspectInField: 'നേരിൽ പരിശോധിക്കേണ്ട കാര്യങ്ങൾ:',
    privacyNoticeTitle: 'കർഷക സ്വകാര്യത',
    privacyNoticeBody: 'ചിത്രങ്ങൾ നിങ്ങളുടെ ബ്രൗസറിൽ തന്നെയാണ് പരിശോധിക്കുന്നത്.',
    optionalAiVision: 'കൂടുതൽ AI അഭിപ്രായം',
    aiVisionDisclaimer: 'ഇതൊരു പരീക്ഷണാടിസ്ഥാനത്തിലുള്ള മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്.',

    spraySuitabilityTitle: 'മരുന്ന് തളിക്കാനും നനയ്ക്കാനുമുള്ള അനുയോജ്യ സമയം',
    spraySuitabilityDesc: 'താപനിലയും കാറ്റിന്റെ വേഗതയും അടിസ്ഥാനമാക്കിയുള്ള നിർദ്ദേശം.',
    hourlyForecastTitle: '24 മണിക്കൂർ കാലാവസ്ഥയും മഴ സാധ്യതയും',
    hourlyForecastDesc: 'മണിക്കൂർ തിരിച്ചുള്ള താപനിലയും മണ്ണിലെ ഈർപ്പവും.',
    soilMoistureDepthTitle: 'ആഴം തിരിച്ചുള്ള മണ്ണിലെ ഈർപ്പം',
    surfaceSoil: 'മേൽമണ്ണ് (0–10 സെ.മീ)',
    rootZoneSoil: 'വേരുപടലം (10–30 സെ.മീ)',
    rainProbability: 'മഴ സാധ്യത',
    windSpeed: 'കാറ്റിന്റെ വേഗത',

    fpoTitle: 'എഫ്‌പി‌ഒ സപ്ലൈ ചെയിൻ ഔട്ട്‌ലുക്ക്',
    fpoSubtitle: 'വിളവെടുപ്പ് സംഭരണ ആസൂത്രണം.',
    totalPlotsCovered: 'നിരീക്ഷിക്കുന്ന കൃഷിയിടങ്ങൾ',
    totalAreaCovered: 'ആകെ വിസ്തീർണ്ണം',
    cropRiskBreakdown: 'വിള തിരിച്ചുള്ള പരിശോധന',
    procurementTimeline: 'വിളവെടുപ്പ് തയ്യാറെടുപ്പ് സമയം',
    suggestedOperations: 'നിർദ്ദേശിച്ച പ്രവർത്തനങ്ങൾ',
    exportFpoCsv: 'ഡൗൺലോഡ് ചെയ്യുക (CSV)',
    fpoCaveatTitle: 'ആസൂത്രണ സൂചന മാത്രം',
    fpoCaveatText: 'നേരിട്ടുള്ള പരിശോധനയിലൂടെ ഉറപ്പുവരുത്തുക.',

    reportsTitle: 'റിപ്പോർട്ടുകൾ & എക്സ്പോർട്ട്',
    reportsSubtitle: 'പ്രിന്റ് ചെയ്യാവുന്ന ഉപദേശങ്ങളും സി‌എസ്‌വി ഫയലുകളും.',
    filterByDateRange: 'തീയതി പരിധി',
    filterByPlot: 'കൃഷിയിടം തിരഞ്ഞെടുക്കുക',
    downloadCsv: 'CSV ഡൗൺലോഡ് ചെയ്യുക',
    printReport: 'പ്രിന്റ് / PDF',
    advisoryHistoryTable: 'ഉപദേശ രേഖകൾ',
    allPlots: 'എല്ലാ കൃഷിയിടങ്ങളും',

    settingsTitle: 'ക്രമീകരണങ്ങൾ',
    settingsSubtitle: 'ഭാഷ, അളവുകൾ എന്നിവ മാറ്റുക.',
    prefLanguage: 'ആപ്പ് ഭാഷ',
    prefUnits: 'അളവ് യൂണിറ്റുകൾ',
    prefRegion: 'മേഖല / ജില്ല',
    prefSpeech: 'വോയ്‌സ് വായന',
    resetDemoData: 'ഡാറ്റ റീസെറ്റ് ചെയ്യുക',
    resetDemoConfirm: 'എല്ലാ ഡാറ്റയും തുടക്ക നിലയിലേക്ക് മാറ്റണോ?',
    resetSuccess: 'ഡാറ്റ വിജയകരമായി റീസെറ്റ് ചെയ്തു.',
    aboutTitle: 'ഫാംപൾസിനെക്കുറിച്ച്',
    aboutBody: 'കർഷകർക്ക് ലളിതവും സുതാര്യവുമായ കൃഷി ഉപദേശങ്ങൾ നൽകുന്ന സംവിധാനം.',
    close: 'അടയ്ക്കുക',
  },

  kn: {
    appName: 'ಫಾರ್ಮ್‌ಪಲ್ಸ್ (FarmPulse)',
    tagline: 'ಏನು ನಡೆಯುತ್ತಿದೆ ಎಂದು ಮಾತ್ರವಲ್ಲ, ಏಕೆ ಎಂದು ವಿವರಿಸಿ.',
    taglineSub: 'ರೈತರಿಗೆ ಮತ್ತು ಎಫ್‌ಪಿಒಗಳಿಗೆ ವಿವರಣಾತ್ಮಕ ಬೆಳೆ ಸಲಹೆ',
    demoClusterLabel: 'ಕಾವೇರಿಪಾಕ್ಕಂ ಪೈಲಟ್ ಕ್ಲಸ್ಟರ್, ತಮಿಳುನಾಡು',
    demoClusterNotice: 'ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್ ಉಪಗ್ರಹ ತಂತ್ರಜ್ಞಾನ',
    demoUser: 'ಮಾರಿಮುತ್ತು ಜಿ. (ರೈತ)',
    demoBadge: 'ಡೆಮೊ ಮಾಹಿತಿ',
    readAloud: 'ಸಲಹೆಯನ್ನು ಧ್ವನಿಯಲ್ಲಿ ಕೇಳಿ',
    readingAloud: 'ಓದಲಾಗುತ್ತಿದೆ...',
    stopAudio: 'ಧ್ವನಿ ನಿಲ್ಲಿಸಿ',
    unsupportedSpeech: 'ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಧ್ವನಿ ಸೌಲಭ್ಯವಿಲ್ಲ.',

    login: 'ಲಾಗಿನ್ / ಬದಲಾಯಿಸಿ',
    logout: 'ಲಾಗ್ ಔಟ್',
    switchProfile: 'ಬಳಕೆದಾರರ ಪ್ರೊಫೈಲ್ ಬದಲಾಯಿಸಿ',
    loginModalTitle: 'ಫಾರ್ಮ್‌ಪಲ್ಸ್ ಪ್ರವೇಶ',
    loginModalSubtitle: 'ನಿಮ್ಮ ಜಮೀನುಗಳು ಮತ್ತು ಉಪಗ್ರಹ ನಕ್ಷೆಗಳನ್ನು ನೋಡಲು ಸೈನ್ ಇನ್ ಮಾಡಿ.',
    signInWithGoogle: 'ಗೂಗಲ್ ಮೂಲಕ ಲಾಗಿನ್ ಮಾಡಿ',
    signInWithPhone: 'ಮೊಬೈಲ್ ಒಟಿಪಿ ಮೂಲಕ ಲಾಗಿನ್ ಮಾಡಿ',
    enterMobileNumber: '10 ಅಂಕಿಯ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ',
    sendOtp: 'ಒಟಿಪಿ ಕಳುಹಿಸಿ',
    verifyOtp: 'ಪರಿಶೀಲಿಸಿ ಪ್ರವೇಶಿಸಿ',
    enterOtpPlaceholder: '4 ಅಂಕಿಯ ಒಟಿಪಿ (ಉದಾ: 1234)',
    otpSentNotice: 'ಒಟಿಪಿ ಕಳುಹಿಸಲಾಗಿದೆ! ಮುಂದುವರಿಯಲು 1234 ನಮೂದಿಸಿ.',
    instantDemoProfiles: 'ಅಥವಾ ತ್ವರಿತ ಪ್ರೊಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ:',
    profileFarmer: 'ರೈತ (ಮಾರಿಮುತ್ತು ಜಿ. - 2.4 ಎಕರೆ)',
    profileFpo: 'ಎಫ್‌ಪಿಒ ವ್ಯವಸ್ಥಾಪಕ (ಸೆಂಥಿಲ್ ಕುಮಾರ್)',
    profileAdo: 'ಕೃಷಿ ಅಧಿಕಾರಿ (ಡಾ. ಅನಿತಾ ಆರ್.)',
    customSignIn: 'ಹೊಸ ರೈತರ ನೋಂದಣಿ',
    fullName: 'ಪೂರ್ಣ ಹೆಸರು',
    villageName: 'ಗ್ರಾಮ / ತಾಲೂಕು',
    role: 'ಪಾತ್ರ',
    loggedInAs: 'ಲಾಗಿನ್ ಆಗಿರುವ ಖಾತೆ',

    navDashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    navAnalysis: 'ಕೃಷಿ ವಿಶ್ಲೇಷಣೆ',
    navAdvisory: 'ಬೆಳೆ ಒತ್ತಡ ಸಲಹೆ',
    navExplanation: 'ವಿವರಣೆ ಮತ್ತು ಒಳನೋಟಗಳು',
    navAskAi: 'ಕೃಷಿ AI ಸಹಾಯಕ',
    navFieldMap: 'ಜಮೀನು ಮತ್ತು ಸ್ಥಳ ನಕ್ಷೆ',
    navPlots: 'ಜಮೀನುಗಳ ಪರಿಶೋಧನೆ',
    navLeafCheck: 'ಎಲೆ ಪರಿಶೀಲನೆ',
    navWeather: 'ಹವಾಮಾನ ಮತ್ತು ಪ್ರವೃತ್ತಿ',
    navWeatherMap: 'ಹವಾಮಾನ ನಕ್ಷೆ',
    navFpo: 'ಎಫ್‌ಪಿಒ ಪೂರೈಕೆ ಸರಪಳಿ',
    navMandi: 'ಮಂಡಿ ಬೆಲೆಗಳು & ಬೆಳೆ ಕ್ಯಾಲೆಂಡರ್',
    navReports: 'ವರದಿಗಳು ಮತ್ತು ಇತಿಹಾಸ',
    navSettings: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',

    teamBadge: 'PRIME ELITE',
    trySampleFarm: 'ಮಾದರಿ ಜಮೀನು ಪ್ರಯತ್ನಿಸಿ',
    runAnalysis: 'ಸಮಗ್ರ ವಿಶ್ಲೇಷಣೆ ನಡೆಸಿ',
    resetSample: 'ಮಾದರಿಗೆ ಮರುಹೊಂದಿಸಿ',
    waterStress: 'ನೀರಿನ ಒತ್ತಡ',
    nutrientStress: 'ಪೋಷಕಾಂಶಗಳ ಕೊರತೆ',
    pestDiseaseRisk: 'ಕೀಟ ಮತ್ತು ರೋಗದ ಅಪಾಯ',
    heatStress: 'ಉಷ್ಣತೆಯ ಒತ್ತಡ',

    riskLow: 'ಕಡಿಮೆ ಒತ್ತಡ',
    riskWatch: 'ಗಮನಿಸಬೇಕಾದ ಸ್ಥಿತಿ',
    riskHigh: 'ಹೆಚ್ಚಿನ ಅಪಾಯ',
    riskLowDesc: 'ಬೆಳೆ ಉತ್ತಮ ಸ್ಥಿತಿಯಲ್ಲಿದೆ.',
    riskWatchDesc: 'ಆರಂಭಿಕ ತೇವಾಂಶ ಅಥವಾ ಉಷ್ಣತೆಯ ಕೊರತೆ.',
    riskHighDesc: 'ತೀವ್ರ ಬೆಳೆ ಒತ್ತಡ; ತಕ್ಷಣ ಜಮೀನು ಪರಿಶೀಲಿಸಿ.',

    sourceFarmer: 'ರೈತರ ದಾಖಲೆ',
    sourceSensor: 'ಮಣ್ಣಿನ ಸಂವೇದಕ',
    sourceSatellite: 'ಸೆಂschemaನೆಲ್-2 ಉಪಗ್ರಹ',
    sourceWeatherApi: 'ಹವಾಮಾನ ಸೇವೆ',
    sourceDemo: 'ಡೆಮೊ ಮಾಹಿತಿ',

    greetingFarmer: 'ಶುಭೋದಯ',
    greetingSubtitle: 'ಕಾವೇರಿಪಾಕ್ಕಂ ಪ್ರದೇಶದ ಇಂದಿನ ಜಮೀನು ಮಾಹಿತಿ ಮತ್ತು ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್ ವರದಿ.',
    monitoredPlots: 'ಮೇಲ್ವಿಚಾರಣೆ ಜಮೀನುಗಳು',
    monitoredArea: 'ಒಟ್ಟು ವಿಸ್ತೀರ್ಣ',
    highPriorityPlots: 'ತುರ್ತು ಜಮೀನುಗಳು',
    dataCoverage: 'ಮಾಹಿತಿ ಲಭ್ಯತೆ',
    fieldHealthOverview: 'ಜಮೀನು ಆರೋಗ್ಯ ಅವಲೋಕನ (ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್ ಉಪಗ್ರಹ)',
    illustrativeMapNote: 'ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್ ಆಧಾರಿತ ಅಧಿಕ-ರೆಸಲ್ಯೂಶನ್ ಉಪಗ್ರಹ ಚಿತ್ರ',
    plotStatusList: 'ಜಮೀನುಗಳ ಪ್ರಸ್ತುತ ಸ್ಥಿತಿ',
    weatherStripTitle: '7 ದಿನಗಳ ಹವಾಮಾನ',
    whyThisAlertTitle: 'ಈ ಎಚ್ಚರಿಕೆ ಏಕೆ? — ಸಾಕ್ಷ್ಯಗಳು',
    priorityActionsToday: 'ಇಂದಿನ ಆದ್ಯತೆಯ ಕೆಲಸಗಳು',
    recentActivity: 'ಇತ್ತೀಚಿನ ದಾಖಲೆಗಳು',
    clusterRiskSummary: 'ಪ್ರದೇಶದ ಅಪಾಯ ಹಂಚಿಕೆ',
    viewPlotDetails: 'ಸಂಪೂರ್ಣ ವಿವರ ನೋಡಿ',
    actionCompleted: 'ಪೂರ್ಣಗೊಂಡಿದೆ',
    actionPending: 'ಬಾಕಿ ಇರುವ ಕೆಲಸ',
    mapViewSatellite: 'ಉಪಗ್ರಹ',
    mapViewHybrid: 'ಹೈಬ್ರಿಡ್',
    mapViewRoadmap: 'ರಸ್ತೆ ನಕ್ಷೆ',
    mapToggleGoogle: 'ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್ ನೋಟ',
    mapToggleSchematic: 'ಗ್ರಿಡ್ ನೋಟ',
    gpsCoordinates: 'ಜಿಪಿಎಸ್ ಸ್ಥಳ',

    plotSearchPlaceholder: 'ಜಮೀನು ಅಥವಾ ಬೆಳೆ ಹೆಸರನ್ನು ಹುಡುಕಿ...',
    filterAllRisk: 'ಎಲ್ಲಾ ಅಪಾಯ ಮಟ್ಟಗಳು',
    filterAllCrops: 'ಎಲ್ಲಾ ಬೆಳೆ ತಳಿಗಳು',
    sortByRecent: 'ಇತ್ತೀಚಿನ ಸಮಯ',
    sortByRisk: 'ಹೆಚ್ಚಿನ ಅಪಾಯ ಮೊದಲು',
    sortByArea: 'ದೊಡ್ಡ ವಿಸ್ತೀರ್ಣ ಮೊದಲು',
    viewGrid: 'ಗ್ರಿಡ್ ನೋಟ',
    viewList: 'ಪಟ್ಟಿ ನೋಟ',
    noPlotsFound: 'ಜಮೀನುಗಳು ಕಂಡುಬಂದಿಲ್ಲ.',
    growthStage: 'ಬೆಳೆ ಹಂತ',
    lastObservation: 'ಕೊನೆಯ ಪರಿಶೀಲನೆ',
    soilMoisture: 'ಮಣ್ಣಿನ ತೇವಾಂಶ',
    daysWithoutRain: 'ಮಳೆಯಿಲ್ಲದ ದಿನಗಳು',
    weeklyGreenness: 'ವಾರದ ಹಸಿರು ಬದಲಾವಣೆ',
    temperature: 'ಗರಿಷ್ಠ ತಾಪಮಾನ',
    humidity: 'ಗಾಳಿಯ ತೇವಾಂಶ',

    advisoryEngineTitle: 'ವಿವರಣಾತ್ಮಕ ಬೆಳೆ ಸಲಹಾ ಎಂಜಿನ್',
    advisoryEngineSubtitle: 'ಸ್ಪಷ್ಟ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಕೃಷಿ ಸಲಹೆ.',
    howThisWasAssessed: 'ಇದನ್ನು ಹೇಗೆ ಲೆಕ್ಕಹಾಕಲಾಗಿದೆ?',
    howFormulaWorks: 'ಫಾರ್ಮ್‌ಪಲ್ಸ್ ಮಣ್ಣಿನ ತೇವಾಂಶ, ಮಳೆ ಕೊರತೆ ಮತ್ತು ತಾಪಮಾನವನ್ನು ಪಾರದರ್ಶಕ ನಿಯಮಗಳಿಂದ ವಿಶ್ಲೇಷಿಸುತ್ತದೆ.',
    whyWeThinkThis: 'ನಾವು ಇದನ್ನು ಏಕೆ ಶಿಫಾರಸು ಮಾಡುತ್ತೇವೆ?',
    whatToDoNext: 'ಮುಂದೆ ಏನು ಮಾಡಬೇಕು?',
    ruleContributions: 'ನಿಯಮಗಳ ಪಾಲು (ಡೆಮೊ)',
    coverageBadgeNote: 'ಮಾಹಿತಿ ಲಭ್ಯತೆಯ ಶೇಕಡಾವಾರು ಪ್ರಮಾಣ.',
    missingDataNotes: 'ಲಭ್ಯವಿಲ್ಲದ ಮಾಹಿತಿಗಳು',
    officerConsultWarningTitle: 'ಕೃಷಿ ಅಧಿಕಾರಿಯನ್ನು ಸಂಪರ್ಕಿಸಿ',
    officerConsultWarningBody: 'ರಾಸಾಯನಿಕ ಸಿಂಪಡಿಸುವ ಮೊದಲು ಅಥವಾ ಅಧಿಕ ನೀರು ಹರಿಸುವ ಮೊದಲು ಕೃಷಿ ಅಧಿಕಾರಿಯ ಸಲಹೆ ಪಡೆಯಿರಿ.',
    interactiveScenarioTester: 'ಪ್ರಾಯೋಗಿಕ ಪರೀಕ್ಷಾ ಸಾಧನ',
    resetToGroundValues: 'ಮೂಲ ಮೌಲ್ಯಗಳಿಗೆ ಮರುಹೊಂದಿಸಿ',
    runSimulation: 'ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ',

    leafCheckTitle: 'ಎಲೆ ದೃಶ್ಯ ತಪಾಸಣೆ ಸಹಾಯಕ',
    leafCheckSubtitle: 'ಎಲೆಯ ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ರೋಗ ಲಕ್ಷಣಗಳನ್ನು ಆರಿಸಿ.',
    dragDropPhoto: 'ಎಲೆಯ ಚಿತ್ರವನ್ನು ಇಲ್ಲಿ ಎಳೆಯಿರಿ',
    browsePhoto: 'ಚಿತ್ರ ಆಯ್ಕೆಮಾಡಿ',
    photoFormatLimit: 'JPEG, PNG, WebP ಗರಿಷ್ಠ 5 MB.',
    removePhoto: 'ಚಿತ್ರ ತೆಗೆಯಿರಿ',
    symptomsObserved: 'ಜಮೀನಿನಲ್ಲಿ ನೀವು ಏನು ಗಮನಿಸುತ್ತಿದ್ದೀರಿ?',
    selectSymptomsHint: 'ಎಲೆಯ ಮೇಲೆ ಕಾಣುವ ಲಕ್ಷಣಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ:',
    possibleCausesTitle: 'ಸಾಧ್ಯವಿರುವ ಕಾರಣಗಳು',
    confirmWithAgronomist: 'ಕೃಷಿ ತಜ್ಞರೊಂದಿಗೆ ದೃಢೀಕರಿಸಿ.',
    whatToInspectInField: 'ಜಮೀನಿನಲ್ಲಿ ತಪಾಸಣೆ ಮಾಡಬೇಕಾದದ್ದು:',
    privacyNoticeTitle: 'ರೈತರ ಗೌಪ್ಯತೆ ಮತ್ತು ರಕ್ಷಣೆ',
    privacyNoticeBody: 'ಚಿತ್ರಗಳ ವಿಶ್ಲೇಷಣೆ ನಿಮ್ಮ ಬ್ರೌಸರ್‌ನಲ್ಲೇ ನಡೆಯುತ್ತದೆ.',
    optionalAiVision: 'ಹೆಚ್ಚುವರಿ AI ಅಭಿಪ್ರಾಯ',
    aiVisionDisclaimer: 'ಇದು ಪ್ರಾಯೋಗಿಕ ಅಂದಾಜು ಮಾತ್ರ.',

    spraySuitabilityTitle: 'ಔಷಧ ಸಿಂಪಡಣೆ ಮತ್ತು ನೀರಾವರಿಗೆ ಸೂಕ್ತ ಸಮಯ',
    spraySuitabilityDesc: 'ತಾಪಮಾನ, ಗಾಳಿಯ ವೇಗ ಮತ್ತು ತೇವಾಂಶ ಆಧಾರಿತ ಮಾರ್ಗದರ್ಶನ.',
    hourlyForecastTitle: '24 ಗಂಟೆಗಳ ಹವಾಮಾನ ಮತ್ತು ಮಳೆ ಸಾಧ್ಯತೆ',
    hourlyForecastDesc: 'ಗಂಟೆವಾರು ತಾಪಮಾನ ಮತ್ತು ಮಣ್ಣಿನ ತೇವಾಂಶ.',
    soilMoistureDepthTitle: 'ಆಳದ ಪ್ರಕಾರ ಮಣ್ಣಿನ ತೇವಾಂಶ',
    surfaceSoil: 'ಮೇಲ್ಮಣ್ಣು (0–10 ಸೆಂ.ಮೀ)',
    rootZoneSoil: 'ಬೇರು ವಲಯ (10–30 ಸೆಂ.ಮೀ)',
    rainProbability: 'ಮಳೆ ಸಾಧ್ಯತೆ',
    windSpeed: 'ಗಾಳಿಯ ವೇಗ',

    fpoTitle: 'ಎಫ್‌ಪಿಒ ಪೂರೈಕೆ ಸರಪಳಿ ಮತ್ತು ಮುನ್ನೋಟ',
    fpoSubtitle: 'ಖರೀದಿ ಯೋಜನೆಗಾಗಿ ಪ್ರದೇಶದ ಮಾಹಿತಿ.',
    totalPlotsCovered: 'ಮೇಲ್ವಿಚಾರಣೆ ಜಮೀನುಗಳು',
    totalAreaCovered: 'ಒಟ್ಟು ಬೆಳೆ ವಿಸ್ತೀರ್ಣ',
    cropRiskBreakdown: 'ತಳಿವಾರು ವಿಶ್ಲೇಷಣೆ',
    procurementTimeline: 'ಕೊಯ್ಲು ಸಿದ್ಧತೆಯ ಸಮಯ',
    suggestedOperations: 'ಶಿಫಾರಸು ಮಾಡಿದ ಕಾರ್ಯಾಚರಣೆಗಳು',
    exportFpoCsv: 'ವರದಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ (CSV)',
    fpoCaveatTitle: 'ಯೋಜನಾ ಮಾರ್ಗದರ್ಶಿ ಮಾತ್ರ',
    fpoCaveatText: 'ನೇರ ಜಮೀನು ಭೇಟಿಗಳೊಂದಿಗೆ ಪರಿಶೀಲಿಸಿ.',

    reportsTitle: 'ವರದಿಗಳು ಮತ್ತು ಡೌನ್‌ಲೋಡ್',
    reportsSubtitle: 'ಮುದ್ರಿಸಬಹುದಾದ ಸಲಹೆಗಳು ಮತ್ತು CSV ಫೈಲ್‌ಗಳು.',
    filterByDateRange: 'ದಿನಾಂಕ ಶ್ರೇಣಿ',
    filterByPlot: 'ಜಮೀನು ಆಯ್ಕೆಮಾಡಿ',
    downloadCsv: 'CSV ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ',
    printReport: 'ಪ್ರಿಂಟ್ / PDF',
    advisoryHistoryTable: 'ಸಲಹಾ ಇತಿಹಾಸ',
    allPlots: 'ಎಲ್ಲಾ ಜಮೀನುಗಳು',

    settingsTitle: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು ಮತ್ತು ಆದ್ಯತೆಗಳು',
    settingsSubtitle: 'ಭಾಷೆ, ಅಳತೆಗಳು ಮತ್ತು ಧ್ವನಿ ಆದ್ಯತೆಗಳನ್ನು ಬದಲಾಯಿಸಿ.',
    prefLanguage: 'ಅಪ್ಲಿಕೇಶನ್ ಭಾಷೆ',
    prefUnits: 'ಅಳತೆ ಮಾಪನಗಳು',
    prefRegion: 'ಪ್ರದೇಶ / ಜಿಲ್ಲೆ',
    prefSpeech: 'ಧ್ವನಿ ಓದುವಿಕೆ',
    resetDemoData: 'ಮಾಹಿತಿ ಮರುಹೊಂದಿಸಿ',
    resetDemoConfirm: 'ಎಲ್ಲಾ ಮಾಹಿತಿಯನ್ನು ಮೊದಲಿನ ಸ್ಥಿತಿಗೆ ತರಬೇಕೆ?',
    resetSuccess: 'ಮಾಹಿತಿ ಯಶಸ್ವಿಯಾಗಿ ಮರುಹೊಂದಿಸಲಾಗಿದೆ.',
    aboutTitle: 'ಫಾರ್ಮ್‌ಪಲ್ಸ್ ಬಗ್ಗೆ',
    aboutBody: 'ರೈತರಿಗೆ ಪಾರದರ್ಶಕ ಮತ್ತು ವಿವರಣಾತ್ಮಕ ತಾಂತ್ರಿಕ ಸಲಹೆ ನೀಡುವ ವೇದಿಕೆ.',
    close: 'ಮುಚ್ಚಿ',
  },
};
